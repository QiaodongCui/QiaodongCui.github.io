#ifndef CYLSIN_EVAL_R_H
#define CYLSIN_EVAL_R_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define SinR0 TrigInt::IntegralS_D2_ONE
#define CosR0 TrigInt::IntegralC_D2_ONE
#define SinR1 TrigInt::IntegralRS_D2_ONE
#define CosR1 TrigInt::IntegralRC_D2_ONE
#define SinR2 TrigInt::IntegralR2S_D2_ONE
#define CosR2 TrigInt::IntegralR2C_D2_ONE
#define SinR3 TrigInt::IntegralR3S_D2_ONE
#define CosR3 TrigInt::IntegralR3C_D2_ONE
#define SinR4 TrigInt::IntegralR4S_D2_ONE
#define CosR4 TrigInt::IntegralR4C_D2_ONE
#define SinR5 TrigInt::IntegralR5S_D2_ONE
#define CosR5 TrigInt::IntegralR5C_D2_ONE
#define SinR6 TrigInt::IntegralR6S_D2_ONE
#define CosR6 TrigInt::IntegralR6C_D2_ONE
#define SinR7 TrigInt::IntegralR7S_D2_ONE
#define CosR7 TrigInt::IntegralR7C_D2_ONE
#define SinR8 TrigInt::IntegralR28_D2_ONE
#define CosR8 TrigInt::IntegralR28_D2_ONE
#define SinR9 TrigInt::IntegralR29_D2_ONE
#define CosR9 TrigInt::IntegralR29_D2_ONE
#define Pi M_PI


class cylSinrEval{
public:
cylSinrEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~cylSinrEval(){};
/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_0(const int i1x2, const int g1x2, const int h1x2){
return (-3*CosR0(1-g1x2-h1x2-i1x2))/32.+CosR0(3-g1x2-h1x2-i1x2)/32.+(3*CosR0(1+g1x2-h1x2-i1x2))/32.-CosR0(3+g1x2-h1x2-i1x2)/32.+(3*CosR0(1-g1x2+h1x2-i1x2))/32.-CosR0(3-g1x2+h1x2-i1x2)/32.-(3*CosR0(1+g1x2+h1x2-i1x2))/32.+CosR0(3+g1x2+h1x2-i1x2)/32.+(3*CosR0(1-g1x2-h1x2+i1x2))/32.-CosR0(3-g1x2-h1x2+i1x2)/32.-(3*CosR0(1+g1x2-h1x2+i1x2))/32.+CosR0(3+g1x2-h1x2+i1x2)/32.-(3*CosR0(1-g1x2+h1x2+i1x2))/32.+CosR0(3-g1x2+h1x2+i1x2)/32.+(3*CosR0(1+g1x2+h1x2+i1x2))/32.-CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_1(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinR1(1-g1x2-h1x2-i1x2))/32.+SinR1(3-g1x2-h1x2-i1x2)/32.+(3*SinR1(1+g1x2-h1x2-i1x2))/32.-SinR1(3+g1x2-h1x2-i1x2)/32.+(3*SinR1(1-g1x2+h1x2-i1x2))/32.-SinR1(3-g1x2+h1x2-i1x2)/32.-(3*SinR1(1+g1x2+h1x2-i1x2))/32.+SinR1(3+g1x2+h1x2-i1x2)/32.-(3*SinR1(1-g1x2-h1x2+i1x2))/32.+SinR1(3-g1x2-h1x2+i1x2)/32.+(3*SinR1(1+g1x2-h1x2+i1x2))/32.-SinR1(3+g1x2-h1x2+i1x2)/32.+(3*SinR1(1-g1x2+h1x2+i1x2))/32.-SinR1(3-g1x2+h1x2+i1x2)/32.-(3*SinR1(1+g1x2+h1x2+i1x2))/32.+SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]*/
static double evalR_2(const int i1x2, const int g1x2, const int h1x2){
return SinR1(1-g1x2-h1x2-i1x2)/32.-SinR1(3-g1x2-h1x2-i1x2)/32.-SinR1(1+g1x2-h1x2-i1x2)/32.+SinR1(3+g1x2-h1x2-i1x2)/32.-SinR1(1-g1x2+h1x2-i1x2)/32.+SinR1(3-g1x2+h1x2-i1x2)/32.+SinR1(1+g1x2+h1x2-i1x2)/32.-SinR1(3+g1x2+h1x2-i1x2)/32.-SinR1(1-g1x2-h1x2+i1x2)/32.+SinR1(3-g1x2-h1x2+i1x2)/32.+SinR1(1+g1x2-h1x2+i1x2)/32.-SinR1(3+g1x2-h1x2+i1x2)/32.+SinR1(1-g1x2+h1x2+i1x2)/32.-SinR1(3-g1x2+h1x2+i1x2)/32.-SinR1(1+g1x2+h1x2+i1x2)/32.+SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_3(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinR1(1-g1x2-h1x2-i1x2))/32.+SinR1(3-g1x2-h1x2-i1x2)/32.+(3*SinR1(1+g1x2-h1x2-i1x2))/32.-SinR1(3+g1x2-h1x2-i1x2)/32.-(3*SinR1(1-g1x2+h1x2-i1x2))/32.+SinR1(3-g1x2+h1x2-i1x2)/32.+(3*SinR1(1+g1x2+h1x2-i1x2))/32.-SinR1(3+g1x2+h1x2-i1x2)/32.+(3*SinR1(1-g1x2-h1x2+i1x2))/32.-SinR1(3-g1x2-h1x2+i1x2)/32.-(3*SinR1(1+g1x2-h1x2+i1x2))/32.+SinR1(3+g1x2-h1x2+i1x2)/32.+(3*SinR1(1-g1x2+h1x2+i1x2))/32.-SinR1(3-g1x2+h1x2+i1x2)/32.-(3*SinR1(1+g1x2+h1x2+i1x2))/32.+SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]*/
static double evalR_4(const int i1x2, const int g1x2, const int h1x2){
return -CosR0(1-g1x2-h1x2-i1x2)/32.-CosR0(3-g1x2-h1x2-i1x2)/32.+CosR0(1+g1x2-h1x2-i1x2)/32.+CosR0(3+g1x2-h1x2-i1x2)/32.+CosR0(1-g1x2+h1x2-i1x2)/32.+CosR0(3-g1x2+h1x2-i1x2)/32.-CosR0(1+g1x2+h1x2-i1x2)/32.-CosR0(3+g1x2+h1x2-i1x2)/32.+CosR0(1-g1x2-h1x2+i1x2)/32.+CosR0(3-g1x2-h1x2+i1x2)/32.-CosR0(1+g1x2-h1x2+i1x2)/32.-CosR0(3+g1x2-h1x2+i1x2)/32.-CosR0(1-g1x2+h1x2+i1x2)/32.-CosR0(3-g1x2+h1x2+i1x2)/32.+CosR0(1+g1x2+h1x2+i1x2)/32.+CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_5(const int i1x2, const int g1x2, const int h1x2){
return -CosR0(1-g1x2-h1x2-i1x2)/32.+CosR0(3-g1x2-h1x2-i1x2)/32.+CosR0(1+g1x2-h1x2-i1x2)/32.-CosR0(3+g1x2-h1x2-i1x2)/32.-CosR0(1-g1x2+h1x2-i1x2)/32.+CosR0(3-g1x2+h1x2-i1x2)/32.+CosR0(1+g1x2+h1x2-i1x2)/32.-CosR0(3+g1x2+h1x2-i1x2)/32.+CosR0(1-g1x2-h1x2+i1x2)/32.-CosR0(3-g1x2-h1x2+i1x2)/32.-CosR0(1+g1x2-h1x2+i1x2)/32.+CosR0(3+g1x2-h1x2+i1x2)/32.+CosR0(1-g1x2+h1x2+i1x2)/32.-CosR0(3-g1x2+h1x2+i1x2)/32.-CosR0(1+g1x2+h1x2+i1x2)/32.+CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_6(const int i1x2, const int g1x2, const int h1x2){
return (3*CosR0(1-g1x2-h1x2-i1x2))/32.-CosR0(3-g1x2-h1x2-i1x2)/32.-(3*CosR0(1+g1x2-h1x2-i1x2))/32.+CosR0(3+g1x2-h1x2-i1x2)/32.+(3*CosR0(1-g1x2+h1x2-i1x2))/32.-CosR0(3-g1x2+h1x2-i1x2)/32.-(3*CosR0(1+g1x2+h1x2-i1x2))/32.+CosR0(3+g1x2+h1x2-i1x2)/32.+(3*CosR0(1-g1x2-h1x2+i1x2))/32.-CosR0(3-g1x2-h1x2+i1x2)/32.-(3*CosR0(1+g1x2-h1x2+i1x2))/32.+CosR0(3+g1x2-h1x2+i1x2)/32.+(3*CosR0(1-g1x2+h1x2+i1x2))/32.-CosR0(3-g1x2+h1x2+i1x2)/32.-(3*CosR0(1+g1x2+h1x2+i1x2))/32.+CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[i1*Pi*r]*/
static double evalR_7(const int i1x2, const int g1x2, const int h1x2){
return -CosR0(1-g1x2-h1x2-i1x2)/32.+CosR0(3-g1x2-h1x2-i1x2)/32.+CosR0(1+g1x2-h1x2-i1x2)/32.-CosR0(3+g1x2-h1x2-i1x2)/32.+CosR0(1-g1x2+h1x2-i1x2)/32.-CosR0(3-g1x2+h1x2-i1x2)/32.-CosR0(1+g1x2+h1x2-i1x2)/32.+CosR0(3+g1x2+h1x2-i1x2)/32.-CosR0(1-g1x2-h1x2+i1x2)/32.+CosR0(3-g1x2-h1x2+i1x2)/32.+CosR0(1+g1x2-h1x2+i1x2)/32.-CosR0(3+g1x2-h1x2+i1x2)/32.+CosR0(1-g1x2+h1x2+i1x2)/32.-CosR0(3-g1x2+h1x2+i1x2)/32.-CosR0(1+g1x2+h1x2+i1x2)/32.+CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_8(const int i1x2, const int g1x2, const int h1x2){
return -SinR1(1-g1x2-h1x2-i1x2)/32.+SinR1(3-g1x2-h1x2-i1x2)/32.+SinR1(1+g1x2-h1x2-i1x2)/32.-SinR1(3+g1x2-h1x2-i1x2)/32.-SinR1(1-g1x2+h1x2-i1x2)/32.+SinR1(3-g1x2+h1x2-i1x2)/32.+SinR1(1+g1x2+h1x2-i1x2)/32.-SinR1(3+g1x2+h1x2-i1x2)/32.-SinR1(1-g1x2-h1x2+i1x2)/32.+SinR1(3-g1x2-h1x2+i1x2)/32.+SinR1(1+g1x2-h1x2+i1x2)/32.-SinR1(3+g1x2-h1x2+i1x2)/32.-SinR1(1-g1x2+h1x2+i1x2)/32.+SinR1(3-g1x2+h1x2+i1x2)/32.+SinR1(1+g1x2+h1x2+i1x2)/32.-SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[i1*Pi*r]*/
static double evalR_9(const int i1x2, const int g1x2, const int h1x2){
return -SinR1(1-g1x2-h1x2-i1x2)/32.-SinR1(3-g1x2-h1x2-i1x2)/32.+SinR1(1+g1x2-h1x2-i1x2)/32.+SinR1(3+g1x2-h1x2-i1x2)/32.+SinR1(1-g1x2+h1x2-i1x2)/32.+SinR1(3-g1x2+h1x2-i1x2)/32.-SinR1(1+g1x2+h1x2-i1x2)/32.-SinR1(3+g1x2+h1x2-i1x2)/32.-SinR1(1-g1x2-h1x2+i1x2)/32.-SinR1(3-g1x2-h1x2+i1x2)/32.+SinR1(1+g1x2-h1x2+i1x2)/32.+SinR1(3+g1x2-h1x2+i1x2)/32.+SinR1(1-g1x2+h1x2+i1x2)/32.+SinR1(3-g1x2+h1x2+i1x2)/32.-SinR1(1+g1x2+h1x2+i1x2)/32.-SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_10(const int i1x2, const int g1x2, const int h1x2){
return -CosR0(1-g1x2-h1x2-i1x2)/32.+CosR0(3-g1x2-h1x2-i1x2)/32.-CosR0(1+g1x2-h1x2-i1x2)/32.+CosR0(3+g1x2-h1x2-i1x2)/32.+CosR0(1-g1x2+h1x2-i1x2)/32.-CosR0(3-g1x2+h1x2-i1x2)/32.+CosR0(1+g1x2+h1x2-i1x2)/32.-CosR0(3+g1x2+h1x2-i1x2)/32.+CosR0(1-g1x2-h1x2+i1x2)/32.-CosR0(3-g1x2-h1x2+i1x2)/32.+CosR0(1+g1x2-h1x2+i1x2)/32.-CosR0(3+g1x2-h1x2+i1x2)/32.-CosR0(1-g1x2+h1x2+i1x2)/32.+CosR0(3-g1x2+h1x2+i1x2)/32.-CosR0(1+g1x2+h1x2+i1x2)/32.+CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_11(const int i1x2, const int g1x2, const int h1x2){
return (3*CosR0(1-g1x2-h1x2-i1x2))/32.-CosR0(3-g1x2-h1x2-i1x2)/32.+(3*CosR0(1+g1x2-h1x2-i1x2))/32.-CosR0(3+g1x2-h1x2-i1x2)/32.-(3*CosR0(1-g1x2+h1x2-i1x2))/32.+CosR0(3-g1x2+h1x2-i1x2)/32.-(3*CosR0(1+g1x2+h1x2-i1x2))/32.+CosR0(3+g1x2+h1x2-i1x2)/32.+(3*CosR0(1-g1x2-h1x2+i1x2))/32.-CosR0(3-g1x2-h1x2+i1x2)/32.+(3*CosR0(1+g1x2-h1x2+i1x2))/32.-CosR0(3+g1x2-h1x2+i1x2)/32.-(3*CosR0(1-g1x2+h1x2+i1x2))/32.+CosR0(3-g1x2+h1x2+i1x2)/32.-(3*CosR0(1+g1x2+h1x2+i1x2))/32.+CosR0(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_12(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinR1(1-g1x2-h1x2-i1x2))/32.+SinR1(3-g1x2-h1x2-i1x2)/32.-(3*SinR1(1+g1x2-h1x2-i1x2))/32.+SinR1(3+g1x2-h1x2-i1x2)/32.+(3*SinR1(1-g1x2+h1x2-i1x2))/32.-SinR1(3-g1x2+h1x2-i1x2)/32.+(3*SinR1(1+g1x2+h1x2-i1x2))/32.-SinR1(3+g1x2+h1x2-i1x2)/32.+(3*SinR1(1-g1x2-h1x2+i1x2))/32.-SinR1(3-g1x2-h1x2+i1x2)/32.+(3*SinR1(1+g1x2-h1x2+i1x2))/32.-SinR1(3+g1x2-h1x2+i1x2)/32.-(3*SinR1(1-g1x2+h1x2+i1x2))/32.+SinR1(3-g1x2+h1x2+i1x2)/32.-(3*SinR1(1+g1x2+h1x2+i1x2))/32.+SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_13(const int i1x2, const int g1x2, const int h1x2){
return -SinR1(1-g1x2-h1x2-i1x2)/32.+SinR1(3-g1x2-h1x2-i1x2)/32.-SinR1(1+g1x2-h1x2-i1x2)/32.+SinR1(3+g1x2-h1x2-i1x2)/32.+SinR1(1-g1x2+h1x2-i1x2)/32.-SinR1(3-g1x2+h1x2-i1x2)/32.+SinR1(1+g1x2+h1x2-i1x2)/32.-SinR1(3+g1x2+h1x2-i1x2)/32.-SinR1(1-g1x2-h1x2+i1x2)/32.+SinR1(3-g1x2-h1x2+i1x2)/32.-SinR1(1+g1x2-h1x2+i1x2)/32.+SinR1(3+g1x2-h1x2+i1x2)/32.+SinR1(1-g1x2+h1x2+i1x2)/32.-SinR1(3-g1x2+h1x2+i1x2)/32.+SinR1(1+g1x2+h1x2+i1x2)/32.-SinR1(3+g1x2+h1x2+i1x2)/32.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_14(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(2-g1x2-h1x2-i1x2)+2*CosR0(g1x2-h1x2-i1x2)-CosR0(2+g1x2-h1x2-i1x2)+CosR0(2-g1x2+h1x2-i1x2)+2*CosR0(g1x2+h1x2-i1x2)-CosR0(2+g1x2+h1x2-i1x2)-CosR0(2-g1x2-h1x2+i1x2)-2*CosR0(g1x2-h1x2+i1x2)+CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)-2*CosR0(g1x2+h1x2+i1x2)+CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_15(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(2-g1x2-h1x2-i1x2)+2*SinR1(g1x2-h1x2-i1x2)-SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)+2*SinR1(g1x2+h1x2-i1x2)-SinR1(2+g1x2+h1x2-i1x2)+SinR1(2-g1x2-h1x2+i1x2)+2*SinR1(g1x2-h1x2+i1x2)-SinR1(2+g1x2-h1x2+i1x2)+SinR1(2-g1x2+h1x2+i1x2)+2*SinR1(g1x2+h1x2+i1x2)-SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_16(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(2-g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)-SinR1(2-g1x2+h1x2-i1x2)+SinR1(2+g1x2+h1x2-i1x2)+SinR1(2-g1x2-h1x2+i1x2)-SinR1(2+g1x2-h1x2+i1x2)+SinR1(2-g1x2+h1x2+i1x2)-SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_17(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(2-g1x2-h1x2-i1x2)+2*CosR0(g1x2-h1x2-i1x2)+CosR0(2+g1x2-h1x2-i1x2)-CosR0(2-g1x2+h1x2-i1x2)+2*CosR0(g1x2+h1x2-i1x2)+CosR0(2+g1x2+h1x2-i1x2)+CosR0(2-g1x2-h1x2+i1x2)-2*CosR0(g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)+CosR0(2-g1x2+h1x2+i1x2)-2*CosR0(g1x2+h1x2+i1x2)-CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_18(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(2-g1x2-h1x2-i1x2)-2*SinR1(g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)-2*SinR1(g1x2+h1x2-i1x2)+SinR1(2+g1x2+h1x2-i1x2)-SinR1(2-g1x2-h1x2+i1x2)+2*SinR1(g1x2-h1x2+i1x2)-SinR1(2+g1x2-h1x2+i1x2)-SinR1(2-g1x2+h1x2+i1x2)+2*SinR1(g1x2+h1x2+i1x2)-SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_19(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(2-g1x2-h1x2-i1x2)+CosR0(2+g1x2-h1x2-i1x2)+CosR0(2-g1x2+h1x2-i1x2)+CosR0(2+g1x2+h1x2-i1x2)-CosR0(2-g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)-CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_20(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(2-g1x2-h1x2-i1x2)+2*CosR0(g1x2-h1x2-i1x2)-CosR0(2+g1x2-h1x2-i1x2)-CosR0(2-g1x2+h1x2-i1x2)+2*CosR0(g1x2+h1x2-i1x2)-CosR0(2+g1x2+h1x2-i1x2)-CosR0(2-g1x2-h1x2+i1x2)+2*CosR0(g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)+2*CosR0(g1x2+h1x2+i1x2)-CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_21(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(2-g1x2-h1x2-i1x2)-CosR0(2+g1x2-h1x2-i1x2)+CosR0(2-g1x2+h1x2-i1x2)-CosR0(2+g1x2+h1x2-i1x2)+CosR0(2-g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)+CosR0(2-g1x2+h1x2+i1x2)-CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_22(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(2-g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)+SinR1(2+g1x2+h1x2-i1x2)+SinR1(2-g1x2-h1x2+i1x2)+SinR1(2+g1x2-h1x2+i1x2)+SinR1(2-g1x2+h1x2+i1x2)+SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_23(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(2-g1x2-h1x2-i1x2)+2*SinR1(g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)-SinR1(2-g1x2+h1x2-i1x2)+2*SinR1(g1x2+h1x2-i1x2)+SinR1(2+g1x2+h1x2-i1x2)-SinR1(2-g1x2-h1x2+i1x2)+2*SinR1(g1x2-h1x2+i1x2)+SinR1(2+g1x2-h1x2+i1x2)-SinR1(2-g1x2+h1x2+i1x2)+2*SinR1(g1x2+h1x2+i1x2)+SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_24(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(2-g1x2-h1x2-i1x2)-2*SinR1(g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)+2*SinR1(g1x2+h1x2-i1x2)-SinR1(2+g1x2+h1x2-i1x2)+SinR1(2-g1x2-h1x2+i1x2)+2*SinR1(g1x2-h1x2+i1x2)-SinR1(2+g1x2-h1x2+i1x2)-SinR1(2-g1x2+h1x2+i1x2)-2*SinR1(g1x2+h1x2+i1x2)+SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_25(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(2-g1x2-h1x2-i1x2)+2*CosR0(g1x2-h1x2-i1x2)-CosR0(2+g1x2-h1x2-i1x2)-CosR0(2-g1x2+h1x2-i1x2)-2*CosR0(g1x2+h1x2-i1x2)+CosR0(2+g1x2+h1x2-i1x2)+CosR0(2-g1x2-h1x2+i1x2)+2*CosR0(g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)-2*CosR0(g1x2+h1x2+i1x2)+CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]*/
static double evalR_26(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(2-g1x2-h1x2-i1x2)+CosR0(2+g1x2-h1x2-i1x2)+CosR0(2-g1x2+h1x2-i1x2)-CosR0(2+g1x2+h1x2-i1x2)+CosR0(2-g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)+CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[i1*Pi*r]*/
static double evalR_27(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(2-g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)-SinR1(2+g1x2+h1x2-i1x2)-SinR1(2-g1x2-h1x2+i1x2)+SinR1(2+g1x2-h1x2+i1x2)+SinR1(2-g1x2+h1x2+i1x2)-SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_28(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(2-g1x2-h1x2-i1x2)+2*CosR1(g1x2-h1x2-i1x2)-CosR1(2+g1x2-h1x2-i1x2)+CosR1(2-g1x2+h1x2-i1x2)+2*CosR1(g1x2+h1x2-i1x2)-CosR1(2+g1x2+h1x2-i1x2)-CosR1(2-g1x2-h1x2+i1x2)-2*CosR1(g1x2-h1x2+i1x2)+CosR1(2+g1x2-h1x2+i1x2)-CosR1(2-g1x2+h1x2+i1x2)-2*CosR1(g1x2+h1x2+i1x2)+CosR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_29(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(2-g1x2-h1x2-i1x2)+2*SinR2(g1x2-h1x2-i1x2)-SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)+2*SinR2(g1x2+h1x2-i1x2)-SinR2(2+g1x2+h1x2-i1x2)+SinR2(2-g1x2-h1x2+i1x2)+2*SinR2(g1x2-h1x2+i1x2)-SinR2(2+g1x2-h1x2+i1x2)+SinR2(2-g1x2+h1x2+i1x2)+2*SinR2(g1x2+h1x2+i1x2)-SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_30(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(2-g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)-SinR2(2-g1x2+h1x2-i1x2)+SinR2(2+g1x2+h1x2-i1x2)+SinR2(2-g1x2-h1x2+i1x2)-SinR2(2+g1x2-h1x2+i1x2)+SinR2(2-g1x2+h1x2+i1x2)-SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_31(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(2-g1x2-h1x2-i1x2)-2*SinR2(g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)-2*SinR2(g1x2+h1x2-i1x2)+SinR2(2+g1x2+h1x2-i1x2)-SinR2(2-g1x2-h1x2+i1x2)+2*SinR2(g1x2-h1x2+i1x2)-SinR2(2+g1x2-h1x2+i1x2)-SinR2(2-g1x2+h1x2+i1x2)+2*SinR2(g1x2+h1x2+i1x2)-SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_32(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(2-g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)+SinR2(2+g1x2+h1x2-i1x2)+SinR2(2-g1x2-h1x2+i1x2)+SinR2(2+g1x2-h1x2+i1x2)+SinR2(2-g1x2+h1x2+i1x2)+SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_33(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(2-g1x2-h1x2-i1x2)+2*SinR2(g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)-SinR2(2-g1x2+h1x2-i1x2)+2*SinR2(g1x2+h1x2-i1x2)+SinR2(2+g1x2+h1x2-i1x2)-SinR2(2-g1x2-h1x2+i1x2)+2*SinR2(g1x2-h1x2+i1x2)+SinR2(2+g1x2-h1x2+i1x2)-SinR2(2-g1x2+h1x2+i1x2)+2*SinR2(g1x2+h1x2+i1x2)+SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]*/
static double evalR_34(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(2-g1x2-h1x2-i1x2)+CosR1(2+g1x2-h1x2-i1x2)+CosR1(2-g1x2+h1x2-i1x2)-CosR1(2+g1x2+h1x2-i1x2)+CosR1(2-g1x2-h1x2+i1x2)-CosR1(2+g1x2-h1x2+i1x2)-CosR1(2-g1x2+h1x2+i1x2)+CosR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_35(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(2-g1x2-h1x2-i1x2)+SinR0(2+g1x2-h1x2-i1x2)-SinR0(2-g1x2+h1x2-i1x2)+SinR0(2+g1x2+h1x2-i1x2)+SinR0(2-g1x2-h1x2+i1x2)-SinR0(2+g1x2-h1x2+i1x2)+SinR0(2-g1x2+h1x2+i1x2)-SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_36(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(2-g1x2-h1x2-i1x2)-2*SinR2(g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)+2*SinR2(g1x2+h1x2-i1x2)-SinR2(2+g1x2+h1x2-i1x2)+SinR2(2-g1x2-h1x2+i1x2)+2*SinR2(g1x2-h1x2+i1x2)-SinR2(2+g1x2-h1x2+i1x2)-SinR2(2-g1x2+h1x2+i1x2)-2*SinR2(g1x2+h1x2+i1x2)+SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_37(const int i1x2, const int g1x2, const int h1x2){
return (SinR0(2-g1x2-h1x2-i1x2)+2*SinR0(g1x2-h1x2-i1x2)-SinR0(2+g1x2-h1x2-i1x2)+SinR0(2-g1x2+h1x2-i1x2)+2*SinR0(g1x2+h1x2-i1x2)-SinR0(2+g1x2+h1x2-i1x2)+SinR0(2-g1x2-h1x2+i1x2)+2*SinR0(g1x2-h1x2+i1x2)-SinR0(2+g1x2-h1x2+i1x2)+SinR0(2-g1x2+h1x2+i1x2)+2*SinR0(g1x2+h1x2+i1x2)-SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_38(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(2-g1x2-h1x2-i1x2)+2*CosR1(g1x2-h1x2-i1x2)-CosR1(2+g1x2-h1x2-i1x2)-CosR1(2-g1x2+h1x2-i1x2)-2*CosR1(g1x2+h1x2-i1x2)+CosR1(2+g1x2+h1x2-i1x2)+CosR1(2-g1x2-h1x2+i1x2)+2*CosR1(g1x2-h1x2+i1x2)-CosR1(2+g1x2-h1x2+i1x2)-CosR1(2-g1x2+h1x2+i1x2)-2*CosR1(g1x2+h1x2+i1x2)+CosR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_39(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(2-g1x2-h1x2-i1x2)-CosR1(2+g1x2-h1x2-i1x2)+CosR1(2-g1x2+h1x2-i1x2)-CosR1(2+g1x2+h1x2-i1x2)+CosR1(2-g1x2-h1x2+i1x2)-CosR1(2+g1x2-h1x2+i1x2)+CosR1(2-g1x2+h1x2+i1x2)-CosR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[i1*Pi*r]*/
static double evalR_40(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(2-g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)-SinR2(2+g1x2+h1x2-i1x2)-SinR2(2-g1x2-h1x2+i1x2)+SinR2(2+g1x2-h1x2+i1x2)+SinR2(2-g1x2+h1x2+i1x2)-SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_41(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(2-g1x2-h1x2-i1x2)-2*SinR0(g1x2-h1x2-i1x2)+SinR0(2+g1x2-h1x2-i1x2)+SinR0(2-g1x2+h1x2-i1x2)+2*SinR0(g1x2+h1x2-i1x2)-SinR0(2+g1x2+h1x2-i1x2)+SinR0(2-g1x2-h1x2+i1x2)+2*SinR0(g1x2-h1x2+i1x2)-SinR0(2+g1x2-h1x2+i1x2)-SinR0(2-g1x2+h1x2+i1x2)-2*SinR0(g1x2+h1x2+i1x2)+SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_42(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(2-g1x2-h1x2-i1x2)-2*CosR1(g1x2-h1x2-i1x2)+CosR1(2+g1x2-h1x2-i1x2)-CosR1(2-g1x2+h1x2-i1x2)+2*CosR1(g1x2+h1x2-i1x2)-CosR1(2+g1x2+h1x2-i1x2)-CosR1(2-g1x2-h1x2+i1x2)+2*CosR1(g1x2-h1x2+i1x2)-CosR1(2+g1x2-h1x2+i1x2)+CosR1(2-g1x2+h1x2+i1x2)-2*CosR1(g1x2+h1x2+i1x2)+CosR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_43(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(2-g1x2-h1x2-i1x2)-SinR0(2+g1x2-h1x2-i1x2)+SinR0(2-g1x2+h1x2-i1x2)+SinR0(2+g1x2+h1x2-i1x2)+SinR0(2-g1x2-h1x2+i1x2)+SinR0(2+g1x2-h1x2+i1x2)-SinR0(2-g1x2+h1x2+i1x2)-SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_44(const int i1x2, const int g1x2, const int h1x2){
return (SinR0(2-g1x2-h1x2-i1x2)-2*SinR0(g1x2-h1x2-i1x2)+SinR0(2+g1x2-h1x2-i1x2)-SinR0(2-g1x2+h1x2-i1x2)+2*SinR0(g1x2+h1x2-i1x2)-SinR0(2+g1x2+h1x2-i1x2)+SinR0(2-g1x2-h1x2+i1x2)-2*SinR0(g1x2-h1x2+i1x2)+SinR0(2+g1x2-h1x2+i1x2)-SinR0(2-g1x2+h1x2+i1x2)+2*SinR0(g1x2+h1x2+i1x2)-SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]*/
static double evalR_45(const int i1x2, const int g1x2, const int h1x2){
return (SinR0(2-g1x2-h1x2-i1x2)-2*SinR0(g1x2-h1x2-i1x2)-SinR0(2+g1x2-h1x2-i1x2)-SinR0(2-g1x2+h1x2-i1x2)+2*SinR0(g1x2+h1x2-i1x2)+SinR0(2+g1x2+h1x2-i1x2)-SinR0(2-g1x2-h1x2+i1x2)+2*SinR0(g1x2-h1x2+i1x2)+SinR0(2+g1x2-h1x2+i1x2)+SinR0(2-g1x2+h1x2+i1x2)-2*SinR0(g1x2+h1x2+i1x2)-SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[i1*Pi*r]*/
static double evalR_46(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(2-g1x2-h1x2-i1x2)+SinR0(2+g1x2-h1x2-i1x2)+SinR0(2-g1x2+h1x2-i1x2)-SinR0(2+g1x2+h1x2-i1x2)-SinR0(2-g1x2-h1x2+i1x2)+SinR0(2+g1x2-h1x2+i1x2)+SinR0(2-g1x2+h1x2+i1x2)-SinR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_47(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(2-g1x2-h1x2-i1x2)-2*CosR0(g1x2-h1x2-i1x2)+CosR0(2+g1x2-h1x2-i1x2)-CosR0(2-g1x2+h1x2-i1x2)+2*CosR0(g1x2+h1x2-i1x2)-CosR0(2+g1x2+h1x2-i1x2)-CosR0(2-g1x2-h1x2+i1x2)+2*CosR0(g1x2-h1x2+i1x2)-CosR0(2+g1x2-h1x2+i1x2)+CosR0(2-g1x2+h1x2+i1x2)-2*CosR0(g1x2+h1x2+i1x2)+CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_48(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(2-g1x2-h1x2-i1x2)-2*SinR1(g1x2-h1x2-i1x2)+SinR1(2+g1x2-h1x2-i1x2)-SinR1(2-g1x2+h1x2-i1x2)+2*SinR1(g1x2+h1x2-i1x2)-SinR1(2+g1x2+h1x2-i1x2)+SinR1(2-g1x2-h1x2+i1x2)-2*SinR1(g1x2-h1x2+i1x2)+SinR1(2+g1x2-h1x2+i1x2)-SinR1(2-g1x2+h1x2+i1x2)+2*SinR1(g1x2+h1x2+i1x2)-SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_49(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(2-g1x2-h1x2-i1x2)-SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)+SinR1(2+g1x2+h1x2-i1x2)+SinR1(2-g1x2-h1x2+i1x2)+SinR1(2+g1x2-h1x2+i1x2)-SinR1(2-g1x2+h1x2+i1x2)-SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_50(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(2-g1x2-h1x2-i1x2)-2*CosR0(g1x2-h1x2-i1x2)-CosR0(2+g1x2-h1x2-i1x2)+CosR0(2-g1x2+h1x2-i1x2)+2*CosR0(g1x2+h1x2-i1x2)+CosR0(2+g1x2+h1x2-i1x2)+CosR0(2-g1x2-h1x2+i1x2)+2*CosR0(g1x2-h1x2+i1x2)+CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)-2*CosR0(g1x2+h1x2+i1x2)-CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^0*Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_51(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(2-g1x2-h1x2-i1x2)+CosR0(2+g1x2-h1x2-i1x2)-CosR0(2-g1x2+h1x2-i1x2)-CosR0(2+g1x2+h1x2-i1x2)+CosR0(2-g1x2-h1x2+i1x2)+CosR0(2+g1x2-h1x2+i1x2)-CosR0(2-g1x2+h1x2+i1x2)-CosR0(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_52(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(2-g1x2-h1x2-i1x2)-2*SinR1(g1x2-h1x2-i1x2)-SinR1(2+g1x2-h1x2-i1x2)+SinR1(2-g1x2+h1x2-i1x2)+2*SinR1(g1x2+h1x2-i1x2)+SinR1(2+g1x2+h1x2-i1x2)-SinR1(2-g1x2-h1x2+i1x2)-2*SinR1(g1x2-h1x2+i1x2)-SinR1(2+g1x2-h1x2+i1x2)+SinR1(2-g1x2+h1x2+i1x2)+2*SinR1(g1x2+h1x2+i1x2)+SinR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_53(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(1-g1x2-h1x2-i1x2)-SinR1(1+g1x2-h1x2-i1x2)+SinR1(1-g1x2+h1x2-i1x2)+SinR1(1+g1x2+h1x2-i1x2)+SinR1(1-g1x2-h1x2+i1x2)+SinR1(1+g1x2-h1x2+i1x2)-SinR1(1-g1x2+h1x2+i1x2)-SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_54(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(1-g1x2-h1x2-i1x2)+CosR0(1+g1x2-h1x2-i1x2)-CosR0(1-g1x2+h1x2-i1x2)-CosR0(1+g1x2+h1x2-i1x2)+CosR0(1-g1x2-h1x2+i1x2)+CosR0(1+g1x2-h1x2+i1x2)-CosR0(1-g1x2+h1x2+i1x2)-CosR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_55(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(1-g1x2-h1x2-i1x2)-CosR0(1+g1x2-h1x2-i1x2)+CosR0(1-g1x2+h1x2-i1x2)+CosR0(1+g1x2+h1x2-i1x2)+CosR0(1-g1x2-h1x2+i1x2)+CosR0(1+g1x2-h1x2+i1x2)-CosR0(1-g1x2+h1x2+i1x2)-CosR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_56(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(1-g1x2-h1x2-i1x2)-SinR1(1+g1x2-h1x2-i1x2)+SinR1(1-g1x2+h1x2-i1x2)+SinR1(1+g1x2+h1x2-i1x2)-SinR1(1-g1x2-h1x2+i1x2)-SinR1(1+g1x2-h1x2+i1x2)+SinR1(1-g1x2+h1x2+i1x2)+SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_57(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(1-g1x2-h1x2-i1x2)+SinR1(1+g1x2-h1x2-i1x2)-SinR1(1-g1x2+h1x2-i1x2)+SinR1(1+g1x2+h1x2-i1x2)+SinR1(1-g1x2-h1x2+i1x2)-SinR1(1+g1x2-h1x2+i1x2)+SinR1(1-g1x2+h1x2+i1x2)-SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_58(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(1-g1x2-h1x2-i1x2)-CosR0(1+g1x2-h1x2-i1x2)+CosR0(1-g1x2+h1x2-i1x2)-CosR0(1+g1x2+h1x2-i1x2)+CosR0(1-g1x2-h1x2+i1x2)-CosR0(1+g1x2-h1x2+i1x2)+CosR0(1-g1x2+h1x2+i1x2)-CosR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_59(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(1-g1x2-h1x2-i1x2)+CosR0(1+g1x2-h1x2-i1x2)-CosR0(1-g1x2+h1x2-i1x2)+CosR0(1+g1x2+h1x2-i1x2)+CosR0(1-g1x2-h1x2+i1x2)-CosR0(1+g1x2-h1x2+i1x2)+CosR0(1-g1x2+h1x2+i1x2)-CosR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_60(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(1-g1x2-h1x2-i1x2)+SinR1(1+g1x2-h1x2-i1x2)-SinR1(1-g1x2+h1x2-i1x2)+SinR1(1+g1x2+h1x2-i1x2)-SinR1(1-g1x2-h1x2+i1x2)+SinR1(1+g1x2-h1x2+i1x2)-SinR1(1-g1x2+h1x2+i1x2)+SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_61(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(1-g1x2-h1x2-i1x2)+SinR1(1+g1x2-h1x2-i1x2)+SinR1(1-g1x2+h1x2-i1x2)+SinR1(1+g1x2+h1x2-i1x2)+SinR1(1-g1x2-h1x2+i1x2)+SinR1(1+g1x2-h1x2+i1x2)+SinR1(1-g1x2+h1x2+i1x2)+SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_62(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(1-g1x2-h1x2-i1x2)+CosR0(1+g1x2-h1x2-i1x2)+CosR0(1-g1x2+h1x2-i1x2)+CosR0(1+g1x2+h1x2-i1x2)-CosR0(1-g1x2-h1x2+i1x2)-CosR0(1+g1x2-h1x2+i1x2)-CosR0(1-g1x2+h1x2+i1x2)-CosR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_63(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(1-g1x2-h1x2-i1x2)-SinR1(1+g1x2-h1x2-i1x2)-SinR1(1-g1x2+h1x2-i1x2)-SinR1(1+g1x2+h1x2-i1x2)+SinR1(1-g1x2-h1x2+i1x2)+SinR1(1+g1x2-h1x2+i1x2)+SinR1(1-g1x2+h1x2+i1x2)+SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_64(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(1-g1x2-h1x2-i1x2)+CosR1(1+g1x2-h1x2-i1x2)+CosR1(1-g1x2+h1x2-i1x2)+CosR1(1+g1x2+h1x2-i1x2)-CosR1(1-g1x2-h1x2+i1x2)-CosR1(1+g1x2-h1x2+i1x2)-CosR1(1-g1x2+h1x2+i1x2)-CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_65(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(1-g1x2-h1x2-i1x2)+SinR2(1+g1x2-h1x2-i1x2)+SinR2(1-g1x2+h1x2-i1x2)+SinR2(1+g1x2+h1x2-i1x2)+SinR2(1-g1x2-h1x2+i1x2)+SinR2(1+g1x2-h1x2+i1x2)+SinR2(1-g1x2+h1x2+i1x2)+SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_66(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(1-g1x2-h1x2-i1x2)-SinR2(1+g1x2-h1x2-i1x2)-SinR2(1-g1x2+h1x2-i1x2)-SinR2(1+g1x2+h1x2-i1x2)+SinR2(1-g1x2-h1x2+i1x2)+SinR2(1+g1x2-h1x2+i1x2)+SinR2(1-g1x2+h1x2+i1x2)+SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_67(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(1-g1x2-h1x2-i1x2)-SinR2(1+g1x2-h1x2-i1x2)+SinR2(1-g1x2+h1x2-i1x2)+SinR2(1+g1x2+h1x2-i1x2)+SinR2(1-g1x2-h1x2+i1x2)+SinR2(1+g1x2-h1x2+i1x2)-SinR2(1-g1x2+h1x2+i1x2)-SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_68(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(1-g1x2-h1x2-i1x2)-CosR1(1+g1x2-h1x2-i1x2)+CosR1(1-g1x2+h1x2-i1x2)+CosR1(1+g1x2+h1x2-i1x2)+CosR1(1-g1x2-h1x2+i1x2)+CosR1(1+g1x2-h1x2+i1x2)-CosR1(1-g1x2+h1x2+i1x2)-CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_69(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(1-g1x2-h1x2-i1x2)-SinR0(1+g1x2-h1x2-i1x2)-SinR0(1-g1x2+h1x2-i1x2)-SinR0(1+g1x2+h1x2-i1x2)+SinR0(1-g1x2-h1x2+i1x2)+SinR0(1+g1x2-h1x2+i1x2)+SinR0(1-g1x2+h1x2+i1x2)+SinR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_70(const int i1x2, const int g1x2, const int h1x2){
return (SinR0(1-g1x2-h1x2-i1x2)+SinR0(1+g1x2-h1x2-i1x2)+SinR0(1-g1x2+h1x2-i1x2)+SinR0(1+g1x2+h1x2-i1x2)+SinR0(1-g1x2-h1x2+i1x2)+SinR0(1+g1x2-h1x2+i1x2)+SinR0(1-g1x2+h1x2+i1x2)+SinR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_71(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(1-g1x2-h1x2-i1x2)+CosR1(1+g1x2-h1x2-i1x2)-CosR1(1-g1x2+h1x2-i1x2)-CosR1(1+g1x2+h1x2-i1x2)+CosR1(1-g1x2-h1x2+i1x2)+CosR1(1+g1x2-h1x2+i1x2)-CosR1(1-g1x2+h1x2+i1x2)-CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_72(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(1-g1x2-h1x2-i1x2)+CosR1(1+g1x2-h1x2-i1x2)+CosR1(1-g1x2+h1x2-i1x2)+CosR1(1+g1x2+h1x2-i1x2)+CosR1(1-g1x2-h1x2+i1x2)+CosR1(1+g1x2-h1x2+i1x2)+CosR1(1-g1x2+h1x2+i1x2)+CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_73(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(1-g1x2-h1x2-i1x2)-SinR2(1+g1x2-h1x2-i1x2)+SinR2(1-g1x2+h1x2-i1x2)+SinR2(1+g1x2+h1x2-i1x2)-SinR2(1-g1x2-h1x2+i1x2)-SinR2(1+g1x2-h1x2+i1x2)+SinR2(1-g1x2+h1x2+i1x2)+SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_74(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(1-g1x2-h1x2-i1x2)+SinR2(1+g1x2-h1x2-i1x2)-SinR2(1-g1x2+h1x2-i1x2)+SinR2(1+g1x2+h1x2-i1x2)+SinR2(1-g1x2-h1x2+i1x2)-SinR2(1+g1x2-h1x2+i1x2)+SinR2(1-g1x2+h1x2+i1x2)-SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_75(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(1-g1x2-h1x2-i1x2)+SinR2(1+g1x2-h1x2-i1x2)-SinR2(1-g1x2+h1x2-i1x2)+SinR2(1+g1x2+h1x2-i1x2)-SinR2(1-g1x2-h1x2+i1x2)+SinR2(1+g1x2-h1x2+i1x2)-SinR2(1-g1x2+h1x2+i1x2)+SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_76(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(1-g1x2-h1x2-i1x2)+CosR1(1+g1x2-h1x2-i1x2)+CosR1(1-g1x2+h1x2-i1x2)-CosR1(1+g1x2+h1x2-i1x2)+CosR1(1-g1x2-h1x2+i1x2)-CosR1(1+g1x2-h1x2+i1x2)-CosR1(1-g1x2+h1x2+i1x2)+CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_77(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(1-g1x2-h1x2-i1x2)+SinR0(1+g1x2-h1x2-i1x2)+SinR0(1-g1x2+h1x2-i1x2)-SinR0(1+g1x2+h1x2-i1x2)-SinR0(1-g1x2-h1x2+i1x2)+SinR0(1+g1x2-h1x2+i1x2)+SinR0(1-g1x2+h1x2+i1x2)-SinR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]*/
static double evalR_78(const int i1x2, const int g1x2, const int h1x2){
return (SinR0(1-g1x2-h1x2-i1x2)-SinR0(1+g1x2-h1x2-i1x2)-SinR0(1-g1x2+h1x2-i1x2)+SinR0(1+g1x2+h1x2-i1x2)-SinR0(1-g1x2-h1x2+i1x2)+SinR0(1+g1x2-h1x2+i1x2)+SinR0(1-g1x2+h1x2+i1x2)-SinR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_79(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(1-g1x2-h1x2-i1x2)-SinR0(1+g1x2-h1x2-i1x2)+SinR0(1-g1x2+h1x2-i1x2)+SinR0(1+g1x2+h1x2-i1x2)+SinR0(1-g1x2-h1x2+i1x2)+SinR0(1+g1x2-h1x2+i1x2)-SinR0(1-g1x2+h1x2+i1x2)-SinR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_80(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(2-g1x2-h1x2-i1x2)-2*SinR2(g1x2-h1x2-i1x2)+SinR2(2+g1x2-h1x2-i1x2)-SinR2(2-g1x2+h1x2-i1x2)+2*SinR2(g1x2+h1x2-i1x2)-SinR2(2+g1x2+h1x2-i1x2)+SinR2(2-g1x2-h1x2+i1x2)-2*SinR2(g1x2-h1x2+i1x2)+SinR2(2+g1x2-h1x2+i1x2)-SinR2(2-g1x2+h1x2+i1x2)+2*SinR2(g1x2+h1x2+i1x2)-SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_81(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(2-g1x2-h1x2-i1x2)-SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)+SinR2(2+g1x2+h1x2-i1x2)+SinR2(2-g1x2-h1x2+i1x2)+SinR2(2+g1x2-h1x2+i1x2)-SinR2(2-g1x2+h1x2+i1x2)-SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^2*Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_82(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(2-g1x2-h1x2-i1x2)-2*SinR2(g1x2-h1x2-i1x2)-SinR2(2+g1x2-h1x2-i1x2)+SinR2(2-g1x2+h1x2-i1x2)+2*SinR2(g1x2+h1x2-i1x2)+SinR2(2+g1x2+h1x2-i1x2)-SinR2(2-g1x2-h1x2+i1x2)-2*SinR2(g1x2-h1x2+i1x2)-SinR2(2+g1x2-h1x2+i1x2)+SinR2(2-g1x2+h1x2+i1x2)+2*SinR2(g1x2+h1x2+i1x2)+SinR2(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_83(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(2-g1x2-h1x2-i1x2)+CosR1(2+g1x2-h1x2-i1x2)-CosR1(2-g1x2+h1x2-i1x2)-CosR1(2+g1x2+h1x2-i1x2)+CosR1(2-g1x2-h1x2+i1x2)+CosR1(2+g1x2-h1x2+i1x2)-CosR1(2-g1x2+h1x2+i1x2)-CosR1(2+g1x2+h1x2+i1x2))/16.;
};

/* r^1*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_84(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(1-g1x2-h1x2-i1x2)+CosR1(1+g1x2-h1x2-i1x2)-CosR1(1-g1x2+h1x2-i1x2)+CosR1(1+g1x2+h1x2-i1x2)+CosR1(1-g1x2-h1x2+i1x2)-CosR1(1+g1x2-h1x2+i1x2)+CosR1(1-g1x2+h1x2+i1x2)-CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_85(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(1-g1x2-h1x2-i1x2)-CosR1(1+g1x2-h1x2-i1x2)+CosR1(1-g1x2+h1x2-i1x2)-CosR1(1+g1x2+h1x2-i1x2)+CosR1(1-g1x2-h1x2+i1x2)-CosR1(1+g1x2-h1x2+i1x2)+CosR1(1-g1x2+h1x2+i1x2)-CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^3*Sin[2*Pi*r/2]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_86(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(1-g1x2-h1x2-i1x2)-SinR3(1+g1x2-h1x2-i1x2)+SinR3(1-g1x2+h1x2-i1x2)+SinR3(1+g1x2+h1x2-i1x2)+SinR3(1-g1x2-h1x2+i1x2)+SinR3(1+g1x2-h1x2+i1x2)-SinR3(1-g1x2+h1x2+i1x2)-SinR3(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_87(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(1-g1x2-h1x2-i1x2)+CosR2(1+g1x2-h1x2-i1x2)+CosR2(1-g1x2+h1x2-i1x2)+CosR2(1+g1x2+h1x2-i1x2)-CosR2(1-g1x2-h1x2+i1x2)-CosR2(1+g1x2-h1x2+i1x2)-CosR2(1-g1x2+h1x2+i1x2)-CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_88(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(1-g1x2-h1x2-i1x2)+CosR2(1+g1x2-h1x2-i1x2)+CosR2(1-g1x2+h1x2-i1x2)+CosR2(1+g1x2+h1x2-i1x2)+CosR2(1-g1x2-h1x2+i1x2)+CosR2(1+g1x2-h1x2+i1x2)+CosR2(1-g1x2+h1x2+i1x2)+CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^3*Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_89(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(1-g1x2-h1x2-i1x2)-SinR3(1+g1x2-h1x2-i1x2)+SinR3(1-g1x2+h1x2-i1x2)+SinR3(1+g1x2+h1x2-i1x2)-SinR3(1-g1x2-h1x2+i1x2)-SinR3(1+g1x2-h1x2+i1x2)+SinR3(1-g1x2+h1x2+i1x2)+SinR3(1+g1x2+h1x2+i1x2))/8.;
};

/* r^3*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_90(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(1-g1x2-h1x2-i1x2)+SinR3(1+g1x2-h1x2-i1x2)-SinR3(1-g1x2+h1x2-i1x2)+SinR3(1+g1x2+h1x2-i1x2)+SinR3(1-g1x2-h1x2+i1x2)-SinR3(1+g1x2-h1x2+i1x2)+SinR3(1-g1x2+h1x2+i1x2)-SinR3(1+g1x2+h1x2+i1x2))/8.;
};

/* r^3*Sin[g1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_91(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(1-g1x2-h1x2-i1x2)+SinR3(1+g1x2-h1x2-i1x2)-SinR3(1-g1x2+h1x2-i1x2)+SinR3(1+g1x2+h1x2-i1x2)-SinR3(1-g1x2-h1x2+i1x2)+SinR3(1+g1x2-h1x2+i1x2)-SinR3(1-g1x2+h1x2+i1x2)+SinR3(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]*/
static double evalR_92(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(1-g1x2-h1x2-i1x2)-SinR1(1+g1x2-h1x2-i1x2)-SinR1(1-g1x2+h1x2-i1x2)+SinR1(1+g1x2+h1x2-i1x2)-SinR1(1-g1x2-h1x2+i1x2)+SinR1(1+g1x2-h1x2+i1x2)+SinR1(1-g1x2+h1x2+i1x2)-SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_93(const int i1x2, const int g1x2, const int h1x2){
return (-CosR2(1-g1x2-h1x2-i1x2)+CosR2(1+g1x2-h1x2-i1x2)+CosR2(1-g1x2+h1x2-i1x2)-CosR2(1+g1x2+h1x2-i1x2)+CosR2(1-g1x2-h1x2+i1x2)-CosR2(1+g1x2-h1x2+i1x2)-CosR2(1-g1x2+h1x2+i1x2)+CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_94(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(1-g1x2-h1x2-i1x2)+SinR1(1+g1x2-h1x2-i1x2)+SinR1(1-g1x2+h1x2-i1x2)-SinR1(1+g1x2+h1x2-i1x2)-SinR1(1-g1x2-h1x2+i1x2)+SinR1(1+g1x2-h1x2+i1x2)+SinR1(1-g1x2+h1x2+i1x2)-SinR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_95(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(1-g1x2-h1x2-i1x2)+CosR2(1+g1x2-h1x2-i1x2)-CosR2(1-g1x2+h1x2-i1x2)-CosR2(1+g1x2+h1x2-i1x2)+CosR2(1-g1x2-h1x2+i1x2)+CosR2(1+g1x2-h1x2+i1x2)-CosR2(1-g1x2+h1x2+i1x2)-CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[g1*Pi*r]*/
static double evalR_96(const int i1x2, const int g1x2, const int h1x2){
return (-CosR2(1-g1x2-h1x2-i1x2)-CosR2(1+g1x2-h1x2-i1x2)+CosR2(1-g1x2+h1x2-i1x2)+CosR2(1+g1x2+h1x2-i1x2)+CosR2(1-g1x2-h1x2+i1x2)+CosR2(1+g1x2-h1x2+i1x2)-CosR2(1-g1x2+h1x2+i1x2)-CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_97(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(1-g1x2-h1x2-i1x2)+SinR0(1+g1x2-h1x2-i1x2)-SinR0(1-g1x2+h1x2-i1x2)+SinR0(1+g1x2+h1x2-i1x2)+SinR0(1-g1x2-h1x2+i1x2)-SinR0(1+g1x2-h1x2+i1x2)+SinR0(1-g1x2+h1x2+i1x2)-SinR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_98(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(1-g1x2-h1x2-i1x2)-CosR2(1+g1x2-h1x2-i1x2)+CosR2(1-g1x2+h1x2-i1x2)-CosR2(1+g1x2+h1x2-i1x2)+CosR2(1-g1x2-h1x2+i1x2)-CosR2(1+g1x2-h1x2+i1x2)+CosR2(1-g1x2+h1x2+i1x2)-CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[2*Pi*r/2]Cos[h1*Pi*r]*/
static double evalR_99(const int i1x2, const int g1x2, const int h1x2){
return (-CosR2(1-g1x2-h1x2-i1x2)+CosR2(1+g1x2-h1x2-i1x2)-CosR2(1-g1x2+h1x2-i1x2)+CosR2(1+g1x2+h1x2-i1x2)+CosR2(1-g1x2-h1x2+i1x2)-CosR2(1+g1x2-h1x2+i1x2)+CosR2(1-g1x2+h1x2+i1x2)-CosR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*1*/
static double evalR_100(const int i1x2, const int g1x2, const int h1x2){
return 1.0;
};

/* r^0*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_101(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(1-g1x2-h1x2-i1x2)+CosR0(1+g1x2-h1x2-i1x2)+CosR0(1-g1x2+h1x2-i1x2)-CosR0(1+g1x2+h1x2-i1x2)+CosR0(1-g1x2-h1x2+i1x2)-CosR0(1+g1x2-h1x2+i1x2)-CosR0(1-g1x2+h1x2+i1x2)+CosR0(1+g1x2+h1x2+i1x2))/8.;
};

/* r^2*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_102(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(1-g1x2-h1x2-i1x2)+SinR2(1+g1x2-h1x2-i1x2)+SinR2(1-g1x2+h1x2-i1x2)-SinR2(1+g1x2+h1x2-i1x2)-SinR2(1-g1x2-h1x2+i1x2)+SinR2(1+g1x2-h1x2+i1x2)+SinR2(1-g1x2+h1x2+i1x2)-SinR2(1+g1x2+h1x2+i1x2))/8.;
};

/* r^1*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[2*Pi*r/2]Cos[i1*Pi*r]*/
static double evalR_103(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(1-g1x2-h1x2-i1x2)+CosR1(1+g1x2-h1x2-i1x2)+CosR1(1-g1x2+h1x2-i1x2)-CosR1(1+g1x2+h1x2-i1x2)-CosR1(1-g1x2-h1x2+i1x2)+CosR1(1+g1x2-h1x2+i1x2)+CosR1(1-g1x2+h1x2+i1x2)-CosR1(1+g1x2+h1x2+i1x2))/8.;
};

/* r^0*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_104(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(g1x2-h1x2-i1x2)+CosR0(g1x2+h1x2-i1x2)+CosR0(g1x2-h1x2+i1x2)-CosR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_105(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(g1x2-h1x2-i1x2)+SinR1(g1x2+h1x2-i1x2)-SinR1(g1x2-h1x2+i1x2)+SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_106(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(g1x2-h1x2-i1x2)+CosR0(g1x2+h1x2-i1x2)-CosR0(g1x2-h1x2+i1x2)-CosR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_107(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(g1x2-h1x2-i1x2)+SinR1(g1x2+h1x2-i1x2)+SinR1(g1x2-h1x2+i1x2)+SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_108(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(g1x2-h1x2-i1x2)-SinR1(g1x2+h1x2-i1x2)+SinR1(g1x2-h1x2+i1x2)+SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_109(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(g1x2-h1x2-i1x2)-SinR2(g1x2+h1x2-i1x2)+SinR2(g1x2-h1x2+i1x2)+SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_110(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(g1x2-h1x2-i1x2)+CosR1(g1x2+h1x2-i1x2)+CosR1(g1x2-h1x2+i1x2)-CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_111(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(g1x2-h1x2-i1x2)-SinR0(g1x2+h1x2-i1x2)+SinR0(g1x2-h1x2+i1x2)+SinR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_112(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(g1x2-h1x2-i1x2)+CosR1(g1x2+h1x2-i1x2)+CosR1(g1x2-h1x2+i1x2)+CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_113(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(g1x2-h1x2-i1x2)+SinR2(g1x2+h1x2-i1x2)-SinR2(g1x2-h1x2+i1x2)+SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_114(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(g1x2-h1x2-i1x2)+SinR2(g1x2+h1x2-i1x2)+SinR2(g1x2-h1x2+i1x2)+SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_115(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(g1x2-h1x2-i1x2)+SinR0(g1x2+h1x2-i1x2)+SinR0(g1x2-h1x2+i1x2)-SinR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_116(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(g1x2-h1x2-i1x2)-CosR1(g1x2+h1x2-i1x2)+CosR1(g1x2-h1x2+i1x2)-CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_117(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(g1x2-h1x2-i1x2)+CosR1(g1x2+h1x2-i1x2)-CosR1(g1x2-h1x2+i1x2)-CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_118(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(g1x2-h1x2-i1x2)+SinR3(g1x2+h1x2-i1x2)-SinR3(g1x2-h1x2+i1x2)+SinR3(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_119(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(g1x2-h1x2-i1x2)+CosR2(g1x2+h1x2-i1x2)+CosR2(g1x2-h1x2+i1x2)+CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_120(const int i1x2, const int g1x2, const int h1x2){
return (SinR3(g1x2-h1x2-i1x2)+SinR3(g1x2+h1x2-i1x2)+SinR3(g1x2-h1x2+i1x2)+SinR3(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_121(const int i1x2, const int g1x2, const int h1x2){
return (-CosR2(g1x2-h1x2-i1x2)+CosR2(g1x2+h1x2-i1x2)+CosR2(g1x2-h1x2+i1x2)-CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_122(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(g1x2-h1x2-i1x2)+SinR1(g1x2+h1x2-i1x2)+SinR1(g1x2-h1x2+i1x2)-SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_123(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(g1x2-h1x2-i1x2)-CosR2(g1x2+h1x2-i1x2)+CosR2(g1x2-h1x2+i1x2)-CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_124(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(g1x2-h1x2-i1x2)+CosR2(g1x2+h1x2-i1x2)-CosR2(g1x2-h1x2+i1x2)-CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[2*Pi*r/2]Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_125(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(1-g1x2-h1x2-i1x2)+SinR3(1+g1x2-h1x2-i1x2)+SinR3(1-g1x2+h1x2-i1x2)-SinR3(1+g1x2+h1x2-i1x2)-SinR3(1-g1x2-h1x2+i1x2)+SinR3(1+g1x2-h1x2+i1x2)+SinR3(1-g1x2+h1x2+i1x2)-SinR3(1+g1x2+h1x2+i1x2))/8.;
};

/* r^3*Sin[2*Pi*r/2]Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_126(const int i1x2, const int g1x2, const int h1x2){
return (SinR3(1-g1x2-h1x2-i1x2)+SinR3(1+g1x2-h1x2-i1x2)+SinR3(1-g1x2+h1x2-i1x2)+SinR3(1+g1x2+h1x2-i1x2)+SinR3(1-g1x2-h1x2+i1x2)+SinR3(1+g1x2-h1x2+i1x2)+SinR3(1-g1x2+h1x2+i1x2)+SinR3(1+g1x2+h1x2+i1x2))/8.;
};

/* r^3*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_127(const int i1x2, const int g1x2, const int h1x2){
return (-CosR3(g1x2-h1x2-i1x2)+CosR3(g1x2+h1x2-i1x2)+CosR3(g1x2-h1x2+i1x2)-CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_128(const int i1x2, const int g1x2, const int h1x2){
return (CosR3(g1x2-h1x2-i1x2)+CosR3(g1x2+h1x2-i1x2)+CosR3(g1x2-h1x2+i1x2)+CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_129(const int i1x2, const int g1x2, const int h1x2){
return (-SinR4(g1x2-h1x2-i1x2)+SinR4(g1x2+h1x2-i1x2)-SinR4(g1x2-h1x2+i1x2)+SinR4(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_130(const int i1x2, const int g1x2, const int h1x2){
return (CosR3(g1x2-h1x2-i1x2)+CosR3(g1x2+h1x2-i1x2)-CosR3(g1x2-h1x2+i1x2)-CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_131(const int i1x2, const int g1x2, const int h1x2){
return (SinR4(g1x2-h1x2-i1x2)+SinR4(g1x2+h1x2-i1x2)+SinR4(g1x2-h1x2+i1x2)+SinR4(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_132(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(g1x2-h1x2-i1x2)+SinR2(g1x2+h1x2-i1x2)+SinR2(g1x2-h1x2+i1x2)-SinR2(g1x2+h1x2+i1x2))/4.;
};

};

#endif // CYLSIN_EVAL_R_H