#ifndef TORUS_BASIS_SET_3D_H
#define TORUS_BASIS_SET_3D_H

#include <Eigen/Eigen>
#include <fftw3.h>
#include <fstream>
#include <glog/logging.h>
#include <unordered_map>
#include <memory>

#include "3D/FIELD_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "common/basic_function.h"
#include "common/pairedCoef.h"
#include "common/particle_sph_3d.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/torus_basis_3D.h"

#define FAST_TENSOR

#ifdef FAST_TENSOR
#include "tensorCompute/torus3DTensor.h"
#endif

typedef std::shared_ptr<TorusBasis3D> basisPtr3DTor;

class TorusBasisSet3D : public BasisSet3D {

public:
  // init, 2*wavenumber
  TorusBasisSet3D(const int nR, const int nTheta, const int nPhi, const int rK, const int thetaK, const int phiK,
                  const double a):
    nR_(nR), nTheta_(nTheta),nPhi_(nPhi), nThetaPhi_(nTheta*nPhi), rK_(rK), thetaK_(thetaK), phiK_(phiK),
    a_(a) {
    CHECK(a_ > 1.0);
    // nPhi_ must be even to ensure dst works.
    CHECK(nTheta_ % 2 == 0);
    CHECK(nPhi_ % 2 == 0);
    scale_ = 1.0/(a+1.0);
    scale3_ = (scale_*scale_*scale_);
    allocateMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  TorusBasisSet3D(const int nR, const int nTheta, const int nPhi, std::ifstream& in):nR_(nR), nTheta_(nTheta),nPhi_(nPhi),
                nThetaPhi_(nTheta*nPhi), rK_(0), thetaK_(0), phiK_(0) {
    // nPhi_ must be even to ensure dst works.
    CHECK(nTheta_ % 2 == 0);
    CHECK(nPhi_ % 2 == 0);
    readFromFile(in);
    allocateTemp();
    setUpFFTWPlan();
  };

  ~TorusBasisSet3D(){};
  void ReSeedParticles(std::vector<ParticleSph3D>& particles, std::vector<Eigen::Vector3d>& initPos) override;
  void projBackParticles(const std::vector<Eigen::Vector3d>& initPos, std::vector<ParticleSph3D>& particles) override;

  void InverseTransformToVelocity(Eigen::VectorXd& coefficients) override;
  
  void ForwardTransformtoFrequency(
      const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) override;

  // add a force fields in coordinate (r, theta, phi) directly to the coefficients w/o interpolation.
  // xRes, yRes, zRes lines up with (nphi, ntheta, nr)
  void ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) override;

  void outputTestTensorEntries(const int numWant, const std::string& fname,
        std::vector<Adv_Tensor_Type> *Adv_tensor);
  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const override;
  void readFromFile(std::ifstream& in) override;
  VEC3 getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) override;
  double majorA() {return a_;}

  // Add force to the grid where the particle is.
  template<typename DT, typename VT>
  void addParticleForce(const double& ptlWeight, const VT& pos, const VT& f, VECTOR3_FIELD_3D& buf);

  // directly get velocity at query position from rtp
  Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) override;
  Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) override;
  void projPosBack(ParaParticle3Dd& p) override;
  void projPosBack(ParaParticle3Df& p) override;

  template<typename DT, typename VT, typename MT> void getVelocityPosT(const VT& pos, VT& uCat);
  template<typename DT, typename VT>
  void splatParticleT(const double& ptlWeight, const double& dx, VT& p, FIELD_3D& density);
  //void splatParticle(const double& ptlWeight, const double& dx, Eigen::Vector3d& p, FIELD_3D& density) override;
  //void splatParticle(const double& ptlWeight, const double& dx, Eigen::Vector3f& p, FIELD_3D& density) override;

  int nR() {return nR_;}
  int nPhi() {return nPhi_;}
  int nTheta() {return nTheta_;}
  void interpolateToCartesian(VECTOR3_FIELD_3D* field) override;

protected:
  
  void allocateMGS();
  void initPhiCoef();

  void allocateTemp();
  void setUpFFTWPlan();
  
  void moveInToTgrid(const double* in, double* out);
  void moveTToIngrid(const double* in, double* out);

  void moveTtoPGrid(const double* in, double* out);
  void movePtoTGrid(const double* in, double* out);

  void sumTtoPGrid(const double* in, double* out);
  void add2DSliceToFull(const int offset, const double* slice2D, double* out);
  void extract2DSliceToFull(const int offset, const double* in, double* slice2D);

  void weightR(double* f);
  void weightR2D(double *f);
  void weightJacobian(double* ur, double* ut, double* up);

  void TransR(fftw_plan rPlan, double* in, double* out);
  void TransT(fftw_plan tPlan, double* in, double* out);

  void weightT(const double* wf_, double* f);

  void InverseTransformVR();
  void InverseTransformVT();
  void InverseTransformVP();

  void ForwardTransformVR();
  void ForwardTransformVT();
  void ForwardTransformVP();

  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta,
       const int nPhi, double* ur, double* ut, double* up);
  void projectUniformRTNumerical(const int nR, const int nTheta, const int nPhi, double* fr,
                               double* ft, double* fp, Eigen::VectorXd& fullCoef);

  void interpolateToTorus(const VECTOR3_FIELD_3D& field);
  
  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);

  // clear chunk of mem following ptr, it's up to user
  void clearPointer(double* ptr) {
    std::unordered_map<double*, int>::const_iterator it = pointerSize_.find(ptr);
    CHECK(it != pointerSize_.end());
    memset(ptr, 0x00, sizeof(double)*it->second);
  }

  void clearPairCoef();
  void assignPairCoef(Eigen::VectorXd& fieldCoef);
  void runMGS(const double thresh, const std::vector<basisPtr3DTor>& in, std::vector<basisPtr3DTor>& out,
            Eigen::MatrixXd& Coef, int& m);
  
  double dotProdCast(const basisPtr3DTor a, const basisPtr3DTor b) const {
    return a->dotProdScale(*b, a_)*a->GetInvNorm()*b->GetInvNorm();
  }
  
  double tensorEntryCast(const basisPtr3DTor basis_i, const basisPtr3DTor basis_g, const basisPtr3DTor basis_h);

  const int nR_;
  const int nTheta_;
  const int nPhi_;
  const int nThetaPhi_;

  double dR_;
  double dTheta_;
  double dPhi_;
  int totalSize_;
  double invTotalSize_;

  // need to write this out.....
  int rK_;
  // number of basis along theta
  int thetaK_;
  // number of basis along phi
  int phiK_;
  
  // trimmed dimensions.
  int nRE_;
  int nThetaE_;
  int nPhiE_;

  std::vector<basisPtr3DTor> all_basis_;
  
  std::unordered_map<double*, int> pointerSize_;

  const bool useTrimmedPlan = true;

  // inverse trimmed plans, this plans are 2D for the same reason IsinT_ and IcosT_ are 2D.
  // due to jump in idsit.
  // R plan always operate on a trimmed grid of size nR_*nThetaE_*nPhiE_
  fftw_plan IsinRE_;
  fftw_plan IcosRE_;
  // T plan always operate on a trimmed grid of size nR_*nTheta*nPhiE_
  fftw_plan IsinTE_;
  fftw_plan IcosTE_;

  fftw_plan IsinR2D_;
  fftw_plan IcosR2D_;
  fftw_plan FsinR2D_;
  fftw_plan FcosR2D_;

  // forward trimmed plans
  fftw_plan FsinRE_; 
  fftw_plan FcosRE_;
  fftw_plan FsinTE_;
  fftw_plan FcosTE_;

  // P plan always operate on grid of size P.
  fftw_plan IsinP_;
  fftw_plan IcosP_;
  fftw_plan FsinP_;
  fftw_plan FcosP_;

  // used for Phi89
  fftw_plan IcosRsinT_;
  fftw_plan IcosRcosT_;
  fftw_plan FcosRsinT_;
  fftw_plan FcosRcosT_;
  // pointers of size totalSize_
  // transformation always start with r, then theta, then phi.
  double* inTemp_ = NULL; // grid of size nR_*nThetaE_*nPhiE_
  double* inTemp1_ = NULL;
  double* inTemp2_ = NULL;

  double* tTemp_ = NULL;  // grid of size nR_*nTheta*nPhiE_
  double* pTemp_ = NULL;  // grid of size nR_*nTheta*nPhi_

  // full size grids.
  double* temp0_ = NULL;
  double* vpTemp_ = NULL;
  double* vtTemp_ = NULL;
  double* vrTemp_ = NULL;

  // 2D pointers used for enrichment functions.
  double* rPTemp_ = NULL;
  double* rPTemp1_ = NULL;

  // for Phi^8, Phi^9
  double* rTTemp_ = NULL;
  double* rTTemp1_ = NULL;

  // pointers of size nTheta_
  double* cosTVal_ = NULL;
  double* sinTVal_ = NULL;

  std::default_random_engine m_gen_;
  // major axis
  double a_;

  std::vector<std::vector<pairedCoef>> phiCoef_;

#ifdef FAST_TENSOR
  torus3DTensor tensorEval_;
#endif

};

//typedef std::unique_ptr<CylinderBasis3D> basisPtr;

#endif // TORUS_BASIS_SET_3D_H