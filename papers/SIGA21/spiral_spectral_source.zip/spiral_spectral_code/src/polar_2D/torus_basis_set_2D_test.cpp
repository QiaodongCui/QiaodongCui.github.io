#include <Eigen/Eigen>
#include <fftw3.h>
#include <glog/logging.h>
#include <math.h>

#include "2D/VFIELD2D.h"
#include "polar_2D/torus_basis_2D.h"
#include "polar_2D/torus_basis_set_2D.h"
#include "sphere_3D/sphere_basis_3D.h"

namespace {

void testTransform() {
	const int N = 128;
  TorusBasisSet2D basis(N, 8, 16, 3.0);
  VFIELD2D field(2*N, N);
  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(basis.numBasisAll());
  basis.InverseTramsformToVelocity(fieldCoef, &field);
  //basis.ForwardTransformtoFrequency(field, &fieldCoef);
}

void testTensor() {
  const int N = 128;
  TorusBasisSet2D basis(N, 4, 8, 3.0);
  std::vector<Adv_Tensor_Type> Adv_tensor_;
  basis.outputTestTensorEntries(100, "./torus2D_tensorTest.txt", &Adv_tensor_);
}

void testEntry() {
  const double a = 3.0;

  TorusBasis2D basisi(3, 4, 1, a);
  TorusBasis2D basisg(2, 2, 2, a);
  TorusBasis2D basish(2, 6, 3, a);
  LOG(INFO) << TorusBasis2D::computeTensorEntry(basisi, basisg, basish);
  BasicFunc ss(SIN, T, 13, 1.0);
  LOG(INFO) << ss.integrateP2Pi();
}

};  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);

  //testTransform();
  testTensor();
  //testEntry();
  return 0;
}