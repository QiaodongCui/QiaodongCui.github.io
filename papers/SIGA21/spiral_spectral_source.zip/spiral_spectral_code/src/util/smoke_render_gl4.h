/* Rewrite from  https://graphics.ethz.ch/teaching/former/imagesynthesis_06/miniprojects/p3/index.html
 *Author: Johannes Schmid and Ingemar Rask, 2006, johnny@grob.org */

#ifndef SMOKE_RENDER_3D_H
#define SMOKE_RENDER_3D_H

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/glut.h>

#include <cstdlib>
#include <Eigen/Eigen>

#include "setting.h"
#include "3D/FIELD_3D.h"

#ifndef ALMOST_EQUAL
#define ALMOST_EQUAL(a, b) ((std::abs(a-b)<0.00001)?true:false)
#endif

#define SLICE_NUM			256.0f


class Renderer3DGL4
{
public:
  	void InitGL();
	Renderer3DGL4(const int xRes, const int yRes, const int zRes, const int ScaleRes);
	~Renderer3DGL4();
	void SetLightPostion(const Eigen::Vector3f &pos);
	void SetRendering(bool isRendering);
	void SetSliceOutline(bool isDrawSliceOutline);


	void FillTexture(const FIELD_3D& density_field, const float multiplier,
                     const int low_cut);		// generate texture from smoke density 
	void Render(const glm::mat4& modelView);					// draw the volume

	void DrawLight();
	void DrawVolumeData();

private:

	// texture data
	unsigned char* _textureData;
	// texture handle
	unsigned int _hTexture;				
	//lighting infomations
	Eigen::Vector3f _lightDir;
	Eigen::Vector3f _lightPos;
	int _rayTemplate[4096][3];
	// Real *_volumeData;

	GLfloat _cubeVertices[8][3];
	GLfloat _cubeEdges[12][2][3];

	// draw the slices. mvMatrix must be the MODELVIEW_MATRIX
	void DrawSlices(const glm::mat4& modelView);

	// intersect a plane with the cube, helper function for DrawSlices()
	// plane equation is Ax + By + Cz + D = 0
	std::vector<Eigen::Vector3f> IntersectEdges(float A, float B, float C, float D);

	void GenerateRayTemplate();
	void CastLight(const FIELD_3D& density, unsigned char* intensity);
	inline void LightRay(int x, int y, int z, float decay, 
			const FIELD_3D& density, unsigned char* intensity);

	// if _isDrawSliceOutline==true, the outline of the slices will be drawn as well
	bool _isDrawSliceOutline;
	bool _isRendering;

	int _SIZE;		//size of volume data
  const int xRes_;
  const int yRes_;
  const int zRes_;
  int MaxRes_;
  int Slabsize_;
  float xN_;
  float yN_;
  float zN_;
  float invxN_;
  float invyN_;
  float invzN_;
	float x_;
	float y_;
	float z_;
  // buf for trigs to draw
  unsigned int VBO, VAO;
  int bufSize;
  float* buf;
};


#endif  // SMOKE_RENDER_3D_H

