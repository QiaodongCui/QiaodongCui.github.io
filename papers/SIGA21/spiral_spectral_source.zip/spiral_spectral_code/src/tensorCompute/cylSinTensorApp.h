static double evalcylSin_0(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_1(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_2(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_3(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_4(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+-b*g2*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_5(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi+b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_6(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_7(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_8(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_9(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_10(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+b*g2*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_11(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi+-b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_12(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_13(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_14(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_15(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_16(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i2*i3*Pi*i3*Pi*Pi+b*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_17(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_18(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_19(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_20(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_21(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_22(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i2*i3*Pi*i3*Pi*Pi+b*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_23(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_24(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+b*h2*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_25(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+-b*h2*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_26(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i2*i3*Pi*i3*Pi*Pi+-b*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_27(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i2*i3*Pi*i3*Pi*Pi+-b*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_28(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_86(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+2*b*g3*i2*i3*Pi*i3*Pi*Pi+b*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-2*b*h3*i2*i3*Pi*i3*Pi*Pi+-b*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_90(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_29(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*i2*Pi*b*i2*b)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_30(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi+-b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_31(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi+b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_32(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_33(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_34(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*i2*Pi*b*i2*b)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_35(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_36(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_37(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_38(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_39(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_40(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+b*g2*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_41(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi+b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_42(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_43(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_44(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_45(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_46(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+-b*g2*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_47(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi+-b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_48(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_49(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_50(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_51(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_52(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i2*i3*Pi*i3*Pi*Pi+-b*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_53(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_54(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_55(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_56(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_57(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_58(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i2*i3*Pi*i3*Pi*Pi+-b*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_59(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_60(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+-b*h2*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_61(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+b*h2*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_62(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i2*i3*Pi*i3*Pi*Pi+b*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_63(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i2*i3*Pi*i3*Pi*Pi+b*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_64(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_86(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-2*b*g3*i2*i3*Pi*i3*Pi*Pi+-b*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+2*b*h3*i2*i3*Pi*i3*Pi*Pi+b*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_90(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_65(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*i2*Pi*b*i2*b)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_66(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi+-b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_67(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi+b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_68(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_69(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_70(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*i2*Pi*b*i2*b)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_71(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_72(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_73(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_74(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_75(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_76(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i3*Pi*i3*Pi*Pi+2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_77(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_78(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_79(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_80(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_81(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_82(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i3*Pi*i3*Pi*Pi+-2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_83(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_84(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_85(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_86(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_87(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_88(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_89(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_90(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_91(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_92(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_93(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_94(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_95(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_96(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i3*Pi*i3*Pi*Pi+-2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_97(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i3*Pi*i3*Pi*Pi+2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_98(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_99(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_100(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_101(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-2*b*i1*Pi*b*b)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_102(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_103(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_104(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_105(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_106(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+2*b*i1*Pi*b*b)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+-b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_107(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_108(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_109(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_110(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_111(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_112(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i3*Pi*i3*Pi*Pi+2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_113(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_114(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_115(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_116(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_117(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_118(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i3*Pi*i3*Pi*Pi+-2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_119(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_120(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_121(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_122(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_123(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_124(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_125(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_126(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_127(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_128(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_129(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_130(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_131(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_132(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i3*Pi*i3*Pi*Pi+-2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_133(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i3*Pi*i3*Pi*Pi+2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_134(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_135(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_136(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_137(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+2*b*i1*Pi*b*b)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_138(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_139(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_140(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_141(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_142(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-2*b*i1*Pi*b*b)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_143(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_144(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_145(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_146(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_147(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_148(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+6*b*g2*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i3*Pi*i3*Pi*Pi+2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+-3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_149(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_150(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_151(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_152(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_153(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_154(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-6*b*g2*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i3*Pi*i3*Pi*Pi+-2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_155(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_156(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_157(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_158(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_159(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_160(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-6*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_161(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_162(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_163(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_164(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_165(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_166(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-6*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_167(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_168(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-6*b*h2*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i3*Pi*i3*Pi*Pi+-2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_169(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+6*b*h2*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i3*Pi*i3*Pi*Pi+2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+-3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_170(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+6*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_171(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+6*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_172(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_127(i1x2, g1x2, h1x2)*(+3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-6*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_128(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi+-2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_129(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+6*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_130(i1x2, g1x2, h1x2)*(+-3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_128(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi+2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_131(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_173(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_174(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_175(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_176(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_177(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_178(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_179(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_180(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_181(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_182(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_183(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_184(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_185(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*Pi/2)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g2*g3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_186(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_187(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_188(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_189(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_190(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_191(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*Pi/2)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g2*g3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_192(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_193(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_194(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_195(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_196(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_197(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_198(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_199(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_200(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_201(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_202(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_203(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+b*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_204(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_205(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_206(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_207(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_208(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_209(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_132(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*Pi)+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+2*b*i3*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+b*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_210(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*Pi/2)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*h2*h3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_211(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*Pi/2)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*h2*h3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_212(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*h3*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_213(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*h3*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-b*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_214(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_132(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*Pi)+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi)))
))
+((cylSinpEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*h3*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+-b*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylSin_215(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylSinpEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylSinpEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
