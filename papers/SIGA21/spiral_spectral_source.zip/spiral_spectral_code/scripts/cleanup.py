import os
import re
rootDir = '../applications/'

def process_oneFile(fname, fnameTrimmed):
	#p = re.compile("std::cout\s*<<([^;]*[^l]);")
	p = re.compile("LOG\(ERROR\)\s*<<([^;]*);")
	#p = re.compile("CHECK1_EQ\(([^,]*)\s*,\s*([^\)]*)\)([^;]*);")
	#p = re.compile("CHECK1\(([^\)]*)\)([^;]*);")

	pattern = 'std::cout << ' + '\"' + fnameTrimmed + ' \"' + ' << __LINE__ << \" FATAL: \" << \\1 << std::endl; exit(0);' ;
	#pattern = 'if (\\1 != \\2) {std::cout << ' + '\"' + fnameTrimmed + ' \"' + ' << __LINE__ << \" FATAL: \" \\3 << std::endl; exit(0);}'
	#pattern = '\\1 \\2 \\3' 
	#pattern = 'if (! \\1) {std::cout << ' + '\"' + fnameTrimmed + ' "' + ' << __LINE__ << \" FATAL: \" \\2 << std::endl; exit(0);}'	
	ReplacedLines = []
	with open(fname, 'r') as f:
		lines = f.readlines()
		for line in lines:
			repL = p.sub(pattern, line)
			ReplacedLines.append(repL)
	with open(fname, 'w') as f:
		for repL in ReplacedLines:
			f.write(repL)

for subdir, dirs, files in os.walk(rootDir):
	for file in files:
		if file.endswith(".h") or file.endswith(".cpp") or file.endswith(".cc"):
			fname = os.path.join(subdir, file)
			#print(fname)
			print(file)
			process_oneFile(fname, file)

#process_oneFile("../applications/laplacian_fluid_sim3D.cpp", "laplacian_fluid_sim3D.cpp")