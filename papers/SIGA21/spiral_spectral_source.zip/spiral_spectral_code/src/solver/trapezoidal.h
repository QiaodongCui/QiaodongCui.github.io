#ifndef TRAPEZOIDAL_H
#define TRAPEZOIDAL_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>

#include "integrator_2d.h"
#include "setting.h"

class Trapezoidal : public Integrator2D {
public:
  Trapezoidal(){};
  ~Trapezoidal(){};
  void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) override;

  template<typename MAT>
	void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
											const MAT& A,     // transfer matrix for non-orthogonal bases.
	                    const Eigen::VectorXd & coefficients_old,
	                    const double dt,
	                    Eigen::VectorXd& coefficients_new,
	                    double& condition_number_,
	                    float& contraction_time,
	                    float& solver_time);

  template<typename MAT>
  void IntegrateForwardSparse(const MAT& A,     // transfer matrix for non-orthogonal bases.
                      const Eigen::VectorXd & coefficients_old,
                      const double dt,
                      Adv_Tensor_Type& C, // should already contracted with the advection tensor
                      Eigen::VectorXd& coefficients_new);

protected:
};

#endif  // TRAPEZOIDAL_H
