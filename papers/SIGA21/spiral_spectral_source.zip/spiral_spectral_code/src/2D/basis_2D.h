#ifndef BASIS_2D_H
#define BASIS_2D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>

class Basis2D {

public:
  // init, 2*wavenumber
  Basis2D(const int k12, const int k22):
  k1(k12*0.5), k2(k22*0.5), k1x2(k12), k2x2(k22) {
  };

  ~Basis2D(){};

  // extract int version of wn1
  // wave number 1, its up to user to ensure K1D is always even
  int WN1I() const {
    return k1x2/2;
  }
  
  int WN2I() const {
    return k2x2/2;
  }
  
  double WN1D() const {
    return k1;
  }

  double WN2D() const {
    return k2;
  }
  
  int WN1x2() const {
    return k1x2;
  }

  int WN2x2() const {
    return k2x2;
  }

  double GetInvNorm() const {
    return invNorm_;
  }

  static uint64_t toHash(const int k12, const int k22, const int idx) {
    uint64_t result = 0;
    result |= (0xffff000000000000 & static_cast<uint64_t>(k12) << 48);
    result |= (0x0000ffff00000000 & static_cast<uint64_t>(k22) << 32); // sign bit
    result |= (0x000000000000ffff & static_cast<uint64_t>(idx) );
    return result;
  }

  void debugPrint() const {
    LOG(INFO) << "k1: " << k1 << " k2: " << k2 << " invNorm: " << invNorm_;
  }

protected:
  const double k1;
  const double k2;

  // 2* wavenumber
  const int k1x2;
  const int k2x2;

  double invNorm_;

};

//typedef std::unique_ptr<Basis2D> basisPtr;

#endif // BASIS_2D_H