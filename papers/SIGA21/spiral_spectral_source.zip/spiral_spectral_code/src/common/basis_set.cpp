#include <cmath>
#include <Eigen/Eigen>
#include <fftw3.h>
#include <glog/logging.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <fstream>

#include "common/basis_set.h"
#include "setting.h"
#include "util/util.h"
#include "2D/VFIELD2D.h"

void BasisSet::allocateBasis() {
  LOG(FATAL) << "base class called";
}

// numerical for now.
void BasisSet::InverseTransformToVelocity(
  const Eigen::VectorXd& coefficients, VFIELD2D* field) {
  LOG(FATAL) << "BASE class called";
}

// TODO: Compute basis dot product normalization term.
void BasisSet::ForwardTransformtoFrequency(
  const VFIELD2D& field, Eigen::VectorXd* coefficients) {
  LOG(FATAL) << "BASE class called";
}

// fill the adv tensor with the old basis.
void BasisSet::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {
  LOG(FATAL) << "BASE class called";
}

void BasisSet::allocateNumerical() {
	LOG(FATAL) << "BASE class called";
}

void BasisSet::VerifyAntisymmetric(const std::vector<Adv_Tensor_Type>& C) {
  const int num_basis_ = C.size();

  double max_abs_entries = FLT_MIN;
  int num_non_zero = 0;
  
  for (int i = 0; i < num_basis_; i++) {
    for (int g = 0; g < num_basis_; g++) {
      for (int h = 0; h < num_basis_; h++) {
        double Cigh = AccessMatrix(C[i],g,h);
        if (Cigh != 0) {
          num_non_zero ++;
          double Cihg = AccessMatrix(C[i],h,g);
          if ((Cigh + Cihg) > 1e-10) {
            LOG(INFO) << "Non symeetric entries found.";
            LOG(INFO) << i << " " << g << " " << h << " " << Cigh << " " << Cihg;
            //exit(0); 
          }
          if (! isfinite(Cigh)) {
            LOG(INFO) << "Nan found";
          }
          if (std::abs(Cigh) > max_abs_entries) {
            max_abs_entries = std::abs(Cigh);
          }
        }
      }
    }
  }
  LOG(INFO) << "Number of non-zero elements in tensor: " << num_non_zero
      << " Maximum abs entry: " << max_abs_entries;
}

void BasisSet::EigenCompress(std::vector<Adv_Tensor_Type> *Adv_tensor) {
  
  std::ofstream out("./SliceEig.txt", std::ios::out);

  for (int i = 0; i < (*Adv_tensor).size(); i++) {
    if ((*Adv_tensor)[i].nonZeros() == 0)
      continue;
    Eigen::RealSchur<Eigen::MatrixXd> es;
    // cout << spSlice.nonZeros() << endl;
    Eigen::MatrixXd slide = (*Adv_tensor)[i];

    es.compute(slide);
    Eigen::MatrixXd TMat = es.matrixT();
    std::vector<double> imagEigs;
    //printf("UpperDiag\n");
    for (int i = 1; i < TMat.cols(); i++) {
      //printf("%f ", TMat(i-1, i));
      imagEigs.push_back(TMat(i-1, i));
    }
    
    sort(imagEigs.begin(), imagEigs.end(), [](const double& a, const double& b){
      return fabs(a) > fabs(b);
    });

    printf("sorted eigs\n");
    for (int i = 0; i < imagEigs.size(); i++) {
      out << imagEigs[i] << " ";
    }
    out << "\n";
  }

  exit(0);
}

void BasisSet::computeInnerProduct() {
  
  /*H_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
  // only compute half cuz symmetric
  for(int i = 0; i < all_basis_.size(); i++) {
    for (int j = i; j < all_basis_.size(); j++) {
      H_(i,j) = all_basis_[i]->dotProd(*all_basis_[j])*all_basis_[i]->GetInvNorm()*all_basis_[j]->GetInvNorm();
      H_(j,i) = H_(i,j);
    }
  }

  // H should be positive definite.
  SelfAdjointEigenSolver<Eigen::MatrixXd> es(H_);
  Eigen::VectorXd eigs = es.eigenvalues();

  double maxEig = eigs[H_.rows() - 1];
  int i = 0;
  for (i = 0; i < H_.rows(); i++) {
    if (eigs[i] > 0.1*maxEig)
      break;
  }

  Eigen::VectorXd lEigs = eigs.tail(eigs.size() - i);

  LOG(INFO) << "percentage discared: " << 1.0 - (double)(lEigs.size())/ eigs.size();
  Eigen::VectorXd invEigs = 1.0 / lEigs.array().sqrt();

  // transfer matrix D^{-0.5}*U^T
  A_ = invEigs.asDiagonal()*(es.eigenvectors().rightCols(lEigs.size())).transpose();

  //A_.resize(all_basis_.size(), all_basis_.size());
  //A_.setIdentity();
  numBasisOrtho_ = A_.rows();*/
  LOG(FATAL) << "depredated";
}

void BasisSet::writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const {
  LOG(FATAL) << "base class called";
}

void BasisSet::readFromFile(std::ifstream& in) {
  LOG(FATAL) << "base class called";
}

// compute the ur, ut on a uniform r, t grid, test only.
void BasisSet::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut) {
  LOG(FATAL) << "base class called";
}

void BasisSet::projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef) {
  LOG(FATAL) << "base class called";
}
