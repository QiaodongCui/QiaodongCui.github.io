import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import sys
import scipy.sparse as sparse
from scipy.sparse import coo_matrix

f = open(sys.argv[1], "rb")
nnz = np.fromfile(f, dtype=np.int32, count=1)
rows = np.fromfile(f, dtype=np.int32, count=1)
cols = np.fromfile(f, dtype=np.int32, count=1)

row = np.fromfile(f, dtype=np.int32, count=nnz[0])
col = np.fromfile(f, dtype=np.int32, count=nnz[0])
data = np.fromfile(f, dtype=np.float64,count=nnz[0])
#print(col.min(), col.max())

#print(row.shape, col.shape, data.shape)
coo = coo_matrix((data, (row, col)), shape=(rows[0], cols[0]))
# visualize the sparse matrix with Spy

plt.spy(coo, markersize=0.01)
plt.show()