#ifndef OBSTACLE3D_3D_H
#define OBSTACLE3D_3D_H

#include <Eigen/Eigen>
#include <glog/logging.h>
#include <iostream>
#include <fstream>

#include "3D/VECTOR3_FIELD_3D.h"
#include "Alg/VEC3.h"
#include "Alg/MATRIX3.h"
#include "FIELD_3D.h"




struct ObstacleParams3D{
  ObstacleParams3D() {
    use_obstacles = false;
    obstacle_force_scale = 20.;
  }
  bool use_obstacles;
  double obstacle_force_scale;
  bool handle_obstacle_implicit;
  bool move_obstacle;
  std::string obstacle_type;
  std::string obstacle_file;
  std::string obstacle_list;
};

struct ObstacleIdx3D {
  ObstacleIdx3D(const int xpos, const int ypos,
                const int zpos, const int mode_):idx(VEC3I(xpos, ypos, zpos)), mode(mode_){
  }
  // x, y, z...
  VEC3I idx;
  int mode;
};

class OBSTACLE3D  
{
public:
  OBSTACLE3D(const VEC3I& gridRes, const double dx):gridRes_(gridRes),dx_(dx) {
    // Default color.
    color_ = VEC3F(0.1, 0.2, 0.8);
  };
  virtual ~OBSTACLE3D() {};

  bool inside(float x, float y, float z) {return inside(VEC3F(x,y,z));}
  virtual void draw() const {
    LOG(FATAL) << "Base class called";
  }
  virtual bool inside(const VEC3F& point) const {
    LOG(FATAL) << "Base class called.";
  }
  // virtual Real distance(const VEC3F& point) = 0;

  // Eigen::Vector3f& translation()     { return Translation_; };
  // Eigen::Matrix3f& rotation()      { return Rotation_; };
  // Eigen::Vector3f& velocity()        { return V_; };

  // virtual void scale(const Real alpha) = 0;
  // virtual void boundingBox(VEC3F& mins, VEC3F& maxs) const = 0;
  virtual void CalculateNormalForce(
      const VECTOR3_FIELD_3D& velocity, char * check, const double dt, const double cell_len, const double force_amp,
      VECTOR3_FIELD_3D* normal_component) const {
        LOG(FATAL) << "Base class called.";
      }
  
  virtual void MoveObstacle(const double dt) {
    LOG(FATAL) << "Base class called.";
  }
  
  virtual void SetVelocity(const VEC3F& velo) {
    LOG(FATAL) << "Base class called.";
  }
  
  virtual
  void ZeroOutVelocityDensityObstalce(const double cell_len,
                                      VECTOR3_FIELD_3D* velocity, FIELD_3D* density) {
    LOG(FATAL) << "Base class called.";
  }
  
  virtual void RasterToGrid(unsigned char* obstacle_filed) {
    LOG(FATAL) << "Base method called.";
  }
  
  virtual void OutPutGeometryToPBRT(const std::string &fname) {
    LOG(FATAL) << "Base class called.";
  }
  
  virtual void OutPutGeometryToPBRT(std::ofstream& out) {
    LOG(FATAL) << "Base class called.";
  }
  void set_color(const VEC3F& color) {color_ = color;};
  virtual bool GetTrigger() {
    LOG(WARNING) << "Based called";
    return false;
  }
  virtual VEC3F getVelocityAt(const VEC3F& point) const {
    LOG(FATAL) << "Base called.";
  }
  virtual void setOmega(const float mouse_dx, const float mouse_dy,
                        const float pos_x, const float pos_y, const double dt) {
    return;
  }
protected:
  const VEC3I gridRes_;
  // Axis aligned boundingBox
  VEC3I AABBStart_;
  VEC3I AABBEnd_;
  const double dx_;
  VEC3F color_;
  
};


#endif  // OBSTACLE3D_3D_H
