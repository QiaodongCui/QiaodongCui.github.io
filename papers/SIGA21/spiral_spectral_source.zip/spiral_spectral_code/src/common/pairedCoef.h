#ifndef PAIRED_COEF_H
#define PAIRED_COEF_H

#include <glog/logging.h>

// first wavenumber can be half integer due to neumann, dirichlet bc.
struct pairedCoef {
  pairedCoef(int i1, int i2, int i3, double coef):i1x2(i1), i2x2(i2), i3x2(i3), coef(coef){
    ;
  }
  pairedCoef(){};

  int i1x2 = 0;
  int i2x2 = 0;
  int i3x2 = 0;
  double coef = 0.0;
  void debugPrint() const {
    LOG(INFO) << i1x2 << " " << i2x2 << " " << i3x2 << " " << coef;
  }
};

struct pairedCoef2 {
  pairedCoef2(int i1x2, int i2x2, double coef):i1x2_(i1x2), i2x2_(i2x2), coef_(coef){
    ;
  }
  pairedCoef2(){};

  int i1x2_ = 0;
  int i2x2_ = 0;
  double coef_ = 0.0;
};

struct pairedCoef3 {
  
  pairedCoef3(int i1x2, int i2x2, int i3x2, double coef):i1x2_(i1x2), i2x2_(i2x2), i3x2_(i3x2), coef_(coef) {
    ;
  }

  pairedCoef3(){};

  int i1x2_ = 0;
  int i2x2_ = 0;
  int i3x2_ = 0;
  double coef_ = 0.0;
};

struct pairedCoef3dv
{
  pairedCoef3dv(){};
  
  pairedCoef3dv(int i1x2, int i2x2, int i3x2, double coef, const double(&C)[3]):
  i1x2_(i1x2), i2x2_(i2x2), i3x2_(i3x2), coef_(coef) { 
    C_[0] = C[0];
    C_[1] = C[1];
    C_[2] = C[2];
  }

  int i1x2_ = 0;
  int i2x2_ = 0;
  int i3x2_ = 0;
  double coef_ = 0.0;
  double C_[3];
};

struct pairedCoef2d2 {
  pairedCoef2d2(int i1, int i2, double coef):i1_(i1), i2_(i2), coef_(coef){
    ;
  }
  pairedCoef2d2(){};

  int i1_ = 0;
  int i2_ = 0;
  double coef_ = 0.0;
};

#endif  // PAIRED_COEF_H