#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "tensorCompute/sphere2DTensor.h"
#include "polar_2D/sphere_basis_2D_all.h"
#include "polar_2D/sphere_basis_set_2D.h"
#include "util/timer.h"

namespace {

void test() {

const int phiK_ = 20;
const int thetaK_ = 20;

std::vector<spherePtrAll> all_basis_;

	  // Phi^0, Psi^0
  for (int j = 1; j < phiK_; j++) {
    // Psi^0
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        all_basis_.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2, 3)));
      }
    }
    for (int i = 1; i <= thetaK_; i++) { 
      // init, 2*wavenumber.
      all_basis_.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2*j, 0)));
    }
  }

  // Phi^1, Psi^1
  for (int j = 1; j < phiK_; j++) {
        
    // Psi^1
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        all_basis_.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2, 4)));
      }
    }

    for (int i = 1; i <= thetaK_; i++) {
      // Phi^1
      all_basis_.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2*j, 1)));
    }
  }


  for (int i = 1; i <= thetaK_; i++) {
    all_basis_.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 0, 2)));
  }



  const int numBasisAll_ = all_basis_.size();

Timer timer;
timer.Reset();
  LOG(INFO) << numBasisAll_;

  sphere2DTensor tensorEval;

  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
  	//LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const SphereBasis2DAll& basis_i = *all_basis_[i];
        const SphereBasis2DAll& basis_g = *all_basis_[g];
        const SphereBasis2DAll& basis_h = *all_basis_[h];
        volatile double Cigh = SphereBasis2DAll::computeTensorEntry(basis_i, basis_g, basis_h);
				const int idx = basis_i.index()*25 + basis_g.index()*5 + basis_h.index();
        double invWn = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
        volatile double Cnew = tensorEval.pointers_[idx](basis_i, basis_g, basis_h)*invWn;
        CHECK(fabs(Cigh -  Cnew) < 1e-6) << Cigh << " " << Cnew << " " << i << " " << g << " " << h;
      }
    }
  }
  LOG(INFO) << timer.ElapsedTimeInSeconds();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
	
	test();

  return 0;
}