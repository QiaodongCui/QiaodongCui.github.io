#ifndef LAPLACIAN_BASIS_SET_3D_H
#define LAPLACIAN_BASIS_SET_3D_H

#include <fstream>
#include <Eigen/Eigen>
#include <glog/logging.h>
#include <string>
#include <vector>

#include "3D/VECTOR3_FIELD_3D.h"
#include "Alg/VEC3.h"
#include "setting.h"
#include "util/util.h"

class LaplacianBasisSet3D {
  // des_basis_dim: desired basis_dimention.
public:
  LaplacianBasisSet3D(const int des_basis_dim, const int xRes, 
                      const int yRes, const int zRes, const std::string const_strategy,
                      const bool allocate_high_freq, const double low_freq_ratio):
                      des_basis_dim_(des_basis_dim),xRes_(xRes),
                      yRes_(yRes),zRes_(zRes), constant_init_strategy_(const_strategy),
                      allocate_high_freq_(allocate_high_freq), low_freq_ratio_(low_freq_ratio),
                      dxyz_(Eigen::Vector3d(M_PI / static_cast<double>(xRes),
                                            M_PI / static_cast<double>(yRes),
                                            M_PI / static_cast<double>(zRes)))
  {// initialize the number of actually allocated basis to zero.
    basis_dim_ = 0;
    int_type_const_strategy_ = -1;
    if (constant_init_strategy_ == "principle_x") {
      int_type_const_strategy_ = 0;
    } else if (constant_init_strategy_ == "principle_y") {
      int_type_const_strategy_ = 1;
    } else if (constant_init_strategy_ == "principle_z") {
      int_type_const_strategy_ = 2;
    } else if (constant_init_strategy_ == "random") {
      int_type_const_strategy_ = 3;
    } else if (constant_init_strategy_ == "uniform") {
      int_type_const_strategy_ = 4;
    } else {
      LOG(FATAL) << "Unknow constant_init_strategy: " << constant_init_strategy_;
    }
  }
  ~LaplacianBasisSet3D(){}
  virtual void FillBasisNumerical(
      const Eigen::VectorXd& coefficients, VECTOR3_FIELD_3D* field) = 0;
  virtual int AllocateAllBasis() = 0;
  
  virtual void InverseTramsformToVelocity(
      const Eigen::VectorXd& coefficients, VECTOR3_FIELD_3D* field) = 0;
  // Input a std::vector field, transform and output the basis coefficients.
  virtual void ForwardTransformtoFrequency(
      const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) = 0;
  // Verify the tensor is antisymmetric C_{ij}^k = - C_{ik}^j
  void VerifyAntisymmetric(const std::vector<Adv_Tensor_Type>& C);
  
  virtual void ComputeEigenValues(Eigen::VectorXd* eigenValue) = 0;
  
  virtual void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) = 0;
  // For Dirichlet basis, the type is 0, one Neumann wall is 1, two neumann wall is 2.
  virtual void WriteBasis(std::ofstream& out) = 0;
  virtual int ReadBasis(std::ifstream& infile) = 0;
  int GetBasisDim() const {return basis_dim_;}
  virtual double ComputeBasisAt(const VEC3I& pos, const int basis_idx, const int mode) const = 0;
  virtual void PrintDebugInfo(const Eigen::VectorXd& coefficients) = 0;
  virtual void ComputeBasisWeights(Eigen::VectorXd* weights) = 0;
  static void MultiplyweightTensor(std::vector<Adv_Tensor_Type>& C, const Eigen::VectorXd& weights);
protected:
  const int des_basis_dim_;
  int basis_dim_;
  const int xRes_;
  const int yRes_;
  const int zRes_;
  const std::string constant_init_strategy_;
  const bool allocate_high_freq_;
  const double low_freq_ratio_;
  const Eigen::Vector3d dxyz_;
  int int_type_const_strategy_;
};

#endif  // LAPLACIAN_BASIS_SET_3D_H
