/*
 This file is part of SSFR (Zephyr).
 
 Zephyr is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Zephyr is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Zephyr.  If not, see <http://www.gnu.org/licenses/>.
 
 Copyright 2013 Theodore Kim
 */
#ifndef GRID_3D_H
#define GRID_3D_H

#include <Eigen/Eigen>

#include <cmath>
#include <string>
#include <map>
#include <iostream>

#include "setting.h"
#include "Alg/VEC3.h"
#include "Alg/VECTOR.h"



template <class T>
class GRID_3D {
public:
  GRID_3D();
  GRID_3D(const int& xRes, const int& yRes, const int& zRes, const VEC3F& center = VEC3F(0,0,0), const VEC3F& lengths = VEC3F(1,1,1));
  GRID_3D(const GRID_3D& m);
  GRID_3D(const bool* data, const int& xRes, const int& yRes, const int& zRes);
  ~GRID_3D();

  // accessors
  inline T& operator()(int x, int y, int z) { 
    assert(z >= 0 && z < _zRes && y >= 0 && y < _yRes && x >= 0 && x < _xRes);
    return _data[z * _slabSize + y * _xRes + x]; 
  };
  const T operator()(int x, int y, int z) const { 
    assert(z >= 0 && z < _zRes && y >= 0 && y < _yRes && x >= 0 && x < _xRes);
    return _data[z * _slabSize + y * _xRes + x]; 
  };
  const T operator()(const VEC3F& position) const; 

  inline T& operator[](int x) { return _data[x]; };
  const T operator[](int x) const { return _data[x]; };
  T* data() { return _data; };
  T*& dataRef() { return _data; };
  const T* dataConst() const { return _data; };
  const int xRes() const { return _xRes; };
  const int yRes() const { return _yRes; };
  const int zRes() const { return _zRes; };
  VEC3F dxs() const { return VEC3F(_dx, _dy, _dz); };
  VEC3F invDxs() const { return VEC3F(_invDx, _invDy, _invDz); };
  const T dx() const { return _dx; };
  const T dy() const { return _dy; };
  const T dz() const { return _dz; };
  const T invDx() const { return _invDx; };
  const T invDy() const { return _invDy; };
  const T invDz() const { return _invDz; };
  const int slabSize() const { return _slabSize; };
  const VEC3F center() const { return _center; };
  const VEC3F lengths() const { return _lengths; };
  const int totalCells() const { return _totalCells; };
  const int outside() const { return _outside; };

  const int maxRes() const { return (_xRes > _yRes) ? ((_zRes > _xRes) ? _zRes : _xRes) : ((_zRes > _yRes) ? _zRes : _yRes); };

  // reset dimensions
  void setCenter(const VEC3F& center) { _center = center; };
  
  void clear();
  
  // T-valued cell center coordinates
  VEC3F cellCenter(int x, int y, int z) const;
  
  // overloaded operators
  GRID_3D& operator=(const T& alpha);
  GRID_3D& operator=(const GRID_3D& A);
  GRID_3D& operator*=(const T& alpha);
  GRID_3D& operator/=(const T& alpha);
  GRID_3D& operator+=(const T& alpha);
  GRID_3D& operator-=(const T& alpha);
  GRID_3D& operator-=(const GRID_3D& input);
  GRID_3D& operator+=(const GRID_3D& input);
  GRID_3D& operator*=(const GRID_3D& input);

  // BLAS-like interface, output += alpha * input
  void axpy(const T& alpha, const GRID_3D& input);
	
  void resizeAndWipe(int xRes, int yRes, int zRes, const VEC3F& center = VEC3F(0,0,0), const VEC3F& lengths = VEC3F(1,1,1));

  // what's the maximum resolution in any direction?
  int maxRes();
  
  // norms
  T max();
  T min();
  
  // sum of the entire field
  T sum();

  // std::vector of the field's dimesions
  VEC3F dims() const { return VEC3F(_xRes, _yRes, _zRes); };

  // field minimum
  T fieldMin();

  // field maximum
  T fieldMax();
  
  // field maximum cell index
  VEC3F maxIndex();

  // field minimum cell index
  VEC3F minIndex();

  // draw to OpenGL

  // copy out the boundary
  void copyBorderAll();

  // do a cubic Hermite interpolation, but turn off monotonic clamping
  static T cubicInterpUnclamped(const T interp, const T* points);
 
  // set a border of size 1 to zero
  void setZeroBorder();

  // swap the contents with another object
  void swapPointers(GRID_3D& field);

  // take the dot product with respect to another field
  T dot(const GRID_3D& input) const;

  // peel off the outer boundary of grid cells
  GRID_3D peelBoundary() const;

  // return a flattened array of all the field contents
  VECTOR flattened();
  Eigen::VectorXd flattenedEigen();

private:
  int _xRes;
  int _yRes;
  int _zRes;

  int _slabSize;
  int _totalCells;

  T* _data;

  // what fast marching considers "outside"
  int _outside;

  // center position of the grid
  VEC3F _center;

  // lengths of the x,y,z dimensions of the grid
  VEC3F _lengths;

  // physical lengths
  T _dx;
  T _dy;
  T _dz;

  T _invDx;
  T _invDy;
  T _invDz;
};

template <class T>
GRID_3D<T> operator^(const GRID_3D<T>& A, const T alpha);

template <class T>
GRID_3D<T> operator*(const GRID_3D<T>& A, const T alpha);

template <class T>
GRID_3D<T> operator/(const GRID_3D<T>& A, const T alpha);

template <class T>
GRID_3D<T> operator/(const GRID_3D<T>& A, const GRID_3D<T>& B);

template <class T>
GRID_3D<T> operator+(const GRID_3D<T>& A, const T alpha);

template <class T>
GRID_3D<T> operator*(const T alpha, const GRID_3D<T>& A);

template <class T>
GRID_3D<T> operator+(const T alpha, const GRID_3D<T>& A);

template <class T>
GRID_3D<T> operator-(const T alpha, const GRID_3D<T>& A);

template <class T>
GRID_3D<T> operator-(const GRID_3D<T>& A, const GRID_3D<T>& B);

template <class T>
GRID_3D<T> operator+(const GRID_3D<T>& A, const GRID_3D<T>& B);

template <class T>
GRID_3D<T> operator*(const GRID_3D<T>& A, const GRID_3D<T>& B);

#endif
