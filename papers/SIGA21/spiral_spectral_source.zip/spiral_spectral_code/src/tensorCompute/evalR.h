#ifndef EVAL_R_H
#define EVAL_R_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define SinR0 TrigInt::IntegralS_D2_ONE
#define CosR0 TrigInt::IntegralC_D2_ONE
#define SinR1 TrigInt::IntegralRS_D2_ONE
#define CosR1 TrigInt::IntegralRC_D2_ONE
#define SinR2 TrigInt::IntegralR2S_D2_ONE
#define CosR2 TrigInt::IntegralR2C_D2_ONE
#define SinR3 TrigInt::IntegralR3S_D2_ONE
#define CosR3 TrigInt::IntegralR3C_D2_ONE
#define SinR4 TrigInt::IntegralR4S_D2_ONE
#define CosR4 TrigInt::IntegralR4C_D2_ONE
#define SinR5 TrigInt::IntegralR5S_D2_ONE
#define CosR5 TrigInt::IntegralR5C_D2_ONE
#define SinR6 TrigInt::IntegralR6S_D2_ONE
#define CosR6 TrigInt::IntegralR6C_D2_ONE
#define SinR7 TrigInt::IntegralR7S_D2_ONE
#define CosR7 TrigInt::IntegralR7C_D2_ONE
#define SinR8 TrigInt::IntegralR28_D2_ONE
#define CosR8 TrigInt::IntegralR28_D2_ONE
#define SinR9 TrigInt::IntegralR29_D2_ONE
#define CosR9 TrigInt::IntegralR29_D2_ONE
#define Pi M_PI


class rEval{
public:
rEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~rEval(){};
/* r^2*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_0(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(g1x2-h1x2-i1x2)+CosR2(g1x2+h1x2-i1x2)-CosR2(g1x2-h1x2+i1x2)-CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_1(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(g1x2-h1x2-i1x2)+SinR3(g1x2+h1x2-i1x2)+SinR3(g1x2-h1x2+i1x2)-SinR3(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_2(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(g1x2-h1x2-i1x2)+SinR1(g1x2+h1x2-i1x2)+SinR1(g1x2-h1x2+i1x2)-SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_3(const int i1x2, const int g1x2, const int h1x2){
return (SinR3(g1x2-h1x2-i1x2)+SinR3(g1x2+h1x2-i1x2)+SinR3(g1x2-h1x2+i1x2)+SinR3(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_4(const int i1x2, const int g1x2, const int h1x2){
return (CosR4(g1x2-h1x2-i1x2)+CosR4(g1x2+h1x2-i1x2)-CosR4(g1x2-h1x2+i1x2)-CosR4(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_5(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(g1x2-h1x2-i1x2)-CosR2(g1x2+h1x2-i1x2)+CosR2(g1x2-h1x2+i1x2)-CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_6(const int i1x2, const int g1x2, const int h1x2){
return (CosR3(g1x2-h1x2-i1x2)+CosR3(g1x2+h1x2-i1x2)-CosR3(g1x2-h1x2+i1x2)-CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_7(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(g1x2-h1x2-i1x2)+SinR0(g1x2+h1x2-i1x2)+SinR0(g1x2-h1x2+i1x2)-SinR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_8(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(g1x2-h1x2-i1x2)+CosR1(g1x2+h1x2-i1x2)-CosR1(g1x2-h1x2+i1x2)-CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_9(const int i1x2, const int g1x2, const int h1x2){
return (SinR2(g1x2-h1x2-i1x2)+SinR2(g1x2+h1x2-i1x2)+SinR2(g1x2-h1x2+i1x2)+SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_10(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(g1x2-h1x2-i1x2)+SinR2(g1x2+h1x2-i1x2)+SinR2(g1x2-h1x2+i1x2)-SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_11(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(g1x2-h1x2-i1x2)-CosR1(g1x2+h1x2-i1x2)+CosR1(g1x2-h1x2+i1x2)-CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_12(const int i1x2, const int g1x2, const int h1x2){
return (-CosR1(g1x2-h1x2-i1x2)+CosR1(g1x2+h1x2-i1x2)+CosR1(g1x2-h1x2+i1x2)-CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_13(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(g1x2-h1x2-i1x2)+SinR2(g1x2+h1x2-i1x2)-SinR2(g1x2-h1x2+i1x2)+SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_14(const int i1x2, const int g1x2, const int h1x2){
return (-CosR3(g1x2-h1x2-i1x2)+CosR3(g1x2+h1x2-i1x2)+CosR3(g1x2-h1x2+i1x2)-CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_15(const int i1x2, const int g1x2, const int h1x2){
return (-CosR4(g1x2-h1x2-i1x2)+CosR4(g1x2+h1x2-i1x2)+CosR4(g1x2-h1x2+i1x2)-CosR4(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_16(const int i1x2, const int g1x2, const int h1x2){
return (-CosR2(g1x2-h1x2-i1x2)+CosR2(g1x2+h1x2-i1x2)+CosR2(g1x2-h1x2+i1x2)-CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_17(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(g1x2-h1x2-i1x2)+SinR3(g1x2+h1x2-i1x2)-SinR3(g1x2-h1x2+i1x2)+SinR3(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_18(const int i1x2, const int g1x2, const int h1x2){
return (CosR4(g1x2-h1x2-i1x2)+CosR4(g1x2+h1x2-i1x2)+CosR4(g1x2-h1x2+i1x2)+CosR4(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_19(const int i1x2, const int g1x2, const int h1x2){
return (-SinR3(g1x2-h1x2-i1x2)-SinR3(g1x2+h1x2-i1x2)+SinR3(g1x2-h1x2+i1x2)+SinR3(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_20(const int i1x2, const int g1x2, const int h1x2){
return (CosR3(g1x2-h1x2-i1x2)+CosR3(g1x2+h1x2-i1x2)+CosR3(g1x2-h1x2+i1x2)+CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_21(const int i1x2, const int g1x2, const int h1x2){
return (-SinR2(g1x2-h1x2-i1x2)-SinR2(g1x2+h1x2-i1x2)+SinR2(g1x2-h1x2+i1x2)+SinR2(g1x2+h1x2+i1x2))/4.;
};

/* r^0*1*/
static double evalR_22(const int i1x2, const int g1x2, const int h1x2){
return 1.0;
};

/* r^4*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_23(const int i1x2, const int g1x2, const int h1x2){
return (-SinR4(g1x2-h1x2-i1x2)-SinR4(g1x2+h1x2-i1x2)+SinR4(g1x2-h1x2+i1x2)+SinR4(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[g1*Pi*r]Sin[i1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_24(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(g1x2-h1x2-i1x2)+CosR0(g1x2+h1x2-i1x2)-CosR0(g1x2-h1x2+i1x2)-CosR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_25(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(g1x2-h1x2-i1x2)-SinR1(g1x2+h1x2-i1x2)+SinR1(g1x2-h1x2+i1x2)+SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^2*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_26(const int i1x2, const int g1x2, const int h1x2){
return (CosR2(g1x2-h1x2-i1x2)+CosR2(g1x2+h1x2-i1x2)+CosR2(g1x2-h1x2+i1x2)+CosR2(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_27(const int i1x2, const int g1x2, const int h1x2){
return (SinR1(g1x2-h1x2-i1x2)+SinR1(g1x2+h1x2-i1x2)+SinR1(g1x2-h1x2+i1x2)+SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[g1*Pi*r]Sin[h1*Pi*r]Sin[i1*Pi*r]*/
static double evalR_28(const int i1x2, const int g1x2, const int h1x2){
return (-SinR4(g1x2-h1x2-i1x2)+SinR4(g1x2+h1x2-i1x2)+SinR4(g1x2-h1x2+i1x2)-SinR4(g1x2+h1x2+i1x2))/4.;
};

/* r^3*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_29(const int i1x2, const int g1x2, const int h1x2){
return (CosR3(g1x2-h1x2-i1x2)-CosR3(g1x2+h1x2-i1x2)+CosR3(g1x2-h1x2+i1x2)-CosR3(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_30(const int i1x2, const int g1x2, const int h1x2){
return (-SinR4(g1x2-h1x2-i1x2)+SinR4(g1x2+h1x2-i1x2)-SinR4(g1x2-h1x2+i1x2)+SinR4(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[h1*Pi*r]Sin[i1*Pi*r]Cos[g1*Pi*r]*/
static double evalR_31(const int i1x2, const int g1x2, const int h1x2){
return (-CosR0(g1x2-h1x2-i1x2)+CosR0(g1x2+h1x2-i1x2)+CosR0(g1x2-h1x2+i1x2)-CosR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_32(const int i1x2, const int g1x2, const int h1x2){
return (-SinR1(g1x2-h1x2-i1x2)+SinR1(g1x2+h1x2-i1x2)-SinR1(g1x2-h1x2+i1x2)+SinR1(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_33(const int i1x2, const int g1x2, const int h1x2){
return (SinR4(g1x2-h1x2-i1x2)+SinR4(g1x2+h1x2-i1x2)+SinR4(g1x2-h1x2+i1x2)+SinR4(g1x2+h1x2+i1x2))/4.;
};

/* r^4*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_34(const int i1x2, const int g1x2, const int h1x2){
return (CosR4(g1x2-h1x2-i1x2)-CosR4(g1x2+h1x2-i1x2)+CosR4(g1x2-h1x2+i1x2)-CosR4(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[i1*Pi*r]Cos[g1*Pi*r]Cos[h1*Pi*r]*/
static double evalR_35(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(g1x2-h1x2-i1x2)-SinR0(g1x2+h1x2-i1x2)+SinR0(g1x2-h1x2+i1x2)+SinR0(g1x2+h1x2+i1x2))/4.;
};

/* r^1*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_36(const int i1x2, const int g1x2, const int h1x2){
return (CosR1(g1x2-h1x2-i1x2)+CosR1(g1x2+h1x2-i1x2)+CosR1(g1x2-h1x2+i1x2)+CosR1(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[g1*Pi*r]Sin[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_37(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(g1x2-h1x2-i1x2)-CosR0(g1x2+h1x2-i1x2)+CosR0(g1x2-h1x2+i1x2)-CosR0(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_38(const int i1x2, const int g1x2, const int h1x2){
return (SinR0(g1x2-h1x2-i1x2)+SinR0(g1x2+h1x2-i1x2)+SinR0(g1x2-h1x2+i1x2)+SinR0(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Sin[h1*Pi*r]Cos[g1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_39(const int i1x2, const int g1x2, const int h1x2){
return (-SinR0(g1x2-h1x2-i1x2)+SinR0(g1x2+h1x2-i1x2)-SinR0(g1x2-h1x2+i1x2)+SinR0(g1x2+h1x2+i1x2))/4.;
};

/* r^0*Cos[g1*Pi*r]Cos[h1*Pi*r]Cos[i1*Pi*r]*/
static double evalR_40(const int i1x2, const int g1x2, const int h1x2){
return (CosR0(g1x2-h1x2-i1x2)+CosR0(g1x2+h1x2-i1x2)+CosR0(g1x2-h1x2+i1x2)+CosR0(g1x2+h1x2+i1x2))/4.;
};

};

#endif // EVAL_R_H