#include <Eigen/Eigen>
#include <fftw3.h>
#include <fstream>
#include <iomanip>
#include <glog/logging.h>
#include <unordered_map>
#include <memory>

#include "common/basic_function.h"
#include "common/basis_set.h"
#include "common/particle_sph_3d.h"
#include "3D/FIELD_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "polar_2D/torus_basis_2D.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/torus_basis_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"
#include "util/read_write_tensor.h"
#include "util/transform.h"
#include "util/timer.h"

using namespace std;

// Get some value from the grid.
#define GET_GRID(grid, idx3, idx2, idx1, stride2, stride1, mult, valAssign)\
  if ((idx3) >= 0 && (idx2) >= 0 && (idx1) >= 0)\
    valAssign += grid[(idx3) + (idx2)*(stride2) + (idx1)*(stride1)]*(mult);

// Put some value to grid.
#define PUT_GRID(grid, idx3, idx2, idx1, stride2, stride1, mult, valAssign)\
  if ((idx3) >= 0 && (idx2) >= 0 && (idx1) >= 0)\
    grid[(idx3) + (idx2)*(stride2) + (idx1)*(stride1)] += valAssign*(mult);

#define MGSORTHORUN Eigen::MatrixXd Coef;\
int m = 1;\
vector<basisPtr3DTor> allocated;\
runMGS(thresh, tempBuffer, allocated, Coef, m);\
all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
Coefs.push_back(Coef.topLeftCorner(m,m));

void TorusBasisSet3D::allocateMGS() {
 // we have 6 different modes.
  //phiCoef_.resize(10);
  vector<Eigen::MatrixXd> Coefs;
  const double thresh = 0.2;

  // allocate Phi^0, Psi^2, Psi^5
  for (int i3 = 1; i3 < phiK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {
      vector<basisPtr3DTor> tempBuffer;

      if (i2 == 1) {
        // Phi^6
        for (int i1 = 1; i1 < rK_; i1++) {
          tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 6, a_)));
        }
        // Phi^4
        for (int i1 = 1; i1 < rK_; i1++) {
          tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 4, a_)));
        }
        // Phi^2
        for (int i1 = 1; i1 < rK_; i1++) {
          tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2 - 1, i3*2, 2, a_)));
        }
      }

      // Phi^0
      for (int i1 = 1; i1 < rK_; i1++) {
        tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2, i3*2, 0, a_)));
      }
      // Run MGS, reject basis, and collect coefficients.
      MGSORTHORUN;
    }

  for (int i3 = 1; i3 < phiK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {

      vector<basisPtr3DTor> tempBuffer;
      
      if (i2 == 1) {
        // Phi^7
        for (int i1 = 1; i1 < rK_; i1++) {
          tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 7, a_)));
        }
        
        // Phi^5
        for (int i1 = 1; i1 < rK_; i1++) {
          tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 5, a_)));
        }
        
        // Phi^3
        for (int i1 = 1; i1 < rK_; i1++) {
          tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2 - 1, i3*2, 3, a_)));
        }
      }

      // Phi^1
      for (int i1 = 1; i1 < rK_; i1++) {
        tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2, i3*2, 1, a_)));
      }
      // Run MGS, reject basis, and collect coefficients.
      MGSORTHORUN;
    }

    for (int i2 = 1; i2 < thetaK_; i2++) {
      vector<basisPtr3DTor> tempBuffer;
      // Phi^9
      for (int i1 = 1; i1 < rK_; i1++) {
        tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(2*i1 - 2, i2 - 1, 0, 9, a_)));
      }
      // Phi^8
      for (int i1 = 1; i1 < rK_; i1++) {
        tempBuffer.push_back(basisPtr3DTor(new TorusBasis3D(2*i1 - 2, i2, 0, 8, a_)));
      }
      // Run MGS, reject basis, and collect coefficients.
      MGSORTHORUN;
    }

  initPhiCoef();
  numBasisAll_ = all_basis_.size();
  numBasisOrtho_ = all_basis_.size();
  LOG(INFO) << "total number of basis " << numBasisAll_;
  LOG(INFO) << "total number of ortho basis: " << numBasisOrtho_;

 // Assemble global coefficient matrix.
  A_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
  int colIdx = 0;
  // Square matrices.
  for (int i = 0; i < Coefs.size(); i++) {
    int curSize = Coefs[i].rows();
    A_.block(colIdx, colIdx, curSize, curSize) = Coefs[i];
    colIdx += curSize;
  }
}

void TorusBasisSet3D::initPhiCoef() {
  for (int i = 0; i < 10; i++) {
    vector<pairedCoef> coefs;
    phiCoef_.push_back(coefs);
  }
  // init phiCoef
  for (int i = 0; i < all_basis_.size(); i++) {
    int idx = all_basis_[i]->index();
    int i1x2 = all_basis_[i]->WN1x2();
    int i2x2 = all_basis_[i]->WN2x2();
    int i3x2 = all_basis_[i]->WN3x2();
    pairedCoef coef(i1x2, i2x2, i3x2, 0.0);
    phiCoef_[idx].push_back(coef);
  }
}

void TorusBasisSet3D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[index][Coefidx[index]].coef = fieldCoef[i]*C_x;
    Coefidx[index]++;
  }
}

void TorusBasisSet3D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  fieldCoef.setZero();
  vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    // 0.125 comes from 2 factor from foward dcts. This funcion assumes doing dcts along three
    // directions.
    double C_x = all_basis_[i]->GetInvNorm()*0.125;
    fieldCoef[i] += phiCoef_[index][Coefidx[index]].coef*C_x*dR_*dTheta_*dPhi_;
    Coefidx[index]++;
  }
}

void TorusBasisSet3D::allocateTemp() {
  totalSize_ = nTheta_*nPhi_*nR_;

  invTotalSize_ = 1.0 / totalSize_;
  dR_ = 1.0 / nR_;
  dTheta_ = 2.0*M_PI / nTheta_;
  dPhi_ = 2.0*M_PI / nPhi_;
  
  nPhiE_ = phiK_*2 + 4;
  nThetaE_ = thetaK_*2 + 4;

  // these are used for principle basis functions.
  inTemp_ = (double*) fftw_malloc(sizeof(double)*nR_*nThetaE_*nPhiE_);
  memset(inTemp_, 0x00, sizeof(double)*nR_*nThetaE_*nPhiE_);
  pointerSize_[inTemp_] = nR_*nThetaE_*nPhiE_;
  
  inTemp1_ = (double*) fftw_malloc(sizeof(double)*nR_*nThetaE_*nPhiE_);
  memset(inTemp1_, 0x00, sizeof(double)*nR_*nThetaE_*nPhiE_);
  pointerSize_[inTemp1_] = nR_*nThetaE_*nPhiE_;

  inTemp2_ = (double*) fftw_malloc(sizeof(double)*nR_*nThetaE_*nPhiE_);
  memset(inTemp2_, 0x00, sizeof(double)*nR_*nThetaE_*nPhiE_);
  pointerSize_[inTemp2_] = nR_*nThetaE_*nPhiE_;

  tTemp_ = (double*) fftw_malloc(sizeof(double)* nR_*nTheta_*nPhiE_);
  memset(tTemp_, 0x00, sizeof(double)*nR_*nTheta_*nPhiE_);
  pointerSize_[tTemp_] = nR_*nTheta_*nPhiE_;

  pTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(pTemp_, 0x00, sizeof(double)*totalSize_);
  pointerSize_[pTemp_] = totalSize_;

  temp0_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(temp0_, 0x00, sizeof(double)*totalSize_);
  pointerSize_[temp0_] = totalSize_;

  vrTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(vrTemp_, 0x00, sizeof(double)*totalSize_);
  pointerSize_[vrTemp_] = totalSize_;

  vtTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(vtTemp_, 0x00, sizeof(double)*totalSize_);
  pointerSize_[vtTemp_] = totalSize_;

  vpTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(vpTemp_, 0x00, sizeof(double)*totalSize_);
  pointerSize_[vpTemp_] = totalSize_;

  int rpRsize = 2*nR_;
  rPTemp_ = (double*) fftw_malloc(sizeof(double)*rpRsize*nPhiE_);
  memset(rPTemp_, 0x00, sizeof(double)*rpRsize*nPhiE_);
  pointerSize_[rPTemp_] = rpRsize*nPhiE_;

  rPTemp1_ = (double*) fftw_malloc(sizeof(double)*rpRsize*nPhiE_);
  memset(rPTemp1_, 0x00, sizeof(double)*rpRsize*nPhiE_);
  pointerSize_[rPTemp1_] = rpRsize*nPhiE_;

  cosTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  memset(cosTVal_, 0x00, sizeof(double)*nTheta_);
  pointerSize_[cosTVal_] = nTheta_;

  sinTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  memset(sinTVal_, 0x00, sizeof(double)*nTheta_);
  pointerSize_[sinTVal_] = nTheta_;

  for (int j = 0; j < nTheta_; j++) {
    const double t = ((double)(j) + 0.5)*dTheta_;
    sinTVal_[j] = sin(t);
    cosTVal_[j] = cos(t);
  }

  rTTemp_ = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
  memset(rTTemp_, 0x00, sizeof(double)*nR_*nTheta_);
  pointerSize_[rTTemp_] = nR_*nTheta_;

  rTTemp1_ = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
  memset(rTTemp1_, 0x00, sizeof(double)*nR_*nTheta_);
  pointerSize_[rTTemp1_] = nR_*nTheta_;

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    double k3 = all_basis_[i]->WN3D();
    waveNum2_[i] = k1*k1 + k2*k2 + k3*k3;
  }
}

void TorusBasisSet3D::setUpFFTWPlan() {
  fftw_r2r_kind invS_ = FFTW_RODFT01;
  fftw_r2r_kind invC_ = FFTW_REDFT01;
  fftw_r2r_kind fwdS_ = FFTW_RODFT10;
  fftw_r2r_kind fwdC_ = FFTW_REDFT10;

  // full plans are all 2D plans,
  // R plan only covers a nr*nz slice, need to run nT times. 
  // T plan only covers a nz*nt slice, need to run nR times.
  // stride, dist
  //int howManyR = nPhi_;
  int nr[1] = {nR_};
  
  nPhiE_ = phiK_*2 + 4;
  // Need to be executed thetaK_*2 times
  IsinRE_ = fftw_plan_many_r2r(1, nr, nPhiE_, inTemp_, nr, nPhiE_*nThetaE_, 1, inTemp_, nr, nPhiE_*nThetaE_, 1, &invS_, FFTW_MEASURE);
  IcosRE_ = fftw_plan_many_r2r(1, nr, nPhiE_, inTemp_, nr, nPhiE_*nThetaE_, 1, inTemp_, nr, nPhiE_*nThetaE_, 1, &invC_, FFTW_MEASURE);
  FsinRE_ = fftw_plan_many_r2r(1, nr, nPhiE_, inTemp_, nr, nPhiE_*nThetaE_, 1, inTemp_, nr, nPhiE_*nThetaE_, 1, &fwdS_, FFTW_MEASURE);
  FcosRE_ = fftw_plan_many_r2r(1, nr, nPhiE_, inTemp_, nr, nPhiE_*nThetaE_, 1, inTemp_, nr, nPhiE_*nThetaE_, 1, &fwdC_, FFTW_MEASURE);
  
  // 2D plans on 3D grid
  int nr1[1] = {2*nR_};
  IsinR2D_ = fftw_plan_many_r2r(1, nr1, nPhiE_, rPTemp_, nr1, nPhiE_, 1, rPTemp_, nr1, nPhiE_, 1, &invS_, FFTW_MEASURE);
  IcosR2D_ = fftw_plan_many_r2r(1, nr1, nPhiE_, rPTemp_, nr1, nPhiE_, 1, rPTemp_, nr1, nPhiE_, 1, &invC_, FFTW_MEASURE);
  FsinR2D_ = fftw_plan_many_r2r(1, nr1, nPhiE_, rPTemp_, nr1, nPhiE_, 1, rPTemp_, nr1, nPhiE_, 1, &fwdS_, FFTW_MEASURE);
  FcosR2D_ = fftw_plan_many_r2r(1, nr1, nPhiE_, rPTemp_, nr1, nPhiE_, 1, rPTemp_, nr1, nPhiE_, 1, &fwdC_, FFTW_MEASURE);

  int howManyT = nPhi_;
  int nt_[1] = {nTheta_};
  // these are plans for one slice. Because the idist parameter varies when changing from one slice to another.
  // i.e. the idist should be 1, for one slice, but the pointer need to move nTheta_*nPhi_ when moves to next slice.
  // it's unclear how to bake this as one transformations like r and p directions.
  // Same as the guru plan.
  IsinTE_ = fftw_plan_many_r2r(1, nt_, nPhiE_, tTemp_, nt_, nPhiE_, 1, tTemp_, nt_, nPhiE_, 1, &invS_, FFTW_MEASURE);
  IcosTE_ = fftw_plan_many_r2r(1, nt_, nPhiE_, tTemp_, nt_, nPhiE_, 1, tTemp_, nt_, nPhiE_, 1, &invC_, FFTW_MEASURE);
  FsinTE_ = fftw_plan_many_r2r(1, nt_, nPhiE_, tTemp_, nt_, nPhiE_, 1, tTemp_, nt_, nPhiE_, 1, &fwdS_, FFTW_MEASURE);
  FcosTE_ = fftw_plan_many_r2r(1, nt_, nPhiE_, tTemp_, nt_, nPhiE_, 1, tTemp_, nt_, nPhiE_, 1, &fwdC_, FFTW_MEASURE);

  // plans along z direction.
  int howManyZ = nR_*nTheta_;
  int np_[1] = {nPhi_};

  // P plan is full 3D.
  IsinP_ = fftw_plan_many_r2r(1, np_, howManyZ, pTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &invS_, FFTW_MEASURE);
  IcosP_ = fftw_plan_many_r2r(1, np_, howManyZ, pTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &invC_, FFTW_MEASURE);
  FsinP_ = fftw_plan_many_r2r(1, np_, howManyZ, pTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &fwdS_, FFTW_MEASURE);
  FcosP_ = fftw_plan_many_r2r(1, np_, howManyZ, pTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &fwdC_, FFTW_MEASURE);

  // use for 
  IcosRsinT_ = fftw_plan_r2r_2d(nR_, nTheta_, rTTemp_, rTTemp_, invC_, invS_, FFTW_MEASURE);
  IcosRcosT_ = fftw_plan_r2r_2d(nR_, nTheta_, rTTemp_, rTTemp_, invC_, invC_, FFTW_MEASURE);
  FcosRsinT_ = fftw_plan_r2r_2d(nR_, nTheta_, rTTemp_, rTTemp_, fwdC_, fwdS_, FFTW_MEASURE);
  FcosRcosT_ = fftw_plan_r2r_2d(nR_, nTheta_, rTTemp_, rTTemp_, fwdC_, fwdC_, FFTW_MEASURE);
}

void TorusBasisSet3D::TransR(fftw_plan rPlan, double* in, double* out) {
  for (int i = 0; i < nThetaE_ && i < nTheta_; i++)
    fftw_execute_r2r(rPlan, &in[i*nPhiE_], &out[i*nPhiE_]);
}

void TorusBasisSet3D::TransT(fftw_plan tPlan, double* in, double* out) {
  // need to run nR_ because r is currently filled.
  for (int i = 0; i < nR_; i++)
    fftw_execute_r2r(tPlan, &in[i*nTheta_*nPhiE_], &out[i*nTheta_*nPhiE_]);
}

// move grid in of size nR_*nThetaE_*nPhiE_ to grid out of size nR_*nTheta_*nPhiE_ 
void TorusBasisSet3D::moveInToTgrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nThetaE_; j++)
      memcpy(&out[j*nPhiE_ + k*nTheta_*nPhiE_], &in[j*nPhiE_ + k*nThetaE_*nPhiE_], sizeof(double)*nPhiE_);
}

void TorusBasisSet3D::moveTToIngrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nThetaE_; j++)
      memcpy(&out[j*nPhiE_ + k*nThetaE_*nPhiE_], &in[j*nPhiE_ + k*nTheta_*nPhiE_], sizeof(double)*nPhiE_);
}

// move grid in of size nR_*nTheta_*nPhiE_  to grid out of full size
void TorusBasisSet3D::moveTtoPGrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      memcpy(&out[j*nPhi_ + k*nThetaPhi_], &in[j*nPhiE_ + k*nTheta_*nPhiE_], sizeof(double)*nPhiE_);
}

void TorusBasisSet3D::movePtoTGrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      memcpy(&out[j*nPhiE_ + k*nTheta_*nPhiE_], &in[j*nPhi_ + k*nThetaPhi_], sizeof(double)*nPhiE_);
}

// sum grid in of size nR_*nTheta_*nPhiE_  to grid out of full size
void TorusBasisSet3D::sumTtoPGrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhiE_; i++)
        out[j*nPhi_ + k*nThetaPhi_ + i] += in[j*nPhiE_ + k*nTheta_*nPhiE_ + i];
}

// copy a R-Z 2d slice to full 3D grid, used for phi^2-3
void TorusBasisSet3D::add2DSliceToFull(const int offset, const double* slice2D, double* out) {
  // phi2 shares rest transformations with phi0
  // int zRange = nPhiE_;
  // need to copy to the right slice... 2*zStride because we have cos(t).
  int offsetT = offset*nPhiE_;
  for (int k = 0; k < nR_; k++)
    for (int i = 0; i < nPhiE_; i++) {
      out[i + offsetT + k*nTheta_*nPhiE_] += slice2D[i + k*nPhiE_];
    }
}

void TorusBasisSet3D::extract2DSliceToFull(const int offset, const double* in, double* slice2D) {
  // phi2 shares rest transformations with phi0
  // need to copy to the right slice... 2*zStride because we have cos(t).
  int offsetT = offset*nPhiE_;
  for (int k = 0; k < nR_; k++)
    for (int i = 0; i < nPhiE_; i++) {
      slice2D[i + k*nPhiE_] += in[i + offsetT + k*nTheta_*nPhiE_];
    }
}

void TorusBasisSet3D::InverseTransformVR() {

  clearPointer(vrTemp_);
  clearPointer(inTemp_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  
  Eigen::Map<Eigen::VectorXd> vrTempV(vrTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> temp0V(temp0_, totalSize_);

  const int divdR = 2;  // dirichlet, should divide by 2.
  const int divR23 = 1;  // dirichlet, should divide by 2.

  // Phi^0
  for (const auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2 - 1), p.i2x2, (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i2*i3, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  for (const auto& p : phiCoef_[6]) {
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  add2DSliceToFull(2, rPTemp_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, pTemp_);

  clearPointer(inTemp_);
  clearPointer(tTemp_);

  // Phi^2
  for (const auto& p : phiCoef_[2]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2-1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i2*i3, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  //-----
  clearPointer(rPTemp_);

  // Phi^4 rPTemp_
  for (const auto& p : phiCoef_[4]) {
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  add2DSliceToFull(1, rPTemp_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, pTemp_);

  fftw_execute_r2r(IsinP_, pTemp_, vrTemp_);

// the other part where IcosP-------------------------------------------------
//----------------------------------------------------------------------------

  clearPointer(inTemp_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  clearPointer(temp0_);

  // Phi^1
  for (const auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2), (p.i2x2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i2*i3, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  for (const auto& p : phiCoef_[7]) {
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  add2DSliceToFull(2, rPTemp_, tTemp_);


  TransT(IcosTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, pTemp_);

  clearPointer(inTemp_);
  clearPointer(tTemp_);
  // Phi^3
  for (const auto& p : phiCoef_[3]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2), (p.i2x2 - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i2*i3, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  for (const auto& p : phiCoef_[5]) {
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  add2DSliceToFull(1, rPTemp_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, pTemp_);

  fftw_execute_r2r(IcosP_, pTemp_, temp0_);

  // add to total.
  vrTempV += temp0V;

}

// weight by r along the radial, only used by phi4D and phi4A
void TorusBasisSet3D::weightR(double* f) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nThetaE_; j++)
    for (int i = 0; i < nPhiE_; i++) {
      double r = ((double)(k) + 0.5)*dR_;
      f[i + j*nPhiE_ + k*nPhiE_*nThetaE_] *= r;
    }
}

void TorusBasisSet3D::weightR2D(double *f) {
  for (int k = 0; k < nR_; k++)
    for (int i = 0; i < nPhiE_; i++) {
      double r = ((double)(k) + 0.5)*dR_;
      f[i + k*nPhiE_] *= r;
    }
}

void TorusBasisSet3D::InverseTransformVT() {
  clearPointer(vtTemp_);
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);

  Eigen::Map<Eigen::VectorXd> inTempV(inTemp_, pointerSize_[inTemp_]);
  Eigen::Map<Eigen::VectorXd> inTemp1V(inTemp1_, pointerSize_[inTemp1_]);
  Eigen::Map<Eigen::VectorXd> pTempV(pTemp_, pointerSize_[pTemp_]);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, pointerSize_[vtTemp_]);
  
  const int divdR = 2;  // dirichlet, should divide by 2.
  const int divR23 = 1;  // dirichlet, should divide by 2.

  // Phi^0
  for (const auto& p : phiCoef_[0]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2 - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, -i3, p.coef);
    PUT_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2 - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -i3*i1*M_PI, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  // Phi^6 rPTemp_
  for (const auto& p : phiCoef_[6]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, -i3, p.coef);
    PUT_GRID(rPTemp1_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, i3*i1*M_PI, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(IsinR2D_, rPTemp1_, rPTemp1_);
  weightR2D(rPTemp1_);
  add2DSliceToFull(1, rPTemp_, tTemp_);
  add2DSliceToFull(1, rPTemp1_, tTemp_);


  TransT(IsinTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, pTemp_);

  // Phi^2
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  for (const auto& p : phiCoef_[2]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i3, p.coef);
    PUT_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, i3*i1*M_PI, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  // Phi^4 rPTemp_
  for (const auto& p : phiCoef_[4]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
    PUT_GRID(rPTemp1_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, -i3*i1*M_PI, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(IsinR2D_, rPTemp1_, rPTemp1_);
  weightR2D(rPTemp1_);
  add2DSliceToFull(2, rPTemp_, tTemp_);
  add2DSliceToFull(2, rPTemp1_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, pTemp_);

  fftw_execute_r2r(IsinP_, pTemp_, vtTemp_);

// the other part where IcosP-------------------------------------------------
//----------------------------------------------------------------------------
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  // Phi^1
  for (const auto& p : phiCoef_[1]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2), (p.i2x2 - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, -i3, p.coef);
    PUT_GRID(inTemp1_, (p.i3x2), (p.i2x2 - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -i3*i1*M_PI, p.coef);
  } 
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);
  
  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  // Phi^7 rPTemp_
  for (const auto& p : phiCoef_[7]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, -i3, p.coef);
    PUT_GRID(rPTemp1_, (p.i3x2), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, i3*i1*M_PI, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(IsinR2D_, rPTemp1_, rPTemp1_);
  weightR2D(rPTemp1_);
  add2DSliceToFull(1, rPTemp_, tTemp_);
  add2DSliceToFull(1, rPTemp1_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, pTemp_);

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  // Phi^3
  for (const auto& p : phiCoef_[3]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(inTemp_, (p.i3x2), (p.i2x2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i3, p.coef);
    PUT_GRID(inTemp1_, (p.i3x2), (p.i2x2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, i3*i1*M_PI, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  // Phi^5 rPTemp_
  for (const auto& p : phiCoef_[5]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
    PUT_GRID(rPTemp1_, (p.i3x2), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, -i3*i1*M_PI, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(IsinR2D_, rPTemp1_, rPTemp1_);
  weightR2D(rPTemp1_);
  add2DSliceToFull(2, rPTemp_, tTemp_);
  add2DSliceToFull(2, rPTemp1_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, pTemp_);

  fftw_execute_r2r(IcosP_, pTemp_, pTemp_);
  vtTempV += pTempV;
}

void TorusBasisSet3D::weightT(const double* wf_, double* f) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhiE_; i++)
        f[i + j*nPhiE_ + k*nTheta_*nPhiE_] *= wf_[j];
}

void TorusBasisSet3D::InverseTransformVP() {
  clearPointer(vpTemp_);
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(inTemp2_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);

  Eigen::Map<Eigen::VectorXd> inTempV(inTemp_, pointerSize_[inTemp_]);
  Eigen::Map<Eigen::VectorXd> inTemp1V(inTemp1_, pointerSize_[inTemp1_]);
  Eigen::Map<Eigen::VectorXd> inTemp2V(inTemp2_, pointerSize_[inTemp2_]);
  Eigen::Map<Eigen::VectorXd> pTempV(pTemp_, pointerSize_[pTemp_]);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, pointerSize_[vpTemp_]);
  
  const int divdR = 2;  // dirichlet, should divide by 2.
  const int divR23 = 1;  // dirichlet, should divide by 2.

  // Cos[t]*Sin[i2*t] = 1/2 (Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  // Sin[t]*Cos[i2*t] = 1/2 (-Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  // Phi^0
  for (const auto& p : phiCoef_[0]) {
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    int coefMinus = (p.i2x2 - 2) < 0 ? -1 : 1;

    PUT_GRID(inTemp_, (p.i3x2), (p.i2x2 + 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (-0.5 + 0.5*i2), p.coef);
    if ((p.i2x2 - 2) != 0)
      PUT_GRID(inTemp_, (p.i3x2), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (-0.5*coefMinus -0.5*i2*coefMinus), p.coef);

    PUT_GRID(inTemp1_, (p.i3x2), (p.i2x2 + 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI, p.coef);
    if ((p.i2x2 - 2) != 0)
      PUT_GRID(inTemp1_, (p.i3x2), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI*coefMinus, p.coef);
  }

  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);


  clearPointer(rPTemp_);
  // 1/2 Sin[2 t]
  for (const auto& p : phiCoef_[6]) {
    double i1 = p.i1x2*0.5;
    rPTemp_[p.i3x2 + (p.i1x2/divR23 - 1)*nPhiE_] += 0.5*i1*M_PI*p.coef;
  }
  fftw_execute_r2r(IsinR2D_, rPTemp_, rPTemp_);
  weightR2D(rPTemp_);
  add2DSliceToFull(3, rPTemp_, tTemp_);


  TransT(IsinTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, pTemp_);

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);

  // Cos[t]*Cos[i2*t] = 1/2 (Cos[(i2 - 1)t] + Cos[(i2 + 1)t])
  // Sin[t]*Sin[i2*t] = 1/2 (Cos[(i2 - 1)t] - Cos[(i2 + 1)t])
  // Phi^2
  for (const auto& p : phiCoef_[2]) {
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    double coefMinus = p.i2x2 == 2 ? 2.0 : 1.0;  // This part is tricky because the first wavenumber can go to zero.
    PUT_GRID(inTemp_, (p.i3x2), (p.i2x2 + 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (0.5-0.5*i2), p.coef);
    if (p.i2x2 != 0)  // if this happens, the other part alreay have the correct results.
      PUT_GRID(inTemp_, (p.i3x2), abs(p.i2x2 - 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (0.5*coefMinus + 0.5*i2*coefMinus), p.coef);
   
    PUT_GRID(inTemp1_, (p.i3x2), (p.i2x2 + 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI, p.coef);
    if (p.i2x2 != 0)
      PUT_GRID(inTemp1_, (p.i3x2), abs(p.i2x2 - 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI*coefMinus, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  // Phi^4 rPTemp_
  // Cos[t]^2 = 1/2 (1 + Cos[2 t])
  // need to multiply by 2 to keep consistient, because DCT do not weight the DC term by 2
  for (const auto& p : phiCoef_[4]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    rPTemp_[p.i3x2 + (p.i1x2/divR23)*nPhiE_] += 2.0*p.coef;
    rPTemp1_[p.i3x2 + (p.i1x2/divR23 - 1)*nPhiE_] += -i1*M_PI*p.coef;
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(IsinR2D_, rPTemp1_, rPTemp1_);
  weightR2D(rPTemp1_);
  add2DSliceToFull(0, rPTemp_, tTemp_);
  add2DSliceToFull(0, rPTemp1_, tTemp_);
  for (int i = 0; i < pointerSize_[rPTemp1_]; i++)
    rPTemp1_[i] *= 0.5;
  add2DSliceToFull(4, rPTemp1_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, pTemp_);
  
  clearPointer(rTTemp_);
  // Phi^8
  for (const auto& p : phiCoef_[8]) {
    PUT_GRID(rTTemp_, (p.i2x2 - 1), (p.i1x2/divdR), 0, nTheta_, 0, 1.0, p.coef);
  }
  fftw_execute_r2r(IcosRsinT_, rTTemp_, rTTemp_);

  clearPointer(rTTemp1_);
  // Phi^9
  for (const auto& p : phiCoef_[9]) {
    PUT_GRID(rTTemp1_, (p.i2x2), (p.i1x2/divdR), 0, nTheta_, 0, 1.0, p.coef);
  }
  fftw_execute_r2r(IcosRcosT_, rTTemp1_, rTTemp1_);

  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
        pTemp_[0 + j*nPhi_ + k*nThetaPhi_] += rTTemp_[j + k*nTheta_] + rTTemp1_[j + k*nTheta_];

  fftw_execute_r2r(IcosP_, pTemp_, vpTemp_);


// the other part where IsinP-------------------------------------------------
//----------------------------------------------------------------------------
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  // Phi^1
  // Cos[t]*Sin[i2*t] = 1/2 (Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  // Sin[t]*Cos[i2*t] = 1/2 (-Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  for (const auto& p : phiCoef_[1]) {  // This is the same as Phi^0 except the sign is flipped
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    int coefMinus = (p.i2x2 - 2) < 0 ? -1 : 1;
    PUT_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2 + 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, 0.5 - 0.5*i2, p.coef);
    if ((p.i2x2 - 2) != 0)
      PUT_GRID(inTemp_, (p.i3x2 - 1), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, 0.5*coefMinus + 0.5*i2*coefMinus, p.coef);

    PUT_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2 + 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI, p.coef);
    if ((p.i2x2 - 2) != 0)
      PUT_GRID(inTemp1_, (p.i3x2 - 1), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI*coefMinus, p.coef);
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  // 1/2 Sin[2 t]
  for (const auto& p : phiCoef_[7]) {
    double i1 = p.i1x2*0.5;
    rPTemp_[p.i3x2 - 1 + (p.i1x2/divR23 - 1)*nPhiE_] += -0.5*i1*M_PI*p.coef;
  }
  fftw_execute_r2r(IsinR2D_, rPTemp_, rPTemp_);
  weightR2D(rPTemp_);
  add2DSliceToFull(3, rPTemp_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, pTemp_);

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  // Phi^3
  for (const auto& p : phiCoef_[3]) {
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    double coefMinus = p.i2x2 == 2 ? 2.0 : 1.0;  // This part is tricky because the first wavenumber can go to zero.
    PUT_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2 + 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (-0.5 + 0.5*i2), p.coef);
    if (p.i2x2 != 0)  // if this happens, the other part alreay have the correct results.
      PUT_GRID(inTemp_, (p.i3x2 - 1), abs(p.i2x2 - 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (-0.5 -0.5*i2)*coefMinus, p.coef);
   
    PUT_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2 + 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI, p.coef);
    if (p.i2x2 != 0)
      PUT_GRID(inTemp1_, (p.i3x2 - 1), abs(p.i2x2 - 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI*coefMinus, p.coef);

  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);
  weightR(inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  // Phi^5 rPTemp_
  // Cos[t]^2 = 1/2 (1 + Cos[2 t])
  // need to multiply by 2 to keep consistient, because DCT do not weight the DC term by 2
  for (const auto& p : phiCoef_[5]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    PUT_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, -2.0, p.coef);
    PUT_GRID(rPTemp1_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, i1*M_PI, p.coef);
  }
  fftw_execute_r2r(IcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(IsinR2D_, rPTemp1_, rPTemp1_);
  weightR2D(rPTemp1_);
  add2DSliceToFull(0, rPTemp_, tTemp_);
  add2DSliceToFull(0, rPTemp1_, tTemp_);
  for (int i = 0; i < pointerSize_[rPTemp1_]; i++)
    rPTemp1_[i] *= 0.5;
  add2DSliceToFull(4, rPTemp1_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, pTemp_);
  fftw_execute_r2r(IsinP_, pTemp_, pTemp_);

  vpTempV += pTempV;

}

//#define TEST

void TorusBasisSet3D::InverseTransformToVelocity(Eigen::VectorXd& fieldCoef) {
  
  CHECK(fieldCoef.size() == all_basis_.size());

  // test code
#ifdef TEST 
  //srand(time(NULL));
  fieldCoef = Eigen::VectorXd::Random(fieldCoef.size());
  double *ur, *ut, *up;
  ur = (double*) fftw_malloc(sizeof(double)*totalSize_);
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> urV(ur, totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  urV.setZero();
  utV.setZero();
  upV.setZero();
  computeUniformRTNumerical(fieldCoef, nR_, nTheta_, nPhi_, ur, ut, up); 
#endif

  collectPairedCoef(fieldCoef);

  InverseTransformVR();
  InverseTransformVT();
  InverseTransformVP();

#ifdef TEST 
  Eigen::Map<Eigen::VectorXd> vrTempV(vrTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  LOG(INFO) << "diff r " << (urV - vrTempV).norm() << " " << urV.norm() << " " << vrTempV.norm();
  LOG(INFO) << "diff t " << (utV - vtTempV).norm() << " " << utV.norm() << " " << vtTempV.norm();
  LOG(INFO) << "diff p " << (upV - vpTempV).norm() << " " << upV.norm() << " " << vpTempV.norm();
  //exit(0);
#endif

}

void TorusBasisSet3D::clearPairCoef() {
  for (auto& v : phiCoef_)
    for (auto& p : v) {
      p.coef = 0;
    }
}

void TorusBasisSet3D::weightJacobian(double* ur, double* ut, double* up) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        double r  = ((double)(k) + 0.5)*dR_;
        double J = r*(a_ + r*sinTVal_[j])*scale3_;
        ur[i + j*nPhi_ + k*nThetaPhi_] *= J;
        ut[i + j*nPhi_ + k*nThetaPhi_] *= J;
        up[i + j*nPhi_ + k*nThetaPhi_] *= J;
      }
}

void TorusBasisSet3D::ForwardTransformVR() {

  clearPointer(inTemp_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  
  const int divdR = 2;  // dirichlet, should divide by 2.
  const int divR23 = 1;  // dirichlet, should divide by 2.

  fftw_execute_r2r(FsinP_, vrTemp_, pTemp_);

  movePtoTGrid(pTemp_, tTemp_);
  TransT(FcosTE_, tTemp_, tTemp_);

  clearPointer(rPTemp_);
  extract2DSliceToFull(2, tTemp_, rPTemp_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  for (auto& p : phiCoef_[6]) {
    double i3 = p.i3x2*0.5;
    if ((p.i3x2 - 1) >= 0)
      p.coef += rPTemp_[p.i3x2 - 1 + (p.i1x2/divR23)*nPhiE_]*i3;
  }

  moveTToIngrid(tTemp_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^0
  for (auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    if ((p.i3x2 - 1) >= 0 && (p.i1x2/divdR - 1) >= 0)
      p.coef += inTemp_[p.i3x2 - 1 + p.i2x2*nPhiE_ + (p.i1x2/divdR - 1)*nThetaE_*nPhiE_]*i2*i3;
  }

  clearPointer(inTemp_);
  clearPointer(tTemp_);

  movePtoTGrid(pTemp_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);

  clearPointer(rPTemp_);
  extract2DSliceToFull(1, tTemp_, rPTemp_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  // Phi^4 rPTemp_
  for (auto& p : phiCoef_[4]) {
    double i3 = p.i3x2*0.5;
    if ((p.i3x2 - 1) >= 0)
      p.coef += rPTemp_[p.i3x2 - 1 + (p.i1x2/divR23)*nPhiE_]*i3;
  }

  moveTToIngrid(tTemp_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^2
  for (auto& p : phiCoef_[2]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    if ((p.i3x2 - 1) >= 0 && (p.i2x2-1) >= 0 && (p.i1x2/divdR - 1) >= 0)
      p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2-1)*nPhiE_ + (p.i1x2/divdR - 1)*nThetaE_*nPhiE_]*i2*i3;
  }

// the other part where IcosP-------------------------------------------------
//----------------------------------------------------------------------------

  clearPointer(inTemp_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  fftw_execute_r2r(FcosP_, vrTemp_, pTemp_);

  movePtoTGrid(pTemp_, tTemp_);
  TransT(FcosTE_, tTemp_, tTemp_);

  clearPointer(rPTemp_);
  extract2DSliceToFull(2, tTemp_, rPTemp_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  for (auto& p : phiCoef_[7]) {
    double i3 = p.i3x2*0.5;
    p.coef += rPTemp_[p.i3x2 + (p.i1x2/divR23)*nPhiE_]*i3;
  }

  moveTToIngrid(tTemp_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^1
  for (auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    if ((p.i1x2/divdR - 1) >= 0)
      p.coef+= inTemp_[p.i3x2 + (p.i2x2)*nPhiE_ + (p.i1x2/divdR - 1)*nThetaE_*nPhiE_]*i2*i3;
  }

  clearPointer(inTemp_);
  clearPointer(tTemp_);
  movePtoTGrid(pTemp_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);

  clearPointer(rPTemp_);
  extract2DSliceToFull(1, tTemp_, rPTemp_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  for (auto& p : phiCoef_[5]) {
    double i3 = p.i3x2*0.5;
    p.coef += rPTemp_[p.i3x2 + (p.i1x2/divR23)*nPhiE_]*i3;
  }

  moveTToIngrid(tTemp_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^3
  for (auto& p : phiCoef_[3]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    if ((p.i2x2 - 1) >= 0 && (p.i1x2/divdR - 1) >= 0)
      p.coef += inTemp_[p.i3x2 + (p.i2x2 - 1)*nPhiE_ + (p.i1x2/divdR - 1)*nThetaE_*nPhiE_]*i2*i3;
  }
}

void TorusBasisSet3D::ForwardTransformVT() {
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);

  const int divdR = 2;  // dirichlet, should divide by 2.
  const int divR23 = 1;  // dirichlet, should divide by 2.

  fftw_execute_r2r(FsinP_, vtTemp_, pTemp_);
  movePtoTGrid(pTemp_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);

  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Phi^0
  for (auto& p : phiCoef_[0]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2 - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, -i3, p.coef);
    GET_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2 - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -i3*i1*M_PI, p.coef);
  }

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  extract2DSliceToFull(1, tTemp_, rPTemp_);
  extract2DSliceToFull(1, tTemp_, rPTemp1_);
  weightR2D(rPTemp1_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp1_, rPTemp1_);
  // Phi^6 rPTemp_
  for (auto& p : phiCoef_[6]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, -i3, p.coef);
    GET_GRID(rPTemp1_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, i3*i1*M_PI, p.coef);
  }

  // Phi^2
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);

  movePtoTGrid(pTemp_, tTemp_);
  TransT(FcosTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  for (auto& p : phiCoef_[2]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i3, p.coef);
    GET_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, i3*i1*M_PI, p.coef);
  }

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  extract2DSliceToFull(2, tTemp_, rPTemp_);
  extract2DSliceToFull(2, tTemp_, rPTemp1_);
  weightR2D(rPTemp1_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp1_, rPTemp1_);
  // Phi^4 rPTemp_
  for (auto& p : phiCoef_[4]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
    GET_GRID(rPTemp1_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, -i3*i1*M_PI, p.coef);
  }

// the other part where IcosP-------------------------------------------------
//----------------------------------------------------------------------------

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);

  fftw_execute_r2r(FcosP_, vtTemp_, pTemp_);
  movePtoTGrid(pTemp_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Phi^1
  for (auto& p : phiCoef_[1]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(inTemp_, (p.i3x2), (p.i2x2 - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, -i3, p.coef);
    GET_GRID(inTemp1_, (p.i3x2), (p.i2x2 - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -i3*i1*M_PI, p.coef);
  }
  
  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  extract2DSliceToFull(1, tTemp_, rPTemp_);
  extract2DSliceToFull(1, tTemp_, rPTemp1_);
  weightR2D(rPTemp1_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp1_, rPTemp1_);
  // Phi^7 rPTemp_
  for (auto& p : phiCoef_[7]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, -i3, p.coef);
    GET_GRID(rPTemp1_, (p.i3x2), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, i3*i1*M_PI, p.coef);
  }

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);

  movePtoTGrid(pTemp_, tTemp_);
  TransT(FcosTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Phi^3
  for (auto& p : phiCoef_[3]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(inTemp_, (p.i3x2), (p.i2x2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, i3, p.coef);
    GET_GRID(inTemp1_, (p.i3x2), (p.i2x2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, i3*i1*M_PI, p.coef);
  }

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  extract2DSliceToFull(2, tTemp_, rPTemp_);
  extract2DSliceToFull(2, tTemp_, rPTemp1_);
  weightR2D(rPTemp1_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp1_, rPTemp1_);
  // Phi^5 rPTemp_
  for (auto& p : phiCoef_[5]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, i3, p.coef);
    GET_GRID(rPTemp1_, (p.i3x2), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, -i3*i1*M_PI, p.coef);
  }
}

void TorusBasisSet3D::ForwardTransformVP() {
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(inTemp2_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);
  
  const int divdR = 2;  // dirichlet, should divide by 2.
  const int divR23 = 1;  // dirichlet, should divide by 2.

  fftw_execute_r2r(FcosP_, vpTemp_, pTemp_);

  movePtoTGrid(pTemp_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Cos[t]*Sin[i2*t] = 1/2 (Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  // Sin[t]*Cos[i2*t] = 1/2 (-Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  // Phi^0
  for (auto& p : phiCoef_[0]) {
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    int coefMinus = (p.i2x2 - 2) < 0 ? -1 : 1;

    GET_GRID(inTemp_, (p.i3x2), (p.i2x2 + 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (-0.5 + 0.5*i2), p.coef);
    if ((p.i2x2 - 2) != 0)
      GET_GRID(inTemp_, (p.i3x2), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, (-0.5*coefMinus -0.5*i2*coefMinus), p.coef);

    GET_GRID(inTemp1_, (p.i3x2), (p.i2x2 + 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI, p.coef);
    if ((p.i2x2 - 2) != 0)
      GET_GRID(inTemp1_, (p.i3x2), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI*coefMinus, p.coef);
  }

  clearPointer(rPTemp_);
  extract2DSliceToFull(3, tTemp_, rPTemp_);
  weightR2D(rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp_, rPTemp_);
  // 1/2 Sin[2 t]
  for (auto& p : phiCoef_[6]) {
    double i1 = p.i1x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, 0.5*i1*M_PI, p.coef);
  }

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  movePtoTGrid(pTemp_, tTemp_);
  TransT(FcosTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Cos[t]*Cos[i2*t] = 1/2 (Cos[(i2 - 1)t] + Cos[(i2 + 1)t])
  // Sin[t]*Sin[i2*t] = 1/2 (Cos[(i2 - 1)t] - Cos[(i2 + 1)t])
  // Phi^2
  for (auto& p : phiCoef_[2]) {
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    GET_GRID(inTemp_, (p.i3x2), (p.i2x2 + 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, 0.5-0.5*i2, p.coef);
    GET_GRID(inTemp_, (p.i3x2), abs(p.i2x2 - 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, 0.5+0.5*i2, p.coef);
    GET_GRID(inTemp1_, (p.i3x2), (p.i2x2 + 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI, p.coef);
    GET_GRID(inTemp1_, (p.i3x2), abs(p.i2x2 - 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI, p.coef);
  }

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  extract2DSliceToFull(0, tTemp_, rPTemp_);
  extract2DSliceToFull(0, tTemp_, rPTemp1_);
  extract2DSliceToFull(4, tTemp_, rPTemp1_);
  weightR2D(rPTemp1_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp1_, rPTemp1_);
  // Phi^4 rPTemp_
  // Cos[t]^2 = 1/2 (1 + Cos[2 t])
  // need to multiply by 2 to keep consistient, because DCT do not weight the DC term by 2
  for (auto& p : phiCoef_[4]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2), (p.i1x2/divR23), 0, nPhiE_, 0, 1.0, p.coef);
    GET_GRID(rPTemp1_, (p.i3x2), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, -0.5*i1*M_PI, p.coef);
  }
  
  clearPointer(rTTemp_);
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
        rTTemp_[j + k*nTheta_] += pTemp_[0 + j*nPhi_ + k*nThetaPhi_];

  memcpy(rTTemp1_, rTTemp_, sizeof(double)*pointerSize_[rTTemp_]);
  fftw_execute_r2r(FcosRsinT_, rTTemp_, rTTemp_);
  // Phi^8
  for (auto& p : phiCoef_[8]) {
    // should use 2 to be consistent with the 2 factor of DCT
    GET_GRID(rTTemp_, (p.i2x2 - 1), (p.i1x2/divdR), 0, nTheta_ , 0, 1.0, p.coef);
  }

  // Phi^9
  fftw_execute_r2r(FcosRcosT_, rTTemp1_, rTTemp1_);
  for (auto& p : phiCoef_[9]) {
    GET_GRID(rTTemp1_, (p.i2x2), (p.i1x2/divdR), 0, nTheta_, 0, 1.0, p.coef);
  }

// the other part where IsinP-------------------------------------------------
//----------------------------------------------------------------------------
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  clearPointer(pTemp_);

  fftw_execute_r2r(FsinP_, vpTemp_, pTemp_);
  movePtoTGrid(pTemp_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Phi^1
  // Cos[t]*Sin[i2*t] = 1/2 (Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  // Sin[t]*Cos[i2*t] = 1/2 (-Sin[(i2 - 1)t] + Sin[(i2 + 1)t])
  for (auto& p : phiCoef_[1]) {  // This is the same as Phi^0 except the sign is flipped
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    int coefMinus = (p.i2x2 - 2) < 0 ? -1 : 1;
    GET_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2 + 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, 0.5 - 0.5*i2, p.coef);
    if ((p.i2x2 - 2) != 0)
      GET_GRID(inTemp_, (p.i3x2 - 1), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, 0.5*coefMinus + 0.5*i2*coefMinus, p.coef);

    GET_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2 + 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI, p.coef);
    if ((p.i2x2 - 2) != 0)
      GET_GRID(inTemp1_, (p.i3x2 - 1), (abs(p.i2x2 - 2) - 1), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, 0.5*i1*M_PI*coefMinus, p.coef);
  }

  clearPointer(rPTemp_);
  extract2DSliceToFull(3, tTemp_, rPTemp_);
  weightR2D(rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp_, rPTemp_);
  // 1/2 Sin[2 t]
  for ( auto& p : phiCoef_[7]) {
    double i1 = p.i1x2*0.5;
    //rPTemp_[p.i3x2 - 1 + (p.i1x2/divR23 - 1)*nPhiE_] += -0.5*i1*M_PI*p.coef;
    GET_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0,-0.5*i1*M_PI, p.coef);
  }

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  movePtoTGrid(pTemp_, tTemp_);
  TransT(FcosTE_, tTemp_, tTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  moveTToIngrid(tTemp_, inTemp1_);
  weightR(inTemp1_);
  TransR(FsinRE_, inTemp_, inTemp_);
  TransR(FcosRE_, inTemp1_, inTemp1_);
  // Phi^3
  for ( auto& p : phiCoef_[3]) {
    double i1 = p.i1x2*0.5;
    double i2 = p.i2x2*0.5;
    GET_GRID(inTemp_, (p.i3x2 - 1), (p.i2x2 + 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, -0.5+0.5*i2, p.coef);
    GET_GRID(inTemp_, (p.i3x2 - 1), abs(p.i2x2 - 2), (p.i1x2/divdR - 1), nPhiE_, nThetaE_*nPhiE_, -0.5-0.5*i2, p.coef);
    GET_GRID(inTemp1_, (p.i3x2 - 1), (p.i2x2 + 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI, p.coef);
    GET_GRID(inTemp1_, (p.i3x2 - 1), abs(p.i2x2 - 2), (p.i1x2/divdR), nPhiE_, nThetaE_*nPhiE_, -0.5*i1*M_PI, p.coef);
  }

  clearPointer(rPTemp_);
  clearPointer(rPTemp1_);
  extract2DSliceToFull(0, tTemp_, rPTemp_);
  extract2DSliceToFull(0, tTemp_, rPTemp1_);
  extract2DSliceToFull(4, tTemp_, rPTemp1_);
  weightR2D(rPTemp1_);
  fftw_execute_r2r(FcosR2D_, rPTemp_, rPTemp_);
  fftw_execute_r2r(FsinR2D_, rPTemp1_, rPTemp1_);
  // Phi^5 rPTemp_
  // Cos[t]^2 = 1/2 (1 + Cos[2 t])
  // need to multiply by 2 to keep consistient, because DCT do not weight the DC term by 2
  for ( auto& p : phiCoef_[5]) {
    double i1 = p.i1x2*0.5;
    double i3 = p.i3x2*0.5;
    GET_GRID(rPTemp_, (p.i3x2 - 1), (p.i1x2/divR23), 0, nPhiE_, 0, -1.0, p.coef);
    GET_GRID(rPTemp1_, (p.i3x2 - 1), (p.i1x2/divR23 - 1), 0, nPhiE_, 0, 0.5*i1*M_PI, p.coef);
  }
}

void TorusBasisSet3D::ForwardTransformtoFrequency(
    const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) {
  
  interpolateToTorus(field);
  // Be CAREFUL of zStride when interpolate field into vr, vt, vp.
  // interpolateToSphere(field);
  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();

 // test code
#ifdef TEST
  srand(time(NULL));
  double *ur, *ut, *up;
  ur = (double*) fftw_malloc(sizeof(double)*totalSize_);
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> urV(ur, totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  urV.setZero();
  utV.setZero();
  upV.setZero();

  srand((unsigned int) (time(0)));
  Eigen::VectorXd basisCoef1 = Eigen::VectorXd::Random(all_basis_.size());
  computeUniformRTNumerical(basisCoef1, nR_, nTheta_, nPhi_, ur, ut, up); 
  // collect into vr, due to z stride might be different.
  memcpy(vrTemp_, ur, sizeof(double)*totalSize_);
  memcpy(vtTemp_, ut, sizeof(double)*totalSize_);
  memcpy(vpTemp_, up, sizeof(double)*totalSize_);

  weightJacobian(ur, ut, up);

#endif
  weightJacobian(vrTemp_, vtTemp_, vpTemp_);

  ForwardTransformVR();
  ForwardTransformVT();
  ForwardTransformVP();
  assignPairCoef(fieldCoef);

#ifdef TEST
  Eigen::VectorXd projCoef = Eigen::VectorXd::Zero(all_basis_.size());
  projectUniformRTNumerical(nR_, nTheta_, nPhi_, ur, ut, up, projCoef);
  LOG(INFO) << "diff: " << (projCoef - fieldCoef).norm() << " " << projCoef.norm() << " " << fieldCoef.norm();
  //exit(0);
#endif

  *coefficients = A_*fieldCoef;
}

// xRes, yRes, zRes lines up with (nphi, ntheta, nr)
void TorusBasisSet3D::ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) {
  CHECK(df.xRes() == nPhi_);
  CHECK(df.yRes() == nTheta_);
  CHECK(df.zRes() == nR_);

  for (int i = 0; i < totalSize_; i++) {
    vrTemp_[i] = df[i][0];
    vtTemp_[i] = df[i][1];
    vpTemp_[i] = df[i][2];
  }

  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();

  weightJacobian(vrTemp_, vtTemp_, vpTemp_);

  ForwardTransformVR();
  ForwardTransformVT();
  ForwardTransformVP();
  assignPairCoef(fieldCoef);

  *coefficients = A_*fieldCoef;
}

void TorusBasisSet3D::projectUniformRTNumerical(const int nR, const int nTheta, const int nPhi, double* fr,
                                           double* ft, double* fp, Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    fullCoef[i] = all_basis_[i]->ProjectUniformU(nR, nTheta, nPhi, fr, ft, fp);
  }
}

void TorusBasisSet3D::outputTestTensorEntries(const int numWant, const string& fname,
      std::vector<Adv_Tensor_Type> *Adv_tensor) {

 CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  vector<Eigen::Vector3i> indices;

  for (int i = 0; i < numBasisAll_; i++) {
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const TorusBasis3D& basis_i = *all_basis_[i];
        const TorusBasis3D& basis_g = *all_basis_[g];
        const TorusBasis3D& basis_h = *all_basis_[h];

        double Cigh = TorusBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
        CHECK(std::isfinite(Cigh));

        if (abs(Cigh) < 1e-12) {
          continue;
        }

        indices.push_back(Eigen::Vector3i(i,g,h));
        tripletList.push_back(T(g,h, Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  BasisSet::VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    basisPtr3DTor basis_i = all_basis_[indices[i][0]];
    basisPtr3DTor basis_g = all_basis_[indices[i][1]];
    basisPtr3DTor basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " << basis_i->WN3x2() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " << basis_g->WN3x2() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " << basis_h->WN3x2() << " " <<
           std::setprecision(12) << basis_i->GetInvNorm() << " " << basis_g->GetInvNorm()
           << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}

double TorusBasisSet3D::tensorEntryCast(const basisPtr3DTor basis_i, const basisPtr3DTor basis_g, const basisPtr3DTor basis_h) {
    return TorusBasis3D::computeTensorEntryScale(*basis_i, *basis_g, *basis_h, scale3_);
}

void TorusBasisSet3D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {
  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;

#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    // compute half
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {
        //
        double Cigh = 0;

#ifdef FAST_TENSOR
        const TorusBasis3D& basis_i = *all_basis_[i];
        const TorusBasis3D& basis_g = *all_basis_[g];
        const TorusBasis3D& basis_h = *all_basis_[h];
        const int idx = basis_i.index()*100 + basis_g.index()*10 + basis_h.index();
        Cigh = tensorEval_.pointers_[idx](basis_i, basis_g, basis_h, a_)*scale3_;
#else
        Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);
        CHECK(std::isfinite(Cigh));
#endif

        if (abs(Cigh) <1e-12) {
          continue;
        }
        
        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  //BasisSet::VerifyAntisymmetric(*Adv_tensor);
  //exit(0);
}

#define dotProdMarco(arg, i,j) dotProdCast(arg[i], arg[j])
// Run MGS on a set of basis functions stored in in, and orthogonalize them. The kept basis
// is stored in out. The basis functions with distinct part smalelr than thresh of existing basis
// are thrown away. Coef are a matrix which kepts the coefficients of MGS. m is the number of
// basis functions that are kept.
void TorusBasisSet3D::runMGS(const double thresh, const vector<basisPtr3DTor>& in, vector<basisPtr3DTor>& out,
            Eigen::MatrixXd& Coef, int& m) {
  out.clear();
  // inner product matrix of all basis.
  Eigen::MatrixXd H = Eigen::MatrixXd::Zero(in.size(), in.size());
  // temp buffer.
  Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(in.size(), in.size());
  // Coefficients matrix.
  Coef = Eigen::MatrixXd::Zero(in.size(), in.size());
  // map from row/col index of H matrix to basis index
  Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(in.size());
  Coef(0,0) = 1.0; 
  H(0,0) = dotProdMarco(in, 0,0);
  HC.col(0) = H*Coef.row(0).transpose();
  idxMap[0] = 0;
  // The first one.
  out.push_back(in[0]);
  // size of the final allocated basis.
  m = 1;

  for(int i = 1; i < in.size(); i++) {
    Coef(m,m) = 1.0;
    H(m,m) = dotProdMarco(in, i,i);
    for (int j = 0; j < m; j++)
      H(j,m) = H(m,j) = dotProdMarco(in, i,idxMap[j]);
    for (int j = 0; j < m; j++) {
      HC(m,j) = H.row(m)*Coef.row(j).transpose();
    }

    for (int j = 0; j < m; j++) {
      double dotProd = Coef.row(m)*HC.col(j);
      Coef.row(m) -= dotProd*Coef.row(j);
    }

    // compute norm.
    HC.col(m) = H*Coef.row(m).transpose();
    double norm2 = Coef.row(m)*HC.col(m);

    if (norm2 > thresh) {
      idxMap[m] = i;
      Coef.row(m) /= sqrt(norm2);
      HC.col(m) /= sqrt(norm2);
      m++;
      out.push_back(in[i]);
    }
    else {
      LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";
    }
  }
  CHECK(m <= in.size());
  CHECK(m == out.size());
  // test
  // Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  // for (int i = 0; i < reduced.rows(); i++) {
  //   reduced(i,i) -= 1.0;
  // }
  // LOG(INFO) << reduced.norm();
}
#define CLAMPR(rv) \
rv = (rv < 0) ? 0 : rv;\
rv = (rv > nR_ - 1) ? nR_ - 1 : rv;\

#define CLAMPT(tv) \
tv = (tv < 0) ? nTheta_ + tv : tv;\
tv = (tv > nTheta_ - 1) ? tv - nTheta_ : tv;

#define CLAMPP(pv) \
pv = (pv < 0) ? nPhi_ + pv : pv;\
pv = (pv > nPhi_ - 1) ? pv - nPhi_ : pv;

#define interPol(arg_)\
wr0*(wp0 * (wt0 * arg_[i000] + wt1 * arg_[i010]) +\
     wp1 * (wt0 * arg_[i100] + wt1 * arg_[i110]))+\
wr1*(wp0 * (wt0 * arg_[i001] + wt1 * arg_[i011]) +\
     wp1 * (wt0 * arg_[i101] + wt1 * arg_[i111]))

void TorusBasisSet3D::interpolateToCartesian(VECTOR3_FIELD_3D* field) {
  
  const int xRes = field->xRes();
  const int yRes = field->yRes();
  const int zRes = field->zRes();
  CHECK(xRes == yRes);
  // The physical dimension is xyz: [-(a+1), (a+1)]x[-(a+1), (a+1)]x[-1, 1]
  // physical dx
  double dx = 2.0*(a_+1.0) / xRes;
  double lz = zRes*dx;

  #pragma omp parallel for
  for (int k = 0; k < zRes; k++)
    for (int j = 0; j < yRes; j++)
      for (int i = 0; i < xRes; i++) {
        
        const int cidx = i + j*xRes + k*xRes*yRes;
        Eigen::Vector3d uSph(0,0,0);
        Eigen::Vector3d uCat(0,0,0);
        
        Eigen::Vector3d pos(((double)(i) + 0.5)*dx - a_ - 1.0 , ((double)(j) + 0.5)*dx - a_ - 1.0,
                 ((double)(k) + 0.5)*dx - lz*0.5);  // [-(a+1), (a+1)]^2x[-lz/2, lz/2]

        // parameter space.
        Eigen::Vector3d sphCord = Transform::Torodial::toTorodial(pos, a_);

        const double r = sphCord[0]; // [0, 1]
        const double t = sphCord[1]; // [0, 2pi]
        const double p = sphCord[2]; // [0, 2pi]
        // center aligned.
        if (r > 1.0)  // velocity is zero
          continue;

        int r0 = (int)(r/dR_);
        int r1 = r0 + 1;
        int t0 = (int)(t/dTheta_);
        int t1 = t0 + 1;
        int p0 = (int)(p/dPhi_);
        int p1 = p0 + 1;
        
        // clamp
        CLAMPR(r0);
        CLAMPR(r1);
        // periodic bc
        CLAMPT(t0);
        CLAMPT(t1);
        CLAMPP(p0);
        CLAMPP(p1);

        // get interpolation weights
        const double wp1 = p/dPhi_ - p0;
        const double wp0 = 1.0 - wp1;
        const double wt1 = t/dTheta_ - t0;
        const double wt0 = 1.0 - wt1;
        const double wr1 = r/dR_ - r0;
        const double wr0 = 1.0 - wr1;

        const int i000 = p0 + t0 * nPhi_ + r0 * nThetaPhi_;
        const int i010 = p0 + t1 * nPhi_ + r0 * nThetaPhi_;
        const int i100 = p1 + t0 * nPhi_ + r0 * nThetaPhi_;
        const int i110 = p1 + t1 * nPhi_ + r0 * nThetaPhi_;
        const int i001 = p0 + t0 * nPhi_ + r1 * nThetaPhi_;
        const int i011 = p0 + t1 * nPhi_ + r1 * nThetaPhi_;
        const int i101 = p1 + t0 * nPhi_ + r1 * nThetaPhi_;
        const int i111 = p1 + t1 * nPhi_ + r1 * nThetaPhi_;

        uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
        Eigen::Matrix3d transMat;
        Transform::Torodial::toCartesianMat(t,p, transMat);
        // toCartesian
        uCat = transMat*uSph;
        (*field)[cidx][0] = uCat[0];
        (*field)[cidx][1] = uCat[1];
        (*field)[cidx][2] = uCat[2];
      }
}

void TorusBasisSet3D::interpolateToTorus(const VECTOR3_FIELD_3D& field) {
  const int xRes = field.xRes();
  const int yRes = field.yRes();
  const int zRes = field.zRes();
  CHECK(xRes == yRes);

  clearPointer(vrTemp_);
  clearPointer(vtTemp_);
  clearPointer(vpTemp_);
  const int fZres = field.zRes();
  const double invA1 = 1.0/(a_ + 1.0);
  const double dx = 2.0*(a_+1.0) / xRes;
  // dx = 2/xres;
  // cat[2] [0, b] vs [0, lz]
  #pragma omp parallel for
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        int index = i + j*nPhi_ + k*nThetaPhi_;
        Eigen::Vector3d sph;
        sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dPhi_;
        Eigen::Vector3d cat = Transform::Torodial::toCartesian(sph, a_); // [-(a+1), (a+1)]^2x[-1,1]
        // [0, (a+1)]
        cat[0] = (cat[0] + a_ + 1.0)*0.5*invA1;
        cat[1] = (cat[1] + a_ + 1.0)*0.5*invA1; // [0,1]
        //cat[2] -= b_/2;  // [-b/2, b/2]

        Eigen::Matrix3d transMat;
        Transform::Torodial::toCartesianMat(sph[1], sph[2], transMat);
        // in grid coordinates, center aligned.
        double zPos = fZres/2 + cat[2]*0.5*xRes/(a_+1.0);
        // out of bounds.
        if (zPos < 0 || zPos >= fZres)
          continue;
        VEC3 vcat = field.GetVelocity(cat[0]*xRes, cat[1]*xRes, zPos);
        Eigen::Vector3d uCat(vcat[0], vcat[1], vcat[2]);
        Eigen::Vector3d uSph = transMat.transpose()*uCat;
        vrTemp_[index] = uSph[0];
        vtTemp_[index] = uSph[1];
        vpTemp_[index] = uSph[2];
      }
}

void TorusBasisSet3D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta,
     const int nP, double* ur, double* ut, double* up) {

  memset(ur, 0x00, sizeof(double)*totalSize_);
  memset(ut, 0x00, sizeof(double)*totalSize_);
  memset(up, 0x00, sizeof(double)*totalSize_);

  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    all_basis_[i]->AddUniformU(fullCoef[i], nR, nTheta, nP, ur, ut, up);
  }
}

void TorusBasisSet3D::ReSeedParticles(vector<ParticleSph3D>& particles, vector<Eigen::Vector3d>& initPos) {
  // Reseed the particles at random position.
  uniform_real_distribution<double> u(0., 1.);
  uniform_real_distribution<double> phi(0, 2.0*M_PI);

  for (int i = 0; i < particles.size(); i++) {
    double px = u(m_gen_);
    double py = u(m_gen_);
    double r = sqrtf(px);
    double t = 2.0*M_PI*py;
    double p = phi(m_gen_);
    particles[i].position = Transform::Torodial::toCartesian(Eigen::Vector3d(r, t, p), a_)*scale_;
    particles[i].velocity.setZero();
    initPos[i] = particles[i].position;
  }
}

void TorusBasisSet3D::projBackParticles(const vector<Eigen::Vector3d>& initPos, vector<ParticleSph3D>& particles) {
  for (int i = 0; i < particles.size(); i++) {
    //double dist = 0;
    const Eigen::Vector3d& p = particles[i].position/scale_;
    //dist = sqrt(p[0]*p[0] + p[1]*p[1]);
    Eigen::Vector3d sph = Transform::Torodial::toTorodial(p, a_);
    if (sph[0] > 1.0) {
      particles[i].position = initPos[i];
      particles[i].velocity.setZero();
    }
  }
}

VEC3 TorusBasisSet3D::getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) {
  // [-(a+1), (a+1)]x[-1,1]
  VEC3 nPos = p;
  const int xRes = velocity.xRes();

  nPos[0] = (nPos[0] + 1)*0.5; // [0, 1]
  nPos[1] = (nPos[1] + 1)*0.5; // [0, 1]
  double zPos = velocity.zRes()/2 + nPos[2]*xRes*0.5;
  if (zPos < 0 || zPos >= velocity.zRes())
    return VEC3(0,0,0);
  return velocity.GetVelocity(nPos[0]*xRes, nPos[1]*xRes, zPos);
}

void TorusBasisSet3D::writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const {
  out.write(reinterpret_cast<const char *>(&rK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&thetaK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&phiK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&a_), sizeof(double));
  
  // write the size of each modes.
  int modeSizes[phiCoef_.size()];
  for (int i = 0; i < phiCoef_.size(); i++)
    modeSizes[i] = phiCoef_[i].size();
  out.write(reinterpret_cast<const char *>(modeSizes), sizeof(int)*phiCoef_.size());

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }

  writeEigenDense_binary(out, H_);
  writeEigenDense_binary(out, A_);
  int tensorType = 0;
  WriteTensor(Adv_tensor_, tensorType, out);
}

void TorusBasisSet3D::readFromFile(std::ifstream& in) {
  in.read(reinterpret_cast<char *>(&rK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&thetaK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&phiK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&numBasisAll_), sizeof(int));
  in.read(reinterpret_cast<char *>(&numBasisOrtho_), sizeof(int));
  in.read(reinterpret_cast<char *>(&a_), sizeof(double));
  scale_ = (1.0/(a_+1.0));
  scale3_ = scale_*scale_*scale_;
  LOG(INFO) << numBasisAll_;
  //phiCoef_.resize(10);

  int modeSizes[10];
  in.read(reinterpret_cast<char*>(modeSizes), sizeof(int)*10);

  for (int i = 0; i < numBasisAll_; i++) {
    all_basis_.push_back(basisPtr3DTor(TorusBasis3D::fromFile(in, a_)));
  }

  initPhiCoef();
  readEigenDense_binary(in, H_);

  readEigenDense_binary(in, A_);

}

Eigen::Vector3d TorusBasisSet3D::getVelocityPos(const Eigen::Vector3d& pos) {
  Eigen::Vector3d result(0,0,0);
  getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(pos, result);
  return result;
}

Eigen::Vector3f TorusBasisSet3D::getVelocityPos(const Eigen::Vector3f& pos) {
  Eigen::Vector3f result(0,0,0);
  getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(pos, result);
  return result;
}

// pos[-1,1]x[z]
template<typename DT, typename VT, typename MT>
void TorusBasisSet3D::getVelocityPosT(const VT& pos, VT& uCat) {
  VT uSph(0,0,0);
  uCat.setZero();

  // parameter space.
  VT posOrig = pos/scale_;
  VT sphCord = Transform::Torodial::toTorodial(posOrig, a_);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, 2pi]
  const DT& p = sphCord[2]; // [0, 2pi]
  //CHECK(isfinite(r) && isfinite(t) && isfinite(p)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.
  if (r > 1.0)  // velocity is zero
    return;

  int r0 = (int)(r/dR_);
  int r1 = r0 + 1;
  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int p0 = (int)(p/dPhi_);
  int p1 = p0 + 1;
  
  // clamp
  CLAMPR(r0);
  CLAMPR(r1);
  // periodic bc
  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPP(p0);
  CLAMPP(p1);

  // get interpolation weights
  const DT wp1 = p/dPhi_ - p0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;
  const DT wr1 = r/dR_ - r0;
  const DT wr0 = 1.0 - wr1;

  const int i000 = p0 + t0 * nPhi_ + r0 * nThetaPhi_;
  const int i010 = p0 + t1 * nPhi_ + r0 * nThetaPhi_;
  const int i100 = p1 + t0 * nPhi_ + r0 * nThetaPhi_;
  const int i110 = p1 + t1 * nPhi_ + r0 * nThetaPhi_;
  const int i001 = p0 + t0 * nPhi_ + r1 * nThetaPhi_;
  const int i011 = p0 + t1 * nPhi_ + r1 * nThetaPhi_;
  const int i101 = p1 + t0 * nPhi_ + r1 * nThetaPhi_;
  const int i111 = p1 + t1 * nPhi_ + r1 * nThetaPhi_;

  uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
  MT transMat;
  Transform::Torodial::toCartesianMat(t,p, transMat);
  // toCartesian
  uCat = transMat*uSph;
}
template void TorusBasisSet3D::getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(const Eigen::Vector3d&, Eigen::Vector3d&);
template void TorusBasisSet3D::getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(const Eigen::Vector3f&, Eigen::Vector3f&);

template<typename DT, typename VT>
void TorusBasisSet3D::addParticleForce(const double& ptlWeight, const VT& pos, const VT& f, VECTOR3_FIELD_3D& buf) {
  // parameter space.
  VT posOrig = pos/scale_;
  VT sphCord = Transform::Torodial::toTorodial(posOrig, a_);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, 2pi]
  const DT& p = sphCord[2]; // [0, 2pi]
  CHECK(isfinite(r) && isfinite(t) && isfinite(p)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.
  if (r > 1.0)  // velocity is zero
    return;

  int r0 = (int)(r/dR_);
  int r1 = r0 + 1;
  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int p0 = (int)(p/dPhi_);
  int p1 = p0 + 1;
  
  // clamp
  CLAMPR(r0);
  CLAMPR(r1);
  // periodic bc
  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPP(p0);
  CLAMPP(p1);

  // get interpolation weights
  const DT wp1 = p/dPhi_ - p0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;
  const DT wr1 = r/dR_ - r0;
  const DT wr0 = 1.0 - wr1;

  const int i000 = p0 + t0 * nPhi_ + r0 * nThetaPhi_;
  const int i010 = p0 + t1 * nPhi_ + r0 * nThetaPhi_;
  const int i100 = p1 + t0 * nPhi_ + r0 * nThetaPhi_;
  const int i110 = p1 + t1 * nPhi_ + r0 * nThetaPhi_;
  const int i001 = p0 + t0 * nPhi_ + r1 * nThetaPhi_;
  const int i011 = p0 + t1 * nPhi_ + r1 * nThetaPhi_;
  const int i101 = p1 + t0 * nPhi_ + r1 * nThetaPhi_;
  const int i111 = p1 + t1 * nPhi_ + r1 * nThetaPhi_;

  for (int i = 0; i < 3; i++) {
    buf[i000][i] += ptlWeight*wr0*wp0*wt0*f[i];
    buf[i010][i] += ptlWeight*wr0*wp0*wt1*f[i];
    buf[i100][i] += ptlWeight*wr0*wp1*wt0*f[i];
    buf[i110][i] += ptlWeight*wr0*wp1*wt1*f[i];
    buf[i001][i] += ptlWeight*wr1*wp0*wt0*f[i];
    buf[i011][i] += ptlWeight*wr1*wp0*wt1*f[i];
    buf[i101][i] += ptlWeight*wr1*wp1*wt0*f[i];
    buf[i111][i] += ptlWeight*wr1*wp1*wt1*f[i];
  }
}

template void TorusBasisSet3D::addParticleForce<double, Eigen::Vector3d>(const double&, const Eigen::Vector3d&, const Eigen::Vector3d&, VECTOR3_FIELD_3D&);
template void TorusBasisSet3D::addParticleForce<float, Eigen::Vector3f>(const double&, const Eigen::Vector3f&, const Eigen::Vector3f&, VECTOR3_FIELD_3D&);

void TorusBasisSet3D::projPosBack(ParaParticle3Dd& p) {
  Eigen::Vector3d posOrig = p.position_/scale_;
  Eigen::Vector3d sphCord = Transform::Torodial::toTorodial(posOrig, a_);
  if (sphCord[0] <= 1.0)
    return;

  sphCord[0] = 1.0;
  p.position_ = Transform::Torodial::toCartesian(sphCord, a_)*scale_;
  p.weight_ = 0.0;
  p.life_ = 0;
}

void TorusBasisSet3D::projPosBack(ParaParticle3Df& p) {
  Eigen::Vector3f posOrig = p.position_/scale_;
  Eigen::Vector3f sphCord = Transform::Torodial::toTorodial(posOrig, a_);
  if (sphCord[0] <= 1.0)
    return;

  sphCord[0] = 1.0;
  p.position_ = Transform::Torodial::toCartesian(sphCord, a_)*scale_;
  p.weight_ = 0.0;
  p.life_ = 0;
}