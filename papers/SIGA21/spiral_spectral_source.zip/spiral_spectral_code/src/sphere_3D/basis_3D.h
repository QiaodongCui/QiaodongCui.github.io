#ifndef BASIS_3D_H
#define BASIS_3D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>

class Basis3D {

public:
  // init, 2*wavenumber
  Basis3D(const int k12, const int k22, const int k32, const int idx):
  k1(k12*0.5), k2(k22*0.5), k3(k32*0.5), k1x2(k12), k2x2(k22), k3x2(k32), index_(idx) {
  };

  ~Basis3D(){};

  // extract int version of wn1
  // wave number 1, its up to user to ensure K1D is always even
  int WN1I() const {
    return k1x2/2;
  }
  
  int WN2I() const {
    return k2x2/2;
  }

  int WN3I() const {
    return k3x2/2;
  }
  
  double WN1D() const {
    return k1;
  }

  double WN2D() const {
    return k2;
  }
  
  double WN3D() const {
    return k3;
  }
  
  int WN1x2() const {
    return k1x2;
  }

  int WN2x2() const {
    return k2x2;
  }
  
  int WN3x2() const {
    return k3x2;
  }

  double GetInvNorm() const {
    return invNorm_;
  }

  int index() const {
    return  index_;
  }
  
  void debugPrint() const {
    LOG(INFO) << "k12 " << k1x2 << " k22 " << k2x2 << " k32 " << k3x2 << " index " << index_ << " norm " << invNorm_;
  }

  static uint64_t toHash(const int k12, const int k22, const int k32, const int idx) {
    uint64_t result = 0;
    result |= (0xffff000000000000 & static_cast<uint64_t>(k12) << 48);
    result |= (0x0000ffff00000000 & static_cast<uint64_t>(k22) << 32); // sign bit
    result |= (0x00000000ffff0000 & static_cast<uint64_t>(k32) << 16);
    result |= (0x000000000000ffff & static_cast<uint64_t>(idx) );
    return result;
  }

protected:
  const double k1;
  const double k2;
  const double k3;

  // 2* wavenumber
  const int k1x2;
  const int k2x2;
  const int k3x2;

  double invNorm_;

  // index for different kind of basis functions
  const int index_;
};

#endif // BASIS_3D_H