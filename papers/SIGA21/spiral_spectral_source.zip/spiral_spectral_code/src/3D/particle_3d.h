#ifndef PARTICLE_3D_H
#define PARTICLE_3D_H

#include <Eigen/Eigen>

#include "Alg/VEC3.h"

class Particle3D {
public:
  Particle3D(const float px, const float py, const float pz){
    position[0] = px;
    position[1] = py;
    position[2] = pz;
  }
  Particle3D() {
    position = 0;
  }
  ~Particle3D(){}
  VEC3 position;
  VEC3 velocity;
};

#endif
