#ifndef SPIRAL_UTIL_H
#define SPIRAL_UTIL_H

template<typename T>
void runMGS(const double thresh, const std::vector<T>& in, std::vector<T>& out,
            Eigen::MatrixXd& Coef, int& m, double (*dotProdFun)(T, T)) {
  out.clear();
  // inner product matrix of all basis.
  Eigen::MatrixXd H = Eigen::MatrixXd::Zero(in.size(), in.size());
  // temp buffer.
  Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(in.size(), in.size());
  // Coefficients matrix.
  Coef = Eigen::MatrixXd::Zero(in.size(), in.size());
  // map from row/col index of H matrix to basis index
  Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(in.size());
  Coef(0,0) = 1.0; 
  H(0,0) = dotProdFun(in[0], in[0]);
  HC.col(0) = H*Coef.row(0).transpose();
  idxMap[0] = 0;
  // The first one.
  out.push_back(in[0]);
  // size of the final allocated basis.
  m = 1;

  for(int i = 1; i < in.size(); i++) {
    Coef(m,m) = 1.0;
    H(m,m) = dotProdFun(in[i], in[i]);
    for (int j = 0; j < m; j++)
      H(j,m) = H(m,j) = dotProdFun(in[i], in[idxMap[j]]);
    for (int j = 0; j < m; j++) {
      HC(m,j) = H.row(m)*Coef.row(j).transpose();
    }

    for (int j = 0; j < m; j++) {
      double dotProd = Coef.row(m)*HC.col(j);
      Coef.row(m) -= dotProd*Coef.row(j);
    }

    // compute norm.
    HC.col(m) = H*Coef.row(m).transpose();
    double norm2 = Coef.row(m)*HC.col(m);

    if (norm2 > thresh) {
      idxMap[m] = i;
      Coef.row(m) /= sqrt(norm2);
      HC.col(m) /= sqrt(norm2);
      m++;
      out.push_back(in[i]);
    }
    else {
      LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";
      // H should be positive definite.
      //LOG(INFO) << Coef.row(m)*Coef.row(m).transpose();
      //exit(0);
    }
  }
  CHECK(m <= in.size());
  CHECK(m == out.size());
  // test
  // Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  // for (int i = 0; i < reduced.rows(); i++) {
  //   reduced(i,i) -= 1.0;
  // }
  // LOG(INFO) << reduced.norm();
}



#endif  // SPIRAL_UTIL_H