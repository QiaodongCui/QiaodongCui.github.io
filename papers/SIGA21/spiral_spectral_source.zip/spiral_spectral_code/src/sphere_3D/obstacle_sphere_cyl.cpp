#include <glog/logging.h>
#include <Eigen/Eigen>
#include <fstream>
#include <float.h>

#include "sphere_3D/obstacle_sphere_cyl.h"
#include "util/transform.h"

ObstacleSphereCyl::ObstacleSphereCyl(const std::string& locations, const double radius, const double dt) {
  std::ifstream in(locations);
  if (! in.is_open())
    LOG(FATAL) << "cannot open: " << locations;
  double x,y,z;
  while(in >> x && in >> y && in >> z)
    locations_.push_back(Eigen::Vector3d(x,y,-z));

  velocitys_.reserve(locations_.size());
  for (int i = 1; i < locations_.size(); i++) {
    Eigen::Vector3d curV = (locations_[i] - locations_[i-1])/dt;
    velocitys_.push_back(curV);
  }
  velocitys_.push_back(Eigen::Vector3d(0,0,0));
  center_ = locations_[0];
  radius_ = radius;
}

void ObstacleSphereCyl::Init() {
  radius_squared_ = radius_*radius_;
}

// TODO: handle particles.
// TODO: reduce the search range
// f lines up with r, theta, z

void ObstacleSphereCyl::CalculateNormalForce(const int nR, const int nTheta, const int nZ, const double* vr, const double* vt, const double* vz,
                            const double amp, const double b, const double scale,
                            VECTOR3_FIELD_3D& f) const {
  CHECK(f.xRes() == nZ);
  CHECK(f.yRes() == nTheta);
  CHECK(f.zRes() == nR);
  const double dR_ = 1.0 / nR;
  const double dTheta_ = 2.0*M_PI / nTheta;
  // parameter space.
  const double dZ_ = 1.0 / nZ;
  const int nZTheta = nZ*nTheta;
  Eigen::Vector3d centerCyl = Transform::Cylinderical::toCylinderical(center_, b);

  // update the search range.
  int zStart = 0, zEnd = nZ, rStart = 0, rEnd = nR, tStart = 0, tEnd = nTheta;
  // [0-1]
  double zmin = (center_[2] - radius_)/b/scale + 0.5;
  double zmax = (center_[2] + radius_)/b/scale + 0.5;
  zStart = floor(zmin/dZ_);
  zEnd = ceil(zmax/dZ_);
  zStart = (zStart < 0) ? 0 : zStart;
  zStart = (zStart >= nZ) ? nZ - 1 : zStart;
  zEnd = (zEnd < 0) ? 0 : zEnd;
  zEnd = (zEnd >= nZ) ? nZ - 1 : zEnd;
  double distR = centerCyl[0]; 
  double rmin = (distR - radius_)/scale; // [0, 1]
  double rmax = (distR + radius_)/scale;
  rStart = floor(rmin/dR_);
  rEnd   = ceil(rmax/dR_);
  rStart = (rStart < 0) ? 0 : rStart;
  rStart = (rStart >= nR) ? nR - 1 : rStart;
  rEnd = (rEnd < 0) ? 0 : rEnd;
  rEnd = (rEnd >= nR) ? nR - 1 : rEnd;
  if (distR > radius_) {
    double alpha = asin(radius_/distR); // [0, pi/2]
    double curT = centerCyl[1]; // [0, pi*2]
    double t1 = curT - alpha;
    double t2 = curT + alpha;
    t1 = (t1 < 0) ? t1 + 2.0*M_PI : t1;
    t1 = (t1 > 2.0*M_PI) ? t1 - 2.0*M_PI : t1;
    t2 = (t2 < 0) ? t2 + 2.0*M_PI : t2;
    t2 = (t2 > 2.0*M_PI) ? t2 - 2.0*M_PI : t2;
    tStart = floor(std::min(t1, t2)/dTheta_);
    tEnd   = ceil(std::max(t1, t2)/dTheta_);
    tStart = (tStart < 0) ? 0 : tStart;
    tEnd   = (tEnd >= nTheta) ? nTheta - 1: tEnd;
  }

  // wont cause collision because index is unique for each thread.
  #pragma omp parallel for
  for (int k = rStart; k < rEnd; k++)
    for (int j = tStart; j < tEnd; j++)
      for (int i = zStart; i < zEnd; i++) {
        int index = i + j*nZ + k*nZTheta;
        Eigen::Vector3d sph;
        sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dZ_;
        Eigen::Vector3d cat = Transform::Cylinderical::toCartesian(sph, b)*scale; // [-1,1]^3x[0,b*scale]
        cat[2] -= 0.5*b*scale; // zero centered.

        double dist = (cat - center_).norm();
        if (dist > radius_)
          continue;

        Eigen::Matrix3d transMat;
        Transform::Cylinderical::toCartesianMat(sph[1], transMat);
        Eigen::Vector3d vCylRigid = transMat.transpose()*velocity_;
        if (dist < interalRatio_*radius_) {  // inside of the sphere, force the velocity be vrigid.
          f[index][0] += amp*(vCylRigid[0] - vr[index]);
          f[index][1] += amp*(vCylRigid[1] - vt[index]);
          f[index][2] += amp*(vCylRigid[2] - vz[index]);
        } else {  // on the surface, force normal component be zero.
          Eigen::Vector3d normal = (cat - center_)/dist;
          Eigen::Vector3d normalCyl = transMat.transpose()*normal;
          Eigen::Vector3d vField(vr[index], vt[index], vz[index]); // cyl
          Eigen::Vector3d ff = amp*(vCylRigid.dot(normalCyl) - vField.dot(normalCyl))*normalCyl;
          f[index][0] += ff[0];
          f[index][1] += ff[1];
          f[index][2] += ff[2];
        }
      }
}

void ObstacleSphereCyl::SetNormalForce(const int nR, const int nTheta, const int nZ, const double* vr, const double* vt, const double* vz,
                          const double amp, const double b, const double scale,
                          VECTOR3_FIELD_3D& f) const {
  CHECK(f.xRes() == nZ);
  CHECK(f.yRes() == nTheta);
  CHECK(f.zRes() == nR);
  const double dR_ = 1.0 / nR;
  const double dTheta_ = 2.0*M_PI / nTheta;
  // parameter space.
  const double dZ_ = 1.0 / nZ;
  const int nZTheta = nZ*nTheta;
  Eigen::Vector3d centerCyl = Transform::Cylinderical::toCylinderical(center_, b);

  // update the search range.
  int zStart = 0, zEnd = nZ, rStart = 0, rEnd = nR, tStart = 0, tEnd = nTheta;
  // [0-1]
  double zmin = (center_[2] - radius_)/b/scale + 0.5;
  double zmax = (center_[2] + radius_)/b/scale + 0.5;
  zStart = floor(zmin/dZ_);
  zEnd = ceil(zmax/dZ_);
  zStart = (zStart < 0) ? 0 : zStart;
  zStart = (zStart >= nZ) ? nZ - 1 : zStart;
  zEnd = (zEnd < 0) ? 0 : zEnd;
  zEnd = (zEnd >= nZ) ? nZ - 1 : zEnd;
  double distR = centerCyl[0]; 
  double rmin = (distR - radius_)/scale; // [0, 1]
  double rmax = (distR + radius_)/scale;
  rStart = floor(rmin/dR_);
  rEnd   = ceil(rmax/dR_);
  rStart = (rStart < 0) ? 0 : rStart;
  rStart = (rStart >= nR) ? nR - 1 : rStart;
  rEnd = (rEnd < 0) ? 0 : rEnd;
  rEnd = (rEnd >= nR) ? nR - 1 : rEnd;
  if (distR > radius_) {
    double alpha = asin(radius_/distR); // [0, pi/2]
    double curT = centerCyl[1]; // [0, pi*2]
    double t1 = curT - alpha;
    double t2 = curT + alpha;
    t1 = (t1 < 0) ? t1 + 2.0*M_PI : t1;
    t1 = (t1 > 2.0*M_PI) ? t1 - 2.0*M_PI : t1;
    t2 = (t2 < 0) ? t2 + 2.0*M_PI : t2;
    t2 = (t2 > 2.0*M_PI) ? t2 - 2.0*M_PI : t2;
    tStart = floor(std::min(t1, t2)/dTheta_);
    tEnd   = ceil(std::max(t1, t2)/dTheta_);
    tStart = (tStart < 0) ? 0 : tStart;
    tEnd   = (tEnd >= nTheta) ? nTheta - 1: tEnd;
  }
  // set f into default velocity
  for (int i = 0; i < nR*nTheta*nZ; i++) {
    f[i][0] = vr[i];
    f[i][1] = vt[i];
    f[i][2] = vz[i];
  }

  // overwrite f with obstacle velocity.
  #pragma omp parallel for
  for (int k = rStart; k < rEnd; k++)
    for (int j = tStart; j < tEnd; j++)
      for (int i = zStart; i < zEnd; i++) {
        int index = i + j*nZ + k*nZTheta;
        Eigen::Vector3d sph;
        sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dZ_;
        Eigen::Vector3d cat = Transform::Cylinderical::toCartesian(sph, b)*scale; // [-1,1]^3x[0,b*scale]
        cat[2] -= 0.5*b*scale; // zero centered.

        double dist = (cat - center_).norm();
        if (dist > radius_)
          continue;

        Eigen::Matrix3d transMat;
        Transform::Cylinderical::toCartesianMat(sph[1], transMat);
        Eigen::Vector3d vCylRigid = transMat.transpose()*velocity_;
        if (dist < interalRatio_*radius_) {  // inside of the sphere, force the velocity be vrigid.
          f[index][0] = amp*(vCylRigid[0] - vr[index]);
          f[index][1] = amp*(vCylRigid[1] - vt[index]);
          f[index][2] = amp*(vCylRigid[2] - vz[index]);
        } else {  // on the surface, force normal component be zero.
          Eigen::Vector3d normal = (cat - center_)/dist;
          Eigen::Vector3d normalCyl = transMat.transpose()*normal;
          Eigen::Vector3d vField(vr[index], vt[index], vz[index]); // cyl
          Eigen::Vector3d ff = amp*(vCylRigid.dot(normalCyl) - vField.dot(normalCyl))*normalCyl;
          f[index][0] = ff[0];
          f[index][1] = ff[1];
          f[index][2] = ff[2];
        }
      }
}

// is the passed in point inside the sphere?
bool ObstacleSphereCyl::inside(const Eigen::Vector3d& point) const {
  Eigen::Vector3d dist = point - center_;
  if (dist.squaredNorm() <= radius_squared_)
    return true;
  else
    return false;
}
