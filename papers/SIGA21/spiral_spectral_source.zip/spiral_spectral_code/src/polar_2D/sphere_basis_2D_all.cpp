#include "polar_2D/sphere_basis_2D_all.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "elliptic/prolate_sphere_2D_share.h"

void SphereBasis2DAll::DiscretizeAdd(const double coef, VFIELD2D* vfield) const {
  const int nT = vfield->getyRes();
  const int nP = vfield->getxRes();
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double dT = M_PI / nT;
  double dP = 2.0*M_PI/nP;
  
  for (int j = 0; j < nT; j++) {
    for (int i = 0; i < nP; i++) {
      double t = ((double)(j) + 0.5)*dT;   // [0-1]
      double p = ((double)(i) + 0.5)*dP;// - M_PI;  // [0, 2*pi]
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      v *= coef*invNorm_;
      (*vfield)(i,j)[0] = v[0];
      (*vfield)(i,j)[1] = v[1];
    }
  }
}

void SphereBasis2DAll::AddUniformU(const double coef, const int nT, const int nP, double* ut, double* up) const {
  double dT = M_PI / nT;
  double dP = 2.0*M_PI/nP;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;

  for (int j = 0; j < nT; j++) {
    for (int i = 0; i < nP; i++) {
      double t = ((double)(j) + 0.5)*dT;   // [0-1]
      double p = ((double)(i) + 0.5)*dP;// - M_PI;  // [0, 2*pi]
      
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      v *= coef*invNorm_;
      ut[i + j*nP] += v[0];
      up[i + j*nP] += v[1];
    }
  }
}

double SphereBasis2DAll::ProjectUniformU(const int nT, const int nP, double* fr, double* ft) const {
  double dT = M_PI / nT;
  double dP = 2.0*M_PI/nP;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double result = 0;

  for (int j = 0; j < nT; j++) {
    for (int i = 0; i < nP; i++) {
      double t = ((double)(j) + 0.5)*dT;   // [0-1]
      double p = ((double)(i) + 0.5)*dP;// - M_PI;  // [0, 2*pi]
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      result += (v[0]*fr[i + j*nP] + v[1]*ft[i + j*nP]);
    }
  }

  result *= invNorm_;
  result *= dT*dP;

  return result;
}

void SphereBasis2DAll::initBasicCoef() {
  // see dissertation, equ 5.48-5.52
  double invk2 = 1.0;
  if (k2x2 != 0)
    invk2 = 1.0/k2;

  switch (index_) {
    // two regular basis
    case 0:
            phiFunc_[0] = BasicFunc(COS, P, k2x2, 1.0);
            phiFunc_[1] = BasicFunc(SIN, P, k2x2, -invk2);
            CHECK(k1x2 > 0 && k2x2 > 0);
    break;

    case 1:
            phiFunc_[0] = BasicFunc(SIN, P, k2x2, 1.0);
            phiFunc_[1] = BasicFunc(COS, P, k2x2, invk2);
            CHECK(k1x2 > 0 && k2x2 > 0);
    break;

    // circModes
    case 2:
            phiFunc_[0] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[1] = BasicFunc(ONE, P, 0, 1.0);
            CHECK(k1x2 > 0 && k2x2 == 0);
    break;

    // enrich first
    case 3:
            phiFunc_[0] = BasicFunc(COS, P, 2, 1.0);
            phiFunc_[1] = BasicFunc(SIN, P, 2, 1.0);
            CHECK(k1x2 >= 0 && k2x2 == 2);
    break;

    // enrich second
    case 4:
            phiFunc_[0] = BasicFunc(SIN, P, 2, 1.0);
            phiFunc_[1] = BasicFunc(COS, P, 2, -1.0);
            CHECK(k1x2 >= 0 && k2x2 == 2);
    break;

    default:
    LOG(FATAL) << "idx " << index_ << "not supported";
  }

  if (index_ == 0 || index_ == 1) {  // shares expression
    RTMultiply r0;
    r0.rComp = {BasicFunc(ONE, R, 0, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, k1x2, 1.0)};

    RTMultiply t0;
    t0.rComp = {BasicFunc(ONE, R, 0, 1.0)};
    t0.tComp = {BasicFunc(SIN, T, k1x2-2, -0.5*(k1-1.0)), BasicFunc(SIN, T, k1x2+2, 0.5*(k1+1.0))};
    RT_[0] = {r0}; RT_[1] = {t0};
  } else if (index_ == 2) {
    RTMultiply t0;
    t0.rComp = {BasicFunc(ONE, R, 0, 1.0)};
    t0.tComp = {BasicFunc(SIN, T, k1x2, 1.0)};

    RT_[0] = {}; RT_[1] = {t0};
  } else if (index_ == 3 || index_ == 4) {
    RTMultiply r0;
    r0.rComp = {BasicFunc(ONE, R, 0, 1.0)};
    r0.tComp = {BasicFunc(COS, T, k1x2, 1.0)};

    RTMultiply t0;
    t0.rComp = {BasicFunc(ONE, R, 0, 1.0)};
    t0.tComp = {BasicFunc(COS, T, k1x2-2, 0.5*(k1-1.0)), BasicFunc(COS, T, k1x2+2, -0.5*(k1+1.0))};
    RT_[0] = {r0}; RT_[1] = {t0};
  }
}

double SphereBasis2DAll::dotProd(const SphereBasis2DAll& other) const {
  Eigen::Vector2d result(0,0);

  for (int i = 0; i < 2; i++) {
    // <phi_i, phi_i>    
    double pINT = SphereBasis3D::computePhiInt(phiFunc_[i], other.getPhiFunc(i));

    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and phi.
      double rtINT = 0;
      for (const auto& rt1 : RT_[i])
        for (const auto& rt2 : other.getRT(i))
          rtINT += SphereBasis3D::computeVThetaInt(rt1.tComp, rt2.tComp);

      result[i] = pINT*rtINT;
    }
  }
  
  return result.sum();
}

void SphereBasis2DAll::Normalize() {
  norm2_ = dotProd(*this);
  invNorm_ = 1.0/sqrt(norm2_);
}

//sin(t)*D[f_p, t] + cos(t)f_p - D[f_t, p]
void SphereBasis2DAll::curlSph() {
  // sign is grouped into phi func
  curlPhi_[0] = phiFunc_[1];
  curlPhi_[1] = phiFunc_[1];
  curlPhi_[2] = -phiFunc_[0].deriv()[0];
  
  // cos(theta), sin(theta)
  BasicFunc cosT(COS, T, 2, 1.0, 0);
  BasicFunc sinT(SIN, T, 2, 1.0, 0);

  curlRT_[0] = RT_[1];  // f_p
  RTMultiply::derivTVec(curlRT_[0]);  // D[f_p, t]
  RTMultiply::multThetaVec(sinT, curlRT_[0]);  //sin(t)*D[f_p, t]

  curlRT_[1] = RT_[1];  // f_p
  RTMultiply::multThetaVec(cosT, curlRT_[1]);  //cos(t)*f_p

  curlRT_[2] = RT_[0]; // f_t
}

// g_t*h_p - g_p*h_t

void SphereBasis2DAll::crossProdPhi(const SphereBasis2DAll& phiG, const SphereBasis2DAll& phiH,
                                    std::vector<BasicFunc> (&crossPhi)[2]) {
  crossPhi[0] = BasicFunc::multiply(phiG.getPhiFunc(0), phiH.getPhiFunc(1));
  crossPhi[1] = BasicFunc::multiply(phiG.getPhiFunc(1), -phiH.getPhiFunc(0));
}

// sign is in phi component
void SphereBasis2DAll::crossProdRT(const SphereBasis2DAll& phiG, const SphereBasis2DAll& phiH,
                              std::vector<RTMultiply> (&crossRT)[2]) {
  crossRT[0] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(1));
  crossRT[1] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(0));
}

double SphereBasis2DAll::integrateCurlCross(const BasicFunc& curlP, const std::vector<BasicFunc>& crossP,
                                 const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT) {
  // first integrate along phi.
  // int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += SphereBasis3D::computePhiInt(curlP, cp);
  if (fabs(phiInt) < 1e-14)
    return 0.0;
  // integrate along theta, without sin(t) term, because its already in curl.
  double rtInt = 0;
  std::vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  for (const auto& rt : RTProd) {
    double tInt = rt.integrateT();
    if (fabs(tInt) < 1e-14)  // prod is zero.
      continue;
    rtInt += tInt;
  }

  return phiInt*rtInt;
}

double SphereBasis2DAll::computeTensorEntry(const SphereBasis2DAll& phiI, const SphereBasis2DAll& phiG,
       const SphereBasis2DAll& phiH) {
  // compute cross product.
  std::vector<BasicFunc> crossPhi[2];
  std::vector<RTMultiply> crossRT[2];
  SphereBasis2DAll::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis2DAll::crossProdRT(phiG, phiH, crossRT);

  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 3; ind++) {
    rVal += SphereBasis2DAll::integrateCurlCross(phiI.getCurPhi(ind), crossPhi[0], phiI.getCurRT(ind), crossRT[0]);
    rVal += SphereBasis2DAll::integrateCurlCross(phiI.getCurPhi(ind), crossPhi[1], phiI.getCurRT(ind), crossRT[1]);
  }

  return (rVal)*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
}

void SphereBasis2DAll::writeToFile(std::ofstream& out) const {
  out.write(reinterpret_cast<const char *>(&k1x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k2x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&index_), sizeof(int));
}

SphereBasis2DAll* SphereBasis2DAll::fromFile(std::ifstream& in) {
  int k1x2, k2x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));
  return new SphereBasis2DAll(k1x2, k2x2, index_);
}