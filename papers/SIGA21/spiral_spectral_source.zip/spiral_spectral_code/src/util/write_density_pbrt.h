#ifndef WRITE_DENSITY_PBRT_H
#define WRITE_DENSITY_PBRT_H

#include <string>
#include "3D/FIELD_3D.h"

// Write the density field to PBRT.
void WriteDensityPBRT(const std::string& fname, const FIELD_3D& field, const float attenuation_factor);

#endif  // WRITE_DENSITY_PBRT_H
