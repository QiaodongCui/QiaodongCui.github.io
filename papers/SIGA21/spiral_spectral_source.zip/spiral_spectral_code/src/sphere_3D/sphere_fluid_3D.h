#ifndef SPHERE_FLUID_3D_H
#define SPHERE_FLUID_3D_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <learnopengl/shader_m.h>
#include <memory>
#include <vector>

#include "3D/drawer_3d.h"
#include "3D/FIELD_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "3D/particle_3d.h"
#include "common/particle_sph_3d.h"
#include "common/eigen_fluid.h"
#include "elliptic/prolate_oblate_3D.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/cylinder_basis_set_3D.h"
#include "sphere_3D/obstacle_sphere_cyl.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "sphere_3D/sphere_basis_set_3D.h"
#include "sphere_3D/torus_basis_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"
#include "solver/integrator_2d.h"
#include "setting.h"
#include "util/colorMap.h"
#include "util/timer.h"
#include "util/gl4_drawer.h"
#include "util/smoke_render_gl4.h"

/*The physical dimension is [-1,1]^2xz the maximum length is 2.*/

class SphereFluid3D : public EigenFluid {
public:
  SphereFluid3D(
    const int xRes, const int yRes, const int zRes, const int basis_dim,
    const double dt,
    const std::string& basis_type, const std::string& boundaryCnd,
    const std::string& integrator_type,
    double buoyancy, double visc, 
    const int num_particles, const int total_frame,
    const std::string tensor_fname, const double tensorWeight, const double b, 
    const double cylinderH, const bool dissipateDensity, const bool headless, const int maxDensityParticles,
    const double densityPtlWeight, const double vdbGridScale, const double maxHeatParticles,
    const double heatPtlWeight, const int scenario, const bool outputRGBVolume, const double cylSeedH,
    const double cylSeedR, const bool filterForce):
    EigenFluid(basis_dim, dt, buoyancy, visc, num_particles, total_frame, basis_type, tensor_fname,
             tensorWeight, integrator_type),headless_(headless),
    xRes_(xRes), yRes_(yRes), zRes_(zRes),
    boundaryCnd_(boundaryCnd),
    tensorWeight_(tensorWeight),
    b_(b), a_(sqrt(1.0 - b*b)), c_(b/sqrt(1.0 - b*b)),cylinderH_(cylinderH),dissipateDensity_(dissipateDensity),
    maxDensityParticles_(maxDensityParticles*1000000), densityPtlWeight_(densityPtlWeight), vdbGridScale_(vdbGridScale),
    maxHeatParticles_(maxHeatParticles*1000000), heatPtlWeight_(heatPtlWeight), scenario_(scenario),
    outputRGBVolume_(outputRGBVolume), cylSeedH_(cylSeedH), cylSeedR_(cylSeedR), filterForce_(filterForce)
    {
      if (! isfinite(a_) || !isfinite(b_) || ! isfinite(c_)) {
        a_ = 0;
        b_ = 1.0;
        c_ = 1.0;
      }
      // TODO: modify the LaplacianBasisSet2D to support differemt xRes and yRes.
      CHECK(xRes % 2 == 0) << "xres even";
      CHECK(xRes == yRes) << "Only support symmetric domain for now.";
      // make sure this is correct.
      dx_ = 2.0 /xRes_;

      // in this case, the maximum dimension becomes z.
      if (cylinderH_ > 2.0 && basis_type == "cylinder_3d") {
        dx_ = 2.0/zRes_;
      }
      
      Initialize();
    }
  ~SphereFluid3D(){}
  // Perform the forward step.
  void Step();
  void DrawDensity(const glm::mat4& modelView, const double alpha, const bool drawDensity);
  
  void DrawParticles(const double ptl_length);
  void DrawCoefficients(const double multi_factor);
  void DrawObstacles() {};
  void AddBuoyancy();
  //void AddDensity();
  void ReSeedParticles() {
    basis_->ReSeedParticles(particles_, initPos_);
  }
  void addDensityParticles();

  void Quit();
  bool isFinished(){return quit_;}
  
  bool addBounyancyOnce = false;
  bool quit_ = false;
  const std::vector<ParticleSph3D>& particles() {
    return particles_;
  }

  double dx() {
    return dx_;
  }

  void splatParticle();
  void addCircSmoke();

  std::string density_folder_;
  void OutputToPBRT();
  
  // sample the obstacle with tracer particles, just for visualization.
  void setObstacleParticles();

protected:
  const bool headless_;
  std::unique_ptr<Renderer3DGL4> smoke_render_;
  bool render_initialized_ = false;

  void Initialize();
  void FilterForce(Eigen::VectorXd& forceCoef, const double mult);

  // The resolution of the cartesian velocity field.
  const int xRes_;
  const int yRes_;
  const int zRes_;

  const std::string boundaryCnd_;
  
  double tensorWeight_ = 1.0;

  // The energy of current timestep.
  double current_energy_;

  double dx_;

  Eigen::VectorXd tempVector_;
  Eigen::VectorXd fieldCoef_;
  
  std::shared_ptr<BasisSet3D> basis_;
  
  // Class to draw stuff.
  std::unique_ptr<Drawer3D> drawer_;
  std::unique_ptr<coeffcientDrawGL4> coefDrawer_;
  std::unique_ptr<particle3DGL4> ptlGL4_;
  //std::unique_ptr<denstityDrawerSphere> densDrawer_;
  
  // Velocity field.
  VECTOR3_FIELD_3D velocity_;
  // Force field.
  VECTOR3_FIELD_3D force_;
  // A force field that lines-up in the parameter space.
  // xRes, yRes, zRes lines up with (nphi, ntheta, nr)
  VECTOR3_FIELD_3D forceDirect_;

  FIELD_3D forceMag_;

  // Density field.
  FIELD_3D density_;
  FIELD_3D density_old_;
  FIELD_3D temp1;
  FIELD_3D temp2;
  FIELD_3D heat_;

  // Particles.
  std::vector<ParticleSph3D> particles_;
  std::vector<Eigen::Vector3d> initPos_;

  //std::vector<ParaParticle3Df> densityParticles_;
  std::default_random_engine m_gen_;

  std::unique_ptr<ParticleSystem> particleSys_;
  std::vector<Eigen::Vector3f> particleColor_;

  void AddExternalForce();
  void AddWindField(Eigen::VectorXd& fieldCoef);
  void AdvectDensity();
  void AdvectParticles();

  double b_;
  double a_;
  double c_;
  
  double majorA_ = 3.0;
  const double cylinderH_;
  const bool dissipateDensity_;

  const bool particleBasedAdvection_ = true;
  const int maxDensityParticles_;
  const double densityPtlWeight_ ;
  // a multipler of vdb density grid scale compared to simulation
  // grid scale. default value 1.0
  const double vdbGridScale_;

  //temperature
  const int maxHeatParticles_;
  const double heatPtlWeight_;

  // which scenario is it
  const int scenario_;

  const bool outputRGBVolume_;
  bool is_spheroid_ = false;
  bool is_oblate_ = false;
  bool is_prolate_ = false;

  std::vector<std::shared_ptr<ObstacleSphereCyl>> obsSphCyl_;
  double cylSeedH_ = 0.5;
  double cylSeedR_ = 0.9;
  const bool advectTracer_ = false;
  std::shared_ptr<ColorMap> colorMap_;
  const bool filterForce_;
  Adv_Tensor_Type sparseA_;
  Adv_Tensor_Type sparseD_;
};

#endif  // SPHERE_FLUID_3D_H
