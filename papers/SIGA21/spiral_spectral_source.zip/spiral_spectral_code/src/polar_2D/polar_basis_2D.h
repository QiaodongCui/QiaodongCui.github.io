#ifndef POLAR_BASIS_2D_H
#define POLAR_BASIS_2D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>
#include "2D/FIELD2D.h"
#include "2D/VFIELD2D.h"

class PolarBasis2D {

public:
  // init, 2*wavenumber
  PolarBasis2D(const int kk1D, const int kk2D, bool kind):k1(kk1D*0.5), k2(kk2D*0.5), k1x2(kk1D), k2x2(kk2D),
    kind_(kind) {
     invNorm_ = 0; // Default zero.
    // Initialize DCT norm.
    int num_zeros = 0;
    if (k1 == 0) num_zeros ++;
    if (k2 == 0) num_zeros ++;
    // need dct both directions
    if (num_zeros == 0) {
      DCTNorm_ = 0.25;
    } else if (num_zeros == 1) { // only dct one direction
      DCTNorm_ = 0.5;
    } else {  // dc component
      DCTNorm_ = 1;
    }
    poleNorm_ = 1.0;
    if ((0.5*k1 + 0.25*k2) > 1.0)
      poleNorm_ = poleNorm_ / (0.5*k1 + 0.25*k2);
  };

  ~PolarBasis2D(){};

  virtual void DiscretizeAdd(const double coef, FIELD2D& r, FIELD2D& theta,
                            VFIELD2D* vfield) {
    LOG(FATAL) << "base class called";
  }

  virtual void Normalize() {
    LOG(FATAL) << "base class called";
  }

  // compute ur along a uniform theta r grid
  virtual void AddUniformU(const double coef, const int nR, const int nTheta, double* ur, double* ut) const {
    LOG(FATAL) << "base class called";
  }
  
  virtual double ProjectUniformU(const int nR, const int nTheta, double* ur, double* ut) const {
    LOG(FATAL) << "base class called";
  }

  virtual double dotProd(const PolarBasis2D& other) const {
    LOG(FATAL) << "base class called";
  }

  virtual void writeToFile(std::ofstream& out) const {
    LOG(FATAL) << "base class called";
  }
  
  // extract int version of wn1
  // wave number 1, its up to user to ensure K1D is always even
  int WN1I() const {
    return k1x2/2;
  }

  double WN1D() const {
    return k1;
  }
  
  int WN2I() const {
    return k2x2/2;
  }

  // wave number 2
  double WN2D() const {
    return k2x2*0.5;
  }
  
  int WN1x2() const {
    return k1x2;
  }

  int WN2x2() const {
    return k2x2;
  }

  double GetDCTNorm() const {
    return DCTNorm_;
  }
  
  double GetInvNorm() const {
    return invNorm_;
  }
  
  bool kind() const {
    return kind_;
  }

  void debugPrint() const {
    LOG(INFO) << "k1 " << k1 << " k2 " << k2 << " kind " << index_ << " norm " << invNorm_;
  }
  
  double poleNorm() const {
    return poleNorm_;
  }
  int index() const {
    return  index_;
  }
  bool trigFirst() const {
    return k1Sin_;
  }
  bool trigSecond() const {
    return k2Sin_;
  }

protected:
  const double k1;
  const double k2;

  // 2* wavenumber
  const int k1x2;
  const int k2x2;

  double invNorm_;
  double DCTNorm_;
  double poleNorm_;

  //double DCTNorm_;
  // which kind of basis is this ?
  // kind = true  Phi  ur = cos(i1 pi r) sin(i2 theta)
  // kind = false Psi  ur = cos(i1 pi r) cos(i2 theta)
  const bool kind_;

  // index for different kind of basis functions
  int index_;

  // the mode along each direction.
  bool k1Sin_;
  bool k2Sin_;
};

typedef std::shared_ptr<PolarBasis2D> basisPtr;

#endif // POLAR_BASIS_2D_H