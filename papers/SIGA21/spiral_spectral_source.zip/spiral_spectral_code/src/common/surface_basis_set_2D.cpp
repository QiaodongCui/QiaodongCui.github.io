#include "common/surface_basis_set_2D.h"

void SurfaceBasisSet2D::advectRK4(ParticleSph3D& p, const double& dt_) {
  // Get the velocity at the particles.
  const Eigen::Vector3d& position = p.position;

  Eigen::Vector3d p_v = this->getVelocityPos(position);
  Eigen::Vector3d K1 = p_v*dt_;
  Eigen::Vector3d pos1 = position + K1*0.5;
  p_v = this->getVelocityPos(pos1);

  Eigen::Vector3d K2 = p_v*dt_;
  Eigen::Vector3d pos2 = position + K2*0.5;
  p_v = this->getVelocityPos(pos2);

  Eigen::Vector3d K3 = p_v*dt_;
  Eigen::Vector3d pos3 = position + K3;

  p_v = this->getVelocityPos(pos3);
  Eigen::Vector3d K4 = p_v*dt_;

  p.position += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;
  p.velocity = p_v;
}

void SurfaceBasisSet2D::advectRK4(ParaParticle3Df& p, const double& dt_) {
  // Get the velocity at the particles.
  const Eigen::Vector3f& position = p.position_;

  Eigen::Vector3f p_v = this->getVelocityPos(position);
  Eigen::Vector3f K1 = p_v*dt_;
  Eigen::Vector3f pos1 = position + K1*0.5;
  p_v = this->getVelocityPos(pos1);

  Eigen::Vector3f K2 = p_v*dt_;
  Eigen::Vector3f pos2 = position + K2*0.5;
  p_v = this->getVelocityPos(pos2);

  Eigen::Vector3f K3 = p_v*dt_;
  Eigen::Vector3f pos3 = position + K3;

  p_v = this->getVelocityPos(pos3);
  Eigen::Vector3f K4 = p_v*dt_;

  p.position_ += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;
  this->projPosBack(p);
}