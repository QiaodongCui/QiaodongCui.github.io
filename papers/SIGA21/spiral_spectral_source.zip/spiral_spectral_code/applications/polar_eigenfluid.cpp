#include "setting.h"

#include <iostream>
#define GLUT_DISABLE_ATEXIT_HACK

#ifdef APPLE
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <glog/logging.h>
#include <gflags/gflags.h>
#include <sys/time.h>
#include <string>
#include <vector>

#include "polar_2D/polar_fluid_2D.h"
#include "util/timer.h"
//#include "2D/obstacle_2d.h"
#include "util/QUICKTIME_MOVIE.h"
#include "util/get_current_time.h"

PolarFluid2D* fluid;

static int fluid_window_x = 1024, spectra_window_x = 512; 
static int fluid_window_y = 1024, spectra_window_y = 512;
static int fluid_win_id;
static int spectra_win_id;
static int mouse_down[3];
static int omx, omy, mx, my;
const double spectra_draw_factor = 0.2;
// double particle_length_factor = 0.1;
static bool addedDensity = false;
static bool dvel = false;

DEFINE_bool(add_density, true, "Whether to add density into the fluid.");
DEFINE_int32(xRes, 512, "The xReslution of the fluid.");
DEFINE_int32(yRes, 512, "The yReslution of the fluid.");
DEFINE_int32(basis_dim, 20, "The number of wanted basis.");
DEFINE_double(dt, 0.1, "The time step of the simulation.");
DEFINE_double(buoyancy, 0.0001, "The buoyancy of the fluid.");
DEFINE_double(viscosity, 0.005, "The viscosity of the fluid.");
DEFINE_double(tensorWeight, 1.0, "The weight of the tensor.");

DEFINE_double(b, 0.9, "The short axis for elliptic basis functions.");

DEFINE_string(basis_type, "all_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");
DEFINE_string(integrator_type, "RK4", "The integrator_type. Can be RK4, semi_implicit"
              "BiCGSTAB");
DEFINE_int32(total_frame, 2000, "The total frame want to simulate.");
DEFINE_int32(total_num_particles, 1000, "The total number of particles");
DEFINE_double(particle_length_factor, 0.1, "How long is the particles.");
DEFINE_double(force_scale, 0.5, "The force scale to apply the force by mouse");
DEFINE_string(Tensor_file, "", "The file which stores all the tensor.");
DEFINE_bool(add_density_once, false, "Only add the density to the first of the frame");

DEFINE_bool(capture_video, false, "Whether to capture the video.");
DEFINE_string(preview_fpath, "", "The folder to put the preview video.");
QUICKTIME_MOVIE movie;

namespace {

void SavePreviewAndQuit() {
  if (FLAGS_capture_video) {
    std::string datetime = getCurrentDateTime(true);
    std::stringstream outname;
    outname << FLAGS_preview_fpath << datetime << ".mov";
    movie.writeMovie(outname.str().c_str());
    // reset the movie object
    movie = QUICKTIME_MOVIE();
  }
  //delete fluid;
  
  LOG(INFO) << "Exitting...";
  exit(0);
}

}  // namespace

static void fluid_pre_display ( void ) {
  glViewport ( 0, 0, fluid_window_x, fluid_window_y );
  glMatrixMode ( GL_PROJECTION );
  glLoadIdentity ();
  gluOrtho2D ( 0.0, 1.0, 0.0, 1.0 );
  glClearColor ( 1.0f, 1.0f, 1.0f, 1.0f );
  glClear ( GL_COLOR_BUFFER_BIT );
}

static void spectra_pre_display(void) {
  glViewport ( 0, 0, spectra_window_x, spectra_window_y);
  glMatrixMode ( GL_PROJECTION );
  glLoadIdentity ();
  gluOrtho2D ( 0.0, 1.0, 0.0, 1.0 );
  glClearColor ( 0.0f, 0.0f, 0.0f, 1.0f );
  glClear ( GL_COLOR_BUFFER_BIT );
}

static void key_func ( unsigned char key, int x, int y ) {
  switch ( key ) {   
    case 'q':
    case 'Q':
      fluid->Quit();
      exit (0);
      break;
    case 'v':
    case 'V':
      dvel = !dvel;
      break;
    case 'r':
    case 'R':
      fluid->ReSeedParticles();
      break;
  }
}

static void SpecialInput(int key, int x, int y) {
	;
}

static void mouse_func ( int button, int state, int x, int y ) {
  omx = mx = x;
  omx = my = y;

  mouse_down[button] = state == GLUT_DOWN;
}

static void motion_func ( int x, int y ) {
  mx = x;
  my = y;
}

static void reshape_func_fluid ( int width, int height ) {
  glutSetWindow ( fluid_win_id );
  glutReshapeWindow ( width, height );
  fluid_window_x = width;
  fluid_window_y = height;
}

static void reshape_func_extra(int width, int height) {
  glutSetWindow ( spectra_win_id );
  glutReshapeWindow ( width, height );
  spectra_window_x = width;
  spectra_window_y = height;
}

void get_from_UI () {
  int i, j;
  bool addDens = FLAGS_add_density;
  
  if (addDens) {
    //fluid->AddSmokeTestCase(FLAGS_source_smoke_xpos, FLAGS_source_smoke_ypos,
    //                        FLAGS_source_smoke_width, FLAGS_source_smoke_height);
    addedDensity = true;
  }

  if ( !mouse_down[0] && !mouse_down[2] ) {return;}
  
  i = (int)((       mx /(float)fluid_window_x)*(FLAGS_xRes - 1));
  j = (int)(((fluid_window_y-my)/(float)fluid_window_y)*(FLAGS_yRes - 1));
  int index = i + j*FLAGS_xRes;
  if ( i<1 || i>(FLAGS_xRes - 1) || j<1 || j>(FLAGS_yRes - 1) ) return;
  if (mouse_down[0]) {
    fluid->AddForce(i,j,FLAGS_force_scale *(mx - omx),
                    FLAGS_force_scale * (omy - my));
  }
  if ( mouse_down[2] ) {
    fluid->AddSmoke(i,j, 5);
  }
  omx = mx;
  omy = my;
  return;
}

static void idle_func ( void ) {
  get_from_UI();
  {  fluid->Step();
    
  }

  if (fluid->quit_) {
    SavePreviewAndQuit();
  }
  
  glutSetWindow ( fluid_win_id );
  glutPostRedisplay ();
  glutSetWindow(spectra_win_id);
  glutPostRedisplay();
}

static void post_display ( void ) {
  glutSwapBuffers ();
}

static void fluid_display_func ( void ) {
  fluid_pre_display ();
  if ( dvel ) fluid->DrawVelocity();
  else  fluid->DrawDensity();

  fluid->DrawParticles(FLAGS_particle_length_factor);
  fluid->DrawObstacles();
  // The visualization of the velocity subject the aliasing of the screen.
  if (FLAGS_capture_video) {
      movie.addFrameGL(); // This function will eat lots of memory afterwards.
  }
  
  post_display ();
  
}

static void spectra_display_func(void) {
  spectra_pre_display();
  // Plot the spectra coefficients.
  fluid->DrawCoefficients(spectra_draw_factor);
  //if (FLAGS_capture_video) {
  //    movie.addFrameGL(); // This function will eat lots of memory afterwards.
  //}
  post_display();
}

static void open_glut_window ( void ) {
  glutInitDisplayMode ( GLUT_RGBA | GLUT_DOUBLE );

  glutInitWindowPosition ( 0, 0 );
  glutInitWindowSize ( fluid_window_x, fluid_window_y );
  fluid_win_id = glutCreateWindow ( "2d" );

  glClearColor ( 1.0f, 1.0f, 1.0f, 1.0f );
  glClear ( GL_COLOR_BUFFER_BIT );
  glutSwapBuffers ();
  glClear ( GL_COLOR_BUFFER_BIT );
  glutSwapBuffers ();
  fluid_pre_display ();
  glutKeyboardFunc ( key_func );
  glutSpecialFunc(SpecialInput);
  glutMouseFunc ( mouse_func );
  glutMotionFunc ( motion_func );
  glutReshapeFunc ( reshape_func_fluid );
  glutIdleFunc ( idle_func );
  glutDisplayFunc ( fluid_display_func );
  
  glutInitDisplayMode ( GLUT_RGBA | GLUT_DOUBLE );
  glutInitWindowPosition ( 580, 0 );
  glutInitWindowSize ( spectra_window_x, spectra_window_x );
  spectra_win_id = glutCreateWindow("energy");
  glClearColor ( 0.0f, 0.0f, 0.0f, 1.0f );
  glClear ( GL_COLOR_BUFFER_BIT );
  glutSwapBuffers ();
  glClear ( GL_COLOR_BUFFER_BIT );
  glutSwapBuffers ();
  spectra_pre_display();
  glutReshapeFunc (reshape_func_extra);
  glutDisplayFunc(spectra_display_func);
}

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  glutInit (&argc, argv);
  
  fluid = new PolarFluid2D(FLAGS_xRes, FLAGS_yRes, FLAGS_basis_dim,
      FLAGS_dt, FLAGS_basis_type, FLAGS_integrator_type, FLAGS_buoyancy, FLAGS_viscosity,
      FLAGS_total_num_particles, FLAGS_total_frame, FLAGS_Tensor_file,
      FLAGS_tensorWeight, FLAGS_b);

  open_glut_window ();
  glutMainLoop ();

  return 0;
}