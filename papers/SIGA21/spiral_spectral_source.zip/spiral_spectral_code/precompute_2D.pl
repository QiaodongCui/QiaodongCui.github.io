#!/usr/bin/perl -w
use strict;
use warnings;
use Time::HiRes;

my $BIN_PATH = "bin/polar_precompute";

#sphere2D_precompute.flags
#torus2D_precompute.flags

my $script_file = "./torus2D_precompute.flags";

system($BIN_PATH." --flagfile=".$script_file." --logtostderr" );