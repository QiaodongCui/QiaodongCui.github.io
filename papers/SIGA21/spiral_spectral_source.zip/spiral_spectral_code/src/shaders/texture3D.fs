#version 330 core
out vec4 FragColor;

in vec3 TexCoords;

uniform sampler3D texture_diffuse1;

void main()
{   
	vec4 temp = texture(texture_diffuse1, TexCoords);
    FragColor = temp;
}