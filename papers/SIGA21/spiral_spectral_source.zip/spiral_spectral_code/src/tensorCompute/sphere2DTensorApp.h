static double evalsph2D_0(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
))
+((sph2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_1(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
))
+((sph2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_2(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_3(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_4(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_5(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
))
+((sph2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_6(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
))
+((sph2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_7(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_8(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_9(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_10(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_11(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_12(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_13(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_14(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_15(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_16(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_17(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_18(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_19(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
))
+((sph2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_20(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_21(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_22(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_23(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
))
+((sph2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_24(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_25(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
))
+((sph2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_26(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
))
+((sph2DpEval::evalP_25(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_25(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_27(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_26(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_26(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_28(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_27(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_27(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_28(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_28(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_29(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_29(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_29(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_30(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_30(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_30(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_25(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_25(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
))
+((sph2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_31(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
))
+((sph2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_32(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_31(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_31(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_33(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_30(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_30(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_29(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_29(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_34(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_28(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_28(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2*i2*i2)))
+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g2*h1*i2*i2)))
))
+((sph2DpEval::evalP_27(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_27(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_35(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_32(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_32(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_36(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_33(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_33(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_37(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_38(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_34(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_34(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_39(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_35(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_35(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_40(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_36(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_36(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_37(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_37(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_41(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_38(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_38(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_39(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_39(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_42(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_34(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_34(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_43(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_40(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_40(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_44(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_41(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_41(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
))
+((sph2DpEval::evalP_42(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_42(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_45(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_39(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_39(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_38(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_38(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_46(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_37(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_37(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2*i2*i2)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i2*i2)))
))
+((sph2DpEval::evalP_36(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_36(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_47(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_35(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_35(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_48(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_41(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_41(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-h1*i2*i2)))
))
+((sph2DpEval::evalP_42(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_42(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+i2*i2)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_49(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_40(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_40(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g1*i2*i2)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+h1*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_50(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_43(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_43(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
))
+((sph2DpEval::evalP_44(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_44(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_51(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_45(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_45(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
))
+((sph2DpEval::evalP_46(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_46(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_52(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_47(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_47(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_53(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_48(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_48(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
))
+((sph2DpEval::evalP_49(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_49(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+g1*i1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_54(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_50(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_50(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
))
+((sph2DpEval::evalP_51(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_51(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+g1*i1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_55(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_46(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_46(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
+((sph2DpEval::evalP_45(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_45(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_56(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_44(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_44(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
+((sph2DpEval::evalP_43(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_43(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((sph2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_57(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_52(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_52(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_58(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_51(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_51(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
))
+((sph2DpEval::evalP_50(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_50(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-g1*i1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_59(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_49(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_49(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
))
+((sph2DpEval::evalP_48(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_48(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-g1*i1)))
+((sph2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_60(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_53(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_53(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_61(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_54(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_54(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_62(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_63(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_55(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_55(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_64(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_56(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_56(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_65(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_57(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_57(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
))
+((sph2DpEval::evalP_58(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_58(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-h1*i1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_66(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_59(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_59(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
))
+((sph2DpEval::evalP_60(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_60(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+h1*i1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_67(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_55(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_55(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_68(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_61(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_61(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g1*i1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_69(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_62(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_62(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+i1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g1*i1)))
))
+((sph2DpEval::evalP_63(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_63(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+i1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_70(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_60(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_60(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
))
+((sph2DpEval::evalP_59(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_59(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-h1*i1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_71(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_58(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_58(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
))
+((sph2DpEval::evalP_57(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_57(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+h1*i1)))
+((sph2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_72(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_56(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_56(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_73(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_62(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_62(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-i1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+h1*i1)))
))
+((sph2DpEval::evalP_63(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_63(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-i1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_74(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_61(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_61(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g1*i1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_75(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_64(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_64(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
+((sph2DpEval::evalP_65(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_65(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_76(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_66(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_66(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
+((sph2DpEval::evalP_67(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_67(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_77(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_48(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_48(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_78(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_68(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_68(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_69(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_69(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_79(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_70(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_70(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_71(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_71(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_80(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_67(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_67(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
+((sph2DpEval::evalP_66(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_66(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_81(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_65(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_65(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
+((sph2DpEval::evalP_64(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_64(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_82(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_51(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_51(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_83(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_71(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_71(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_70(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_70(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_84(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_69(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_69(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_68(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_68(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_85(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_57(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_57(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_86(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_59(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_59(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_87(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_88(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_61(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_61(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_89(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_62(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_62(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_90(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_72(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_72(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
))
+((sph2DpEval::evalP_73(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_73(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_91(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_74(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_74(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
))
+((sph2DpEval::evalP_75(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_75(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_92(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_61(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_61(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_93(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_76(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_76(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_94(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_77(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_77(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
))
+((sph2DpEval::evalP_78(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_78(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-h1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_95(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_75(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_75(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
))
+((sph2DpEval::evalP_74(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_74(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_96(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_73(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_73(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
))
+((sph2DpEval::evalP_72(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_72(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_97(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_62(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_62(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_98(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_77(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_77(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+h1)))
))
+((sph2DpEval::evalP_78(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_78(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_99(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_76(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_76(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_100(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_79(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_79(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
+((sph2DpEval::evalP_80(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_80(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_101(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_81(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_81(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
+((sph2DpEval::evalP_82(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_82(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_102(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_50(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_50(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_103(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_70(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_70(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_83(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_83(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_104(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_84(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_84(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_69(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_69(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_105(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_82(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_82(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
+((sph2DpEval::evalP_81(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_81(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_106(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_80(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_80(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
+((sph2DpEval::evalP_79(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_79(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_107(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_49(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_49(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_108(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_69(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_69(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_84(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_84(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_109(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_83(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_83(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+g2)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
+((sph2DpEval::evalP_70(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_70(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_110(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_60(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_60(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_111(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_58(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_58(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_112(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_113(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_63(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_63(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_114(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_61(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_61(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_115(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_75(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_75(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
))
+((sph2DpEval::evalP_85(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_85(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_116(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_73(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_73(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
))
+((sph2DpEval::evalP_86(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_86(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_117(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_63(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_63(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_118(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_78(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_78(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_119(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_76(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_76(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*g1*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g1+g1*i1*i1)))
))
+((sph2DpEval::evalP_87(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_87(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+h1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_120(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_86(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_86(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
))
+((sph2DpEval::evalP_73(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_73(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_121(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_85(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_85(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((sph2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((sph2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((sph2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
))
+((sph2DpEval::evalP_75(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_75(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_122(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_61(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_61(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-3*i1)))
+((sph2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-1+-i1*i1)))
+((sph2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_123(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_76(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_76(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-h1+-h1*i1*i1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-h1)))
))
+((sph2DpEval::evalP_87(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_87(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-1)))
+((sph2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+1)))
+((sph2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+1+i1*i1)))
+((sph2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*i1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalsph2D_124(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +((sph2DpEval::evalP_78(i2x2, g2x2, h2x2) == 0) ? 0 :sph2DpEval::evalP_78(i2x2, g2x2, h2x2)*(+((sph2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*g1*i1)))
+((sph2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+g1)))
+((sph2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g1)))
+((sph2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h1*i1)))
+((sph2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g1+-g1*i1*i1)))
+((sph2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+h1)))
+((sph2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h1)))
+((sph2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :sph2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+h1+h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
