import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pickle

data = pickle.load(open('data/marti_hydro_mid.pkl','rb'))
phi = data['r'].ravel()[0:-1:4]

print(phi.shape)
x = np.zeros(phi.shape)
plt.plot(phi, x, '.', color='black')

plt.show()