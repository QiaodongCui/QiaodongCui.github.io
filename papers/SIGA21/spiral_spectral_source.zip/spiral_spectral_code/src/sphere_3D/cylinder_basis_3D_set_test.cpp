#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "sphere_3D/cylinder_basis_set_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "common/basis_set.h"

#include "util/util.h"
#include "util/timer.h"

using namespace std;

namespace {
  
void testTransform() {
  unique_ptr<CylinderBasisSet3D> cBasis_;
  const int xRes_ = 128;
  cBasis_.reset(new CylinderBasisSet3D(xRes_/2, xRes_, xRes_, 4,4,4, 2.0, true, 0));
  VECTOR3_FIELD_3D velocity_(xRes_, xRes_, xRes_);
  Eigen::VectorXd vecCoef = Eigen::VectorXd::Zero(cBasis_->numBasisAll());
  //vecCoef[0] = 1.0;
  cBasis_->InverseTransformToVelocity(vecCoef);
  //cBasis_->ForwardTransformtoFrequency(velocity_, &vecCoef);
}

void testTensor() {
  const int xRes_ = 128;
  CylinderBasisSet3D basis(xRes_/2, xRes_, xRes_,  4,4,8, 2.0, true, 0);
  vector<Adv_Tensor_Type> Adv_tensor_;
  basis.outputTestTensorEntries(100, "./cylinder3D_tensorTest.txt", &Adv_tensor_);
  //BasisSet::VerifyAntisymmetric(Adv_tensor_);
}

void computeLaplacian() {
  const int xRes_ = 128;
  CylinderBasisSet3D basis(xRes_/2, xRes_, xRes_,  4,4,4, 2.0, true, 0);
  Eigen::MatrixXd laplacian;
  basis.computeLaplacianMatrix(laplacian);
  //LOG(INFO) << laplacian.diagonal().transpose();
  /*for (int i = 0; i < basis.numBasisAll(); i++) {
    basis.printBasis(i);
    printf(" %f \n", laplacian(i,i));
  }*/
  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es;
  es.compute(laplacian);
  LOG(INFO) << "The eigenvalues of A are: " << es.eigenvalues().transpose();
  ofstream out("./laplacian.bin", std::ios::binary);
  uint64_t rows = laplacian.rows(), cols = laplacian.cols();
  out.write((char*)(&rows), sizeof(uint64_t));
  out.write((char*)(&cols), sizeof(uint64_t));
  out.write((char*)(laplacian.data()), sizeof(double)*rows*cols);
  out.close();
}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);
  //testTransform();
  //testTensor();
  computeLaplacian();
}