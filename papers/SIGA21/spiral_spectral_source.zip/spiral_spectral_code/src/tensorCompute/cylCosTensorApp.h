static double evalcylCos_0(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_1(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_2(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_3(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_4(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+b*g2*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_5(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi+b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_6(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_7(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_8(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_9(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_10(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+-b*g2*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_11(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi+-b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_12(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_13(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_14(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_15(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_16(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i2*i3*Pi*i3*Pi*Pi+-b*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_17(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_18(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_19(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_20(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_21(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_22(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i2*i3*Pi*i3*Pi*Pi+-b*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_23(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_24(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+-b*h2*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_25(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+b*h2*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_26(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i2*i3*Pi*i3*Pi*Pi+b*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_27(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i2*i3*Pi*i3*Pi*Pi+b*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_28(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+2*b*h3*i2*i3*Pi*i3*Pi*Pi+b*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_90(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_86(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-2*b*g3*i2*i3*Pi*i3*Pi*Pi+-b*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_29(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*i2*Pi*b*i2*b)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_30(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi+-b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_31(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi+b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_32(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_33(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_34(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*i2*Pi*b*i2*b)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_35(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_36(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_4(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_37(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_0(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_38(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_10(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_39(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_7(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_40(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_14(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+-b*g2*g3*i2*Pi*b*Pi*b*Pi/2+-2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_41(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi+b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_42(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_1(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_16(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_2(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_43(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g2*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g2*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_8(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_3(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_5(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_6(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_3(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_13(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_9(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_4(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_10(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_11(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_12(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_7(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_5(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_15(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_0(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_1(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_2(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_44(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_18(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi+-b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_6(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_8(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_45(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_23(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_17(i1x2, g1x2, h1x2)*(+b*g2*h3*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_21(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_17(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi+b*g2*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_16(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_9(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_11(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_46(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+-b*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*g2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_33(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_12(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g2*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i2*i3*Pi*i3*Pi*Pi+b*g2*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g2*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_39(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_13(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_30(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_47(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi+-b*g2*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*g3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_19(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+-b*g1*g2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*g2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*g2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_48(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_24(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_49(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_20(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_50(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_29(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_51(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_52(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i2*i3*Pi*i3*Pi*Pi+b*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_53(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_54(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_21(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_35(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_22(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi+b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_55(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_22(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_52(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_50(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*Pi*b*i2*Pi*b*Pi/4)+cylSinrEval::evalR_18(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_19(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_20(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_51(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_25(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi+-b*g3*h2*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_49(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_23(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_34(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_25(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_56(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_36(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_63(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_26(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_27(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_57(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_28(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_30(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_58(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i2*i3*Pi*i3*Pi*Pi+b*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h1*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*g3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_59(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_60(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+-b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_40(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+b*h2*h3*i2*Pi*b*Pi*b*Pi/2+2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_61(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+b*g3*h2*i2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i2*Pi*b*Pi*b*Pi*Pi/8+b*g3*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_31(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i2*Pi*b*Pi*b*Pi*Pi/4+b*g3*h1*h2*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_32(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*i2*Pi*b*Pi*b*Pi*Pi)+cylSinrEval::evalR_82(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*i2*Pi*b*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_38(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i2*i3*Pi*i3*Pi*Pi+-b*h2*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h2*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_83(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_44(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_36(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_43(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_81(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_62(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_33(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i2*i3*Pi*i3*Pi*Pi+-b*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+-b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi+-b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_63(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_31(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i2*i3*Pi*i3*Pi*Pi+-b*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_72(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_69(i1x2, g1x2, h1x2)*(+b*h3*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_70(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g1*h3*i2*Pi*b*i2*Pi*b*Pi/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*i2*Pi*b*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi+b*g3*h3*i2*i3*Pi*i2*Pi*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)+cylSinrEval::evalR_66(i1x2, g1x2, h1x2)*(+-b*g3*h3*i3*Pi*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_64(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-2*b*h3*i2*i3*Pi*i3*Pi*Pi+-b*h3*i2*Pi*b*Pi*b*Pi/2+-2*b*h3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_90(i1x2, g1x2, h1x2)*(+b*g1*h3*i2*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i2*Pi*b*Pi*b*Pi*Pi/4+b*g1*h3*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+2*b*h3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_43(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_86(i1x2, g1x2, h1x2)*(+-b*g3*h1*i2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i2*Pi*b*Pi*b*Pi*Pi/4+-b*g3*h1*i1*i2*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+2*b*g3*i2*i3*Pi*i3*Pi*Pi+b*g3*i2*Pi*b*Pi*b*Pi/2+2*b*g3*i1*i2*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_88(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*i2*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*i2*Pi*b*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_65(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi+-b*g3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+b*g3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*g1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*i2*Pi*b*i2*b)+cylSinrEval::evalR_54(i1x2, g1x2, h1x2)*(+-2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*i1*i2*Pi*b*i2*Pi*b)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_66(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi+-b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_39(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+-b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+-b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+-b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_67(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi+b*h2*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*h3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_41(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_35(i1x2, g1x2, h1x2)*(+b*h1*h2*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_37(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)+cylSinrEval::evalR_45(i1x2, g1x2, h1x2)*(+b*h2*i2*Pi*b*i2*Pi*b/4)+cylSinrEval::evalR_46(i1x2, g1x2, h1x2)*(+b*h2*i1*i2*Pi*b*i2*Pi*b/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_68(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_32(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_69(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_77(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_37(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_70(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi+b*h3*i2*i3*Pi*i2*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+-b*h3*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_42(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*h1*i2*Pi*b*i2*Pi*b/2)+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*i2*Pi*b*i2*b)+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_58(i1x2, g1x2, h1x2)*(+2*b*i1*i2*Pi*b*i2*b)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*h1*i1*i2*Pi*b*i2*Pi*b)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_71(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_72(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_73(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_74(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_75(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_76(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i3*Pi*i3*Pi*Pi+-2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_77(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_78(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_79(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_80(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_81(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_82(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i3*Pi*i3*Pi*Pi+2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_83(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_84(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_85(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_86(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_87(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_88(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_89(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_90(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_91(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_92(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_93(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_94(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_95(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_96(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i3*Pi*i3*Pi*Pi+2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_97(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i3*Pi*i3*Pi*Pi+-2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_98(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_99(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_100(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_101(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-2*b*i1*Pi*b*b)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_102(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_103(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_104(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_105(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_106(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+2*b*i1*Pi*b*b)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+-b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_107(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_108(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_50(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_109(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_45(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_110(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_111(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_52(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_112(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i3*Pi*i3*Pi*Pi+-2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_113(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_114(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_46(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_60(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_47(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_115(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_14(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_15(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_48(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_26(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_47(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_48(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_27(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_49(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_59(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_24(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_116(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_51(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_53(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_117(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_59(i1x2, g1x2, h1x2)*(+-b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_60(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_54(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_61(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_55(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_118(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i3*Pi*i3*Pi*Pi+2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_74(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_119(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*g2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g1*g2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_120(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_121(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_122(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_123(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_124(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_125(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_126(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_64(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+-b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_63(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_65(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_127(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_55(i1x2, g1x2, h1x2)*(+b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_62(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_61(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi)+cylSinrEval::evalR_56(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_66(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_67(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_68(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_128(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_69(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
+((cylSintEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_70(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_129(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_71(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
+((cylSintEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_72(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_130(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_131(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+-b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_132(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i3*Pi*i3*Pi*Pi+2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_133(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i3*Pi*i3*Pi*Pi+-2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_67(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_134(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_135(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-2*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_0(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_0(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*i3*Pi*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_136(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_137(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-b*g3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*g1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+2*b*i1*Pi*b*b)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_138(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_139(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_78(i1x2, g1x2, h1x2)*(+-b*h2*i1*Pi*b*Pi*b/2)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*i3*Pi*Pi)+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*h1*h2*i1*Pi*b*Pi*b)+cylSinrEval::evalR_103(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*i3*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_140(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_141(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_115(i1x2, g1x2, h1x2)*(+b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_116(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_142(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+b*h3*i1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_4(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_4(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*h1*i1*Pi*b*Pi*b)+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+-2*b*i1*Pi*b*b)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi*i3*Pi)+cylSinrEval::evalR_123(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*i3*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_143(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_144(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_145(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_146(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_147(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_148(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-6*b*g2*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-2*b*g2*g3*i3*Pi*i3*Pi*Pi+-2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_149(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_150(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_151(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-3*b*g2*h2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_80(i1x2, g1x2, h1x2)*(+-b*g1*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+-b*g2*h2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+3*b*g2*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_29(i1x2, g1x2, h1x2)*(+b*g2*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g2*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_40(i1x2, g1x2, h1x2)*(+b*g2*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g2*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_152(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_153(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_75(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_154(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-3*b*g2*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+6*b*g2*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+2*b*g2*g3*i3*Pi*i3*Pi*Pi+2*b*g2*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+-b*g2*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g2*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_99(i1x2, g1x2, h1x2)*(+-3*b*g2*h3*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-3*b*g1*g2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_91(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*i3*Pi*Pi*Pi/2+-b*g2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_155(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_156(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_157(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_158(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_159(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_160(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+6*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_161(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_162(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_163(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_102(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_65(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_73(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_164(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_165(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_166(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+6*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_167(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_168(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+6*b*h2*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+2*b*h2*h3*i3*Pi*i3*Pi*Pi+2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+-b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+-b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+-3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+-b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_169(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+3*b*g1*h2*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-6*b*h2*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+-2*b*h2*h3*i3*Pi*i3*Pi*Pi+-2*b*h2*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_125(i1x2, g1x2, h1x2)*(+b*g1*h2*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h2*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_96(i1x2, g1x2, h1x2)*(+3*b*g3*h2*i1*Pi*b*Pi*b*Pi/2)+cylSinrEval::evalR_87(i1x2, g1x2, h1x2)*(+3*b*g3*h1*h2*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_126(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*i3*Pi*Pi*Pi+b*g3*h1*h2*i1*Pi*b*i1*Pi*b*Pi*Pi)+cylSinrEval::evalR_89(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*i3*Pi*Pi*Pi/2+b*g3*h2*i1*Pi*b*i1*Pi*b*Pi*Pi/2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_170(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-6*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_171(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_118(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-6*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_120(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_172(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+-6*b*h3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_130(i1x2, g1x2, h1x2)*(+3*b*g1*h3*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_128(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*i3*Pi*Pi+-2*b*h3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_131(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*i3*Pi*Pi*Pi+b*g1*h3*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_127(i1x2, g1x2, h1x2)*(+-3*b*g3*h1*i1*Pi*b*Pi*b*Pi)+cylSinrEval::evalR_109(i1x2, g1x2, h1x2)*(+6*b*g3*i1*Pi*b*Pi*b)+cylSinrEval::evalR_128(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*i3*Pi*Pi+2*b*g3*i1*Pi*b*i1*Pi*b*Pi)+cylSinrEval::evalR_129(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*i3*Pi*Pi*Pi+-b*g3*h1*i1*Pi*b*i1*Pi*b*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_173(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_174(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_175(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_176(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_177(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_178(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_179(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_180(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_181(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_182(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_183(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_184(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_185(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*g2*i3*Pi*Pi/2)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-b*g1*g2*i3*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*g2*g3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*g2*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_186(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_86(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_82(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_187(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_41(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_38(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_83(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_28(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_85(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_34(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_42(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_188(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_56(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_57(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_189(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+b*g2*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_97(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_85(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_62(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_84(i1x2, g1x2, h1x2)*(+-b*g2*h3*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g1*g2*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_58(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_190(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_84(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_98(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_191(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*g2*i3*Pi*Pi/2)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g1*g2*i3*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_87(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*g2*g3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*g2*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_192(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_193(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_194(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_195(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_196(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-2*b*g3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_197(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_198(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h2*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_76(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_77(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+-b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+-b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_199(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+-b*g3*h2*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_79(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_71(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_78(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_68(i1x2, g1x2, h1x2)*(+b*g3*h2*i3*Pi*Pi*Pi/2)+cylSinrEval::evalR_64(i1x2, g1x2, h1x2)*(+b*g3*h1*h2*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_79(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_76(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_200(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_111(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_112(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_73(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_74(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_201(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)))
))
+((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_75(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_202(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_3(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_3(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_121(i1x2, g1x2, h1x2)*(+-b*g3*h1*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+2*b*g3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_203(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_104(i1x2, g1x2, h1x2)*(+-b*g3*Pi)+cylSinrEval::evalR_105(i1x2, g1x2, h1x2)*(+-b*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_204(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_205(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_93(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_53(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_95(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_206(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+-b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+2*b*h3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+-b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_207(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_5(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_5(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_124(i1x2, g1x2, h1x2)*(+b*g1*h3*i3*Pi*Pi*Pi)+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+-2*b*h3*i3*Pi*Pi)))
))
+((cylCospEval::evalP_7(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_7(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_108(i1x2, g1x2, h1x2)*(+b*g3*h3*Pi*Pi)+cylSinrEval::evalR_119(i1x2, g1x2, h1x2)*(+b*g3*h3*i1*Pi*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_208(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_209(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_132(i1x2, g1x2, h1x2)*(+-b*g1*i3*Pi*Pi)+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+2*b*i3*Pi)))
))
+((cylCospEval::evalP_1(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_1(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_110(i1x2, g1x2, h1x2)*(+-b*g3*Pi)+cylSinrEval::evalR_113(i1x2, g1x2, h1x2)*(+-b*g3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_210(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+b*h2*i3*Pi*Pi/2)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+b*h1*h2*i3*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_88(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_88(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+-b*h2*h3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+-b*h2*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_211(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_92(i1x2, g1x2, h1x2)*(+-b*h2*i3*Pi*Pi/2)+cylSinrEval::evalR_57(i1x2, g1x2, h1x2)*(+-b*h1*h2*i3*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_89(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_89(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_101(i1x2, g1x2, h1x2)*(+b*h2*h3*Pi)+cylSinrEval::evalR_94(i1x2, g1x2, h1x2)*(+b*h2*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_212(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_80(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*h3*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_213(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_122(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_81(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_106(i1x2, g1x2, h1x2)*(+b*h3*Pi)+cylSinrEval::evalR_107(i1x2, g1x2, h1x2)*(+b*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_214(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_8(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_8(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_132(i1x2, g1x2, h1x2)*(+b*h1*i3*Pi*Pi)+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+-2*b*i3*Pi)))
))
+((cylCospEval::evalP_2(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_2(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_117(i1x2, g1x2, h1x2)*(+b*h3*Pi)+cylSinrEval::evalR_114(i1x2, g1x2, h1x2)*(+b*h3*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalcylCos_215(const Basis3D& phiI, const Basis3D& phiG, const Basis3D& phiH, const double& b) {
getWaveN;
double val = +((cylCospEval::evalP_6(i3x2, g3x2, h3x2) == 0) ? 0 :cylCospEval::evalP_6(i3x2, g3x2, h3x2)*(+((cylSintEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :cylSintEval::evalT_44(i2x2, g2x2, h2x2)*(+cylSinrEval::evalR_100(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
