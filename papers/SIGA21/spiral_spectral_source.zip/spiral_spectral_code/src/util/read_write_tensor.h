#ifndef READ_WRITE_TENSOR_H
#define READ_WRITE_TENSOR_H

#include <fstream>
#include <Eigen/Eigen>
#include <vector>
#include <string>

#include "setting.h"

void ReadTensorFromMatlab(const std::string& file_name, const int basis_dim, 
                          std::vector<Adv_Tensor_Type>* new_tensor);

void ReadTensor(const std::string file, const int expected_dim ,const int expected_type, 
                std::vector<Adv_Tensor_Type>* Adv_tensor);

template<typename ST>
void ReadTensor(ST& infile, const int expected_dim ,const int expected_type, 
                std::vector<Adv_Tensor_Type>* Adv_tensor) {
  if (!infile.good()) {
    LOG(FATAL) << "Cannot read in stream: ";
  }
  int tensor_dim;
  int tensor_type;
  // First read in the tensor dimention.
  infile.read(reinterpret_cast<char*>(&tensor_dim), sizeof(int));
  infile.read(reinterpret_cast<char*>(&tensor_type), sizeof(int));
  CHECK(tensor_dim == expected_dim) << "Read the tensor with wrong dimention: " << tensor_dim
      << " The expected dimention: " << expected_dim;
  //CHECK(tensor_type == expected_type) << "Read the tensor with wrong type: " << tensor_type
  //    << " The expected dimention: " << expected_type;
  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(tensor_dim);
  //LOG(INFO) << "start to read...";
  // Read each matrix.
  for (int i = 0; i < tensor_dim; i++) {
    uint64_t nnzs, outS,innS;
    infile.read(reinterpret_cast<char*>(&nnzs), sizeof(uint64_t));
    infile.read(reinterpret_cast<char*>(&outS), sizeof(uint64_t));
    infile.read(reinterpret_cast<char*>(&innS), sizeof(uint64_t));
    Adv_Tensor_Type Ck(tensor_dim, tensor_dim);
    Ck.makeCompressed();
    Ck.resizeNonZeros(nnzs);
    infile.read(reinterpret_cast<char*>(Ck.valuePtr()), sizeof(double)*nnzs);
    infile.read(reinterpret_cast<char*>(Ck.outerIndexPtr()), sizeof(int)*outS);
    infile.read(reinterpret_cast<char*>(Ck.innerIndexPtr()), sizeof(int)*nnzs);
    Ck.finalize();
    Adv_tensor->emplace_back(Ck);
  }
}

void ReadTensorSlice(std::ifstream& infile, Adv_Tensor_Type& slice);

template<typename ST>
void WriteTensor(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                 const int tensor_type, ST& out) {
  if (!out.good()) {
    LOG(FATAL) << "Cannot write to stream:";
  }
  int tensor_dim = Adv_tensor.size();
  int type_ = tensor_type;
  
  // first write out the tensor dimention.
  out.write(reinterpret_cast<const char *>(&tensor_dim), sizeof(int));
  // Then write out the tensor type. encoded as int.
  out.write(reinterpret_cast<const char *>(&type_), sizeof(int));
  // Write each sparse matrix.
  for (int i = 0; i < tensor_dim; i++) {
    uint64_t nnzs = Adv_tensor[i].nonZeros();
    uint64_t outS = Adv_tensor[i].outerSize();
    uint64_t innS = Adv_tensor[i].innerSize();
    out.write(reinterpret_cast<const char *>(&nnzs), sizeof(uint64_t));
    out.write(reinterpret_cast<const char *>(&outS), sizeof(uint64_t));
    out.write(reinterpret_cast<const char *>(&innS), sizeof(uint64_t));
    // Write the matrix values.
    out.write(reinterpret_cast<const char *>(Adv_tensor[i].valuePtr()), sizeof(double)*nnzs);
    // Output the index values, the default index value type for eigen is int.
    out.write(reinterpret_cast<const char *>(Adv_tensor[i].outerIndexPtr()), sizeof(int)*outS);
    out.write(reinterpret_cast<const char *>(Adv_tensor[i].innerIndexPtr()), sizeof(int)*nnzs);
  }
}

uint64_t countTensorBytes(const std::vector<Adv_Tensor_Type>& Adv_tensor);

void WriteTensor(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                    const int tensor_type, const std::string file);

void WriteTensorSlice(const Adv_Tensor_Type& slice, std::ofstream& out);

template<typename MAT, typename ST>
static void writeSparseMatrix(const MAT& spMat, ST& out) {
	 if (!out.good()) {
    LOG(FATAL) << "Cannot write to stream:";
  }
  const int rows = spMat.rows();
  const int cols = spMat.cols();

  // first write out rows, cols
  out.write(reinterpret_cast<const char *>(&rows), sizeof(int));
  out.write(reinterpret_cast<const char *>(&cols), sizeof(int));
  
  typename MAT::Index nnzs = spMat.nonZeros();
  typename MAT::Index outS = spMat.outerSize();
  typename MAT::Index innS = spMat.innerSize();

  out.write(reinterpret_cast<const char *>(&nnzs), sizeof(typename MAT::Index));
  out.write(reinterpret_cast<const char *>(&outS), sizeof(typename MAT::Index));
  out.write(reinterpret_cast<const char *>(&innS), sizeof(typename MAT::Index));
  // Write the matrix values.
  out.write(reinterpret_cast<const char *>(spMat.valuePtr()), sizeof(typename MAT::Scalar)*nnzs);
  // Output the index values, the default index value type for eigen is int.
  out.write(reinterpret_cast<const char *>(spMat.outerIndexPtr()), sizeof(typename MAT::StorageIndex)*(outS+1));
  out.write(reinterpret_cast<const char *>(spMat.innerIndexPtr()), sizeof(typename MAT::StorageIndex)*nnzs);
}

template<typename MAT, typename ST>
static void readSparseMatrix(ST& infile, MAT& spMat) {
	if (!infile.good())
    LOG(FATAL) << "Cannot read in stream: ";
  int rows, cols;

  infile.read(reinterpret_cast<char*>(&rows), sizeof(int));
  infile.read(reinterpret_cast<char*>(&cols), sizeof(int));

  typename MAT::Index nnzs, outS,innS;
  infile.read(reinterpret_cast<char*>(&nnzs), sizeof(typename MAT::Index));
  infile.read(reinterpret_cast<char*>(&outS), sizeof(typename MAT::Index));
  infile.read(reinterpret_cast<char*>(&innS), sizeof(typename MAT::Index));
  spMat.resize(rows, cols);
  spMat.makeCompressed();
  spMat.resizeNonZeros(nnzs);
  infile.read(reinterpret_cast<char*>(spMat.valuePtr()), sizeof(typename MAT::Scalar)*nnzs);
  infile.read(reinterpret_cast<char*>(spMat.outerIndexPtr()), sizeof(typename MAT::StorageIndex)*(outS+1));
  infile.read(reinterpret_cast<char*>(spMat.innerIndexPtr()), sizeof(typename MAT::StorageIndex)*nnzs);
  //spMat.finalize();
}

template<typename ST>
void WriteTensorBySlice(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                 const int tensor_type, ST& out) {
  if (!out.good()) {
    LOG(FATAL) << "Cannot write to stream:";
  }
  int tensor_dim = Adv_tensor.size();
  int type_ = tensor_type;
  
  // first write out the tensor dimention.
  out.write(reinterpret_cast<const char *>(&tensor_dim), sizeof(int));
  // Then write out the tensor type. encoded as int.
  out.write(reinterpret_cast<const char *>(&type_), sizeof(int));
  // Write each sparse matrix.
  for (int i = 0; i < tensor_dim; i++) {
    writeSparseMatrix(Adv_tensor[i], out);
  }
}

template<typename ST>
void ReadTensorBySlice(ST& infile, const int expected_dim ,const int expected_type, 
                       std::vector<Adv_Tensor_Type>* Adv_tensor) {
  if (!infile.good()) {
    LOG(FATAL) << "Cannot read in stream: ";
  }
  int tensor_dim;
  int tensor_type;
  // First read in the tensor dimention.
  infile.read(reinterpret_cast<char*>(&tensor_dim), sizeof(int));
  infile.read(reinterpret_cast<char*>(&tensor_type), sizeof(int));
  CHECK(tensor_dim == expected_dim) << "Read the tensor with wrong dimention: " << tensor_dim
      << " The expected dimention: " << expected_dim;

  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(tensor_dim);
  // Read each matrix.
  for (int i = 0; i < tensor_dim; i++) {
    Adv_Tensor_Type Ck;
    readSparseMatrix(infile, Ck);
    Adv_tensor->emplace_back(Ck);
  }
}
#endif  // READ_WRITE_TENSOR_H
