import struct
import sys

fin = open(sys.argv[1], "rb")
tensorType = sys.argv[1].split('/')[-1].split('_')[0]
print(tensorType)
if (tensorType == "torus"):
	print("rK_: " + str(struct.unpack('i', fin.read(4))))
	print("thetaK_: " + str(struct.unpack('i', fin.read(4))))
	print("phiK_: " + str(struct.unpack('i', fin.read(4))))
elif (tensorType == "cylinder" or tensorType == "sphere"):
	fin.read(1)
	print("rK_: " + str(struct.unpack('i', fin.read(4))))
	print("thetaK_: " + str(struct.unpack('i', fin.read(4))))
	print("phiK_: " + str(struct.unpack('i', fin.read(4))))
else:
	print("unknown type")