#include <Eigen/Eigen>
#include <fftw3.h>
#include <iomanip>

#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "common/basic_function.h"
#include "common/basis_set.h"
#include "polar_2D/polar_basis_2D.h"
#include "polar_2D/torus_basis_2D.h"
#include "polar_2D/torus_basis_set_2D.h"
#include "util/gl4_drawer.h"
#include "util/read_write_tensor.h"
#include "util/transform.h"
#include "util/util.h"
#include "polar_2D/spiral_util.h"

#define FAST_TENSOR

using namespace std;

#define MGSORTHORUN Eigen::MatrixXd Coef;\
int m = 1;\
std::vector<torusPtr2D> allocated;\
runMGS(thresh, tempBuffer, allocated, Coef, m, dotProd);\
all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
Coefs.push_back(Coef.topLeftCorner(m,m));

void TorusBasisSet2D::allocateBasisMGS() {
 // diagonal blocks of the coefficient matrix.
  std::vector<Eigen::MatrixXd> Coefs;
  const double thresh = 0.2;

  // Phi^0, Phi^3
  for (int j = 1; j < phiK_; j++) {
    std::vector<torusPtr2D> tempBuffer;
    // Phi^3
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        tempBuffer.push_back(torusPtr2D(new TorusBasis2D(i, 2*j, 3, a_)));
      }
    }
    // Phi^0
    for (int i = 1; i <= thetaK_; i++) { 
      tempBuffer.push_back(torusPtr2D(new TorusBasis2D(i, 2*j, 0, a_)));
    }
    // Run MGS, reject basis, and collect coefficients.
    MGSORTHORUN;
  }

  // Phi^1, Phi^2
  for (int j = 1; j < phiK_; j++) {
    std::vector<torusPtr2D> tempBuffer;    
    // Phi^2
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        tempBuffer.push_back(torusPtr2D(new TorusBasis2D(i, 2, 2, a_)));
      }
    }

    // Phi^1
    for (int i = 1; i <= thetaK_; i++) {
      tempBuffer.push_back(torusPtr2D(new TorusBasis2D(i, 2*j, 1, a_)));
    }
    MGSORTHORUN;
  }
  
  {
    // Phi^4
    std::vector<torusPtr2D> tempBuffer;
    for (int i = 0; i < thetaK_; i++) {
      tempBuffer.push_back(torusPtr2D(new TorusBasis2D(i, 0, 4, a_)));
    }
    // Phi^5
    for (int i = 1; i < thetaK_; i++) {
      tempBuffer.push_back(torusPtr2D(new TorusBasis2D(i, 0, 5, a_)));
    }

    MGSORTHORUN;
  }

  // Assemble global coefficient matrix.
  A_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
  int colIdx = 0;
  // Square matrices.
  for (int i = 0; i < Coefs.size(); i++) {
    int curSize = Coefs[i].rows();
    A_.block(colIdx, colIdx, curSize, curSize) = Coefs[i];
    colIdx += curSize;
  }
  numBasisOrtho_ = all_basis_.size();
  numBasisAll_ = all_basis_.size();
  LOG(INFO) << "number allocated: " << numBasisAll_;
}

void TorusBasisSet2D::allocateTemp() {
  totalSize_ = nTheta_*nPhi_;

  vtTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(vtTemp_, 0x00, sizeof(double)*totalSize_);
  vpTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(vpTemp_, 0x00, sizeof(double)*totalSize_);

  inTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(inTemp_, 0x00, sizeof(double)*totalSize_);

  tTemp0_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(tTemp0_, 0x00, sizeof(double)*totalSize_);
  tTemp1_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(tTemp1_, 0x00, sizeof(double)*totalSize_);
  pTemp0_= (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(pTemp0_, 0x00, sizeof(double)*totalSize_);
  pTemp1_= (double*) fftw_malloc(sizeof(double)*totalSize_);
  memset(pTemp1_, 0x00, sizeof(double)*totalSize_);
  
  t1DTemp0_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  memset(t1DTemp0_, 0x00, sizeof(double)*nTheta_);
  t1DTemp1_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  memset(t1DTemp1_, 0x00, sizeof(double)*nTheta_);

  dTheta_ = 2.0*M_PI / nTheta_;
  dPhi_ = 2.0*M_PI / nPhi_;

  cosTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  memset(cosTVal_, 0x00, sizeof(double)*nTheta_);
  sinTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  memset(sinTVal_, 0x00, sizeof(double)*nTheta_);
  for (int j = 0; j < nTheta_; j++) {
    double theta = ((double)(j) + 0.5)*dTheta_;
    cosTVal_[j] = cos(theta);
    sinTVal_[j] = sin(theta);
  }

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    waveNum2_[i] = k1*k1 + k2*k2;
  }
  initPairCoef();

}

void TorusBasisSet2D::initPairCoef() {
  phiCoef_.resize(6);
  for (int i = 0; i < all_basis_.size(); i++) {
    // Get wavenumber.
    int k1x2 = all_basis_[i]->WN1x2();
    int k2x2 = all_basis_[i]->WN2x2();
    int idx = all_basis_[i]->index();
    phiCoef_[idx].push_back(pairedCoef2(k1x2, k2x2, 0));
  }
}

void TorusBasisSet2D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  std::vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[index][Coefidx[index]].coef_ = fieldCoef[i]*C_x;
    Coefidx[index]++;
  }
}

void TorusBasisSet2D::setUpFFTWPlan() {
  fftw_r2r_kind invS_ = FFTW_RODFT01;
  fftw_r2r_kind invC_ = FFTW_REDFT01;
  fftw_r2r_kind fwdS_ = FFTW_RODFT10;
  fftw_r2r_kind fwdC_ = FFTW_REDFT10;

  int howmanyTheta = 4*phiK_;
  int nt_[1] = {nTheta_};
  int np_[1] = {nPhi_};

  // inverse plans
  // truncated along theta.
  IsinTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, nt_, nPhi_, 1, tTemp0_, nt_, nPhi_, 1, &invS_, FFTW_MEASURE);
  IcosTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, nt_, nPhi_, 1, tTemp0_, nt_, nPhi_, 1, &invC_, FFTW_MEASURE);
  // full plan along phi.
  IcosPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, np_, 1, nPhi_, tTemp0_, np_, 1, nPhi_, &invC_, FFTW_MEASURE);
  IsinPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, np_, 1, nPhi_, tTemp0_, np_, 1, nPhi_, &invS_, FFTW_MEASURE);

  //forward plans
  FsinTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, nt_, nPhi_, 1, tTemp0_, nt_, nPhi_, 1, &fwdS_, FFTW_MEASURE);
  FcosTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, nt_, nPhi_, 1, tTemp0_, nt_, nPhi_, 1, &fwdC_, FFTW_MEASURE);
  // full plan along phi.
  FcosPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, np_, 1, nPhi_, tTemp0_, np_, 1, nPhi_, &fwdC_, FFTW_MEASURE);
  FsinPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, np_, 1, nPhi_, tTemp0_, np_, 1, nPhi_, &fwdS_, FFTW_MEASURE);

  IsinT1D_ = fftw_plan_r2r_1d(nTheta_, t1DTemp0_, t1DTemp1_, invS_, FFTW_MEASURE);
  IcosT1D_ = fftw_plan_r2r_1d(nTheta_, t1DTemp0_, t1DTemp1_, invC_, FFTW_MEASURE);
  FsinT1D_ = fftw_plan_r2r_1d(nTheta_, t1DTemp0_, t1DTemp1_, fwdS_, FFTW_MEASURE);
  FcosT1D_ = fftw_plan_r2r_1d(nTheta_, t1DTemp0_, t1DTemp1_, fwdC_, FFTW_MEASURE);
}

void TorusBasisSet2D::InverseTransformVT() {
  clearPointer(inTemp_);
  clearPointer(vtTemp_);
  clearPointer(tTemp0_);

  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> tTemp0V(tTemp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> inTempV(inTemp_, totalSize_);

  // Phi^0
  for (const auto& pc : phiCoef_[0]) {
    inTemp_[pc.i2x2_ + (pc.i1x2_ - 1)*nPhi_] += pc.coef_;
  }
  // theta component
  fftw_execute_r2r(IsinTheta_, inTemp_, tTemp0_);
  
  clearPointer(inTemp_);
  // Phi^3
  for (const auto& pc : phiCoef_[3]) {
    inTemp_[pc.i2x2_ + (pc.i1x2_)*nPhi_] += pc.coef_;
  }
  fftw_execute_r2r(IcosTheta_, inTemp_, inTemp_);
  tTemp0V += inTempV;

  fftw_execute_r2r(IcosPhi_, tTemp0_, tTemp0_);
  
  vtTempV += tTemp0V;

  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  // Phi^1
  for (const auto& pc : phiCoef_[1]) {
    inTemp_[pc.i2x2_ - 1 + (pc.i1x2_ - 1)*nPhi_] += pc.coef_;
  }
  fftw_execute_r2r(IsinTheta_, inTemp_, tTemp0_);

  clearPointer(inTemp_);
  // Phi^2
  for (const auto& pc : phiCoef_[2]) {
    inTemp_[pc.i2x2_ - 1 + (pc.i1x2_)*nPhi_] += pc.coef_;
  }
  fftw_execute_r2r(IcosTheta_, inTemp_, inTemp_);
  tTemp0V += inTempV;
  fftw_execute_r2r(IsinPhi_, tTemp0_, tTemp0_);

  vtTempV += tTemp0V;
}

void TorusBasisSet2D::weightSinA(double* ptr) {
  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < 4*phiK_; i++) {
      ptr[i + j*nPhi_] *= (a_ + sinTVal_[j]);
    }
}

void TorusBasisSet2D::weightSinA(const double* in, double* out) {
  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < 4*phiK_; i++) {
      out[i + j*nPhi_] = in[i + j*nPhi_]*(a_ + sinTVal_[j]);
    }
}

void TorusBasisSet2D::weightCos(double* ptr) {
 for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < 4*phiK_; i++) {
      ptr[i + j*nPhi_] *= cosTVal_[j];
    } 
}

void TorusBasisSet2D::weightCos(const double* in, double* out) {
 for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < 4*phiK_; i++) {
      out[i + j*nPhi_] = in[i + j*nPhi_]*cosTVal_[j];
    }
}

void TorusBasisSet2D::InverseTransformVP() {
  clearPointer(inTemp_);
  clearPointer(vpTemp_);
  clearPointer(pTemp0_);
  clearPointer(pTemp1_);

  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> pTemp0V(pTemp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> pTemp1V(pTemp1_, totalSize_);
  Eigen::Map<Eigen::VectorXd> inTempV(inTemp_, totalSize_);

  // Phi^0---- -i1/i2*cos[i1*t]*(a+sin[t])
  for (const auto& pc : phiCoef_[0]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    inTemp_[pc.i2x2_ - 1 + (pc.i1x2_)*nPhi_] += -pc.coef_*i1/i2;
    // -1/i2*cos[t]*sin[i1*t]
    pTemp0_[pc.i2x2_ - 1 + (pc.i1x2_ - 1)*nPhi_] += -pc.coef_/i2; 
  }
  // -i1/i2*cos[i1*t]
  fftw_execute_r2r(IcosTheta_, inTemp_, inTemp_);
  fftw_execute_r2r(IsinTheta_, pTemp0_, pTemp0_);

  weightSinA(inTemp_);
  weightCos(pTemp0_);
  // 
  pTemp1V += inTempV + pTemp0V;
  
  clearPointer(inTemp_);
  clearPointer(pTemp0_);
  // Phi^3
  for (const auto& pc : phiCoef_[3]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    inTemp_[pc.i2x2_ - 1 + (pc.i1x2_ - 1)*nPhi_] += pc.coef_*i1/i2;
    pTemp0_[pc.i2x2_ - 1 + (pc.i1x2_)*nPhi_] += -pc.coef_/i2; 
  }
  fftw_execute_r2r(IsinTheta_, inTemp_, inTemp_);
  fftw_execute_r2r(IcosTheta_, pTemp0_, pTemp0_);
  weightSinA(inTemp_);
  weightCos(pTemp0_);
  pTemp1V += inTempV + pTemp0V;

  fftw_execute_r2r(IsinPhi_, pTemp1_, pTemp1_);
  vpTempV += pTemp1V;

  clearPointer(inTemp_);
  clearPointer(pTemp0_);
  clearPointer(pTemp1_);
  // Phi^1
  for (const auto& pc : phiCoef_[1]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    inTemp_[pc.i2x2_ + (pc.i1x2_)*nPhi_] += pc.coef_*i1/i2;
    pTemp0_[pc.i2x2_ + (pc.i1x2_ - 1)*nPhi_] += pc.coef_/i2; 
  }
  fftw_execute_r2r(IcosTheta_, inTemp_, inTemp_);
  fftw_execute_r2r(IsinTheta_, pTemp0_, pTemp0_);
  weightSinA(inTemp_);
  weightCos(pTemp0_);
  pTemp1V += inTempV + pTemp0V;

  clearPointer(inTemp_);
  clearPointer(pTemp0_);
  // Phi^2
  for (const auto& pc : phiCoef_[2]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    inTemp_[pc.i2x2_ + (pc.i1x2_ - 1)*nPhi_] += -pc.coef_*i1/i2;
    pTemp0_[pc.i2x2_ + (pc.i1x2_)*nPhi_] += pc.coef_/i2; 
  }
  fftw_execute_r2r(IsinTheta_, inTemp_, inTemp_);
  fftw_execute_r2r(IcosTheta_, pTemp0_, pTemp0_);
  weightSinA(inTemp_);
  weightCos(pTemp0_);
  pTemp1V += inTempV + pTemp0V;

  fftw_execute_r2r(IcosPhi_, pTemp1_, pTemp1_);
  vpTempV += pTemp1V;

  // Phi^4, Phi^5
  memset(t1DTemp0_, 0x00, sizeof(double)*nTheta_);
  memset(t1DTemp1_, 0x00, sizeof(double)*nTheta_);
  for (const auto& pc : phiCoef_[4]) {
    t1DTemp0_[pc.i1x2_] += pc.coef_; 
  }
  for (const auto& pc : phiCoef_[5]) {
    t1DTemp1_[pc.i1x2_ -1] += pc.coef_; 
  }
  fftw_execute_r2r(IcosT1D_, t1DTemp0_, t1DTemp0_);
  fftw_execute_r2r(IsinT1D_, t1DTemp1_, t1DTemp1_);
  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < nPhi_; i++) {
      vpTemp_[i + j*nPhi_] += t1DTemp0_[j] + t1DTemp1_[j];
    }
}

//#define TEST

void TorusBasisSet2D::InverseTramsformToVelocity(
     Eigen::VectorXd& fieldCoef, VFIELD2D* field) {

  CHECK(fieldCoef.size() == all_basis_.size());
  CHECK(field->getxRes() == nPhi_);
  CHECK(field->getyRes() == nTheta_);
  // test code
#ifdef TEST 
  //srand(time(NULL));
  fieldCoef = Eigen::VectorXd::Random(fieldCoef.size());
  double *ut, *up;
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  utV.setZero();
  upV.setZero();
  computeUniformRTNumerical(fieldCoef, nTheta_, nPhi_, ut, up); 
#endif

  collectPairedCoef(fieldCoef);
  InverseTransformVT();
  InverseTransformVP();

#ifdef TEST 
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  LOG(INFO) << "diff t " << (utV - vtTempV).norm() << " " << utV.norm() << " " << vtTempV.norm();
  LOG(INFO) << "diff p " << (upV - vpTempV).norm() << " " << upV.norm() << " " << vpTempV.norm();
  exit(0);
#endif
  
  for (int j = 0; j < nTheta_; j++) {
    for (int i = 0; i < nPhi_; i++) {
      (*field)(i,j)[0] = vtTemp_[i + j*nPhi_];
      (*field)(i,j)[1] = vpTemp_[i + j*nPhi_];
    }
  }
}

void TorusBasisSet2D::clearPairCoef() {
  for (auto& v : phiCoef_)
    for (auto& p : v) {
      p.coef_ = 0;
    }
}

void TorusBasisSet2D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
  //int bidx[5] = {0,0,0,0,0};
  std::vector<int> bidx(phiCoef_.size(), 0);
  for (int i = 0; i < all_basis_.size(); i++) {
    double C_x = all_basis_[i]->GetInvNorm();
    int idx = all_basis_[i]->index();
    fieldCoef[i] += phiCoef_[idx][bidx[idx]].coef_*C_x*dPhi_*dTheta_*0.25;
    bidx[idx]++;
  }
}

void TorusBasisSet2D::weightJacobian(double* ut, double* up) {
  for (int j = 0; j < nTheta_; j++) {
    for (int i = 0; i < nPhi_; i++) {
      double J = (a_ + sinTVal_[j])*scale3_;
      ut[i + j*nPhi_] *= J;
      up[i + j*nPhi_] *= J;
    }
  }
}

void TorusBasisSet2D::ForwardTransformVT() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);

  fftw_execute_r2r(FcosPhi_, vtTemp_, tTemp0_);

  clearPointer(inTemp_);
  // theta component
  fftw_execute_r2r(FsinTheta_, tTemp0_, inTemp_);

  // Phi^0
  for (auto& pc : phiCoef_[0]) {
    pc.coef_ += inTemp_[pc.i2x2_ + (pc.i1x2_ - 1)*nPhi_];
  }

  clearPointer(inTemp_);
  fftw_execute_r2r(FcosTheta_, tTemp0_, inTemp_);
  // Phi^3
  for (auto& pc : phiCoef_[3]) {
    pc.coef_ += inTemp_[pc.i2x2_ + (pc.i1x2_)*nPhi_];
  }

  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  fftw_execute_r2r(FsinPhi_, vtTemp_, tTemp0_);
  fftw_execute_r2r(FsinTheta_, tTemp0_, inTemp_);
  // Phi^1
  for (auto& pc : phiCoef_[1]) {
    pc.coef_ += inTemp_[pc.i2x2_ - 1 + (pc.i1x2_ - 1)*nPhi_];
  }
  
  clearPointer(inTemp_);
  fftw_execute_r2r(FcosTheta_, tTemp0_, inTemp_);
  // Phi^2
  for (auto& pc : phiCoef_[2]) {
    pc.coef_ += inTemp_[pc.i2x2_ - 1 + (pc.i1x2_)*nPhi_];
  }
}
  
void TorusBasisSet2D::ForwardTransformVP() {

  clearPointer(pTemp1_);
 
  fftw_execute_r2r(FsinPhi_, vpTemp_, pTemp1_);
  clearPointer(tTemp0_);
  clearPointer(tTemp1_);
  // read only
  weightSinA(pTemp1_, tTemp0_);
  weightCos(pTemp1_, tTemp1_);

  clearPointer(inTemp_);
  clearPointer(pTemp0_);
  fftw_execute_r2r(FcosTheta_, tTemp0_, inTemp_);
  fftw_execute_r2r(FsinTheta_, tTemp1_, pTemp0_);

  for (auto& pc : phiCoef_[0]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;  
    pc.coef_ += -inTemp_[pc.i2x2_ - 1 + (pc.i1x2_)*nPhi_]*i1/i2;
    pc.coef_ += -pTemp0_[pc.i2x2_ - 1 + (pc.i1x2_ - 1)*nPhi_]/i2;
  }
  
  clearPointer(inTemp_);
  clearPointer(pTemp0_);
  fftw_execute_r2r(FsinTheta_, tTemp0_, inTemp_);
  fftw_execute_r2r(FcosTheta_, tTemp1_, pTemp0_);
  
  // Phi^3
  for (auto& pc : phiCoef_[3]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    pc.coef_ += inTemp_[pc.i2x2_ - 1 + (pc.i1x2_ - 1)*nPhi_]*i1/i2;
    pc.coef_ += -pTemp0_[pc.i2x2_ - 1 + (pc.i1x2_)*nPhi_]/i2;
  }

  clearPointer(pTemp1_);
  fftw_execute_r2r(FcosPhi_, vpTemp_, pTemp1_);
  // DC part used for Phi^4, Phi^5
  for (int i = 0; i < nTheta_; i++) {
    t1DTemp0_[i] = pTemp1_[i*nPhi_];
  }

  clearPointer(tTemp0_);
  clearPointer(tTemp1_);
  // read only
  weightSinA(pTemp1_, tTemp0_);
  weightCos(pTemp1_, tTemp1_);
  fftw_execute_r2r(FcosTheta_, tTemp0_, inTemp_);
  fftw_execute_r2r(FsinTheta_, tTemp1_, pTemp0_);
  // Phi^1
  for (auto& pc : phiCoef_[1]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    pc.coef_ += inTemp_[pc.i2x2_ + (pc.i1x2_)*nPhi_]*i1/i2;
    pc.coef_ += pTemp0_[pc.i2x2_ + (pc.i1x2_ - 1)*nPhi_]/i2; 
  }

  clearPointer(inTemp_);
  clearPointer(pTemp0_);
  fftw_execute_r2r(FsinTheta_, tTemp0_, inTemp_);
  fftw_execute_r2r(FcosTheta_, tTemp1_, pTemp0_);
  // Phi^2
  for (auto& pc : phiCoef_[2]) {
    double i2 = (double)(pc.i2x2_)*0.5;
    double i1 = (double)(pc.i1x2_)*0.5;
    pc.coef_ += -inTemp_[pc.i2x2_ + (pc.i1x2_ - 1)*nPhi_]*i1/i2;
    pc.coef_ += pTemp0_[pc.i2x2_ + (pc.i1x2_)*nPhi_]/i2; 
  }

  // Phi^4, Phi^5
  fftw_execute_r2r(FcosT1D_, t1DTemp0_, t1DTemp1_);
  for (auto& pc : phiCoef_[4]) {
    pc.coef_ += t1DTemp1_[pc.i1x2_]; 
  }

  fftw_execute_r2r(FsinT1D_, t1DTemp0_, t1DTemp0_);
  for (auto& pc : phiCoef_[5]) {
    pc.coef_ += t1DTemp0_[pc.i1x2_ -1]; 
  }
}

// Input a std::vector field, transform and output the basis coefficients.
void TorusBasisSet2D::ForwardTransformtoFrequency(
      const VFIELD2D& field, Eigen::VectorXd* coefficients) {
  CHECK(field.getxRes() == nPhi_);
  CHECK(field.getyRes() == nTheta_);
  // Be CAREFUL of zStride when interpolate field into vr, vt, vp.
  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();
  clearPointer(vtTemp_);
  clearPointer(vpTemp_);
  // put field into trans.
  for (int j = 0; j < nTheta_; j++) {
    for (int i = 0; i < nPhi_; i++) {
      vtTemp_[i + j*nPhi_] = (field)(i,j)[0];
      vpTemp_[i + j*nPhi_] = (field)(i,j)[1];
    }
  }

  // test code
#ifdef TEST
  srand(time(NULL));
  double *ut, *up;
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  utV.setZero();
  upV.setZero();

  srand((unsigned int) (time(0)));
  Eigen::VectorXd basisCoef1 = Eigen::VectorXd::Random(all_basis_.size());
  computeUniformRTNumerical(basisCoef1, nTheta_, nPhi_, ut, up); 
  // collect into vr, due to z stride might be different.
  memcpy(vtTemp_, ut, sizeof(double)*totalSize_);
  memcpy(vpTemp_, up, sizeof(double)*totalSize_);
  weightJacobian(ut, up);
#endif

  weightJacobian(vtTemp_, vpTemp_);
  ForwardTransformVT();
  ForwardTransformVP();
  assignPairCoef(fieldCoef);

#ifdef TEST
  Eigen::VectorXd projCoef = Eigen::VectorXd::Zero(all_basis_.size());
  projectUniformRTNumerical(nTheta_, nPhi_, ut, up, projCoef);
  LOG(INFO) << "diff: " << (projCoef - fieldCoef).norm() << " " << projCoef.norm() << " " << fieldCoef.norm();
  exit(0);
#endif

  *coefficients = A_*fieldCoef;
}

#ifdef FAST_TENSOR
#include "tensorCompute/torus2DTensor.h"
#endif

void TorusBasisSet2D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {
  CHECK_NOTNULL(Adv_tensor)->clear();
  
#ifdef FAST_TENSOR
  torus2DTensor tensorEval;
#endif

  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  const double pow_w = - 0.00;
  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;

#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {
        //
        double Cigh = 0;

        #ifdef FAST_TENSOR
          const TorusBasis2D& basis_i = *all_basis_[i];
          const TorusBasis2D& basis_g = *all_basis_[g];
          const TorusBasis2D& basis_h = *all_basis_[h];
          const int idx = basis_i.index()*36 + basis_g.index()*6 + basis_h.index();
          double invWn = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
          Cigh = tensorEval.pointers_[idx](basis_i, basis_g, basis_h, a_)*invWn*scale3_; 
        #else
          Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h])*scale3_;
        #endif

        CHECK(std::isfinite(Cigh));
        if (Cigh == 0) {
          continue;
        }
        
        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
}

void TorusBasisSet2D::outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor) {
  CHECK_NOTNULL(Adv_tensor)->clear();
  
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  std::vector<Eigen::Vector3i> indices;
  
  for (int i = 0; i < numBasisAll_; i++) {
    LOG(INFO) << i;
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {

        double Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);

        if (abs(Cigh) <1e-12) {
          continue;
        }
        
        // IncrementMatrixEntry(&(*Adv_tensor)[k],i, j, Cijk*InvNormijk);
        tripletList.push_back(T(g,h, Cigh));
        indices.push_back(Eigen::Vector3i(i,g,h));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  BasisSet::VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  std::ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    torusPtr2D basis_i = all_basis_[indices[i][0]];
    torusPtr2D basis_g = all_basis_[indices[i][1]];
    torusPtr2D basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " <<
           std::setprecision(12) << basis_i->GetInvNorm() << " " << basis_g->GetInvNorm()
           << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}

double TorusBasisSet2D::tensorEntryCast(const torusPtr2D basis_i, const torusPtr2D basis_g, const torusPtr2D basis_h) {
  return TorusBasis2D::computeTensorEntry(*basis_i, *basis_g, *basis_h);
}

void TorusBasisSet2D::readFromFile(std::ifstream& in) {
  in.read(reinterpret_cast<char*>(&numBasisAll_), sizeof(int));
  in.read(reinterpret_cast<char *>(&thetaK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&phiK_), sizeof(int));
  in.read(reinterpret_cast<char*>(&numBasisOrtho_), sizeof(int));
  in.read(reinterpret_cast<char *>(&a_), sizeof(double));
  // to do...
  scale_ = 1.0/(a_+1.0);
  scale3_ = (scale_*scale_*scale_);

  LOG(INFO) << numBasisAll_;
  for (int i = 0; i < numBasisAll_; i++) {
    all_basis_.push_back(torusPtr2D(TorusBasis2D::fromFile(in)));
  }

  readEigenDense_binary(in, A_);
}

void TorusBasisSet2D::writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const {
  out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&thetaK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&phiK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&a_), sizeof(double));

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }
  writeEigenDense_binary(out, A_);
  WriteTensor(Adv_tensor_, 0, out);
}

void TorusBasisSet2D::ReSeedParticles(std::vector<ParticleSph3D>& particles) {
  uniform_real_distribution<double> u1(0, 2*M_PI);
  uniform_real_distribution<double> u2(0, 2*M_PI);

  for (int i = 0; i < particles.size(); i++) {
    Eigen::Vector3d torCord(1, u1(m_gen_), u2(m_gen_));
    Eigen::Vector3d catCord = Transform::Torodial::toCartesian(torCord, a_)*scale_;
    //Eigen::Vector3d pos = sampleOnSphere(m_gen_);
    // [0-1]
    particles[i].position[0] = catCord[0];
    particles[i].position[1] = catCord[1];
    particles[i].position[2] = catCord[2];
    particles[i].velocity.setZero();
  }
}

void TorusBasisSet2D::DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& rot,
                                  const FIELD2D& density, 
                                  const std::vector<ParticleSph3D>& particles, const double& ptl_length, drawerCollection& drawers) {
  glm::mat4 model = glm::mat4(1.f);//glm::mat4(1.0f);
  glm::vec3 scVec(0.5, 0.5, 0.5);
  
  model = glm::translate(model, glm::vec3(0.f, 0.f, -3.f)); // translate it down so it's at the center of the scene
  glm::mat4 rotTotal = glm::rotate(rot, (float)(0.2*M_PI), glm::vec3(1.f, 0.f, 0.f));
  glm::mat4 model1 = model;
  model = glm::scale(model, scVec);
  model = model*rotTotal;
  model1 = glm::scale(model1, glm::vec3(2.0, 2.0, 2.0));
  model1 = model1*rotTotal;
  drawers.textureShader_->use();
  drawers.textureShader_->setMat4("projection", projection);
  drawers.textureShader_->setMat4("view", view);
  drawers.textureShader_->setMat4("model", model);
  drawers.textureShader_->setVec4("color",glm::vec4(1.0,1.0,1.0,1.0));

  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < nPhi_; i++) {
      //int i1 = (i + nPhi_*3/4) % nPhi_;
      int j1 = (j + nTheta_/4) % nTheta_;
      drawers.densDrawer_->textureData[i + j1*nPhi_] = 1.0 - density[i + j*nPhi_];//forceMag_[i + j*nPhi_]/maxMag;
  }
  drawers.densDrawer_->Draw(*drawers.textureShader_);

  drawers.fixColorShader_->use();
  drawers.fixColorShader_->setMat4("projection", projection);
  drawers.fixColorShader_->setMat4("view", view);
  drawers.fixColorShader_->setMat4("model", model1);
  drawers.fixColorShader_->setVec4("color",glm::vec4(0.0,0.0,0.0,1.0));
  drawers.ptlGL4_->updatePos(particles, ptl_length);
  drawers.ptlGL4_->Draw();
}

void TorusBasisSet2D::splatParticle(const float ptlWeight, ParaParticle3Df& p, FIELD2D& density) {
  Eigen::Vector3f posOrig = p.position_ / scale_;
  Eigen::Vector3f sphCord = Transform::Torodial::toTorodial(posOrig, a_);
  float theta = sphCord[1];
  float phi   = sphCord[2];

  int tl = floor(theta/dTheta_);
  int tu = tl+1;
  int pl = floor(phi/dPhi_);
  int pu = pl+1;

  tu = (tu >= nTheta_) ? tu - nTheta_ : tu;
  tu = (tu < 0) ? nTheta_ + tu : tu;
  tl = (tl >= nTheta_) ? tl - nTheta_ : tl;
  tl = (tl < 0) ? nTheta_ + tl : tl;
  pu = (pu >= nPhi_) ? pu - nPhi_ : pu;
  pu = (pu < 0) ? nPhi_ + pu : pu;
  pl = (pl >= nPhi_) ? pl - nPhi_ : pl;
  pl = (pl < 0) ? nPhi_ + pl : pl;

  double wt = theta/dTheta_ - tl;
  double wp = phi/dPhi_ - pl;
  double ww = ptlWeight*p.weight_;
  // interpolate along theta
  density(pl, tl) += ww*(1.0 - wt)*(1.0 - wp);
  density(pl, tu) += ww*wt*(1.0 - wp);
  density(pu, tl) += ww*wp*(1.0 - wt);
  density(pu, tu) += ww*wt*wp;
}

// Add density particles
void TorusBasisSet2D::addParticles(const int x, const int y, const int width, const int height,
                  const int maxParticlePerCell, std::vector<ParaParticle3Df>& densityParticles) {
  // sample uniformly in parameter space, assume the jacobina is uniform (a+sin(t))
  int startx = x - width / 2;
  int starty = y - height / 2;
  int endx = x + width / 2;
  int endy = y + height / 2;
  startx = startx < 0 ? 0 : startx;
  starty = starty < 0 ? 0 : starty;
  endx = endx >= nPhi_ ? nPhi_-1 : endx;
  endy = endy >= nTheta_ ? nTheta_ -1 : endy;
  
  uniform_real_distribution<double> dx(0, 1.0);
  uniform_real_distribution<double> dy(0, 1.0);

  for (int j = starty; j <= endy; j++)
    for (int i = startx; i <= endx; i++)
      for (int k = 0; k < maxParticlePerCell; k++) {
        float theta = ((float)(j) + dy(m_gen_))*dTheta_;
        float phi   = ((float)(i) + dx(m_gen_))*dPhi_;

        ParaParticle3Df newP(Transform::Torodial::toCartesian(Eigen::Vector3f(1.0, theta, phi), a_)*scale_);
        densityParticles.push_back(newP);
      }
}

Eigen::Vector3d TorusBasisSet2D::getVelocityCartesian(const Eigen::Vector3d& pos, const VFIELD2D& velocity) {
  Eigen::Vector3d posOrig = pos/scale_;
  Eigen::Vector3d sph = Transform::Torodial::toTorodial(posOrig, a_);
  VEC2 surfV(0);

  sph[1] = (sph[1] < 0) ? 2*M_PI + sph[1] : sph[1];
  sph[1] = (sph[1] > 2*M_PI) ? sph[1] - 2*M_PI : sph[1];
  sph[2] = (sph[2] < 0) ? 2*M_PI + sph[2] : sph[2];
  sph[2] = (sph[2] > 2*M_PI) ? sph[2] - 2*M_PI : sph[2];

  int tl = floor(sph[1]/dTheta_);
  int tu = tl+1;
  // clamp periodicly
  tu = (tu >= nTheta_) ? tu - nTheta_ : tu;
  tu = (tu < 0) ? nTheta_ + tu : tu;
  tl = (tl >= nTheta_) ? tl - nTheta_ : tl;
  tl = (tl < 0) ? nTheta_ + tl : tl;

  int pl = floor(sph[2]/dPhi_);
  int pu = pl+1;

  pu = (pu >= nPhi_) ? pu - nPhi_ : pu;
  pu = (pu < 0) ? nPhi_ + pu : pu;
  pl = (pl >= nPhi_) ? pl - nPhi_ : pl;
  pl = (pl < 0) ? nPhi_ + pl : pl;

  double wt = sph[1]/dTheta_ - tl;
  double wp = sph[2]/dPhi_ - pl;

  // interpolate along theta
  VEC2 vpl = velocity(pl, tu)*wt + velocity(pl, tl)*(1.0 - wt);
  VEC2 vpu = velocity(pu, tu)*wt + velocity(pu, tl)*(1.0 - wt);
  // interpolate along phi.
  surfV = vpu*wp + vpl*(1.0 - wp);

  // convert to catersian.
  //double sinT = sqrt(1.0 - pos[2]*pos[2]);

  Eigen::Vector3d result(0, 0, 0);
  result[0] = cos(sph[1])*cos(sph[2])*surfV[0] - sin(sph[2])*surfV[1];
  result[1] = cos(sph[1])*sin(sph[2])*surfV[0] + cos(sph[2])*surfV[1];
  result[2] = -sin(sph[1])*surfV[0];

  return result;
}

#define CLAMPT(tv) \
tv = (tv >= nTheta_) ? tv - nTheta_ : tv;\
tv = (tv < 0) ? nTheta_ + tv : tv;

#define CLAMPP(pv) \
pv = (pv >= nPhi_) ? pv - nPhi_ : pv;\
pv = (pv < 0) ? nPhi_ + pv : pv;

#define interPol(arg_)\
(wp0 * (wt0 * arg_[i000] + wt1 * arg_[i010]) +\
 wp1 * (wt0 * arg_[i100] + wt1 * arg_[i110]))\

template<typename DT, typename VT, typename MT>
void TorusBasisSet2D::getVelocityPosT(const VT& pos, VT& uCat) {
  VT posOrig = pos/scale_;
  VT sph = Transform::Torodial::toTorodial(posOrig, a_);

  sph[1] = (sph[1] < 0) ? 2*M_PI + sph[1] : sph[1];
  sph[1] = (sph[1] > 2*M_PI) ? sph[1] - 2*M_PI : sph[1];
  sph[2] = (sph[2] < 0) ? 2*M_PI + sph[2] : sph[2];
  sph[2] = (sph[2] > 2*M_PI) ? sph[2] - 2*M_PI : sph[2];

  int t0 = floor(sph[1]/dTheta_);
  int t1 = t0+1;
  // clamp periodicly
  CLAMPT(t1);
  CLAMPT(t0);

  int p0 = floor(sph[2]/dPhi_);
  int p1 = p0+1;
  CLAMPP(p1);
  CLAMPP(p0);

  const DT wp1 = sph[2]/dPhi_ - p0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = sph[1]/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;

  const int i000 = p0 + t0 * nPhi_;
  const int i010 = p0 + t1 * nPhi_;
  const int i100 = p1 + t0 * nPhi_;
  const int i110 = p1 + t1 * nPhi_;
  VT uSph(0,0,0);
  uSph << 0, interPol(vtTemp_), interPol(vpTemp_);

  MT transMat;
  Transform::Spherical::toCartesianMat(sph[1], sph[2], transMat);
  // toCartesian
  uCat = transMat*uSph;
}

template void TorusBasisSet2D::getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(const Eigen::Vector3d&, Eigen::Vector3d&);
template void TorusBasisSet2D::getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(const Eigen::Vector3f&, Eigen::Vector3f&);

void TorusBasisSet2D::projPosBack(ParaParticle3Df& p) {
  Eigen::Vector3f posOrig = p.position_/scale_;
  Eigen::Vector3f sph = Transform::Torodial::toTorodial(posOrig, a_);
  
  if (sph[0] <= 1.0)
    return;

  sph[0] = 1.0;
  p.position_ = Transform::Torodial::toCartesian(sph, a_)*scale_;
  //p.weight_ = 0.0;
  //p.life_ = 0;
}

Eigen::Vector3d TorusBasisSet2D::getVelocityPos(const Eigen::Vector3d& pos) {
  Eigen::Vector3d result(0,0,0);
  getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(pos, result);
  return result;
}

Eigen::Vector3f TorusBasisSet2D::getVelocityPos(const Eigen::Vector3f& pos) {
  Eigen::Vector3f result(0,0,0);
  getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(pos, result);
  return result;
}

VEC2 TorusBasisSet2D::getVelocityParam(VEC2& pos, const VFIELD2D& velocity) {
  LOG(FATAL) << "not implemented";
  return VEC2(0,0);
}

void TorusBasisSet2D::ProjectParticle(ParticleSph3D& p) {
  Eigen::Vector3d sphCord = Transform::Torodial::toTorodial(p.position, a_);
  p.theta = sphCord[1];
  p.phi   = sphCord[2];
  sphCord[0] = 1.0;
  p.position = Transform::Torodial::toCartesian(sphCord, a_);
}

void TorusBasisSet2D::DrawParticles(const std::vector<ParticleSph3D>& particles, const double ptl_length, drawerCollection& drawers) {
}

// compute the ur, ut on a uniform r, t grid, test only.
void TorusBasisSet2D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nTheta, const int nPhi, double* ut, double* up) {
  memset(ut, 0x00, sizeof(double)*nTheta*nPhi);
  memset(up, 0x00, sizeof(double)*nTheta*nPhi);
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    all_basis_[i]->AddUniformU(fullCoef[i], nTheta, nPhi, ut, up);
  }
}

void TorusBasisSet2D::projectUniformRTNumerical(const int nTheta, const int nPhi, double* ft, double* fp,
                                                Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    fullCoef[i] = all_basis_[i]->ProjectUniformU(nTheta, nPhi, ft, fp);
  }
}