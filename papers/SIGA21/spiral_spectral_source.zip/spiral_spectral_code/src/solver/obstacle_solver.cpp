#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include "obstacle_solver.h"

void SolveObstacleImplicit(const Eigen::VectorXd& omega_in,
        const Eigen::MatrixXd& proj_matrix, Eigen::VectorXd* omega_out) {
  
  Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  solver.compute(proj_matrix);
  (*omega_out) = solver.solve(omega_in);
}
