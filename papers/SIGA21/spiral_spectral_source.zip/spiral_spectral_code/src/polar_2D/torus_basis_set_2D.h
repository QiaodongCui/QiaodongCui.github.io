#ifndef TORUS_BASIS_SET_2D_H
#define TORUS_BASIS_SET_2D_H

#include <Eigen/Eigen>
#include <fftw3.h>
#include <fstream>
#include <learnopengl/shader_m.h>

#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "common/basic_function.h"
#include "common/pairedCoef.h"
#include "common/surface_basis_set_2D.h"
#include "polar_2D/polar_basis_2D.h"
#include "polar_2D/torus_basis_2D.h"
#include "util/gl4_drawer.h"
#include "util/util.h"

typedef std::shared_ptr<TorusBasis2D> torusPtr2D;

class TorusBasisSet2D : public SurfaceBasisSet2D {

public:
  TorusBasisSet2D(const int N, const int thetaK, const int phiK, const double& a):
  thetaK_(thetaK), phiK_(phiK), a_(a) {
    nTheta_ = N;
    nPhi_ = 2*N;
    // nTheta_ must be even to ensure dst works.
    if (nPhi_ % 2 != 0)
      nPhi_ ++;
    scale_ = 1.0/(a+1.0);
    scale3_ = (scale_*scale_*scale_);
    allocateBasisMGS();
    allocateTemp();
    setUpFFTWPlan();

  };

  TorusBasisSet2D(int N, std::ifstream& in):thetaK_(0), phiK_(0) {
    nTheta_ = N;
    nPhi_ = 2*N;
    // nTheta_ must be even to ensure dst works.
    if (nPhi_ % 2 != 0)
      nPhi_ ++;

    // set up table in read from file.
    readFromFile(in);
    allocateTemp();
    setUpFFTWPlan();
  };
  
  void allocateBasisMGS();
  void allocateTemp();
  void setUpFFTWPlan();
  
  void ReSeedParticles(std::vector<ParticleSph3D>& particles) override;

  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  void outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor);

  void InverseTramsformToVelocity(
       Eigen::VectorXd& fieldCoef, VFIELD2D* field) override;

  // Input a std::vector field, transform and output the basis coefficients.
  void ForwardTransformtoFrequency(
      const VFIELD2D& field, Eigen::VectorXd* coefficients) override;
  
  Eigen::Vector3d getVelocityCartesian(const Eigen::Vector3d& pos, const VFIELD2D& velocity) override;
  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const override;
  void readFromFile(std::ifstream& in) override;
  void DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& model, const FIELD2D& density,
                   const std::vector<ParticleSph3D>& particles, const double& ptl_length, drawerCollection& drawers) override;
  void splatParticle(const float ptlWeight, ParaParticle3Df& p, FIELD2D& density) override;

  // Add density particles
  void addParticles(const int x, const int y, const int width, const int height,
                    const int maxParticlePerCell, std::vector<ParaParticle3Df>& densityParticles) override;
  void ProjectParticle(ParticleSph3D& p);
  void DrawParticles(const std::vector<ParticleSph3D>& particles, const double ptl_length, drawerCollection& drawers) override;

  VEC2 getVelocityParam(VEC2& pos, const VFIELD2D& velocity) override;

  void projPosBack(ParaParticle3Df& p) override;
  Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) override;
  Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) override;
  template<typename DT, typename VT, typename MT> void getVelocityPosT(const VT& pos, VT& uCat);

  const double getMajorA() {return a_;}
  
protected:
  
  static double dotProd(const torusPtr2D a, const torusPtr2D b) {
    return a->dotProd(*b)*a->GetInvNorm()*b->GetInvNorm();
  }
  
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nTheta, const int nPhi, double* ut, double* up);
  void projectUniformRTNumerical(const int nTheta, const int nPhi, double* ft, double* fp, Eigen::VectorXd& fullCoef);

  void initPairCoef();
  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);

  void InverseTransformVT();
  void InverseTransformVP();
  void ForwardTransformVT();
  void ForwardTransformVP();

  // clear chunk of mem following ptr, it's up to user
  void clearPointer(double* ptr) {
    std::memset(ptr, 0x00, sizeof(double)*totalSize_);
  }
  void clearPairCoef();
  void assignPairCoef(Eigen::VectorXd& fieldCoef);

  void weightSinA(double* ptr);
  void weightSinA(const double* in, double* out);
  void weightCos(double* ptr);
  void weightCos(const double* in, double* out);
  
  void weightJacobian(double* ut, double* up);
  double tensorEntryCast(const torusPtr2D basis_i, const torusPtr2D basis_g, const torusPtr2D basis_h);
  std::vector<torusPtr2D> all_basis_;

  int nTheta_;
  int nPhi_;
  double dTheta_;
  double dPhi_;

  // need to write this out.....
  // number of basis along theta
  int thetaK_;
  // number of basis along phi
  int phiK_;

  int totalSize_;
  double invTotalSize_;
  // pointers of size totalSize_
  double* vtTemp_;
  double* vpTemp_;
  double* tTemp0_;
  double* tTemp1_;
  double* pTemp0_;
  double* pTemp1_;
  double* inTemp_;

  // 1D buff of size ntheta.
  double* t1DTemp0_;
  double* t1DTemp1_;
  
  // pointers of size ntheta
  double* cosTVal_;
  double* sinTVal_;

  // inverse plans
  fftw_plan IsinTheta_;
  fftw_plan IcosTheta_;
  // only need even less for truncated along enrichment basis.
  fftw_plan IcosPhi_;
  fftw_plan IsinPhi_;
  
  // forward plans
  fftw_plan FsinTheta_;
  fftw_plan FcosTheta_;
  fftw_plan FcosPhi_;
  fftw_plan FsinPhi_;

  fftw_plan IsinT1D_;
  fftw_plan IcosT1D_;
  fftw_plan FsinT1D_;
  fftw_plan FcosT1D_;
  std::vector<std::vector<pairedCoef2>> phiCoef_;
  // major radius
  double a_;
  double scale_;
  double scale3_;
  std::default_random_engine m_gen_;
};

#endif  // TORUS_BASIS_SET_2D_H