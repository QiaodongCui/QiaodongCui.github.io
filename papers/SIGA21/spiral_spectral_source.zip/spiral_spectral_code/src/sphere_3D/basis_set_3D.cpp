#include "sphere_3D/basis_set_3D.h"

// p [-1,1]x[z]
template<typename DT, typename VT>
void BasisSet3D::splatParticleT(const double& ptlWeight, const double& dx, VT& p, FIELD_3D& density) {
  const int _xRes = density.xRes();
  const int _yRes = density.yRes();
  const int _zRes = density.zRes();
  const int _slabSize = density.slabSize();

  // [-(a+1), (a+1)]x[-1,1]
  VT positionCopy = p;
  // [-xRes/2, xRes/2] [-yRes/2, yRes/2], [-z/2, z/2]
  positionCopy /= dx;
  // align to grid
  positionCopy[0] += density.xRes()/2; // [0, xres]
  positionCopy[1] += density.yRes()/2;
  positionCopy[2] += density.zRes()/2;

  int x0 = floor(positionCopy[0]);
  int x1    = x0 + 1;
  int y0 = floor(positionCopy[1]);
  int y1    = y0 + 1;
  int z0 = floor(positionCopy[2]);
  int z1    = z0 + 1;

//if (x0 < 0 || y0 < 0 || z0 < 0 || x1 > _xRes - 1 || y1 > _yRes - 1 || z1 > _zRes - 1) {
//  LOG(INFO) << x0 << " " << y0 <<  " " << z0;
//  return;
//}

  x0 = (x0 < 0) ? 0 : x0;
  y0 = (y0 < 0) ? 0 : y0;
  z0 = (z0 < 0) ? 0 : z0;
  
  x1 = (x1 < 0) ? 0 : x1;
  y1 = (y1 < 0) ? 0 : y1;
  z1 = (z1 < 0) ? 0 : z1;
  
  x0 = (x0 > _xRes - 1) ? _xRes - 1 : x0;
  y0 = (y0 > _yRes - 1) ? _yRes - 1 : y0;
  z0 = (z0 > _zRes - 1) ? _zRes - 1 : z0;

  x1 = (x1 > _xRes - 1) ? _xRes - 1 : x1;
  y1 = (y1 > _yRes - 1) ? _yRes - 1 : y1;
  z1 = (z1 > _zRes - 1) ? _zRes - 1 : z1;

  // get interpolation weights
  const DT s1 = positionCopy[0]- x0;
  const DT s0 = 1.0f - s1;
  const DT t1 = positionCopy[1]- y0;
  const DT t0 = 1.0f - t1;
  const DT u1 = positionCopy[2]- z0;
  const DT u0 = 1.0f - u1;

  const int i000 = x0 + y0 * _xRes + z0 * _slabSize;
  const int i010 = x0 + y1 * _xRes + z0 * _slabSize;
  const int i100 = x1 + y0 * _xRes + z0 * _slabSize;
  const int i110 = x1 + y1 * _xRes + z0 * _slabSize;
  const int i001 = x0 + y0 * _xRes + z1 * _slabSize;
  const int i011 = x0 + y1 * _xRes + z1 * _slabSize;
  const int i101 = x1 + y0 * _xRes + z1 * _slabSize;
  const int i111 = x1 + y1 * _xRes + z1 * _slabSize;

  density[i000] += ptlWeight * u0 * s0 * t0;
  density[i010] += ptlWeight * u0 * s0 * t1;
  density[i100] += ptlWeight * u0 * s1 * t0;
  density[i110] += ptlWeight * u0 * s1 * t1;
  density[i001] += ptlWeight * u1 * s0 * t0;
  density[i011] += ptlWeight * u1 * s0 * t1;
  density[i101] += ptlWeight * u1 * s1 * t0;
  density[i111] += ptlWeight * u1 * s1 * t1;
}

template void BasisSet3D::splatParticleT<float, Eigen::Vector3f>(const double&, const double& dx, Eigen::Vector3f&, FIELD_3D& density);
template void BasisSet3D::splatParticleT<double, Eigen::Vector3d>(const double&, const double& dx, Eigen::Vector3d&, FIELD_3D& density);

void BasisSet3D::splatParticle(const double& ptlWeight, const double& dx, Eigen::Vector3d& p, FIELD_3D& density) {
  splatParticleT<double, Eigen::Vector3d>(ptlWeight, dx, p, density);
}

void BasisSet3D::splatParticle(const double& ptlWeight, const double& dx, Eigen::Vector3f& p, FIELD_3D& density) {
  splatParticleT<float, Eigen::Vector3f>(ptlWeight, dx, p, density);
}

void BasisSet3D::advectRK4(ParticleSph3D& p, const double& dt_) {
  // Get the velocity at the particles.
  const Eigen::Vector3d& position = p.position;

  Eigen::Vector3d p_v = this->getVelocityPos(position);
  Eigen::Vector3d K1 = p_v*dt_;
  Eigen::Vector3d pos1 = position + K1*0.5;
  p_v = this->getVelocityPos(pos1);

  Eigen::Vector3d K2 = p_v*dt_;
  Eigen::Vector3d pos2 = position + K2*0.5;
  p_v = this->getVelocityPos(pos2);

  Eigen::Vector3d K3 = p_v*dt_;
  Eigen::Vector3d pos3 = position + K3;

  p_v = this->getVelocityPos(pos3);
  Eigen::Vector3d K4 = p_v*dt_;

  p.position += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;
  p.velocity = p_v;
}

void BasisSet3D::advectRK4(ParaParticle3Df& p, const double& dt_) {
  // Get the velocity at the particles.
  const Eigen::Vector3f& position = p.position_;

  Eigen::Vector3f p_v = this->getVelocityPos(position);
  Eigen::Vector3f K1 = p_v*dt_;
  Eigen::Vector3f pos1 = position + K1*0.5;
  p_v = this->getVelocityPos(pos1);

  Eigen::Vector3f K2 = p_v*dt_;
  Eigen::Vector3f pos2 = position + K2*0.5;
  p_v = this->getVelocityPos(pos2);

  Eigen::Vector3f K3 = p_v*dt_;
  Eigen::Vector3f pos3 = position + K3;

  p_v = this->getVelocityPos(pos3);
  Eigen::Vector3f K4 = p_v*dt_;

  p.position_ += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;
  this->projPosBack(p);
}
