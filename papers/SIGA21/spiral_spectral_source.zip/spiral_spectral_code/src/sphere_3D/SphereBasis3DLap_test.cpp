#include <Eigen/Eigen>
#include <math.h>

#include "sphere_3D/sphere_basis_3D.h"
#include "common/basic_function.h"
#include "3D/trig_integral_3d.h"
#include "util/util.h"
#include "sphere_3D/SphereBasis3DLap.h"

using namespace std;

namespace {

void testLaplacianDot() {
  SphereBasis3DLap laplacianCompute;

   vector<vector<int>> testTrip = {{1, 1, 1}, {1, 1, 2}, {1, 1, 3}, {1, 1, 4}, {1, 1, 5}, {1, 2, 1}, {1,
   2, 2}, {1, 2, 3}, {1, 2, 4}, {1, 2, 5}, {1, 3, 1}, {1, 3, 2}, {1, 
  3, 3}, {1, 3, 4}, {1, 3, 5}, {1, 4, 1}, {1, 4, 2}, {1, 4, 3}, {1, 4,
   4}, {1, 4, 5}, {1, 5, 1}, {1, 5, 2}, {1, 5, 3}, {1, 5, 4}, {1, 5, 
  5}, {2, 1, 1}, {2, 1, 2}, {2, 1, 3}, {2, 1, 4}, {2, 1, 5}, {2, 2, 
  1}, {2, 2, 2}, {2, 2, 3}, {2, 2, 4}, {2, 2, 5}, {2, 3, 1}, {2, 3, 
  2}, {2, 3, 3}, {2, 3, 4}, {2, 3, 5}, {2, 4, 1}, {2, 4, 2}, {2, 4, 
  3}, {2, 4, 4}, {2, 4, 5}, {2, 5, 1}, {2, 5, 2}, {2, 5, 3}, {2, 5, 
  4}, {2, 5, 5}, {3, 1, 1}, {3, 1, 2}, {3, 1, 3}, {3, 1, 4}, {3, 1, 
  5}, {3, 2, 1}, {3, 2, 2}, {3, 2, 3}, {3, 2, 4}, {3, 2, 5}, {3, 3, 
  1}, {3, 3, 2}, {3, 3, 3}, {3, 3, 4}, {3, 3, 5}, {3, 4, 1}, {3, 4, 
  2}, {3, 4, 3}, {3, 4, 4}, {3, 4, 5}, {3, 5, 1}, {3, 5, 2}, {3, 5, 
  3}, {3, 5, 4}, {3, 5, 5}, {4, 1, 1}, {4, 1, 2}, {4, 1, 3}, {4, 1, 
  4}, {4, 1, 5}, {4, 2, 1}, {4, 2, 2}, {4, 2, 3}, {4, 2, 4}, {4, 2, 
  5}, {4, 3, 1}, {4, 3, 2}, {4, 3, 3}, {4, 3, 4}, {4, 3, 5}, {4, 4, 
  1}, {4, 4, 2}, {4, 4, 3}, {4, 4, 4}, {4, 4, 5}, {4, 5, 1}, {4, 5, 
  2}, {4, 5, 3}, {4, 5, 4}, {4, 5, 5}, {5, 1, 1}, {5, 1, 2}, {5, 1, 
  3}, {5, 1, 4}, {5, 1, 5}, {5, 2, 1}, {5, 2, 2}, {5, 2, 3}, {5, 2, 
  4}, {5, 2, 5}, {5, 3, 1}, {5, 3, 2}, {5, 3, 3}, {5, 3, 4}, {5, 3, 
  5}, {5, 4, 1}, {5, 4, 2}, {5, 4, 3}, {5, 4, 4}, {5, 4, 5}, {5, 5, 
  1}, {5, 5, 2}, {5, 5, 3}, {5, 5, 4}, {5, 5, 5}};

vector<double> val1 = {-103.698, -383.578, -1226.51, -3197.17, -7086.14, -127.611, \
-430.627, -1337.35, -3450.34, -7613.15};
vector<double> val2 ={-103.698, -383.578, -1226.51, -3197.17, -7086.14, -127.611, \
-430.627, -1337.35, -3450.34, -7613.15};
vector<double> val3 ={-65.6791, -65.6791, -65.6791, -65.6791, -65.6791, -122.98, -122.98, \
-122.98, -122.98, -122.98};
vector<double> val4 ={-82.1938, -584.587, -2237.96, -6266.39, -14383.6, -28792.9, \
-52187.3, -87749.4, -139151., -210555.};
vector<double> val5 ={-106.705, -836.118, -3357.49, -9629.35, -22393.6, -45175.7, \
-82284.3, -138812., -220633., -334408.};
vector<double> val6 ={-17.7758, -17.7758, -17.7758, -17.7758, -17.7758, -20.9227, \
-20.9227, -20.9227, -20.9227, -20.9227};
vector<double> val7 = {-55.2517, -173.454, -590.104, -1634.67, -3768.41, -109.138, \
-430.161, -1348.1, -3437.32, -7501.9};

  for (int i = 0; i < testTrip.size() && i < 10; i++) {
    const vector<int>& wn = testTrip[i];
    SphereBasis3D basis1(wn[0]*2, wn[1]*2, wn[2]*2, 0);
    SphereBasis3D basis2(wn[0]*2, wn[1]*2, wn[2]*2, 1);
    SphereBasis3D basis3(wn[0]*2, wn[1]*2, 2, 2);
    SphereBasis3D basis4(wn[0]*2, wn[1]*2, 2, 3);
    SphereBasis3D basis8(wn[0]*2, wn[1]*2, 0, 7);
    SphereBasis3D basis9(wn[0]*2, wn[1]*2, wn[2]*2, 8);
    SphereBasis3D basis10(wn[0]*2, wn[1]*2, wn[2]*2, 9);

    int idx = 0;
    //const int idx = basis_i.index()*10 + basis_j.index();
    //LOG(INFO) << laplacianCompute.pointers_[0](basis1, basis1);
    CHECK(fabs( (laplacianCompute.pointers_[0](basis1, basis1) - val1[i])/val1[i]) < 1e-4);
    idx = basis2.index()*10 + basis2.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis2, basis2) - val2[i])/val2[i]) < 1e-4);
    idx = basis3.index()*10 + basis3.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis3, basis3) - val3[i])/val3[i]) < 1e-4);
    idx = basis4.index()*10 + basis4.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis4, basis4) - val3[i])/val3[i]) < 1e-4);
    idx = basis8.index()*10 + basis8.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis8, basis8) - val6[i])/val6[i]) < 1e-4);
    idx = basis9.index()*10 + basis9.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis9, basis9) - val7[i])/val7[i]) < 1e-4);
    idx = basis10.index()*10 + basis10.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis10, basis10) - val7[i])/val7[i]) < 1e-4);
  }

  for (int i = 1; i <= 10; i++) {
    SphereBasis3D basis5(i*2, 0, 0, 4);
    SphereBasis3D basis6(i*2, 2, 2, 5);
    SphereBasis3D basis7(i*2, 2, 2, 6);

    int idx = 0;
    idx = basis5.index()*10 + basis5.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis5, basis5) - val4[i-1])/val4[i-1]) < 1e-4) << laplacianCompute.pointers_[idx](basis5, basis5)
      << " " << val4[i] << " " << i;
    idx = basis6.index()*10 + basis6.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis6, basis6) - val5[i-1])/val5[i-1]) < 1e-4);
    idx = basis7.index()*10 + basis7.index();
    CHECK(fabs( (laplacianCompute.pointers_[idx](basis7, basis7) - val5[i-1])/val5[i-1]) < 1e-4);
  }
}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);

  testLaplacianDot();

  return 0;
}