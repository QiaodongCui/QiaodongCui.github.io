// Viewer for 3D laplacian fluid simulation.
#include <Eigen/Eigen>
#include <fftw3.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/glut.h>
#include <glog/logging.h>
#include <gflags/gflags.h>
#include <iostream>
#include <learnopengl/shader_m.h>
#include <learnopengl/model.h>
#include <learnopengl/camera.h>
#include <memory>
#include <sstream>
#include <sys/time.h>
#include <string>
#include <sstream>
#include <vector>

#include "sphere_3D/sphere_fluid_3D.h"
#include "util/trackball.h"
#include "util/glPrintString.h"
#include "util/get_current_time.h"
#include "util/gl4_drawer.h"
#include "util/QUICKTIME_MOVIE_GLFW.h"
#include "setting.h"

const double spectra_draw_factor = 0.5;
DEFINE_int32(window_x, 1920, "The x resolution of the window");
DEFINE_int32(window_y, 1080, "The y resolution of the window");

DEFINE_int32(xRes, 128, "The xReslution of the fluid.");
DEFINE_int32(yRes, 128, "The yReslution of the fluid.");
DEFINE_int32(zRes, 128, "The yReslution of the fluid.");

DEFINE_int32(basis_dim, 20, "The number of wanted basis.");
DEFINE_double(dt, 0.1, "The time step of the simulation.");
DEFINE_double(buoyancy, 0.0001, "The buoyancy of the fluid.");
DEFINE_double(viscosity, 0.005, "The viscosity of the fluid.");

DEFINE_string(basis_type, "all_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");
DEFINE_string(boundaryCnd, "all_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");
DEFINE_string(integrator_type, "RK4", "The integrator_type. Can be RK4, semi_implicit"
              "BiCGSTAB");
DEFINE_int32(total_frame, 2000, "The total frame want to simulate.");
DEFINE_int32(total_num_particles, 1000, "The total number of particles");
DEFINE_int32(maxDensityParticles, 2, "max number of density particles in millions");
DEFINE_double(densityPtlWeight, 2.0, "splat Weight for the density particles");
DEFINE_double(vdbGridScale, 1.0, "The scale of VDB grid compared to the grid scale of the sim.");
DEFINE_double(particle_length_factor, 0.1, "How long is the particles.");
DEFINE_double(tensor_weight, 1.0, "Weight of the tensor.");
DEFINE_string(Tensor_file, "", "The file which stores all the tensor.");

DEFINE_string(density_folder, "",  "The folder to store all the density");
DEFINE_bool(write_density, false, "Whether to write the density out.");
DEFINE_bool(output_PBRT, false, "Whether to write density to PBRT.");
DEFINE_bool(output_VDB, false, "Output density to VDB.");
DEFINE_bool(capture_video, false, "Whether to capture the video.");
DEFINE_string(preview_fpath, "", "The folder to put the preview video.");

DEFINE_double(b, 0.9, "The short axis.");
DEFINE_double(cylinderH, 2.0, "The height of the cylinder.");
DEFINE_string(camLocation, "default", "The location of the camera");
DEFINE_double(camZ, 3.0, "z location of the camera");
DEFINE_bool(dissipateDensity, false, "");
DEFINE_int32(FFTW_threads, 6, "number of FFTW threads");
DEFINE_int32(maxHeatParticles, 2, "max number of heat particles in millions");
DEFINE_double(heatPtlWeight, 1.0, "splat Weight for the heat particles");

DEFINE_int32(scenario, 0, "Which scenario is it.");
DEFINE_bool(outputRGBVolume, false, "Output colored volume.");
DEFINE_double(cylSeedH, 0.4, "height of seeded smoke.");
DEFINE_double(cylSeedR, 0.7, "radius of seeded smoke.");
DEFINE_bool(filterForce, false, "filter the contact force.");

std::unique_ptr<SphereFluid3D> fluid;

std::string printstr;
bool is_pause = false;
bool write_dens = false;
bool draw_particles = true;
bool captuerInit = false;

namespace {
}  // namespace

static void idle_func ( void ) {
  fluid->Step();
  
  if (write_dens) {
    if (FLAGS_output_PBRT) {
      fluid->OutputToPBRT();
    }
  }
}

int main(int argc, char ** argv) {

  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  // For problems of smaller size, use less threads are better.
  fftw_init_threads();
  fftw_plan_with_nthreads(FLAGS_FFTW_threads);
  LOG(INFO) << "FFTW  threads " << FLAGS_FFTW_threads;

  CHECK(FLAGS_xRes == FLAGS_yRes);

  fluid.reset(new SphereFluid3D(FLAGS_xRes, FLAGS_yRes, FLAGS_zRes, FLAGS_basis_dim,
      FLAGS_dt, FLAGS_basis_type, FLAGS_boundaryCnd, FLAGS_integrator_type, FLAGS_buoyancy, FLAGS_viscosity,
      FLAGS_total_num_particles, FLAGS_total_frame, FLAGS_Tensor_file,
      FLAGS_tensor_weight, FLAGS_b, FLAGS_cylinderH, FLAGS_dissipateDensity, true, FLAGS_maxDensityParticles, 
      FLAGS_densityPtlWeight, FLAGS_vdbGridScale, FLAGS_maxHeatParticles, FLAGS_heatPtlWeight, FLAGS_scenario,
      FLAGS_outputRGBVolume, FLAGS_cylSeedH, FLAGS_cylSeedR, FLAGS_filterForce));

  fluid->density_folder_ = FLAGS_density_folder;
  write_dens = FLAGS_write_density;

  // render loop
  // -----------
  while (!fluid->isFinished()) {
    idle_func();
  }
  LOG(INFO) << "complected, quitting";  
  return 0;
}