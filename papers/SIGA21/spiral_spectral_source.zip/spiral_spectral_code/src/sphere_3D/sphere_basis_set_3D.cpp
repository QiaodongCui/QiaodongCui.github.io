#include <cstring>
#include <Eigen/Eigen>
#include <fftw3.h>
#include <iomanip>
#include <vector>

#include "3D/VECTOR3_FIELD_3D.h"
#include "3D/particle_3d.h"
#include "elliptic/prolate_oblate_2D.h"
#include "elliptic/prolate_oblate_3D.h"
#include "common/basis_set.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/sphere_basis_set_3D.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "sphere_3D/SphereBasis3DLap.h"
#include "util/read_write_tensor.h"
#include "util/transform.h"
#include "util/timer.h"

using namespace std;

#define MGSORTHORUN Eigen::MatrixXd Coef;\
int m = 1;\
vector<basisPtr3D> allocated;\
runMGS(thresh, tempBuffer, allocated, Coef, m);\
all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
Coefs.push_back(Coef.topLeftCorner(m,m));

#define USE_R_WEIGHT

void SphereBasisSet3D::allocateMGS() {
	// we have 8 different modes.
	phiCoef_.resize(10);
	vector<Eigen::MatrixXd> Coefs;
  const double thresh = 0.2;

	int offsetOdd = !boundaryCnd_ ? 1 : 0;
	// half integer for dirichlet bc
	int offset = boundaryCnd_ ? 1 : 0;

	// allocate Phi^0, Psi^2, Psi^5
	for (int i3 = 1; i3 < phiK_; i3++) {
		vector<basisPtr3D> tempBuffer;
		
		if (i3 == 1) {
			// Psi^5
			for (int i1 = 0; i1 < rK_; i1++) {
				if (! is_prolate_ && ! is_oblate_)
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(i1*2 + offset, 2, 2, 5)));
				else if (! is_oblate_)
          tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 5, *dotData_, true)));
        else
          tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 5, *dotData_, false)));
			}
			// Psi^2
			for (int i2 = 0; i2 < thetaK_; i2++)
				for (int i1 = 1; i1 < rK_; i1++) {
					int w1x2 = i1*2 - offsetOdd;
					int w2x2 = i2*2;
					//if (w2x2 > 3*w1x2) continue;
					if (! is_prolate_ && ! is_oblate_)
						tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(w1x2, w2x2, 2, 2)));
					else if (! is_oblate_)
						tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, 2, 2, *dotData_, true)));
					else
          	tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, 2, 2, *dotData_, false)));
				}
		}

		// Phi^0
		for (int i2 = 1; i2 < thetaK_; i2++) {
			for (int i1 = 1; i1 < rK_; i1++) {
				int w1x2 = i1*2 - offsetOdd;
				int w2x2 = i2*2;
				int w3x2 = i3*2;
				if (! is_prolate_ && ! is_oblate_) {
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(w1x2, w2x2, w3x2, 0)));
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(w1x2, w2x2, w3x2, 8)));
				}
				else if (! is_oblate_)
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, w3x2, 0, *dotData_, true)));
				else
          tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, w3x2, 0, *dotData_, false)));
			}
		}

		// Run MGS, reject basis, and collect coefficients.
		MGSORTHORUN;
	}

	// allocate Phi^1, Psi^3, Psi^6
	for (int i3 = 1; i3 < phiK_; i3++) {
		vector<basisPtr3D> tempBuffer;
		
		if (i3 == 1) {
			// Psi^6
			for (int i1 = 0; i1 < rK_; i1++) {
				if (! is_prolate_ && ! is_oblate_)
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(i1*2 + offset, 2, 2, 6)));
				else if (! is_oblate_)
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 6, *dotData_, true)));
				else
          tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 6, *dotData_, false)));
			}

			// Psi^3
			for (int i2 = 0; i2 < thetaK_; i2++)
				for (int i1 = 1; i1 < rK_; i1++) {
					int w1x2 = i1*2 - offsetOdd;
					int w2x2 = i2*2;
					//if (w2x2 > 3*w1x2) continue;
					if (! is_prolate_ && ! is_oblate_)
						tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(w1x2, w2x2, 2, 3)));
					else if (! is_oblate_)
						tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, 2, 3, *dotData_, true)));
					else
          	tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, 2, 3, *dotData_, false)));
				}
		}

		// Phi^1
		for (int i2 = 1; i2 < thetaK_; i2++)
			for (int i1 = 1; i1 < rK_; i1++) {
				int w1x2 = i1*2 - offsetOdd;
				int w2x2 = i2*2;
				int w3x2 = i3*2;
				if (! is_prolate_ && ! is_oblate_) {
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(w1x2, w2x2, w3x2, 1)));
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(w1x2, w2x2, w3x2, 9)));
				}
				else if (! is_oblate_)
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, w3x2, 1, *dotData_, true)));
				else
        	tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(w1x2, w2x2, w3x2, 1, *dotData_, false)));
			}
		
		// Run MGS, reject basis, and collect coefficients.
		MGSORTHORUN;
	}

	// allocate Psi^4
	{
		vector<basisPtr3D> tempBuffer;
		for (int i1 = 0; i1 < rK_; i1++) {
			if (! is_prolate_ && ! is_oblate_)
				tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(i1*2 + offset, 0, 0, 4)));
			else if (! is_oblate_)
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 0, 0, 4, *dotData_, true)));
			else
      	tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 0, 0, 4, *dotData_, false)));
		}

		// Run MGS, reject basis, and collect coefficients.
		MGSORTHORUN;
	}

	// Phi^7
  {
  	vector<basisPtr3D> tempBuffer;
		for (int i2 = 1; i2 < thetaK_; i2++)
			for (int i1 = 1; i1 < rK_; i1++) {
				if (! is_prolate_ && ! is_oblate_)
					tempBuffer.push_back(basisPtr3D(new     SphereBasis3D(i1*2, i2*2, 0, 7)));
				else if (! is_oblate_)
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2, i2*2, 0, 7, *dotData_, true)));
				else
      		tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2, i2*2, 0, 7, *dotData_, false)));
			}

		// Run MGS, reject basis, and collect coefficients.
		MGSORTHORUN;
	}

	initPhiCoef();
	numBasisAll_ = all_basis_.size();
	numBasisOrtho_ = all_basis_.size();
	LOG(INFO) << "total number of basis " << numBasisAll_;
	LOG(INFO) << "total number of ortho basis: " << numBasisOrtho_;

	// Assemble global coefficient matrix.
  A_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
  int colIdx = 0;
  // Square matrices.
  for (int i = 0; i < Coefs.size(); i++) {
    int curSize = Coefs[i].rows();
    A_.block(colIdx, colIdx, curSize, curSize) = Coefs[i];
    colIdx += curSize;
  }
  //ofstream out("A_sphere3D.bin", ios::binary);
  //writeEigenDense_binary(out, A_);
  //out.close();
}

void SphereBasisSet3D::initPhiCoef() {
	// init phiCoef
	for (int i = 0; i < all_basis_.size(); i++) {
		int idx = all_basis_[i]->index();
		int i1x2 = all_basis_[i]->WN1x2();
		int i2x2 = all_basis_[i]->WN2x2();
		int i3x2 = all_basis_[i]->WN3x2();
		pairedCoef coef(i1x2, i2x2, i3x2, 0);
		phiCoef_[idx].push_back(coef);
		// init inverselookup
    uint64_t hash = Basis3D::toHash(i1x2, i2x2, i3x2, idx);
    basisLookup_[hash] = i;
	}
}

void SphereBasisSet3D::allocateTemp() {

  totalSize_ = nTheta_*nPhi_*nR_;
  invTotalSize_ = 1.0 / totalSize_;
  dR_ = 1.0 / nR_;
  dTheta_ = M_PI / nTheta_;
  dPhi_ = 2.0*M_PI / nPhi_;
  
  int multipier = ! boundaryCnd_ ? 2 : 1;

  inTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(inTemp_, 0x00, sizeof(double)*totalSize_*multipier);
  vrTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(vrTemp_, 0x00, sizeof(double)*totalSize_*multipier);
  vtTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(vtTemp_, 0x00, sizeof(double)*totalSize_*multipier);
  vpTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(vpTemp_, 0x00, sizeof(double)*totalSize_*multipier);
  temp0_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(temp0_, 0x00, sizeof(double)*totalSize_*multipier);
  temp1_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(temp1_, 0x00, sizeof(double)*totalSize_*multipier);
  temp2_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier);
  std::memset(temp2_, 0x00, sizeof(double)*totalSize_*multipier);

  int enrichMultiplier = boundaryCnd_ ? 2 : 1;
  rtemp0_ = (double*) fftw_malloc(sizeof(double)*nR_*enrichMultiplier);
  std::memset(rtemp0_, 0x00, sizeof(double)*nR_*enrichMultiplier);
  rtemp1_ = (double*) fftw_malloc(sizeof(double)*nR_*enrichMultiplier);
  std::memset(rtemp1_, 0x00, sizeof(double)*nR_*enrichMultiplier);
  rtemp2_ = (double*) fftw_malloc(sizeof(double)*nR_*enrichMultiplier);
  std::memset(rtemp2_, 0x00, sizeof(double)*nR_*enrichMultiplier);

  rtTemp_ = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
  std::memset(rtTemp_, 0x00, sizeof(double)*nR_*nTheta_);

  cosTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  std::memset(cosTVal_, 0x00, sizeof(double)*nTheta_);
  sinTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  std::memset(sinTVal_, 0x00, sizeof(double)*nTheta_);
  for (int j = 0; j < nTheta_; j++) {
    double theta = ((double)(j) + 0.5)*dTheta_;
    cosTVal_[j] = cos(theta);
    sinTVal_[j] = sin(theta);
  }

  cosPVal_ = (double*) fftw_malloc(sizeof(double)*nPhi_);
  sinPVal_ = (double*) fftw_malloc(sizeof(double)*nPhi_);
  for (int i = 0; i < nPhi_; i++) {
    double phi = ((double)(i) + 0.5)*dPhi_;
    cosPVal_[i] = cos(phi);
    sinPVal_[i] = sin(phi);
  }

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    double k3 = all_basis_[i]->WN3D();
    waveNum2_[i] = k1*k1 + k2*k2 + k3*k3;
  }

  rCat_ = (double*) fftw_malloc(sizeof(double)*cartesianSize_);
  tCat_ = (double*) fftw_malloc(sizeof(double)*cartesianSize_);
  pCat_ = (double*) fftw_malloc(sizeof(double)*cartesianSize_);
  std::memset(rCat_, 0x00, sizeof(double)*cartesianSize_);
  std::memset(tCat_, 0x00, sizeof(double)*cartesianSize_);
  std::memset(pCat_, 0x00, sizeof(double)*cartesianSize_); 

  sinPi2r_ = (double*)fftw_malloc(sizeof(double)*nR_);
  pirSinPi2r_ = (double*)fftw_malloc(sizeof(double)*nR_);
  pir2Cos2Sin_ = (double*)fftw_malloc(sizeof(double)*nR_);
  
  for (int k = 0; k < nR_; k++) {
  	double r = ((double)(k) + 0.5)*dR_; // [0-1]
  	sinPi2r_[k] = sin(M_PI*0.5*r);
  	pirSinPi2r_[k] = M_PI*r*sinPi2r_[k];
  	pir2Cos2Sin_[k] = M_PI*0.5*r*cos(M_PI*0.5*r) + 2.0*sinPi2r_[k];
  }

  if (is_prolate_ || is_oblate_) {
    h_ = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
    memset(h_, 0x00, sizeof(double)*nR_*nTheta_);
    sqrtCR_ = (double*)fftw_malloc(sizeof(double)*nR_);
    memset(sqrtCR_, 0x00, sizeof(double)*nR_);
    for (int k = 0; k < nR_; k++) {
      double r = ((double)(k) + 0.5)*dR_; // [0-1]
      sqrtCR_[k] = sqrt(1.0 + c_*c_*r*r);
    }
    // set scale factor.
    if (is_prolate_) {
      for (int k = 0; k < nR_; k++) 
        for (int j = 0; j < nTheta_; j++) {
          double r = ((double)(k) + 0.5)*dR_; // [0-1]
          double t = ((double)(j) + 0.5)*dTheta_; // [0-pi]
          h_[j + k*nTheta_] = sqrt(c_*c_*r*r + sin(t)*sin(t));
        }
    }

    if (is_oblate_) {
      for (int k = 0; k < nR_; k++) 
        for (int j = 0; j < nTheta_; j++) {
          double r = ((double)(k) + 0.5)*dR_; // [0-1]
          double t = ((double)(j) + 0.5)*dTheta_; // [0-pi]
          h_[j + k*nTheta_] = sqrt(c_*c_*r*r + cos(t)*cos(t));
      }
    }
  }
  
  initCartesian();
}
  
void SphereBasisSet3D::setUpFFTWPlan() {
  fftw_r2r_kind invS_ = FFTW_RODFT01;
  fftw_r2r_kind invC_ = FFTW_REDFT01;
  fftw_r2r_kind fwdS_ = FFTW_RODFT10;
  fftw_r2r_kind fwdC_ = FFTW_REDFT10;

	int howManyR = nPhiTheta_;
	int nr[1] = {nR_};
	if (!boundaryCnd_)	// neumann
		nr[0] = 2*nR_;
	IsinR_ = fftw_plan_many_r2r(1, nr, howManyR, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &invS_, FFTW_MEASURE);
	IcosR_ = fftw_plan_many_r2r(1, nr, howManyR, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &invC_, FFTW_MEASURE);
	FsinR_ = fftw_plan_many_r2r(1, nr, howManyR, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &fwdS_, FFTW_MEASURE);
	FcosR_ = fftw_plan_many_r2r(1, nr, howManyR, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &fwdC_, FFTW_MEASURE);

	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	IcosR1D_ = fftw_plan_r2r_1d(rsize, rtemp0_, rtemp1_, invC_, FFTW_MEASURE);
	IsinR1D_ = fftw_plan_r2r_1d(rsize, rtemp0_, rtemp1_, invS_, FFTW_MEASURE);
	FcosR1D_ = fftw_plan_r2r_1d(rsize, rtemp0_, rtemp1_, fwdC_, FFTW_MEASURE);
	FsinR1D_ = fftw_plan_r2r_1d(rsize, rtemp0_, rtemp1_, fwdS_, FFTW_MEASURE);
	// This is only used for phi^7
	IsinRsinT_ = fftw_plan_r2r_2d(nR_, nTheta_, rtTemp_, rtTemp_, invS_, invS_, FFTW_MEASURE);
	FsinRsinT_ = fftw_plan_r2r_2d(nR_, nTheta_, rtTemp_, rtTemp_, fwdS_, fwdS_, FFTW_MEASURE);
	int howManyT = nPhi_;
  int nt_[1] = {nTheta_};
  
  // these are 2D plans. Because the idist parameter varies when changing from one slice to another.
  // i.e. the idist should be 1, for one slice, but the pointer need to move nTheta_*nPhi_ when moves to next slice.
  // it's unclear how to bake this as one transformations like r and p directions.
  // Same as the guru plan.
  // Need to be executed nr times
  IsinT_ = fftw_plan_many_r2r(1, nt_, howManyT, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &invS_, FFTW_MEASURE);
  IcosT_ = fftw_plan_many_r2r(1, nt_, howManyT, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &invC_, FFTW_MEASURE);
  FsinT_ = fftw_plan_many_r2r(1, nt_, howManyT, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &fwdS_, FFTW_MEASURE);
	FcosT_ = fftw_plan_many_r2r(1, nt_, howManyT, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &fwdC_, FFTW_MEASURE);

  int howManyTTrim = phiK_*2 + 4;
  IsinTE_ = fftw_plan_many_r2r(1, nt_, howManyTTrim, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &invS_, FFTW_MEASURE);
  IcosTE_ = fftw_plan_many_r2r(1, nt_, howManyTTrim, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &invC_, FFTW_MEASURE);
  FsinTE_ = fftw_plan_many_r2r(1, nt_, howManyTTrim, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &fwdS_, FFTW_MEASURE);
	FcosTE_ = fftw_plan_many_r2r(1, nt_, howManyTTrim, inTemp_, nt_, nPhi_, 1, temp0_, nt_, nPhi_, 1, &fwdC_, FFTW_MEASURE);

  int howManyRTrim = phiK_*2 + 4;
  // Need to be executed thetaK_*2 times
  IsinRE_ = fftw_plan_many_r2r(1, nr, howManyRTrim, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &invS_, FFTW_MEASURE);
	IcosRE_ = fftw_plan_many_r2r(1, nr, howManyRTrim, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &invC_, FFTW_MEASURE);
	FsinRE_ = fftw_plan_many_r2r(1, nr, howManyRTrim, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &fwdS_, FFTW_MEASURE);
	FcosRE_ = fftw_plan_many_r2r(1, nr, howManyRTrim, inTemp_, nr, nPhiTheta_, 1, temp0_, nr, nPhiTheta_, 1, &fwdC_, FFTW_MEASURE);
	int howManyP = nR_*nTheta_;
  int np_[1] = {nPhi_};

  IsinP_ = fftw_plan_many_r2r(1, np_, howManyP, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &invS_, FFTW_MEASURE);
	IcosP_ = fftw_plan_many_r2r(1, np_, howManyP, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &invC_, FFTW_MEASURE);
	FsinP_ = fftw_plan_many_r2r(1, np_, howManyP, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &fwdS_, FFTW_MEASURE);
	FcosP_ = fftw_plan_many_r2r(1, np_, howManyP, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &fwdC_, FFTW_MEASURE);

	// again, 2D plans
	int howManyPTrim = thetaK_*2 + 4;
	IsinPE_ = fftw_plan_many_r2r(1, np_, howManyPTrim, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &invS_, FFTW_MEASURE);
  IcosPE_ = fftw_plan_many_r2r(1, np_, howManyPTrim, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &invC_, FFTW_MEASURE);
	FsinPE_ = fftw_plan_many_r2r(1, np_, howManyPTrim, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &fwdS_, FFTW_MEASURE);
	FcosPE_ = fftw_plan_many_r2r(1, np_, howManyPTrim, inTemp_, np_, 1, nPhi_, temp0_, np_, 1, nPhi_, &fwdC_, FFTW_MEASURE);
}

void SphereBasisSet3D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
	CHECK(fieldCoef.size() == all_basis_.size());
	vector<int> Coefidx(phiCoef_.size(), 0);

	for (int i = 0; i < all_basis_.size(); i++) {
		int index = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[index][Coefidx[index]].coef = fieldCoef[i]*C_x;
    Coefidx[index]++;
	}
}

void SphereBasisSet3D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
	CHECK(fieldCoef.size() == all_basis_.size());
	fieldCoef.setZero();
	vector<int> Coefidx(phiCoef_.size(), 0);

	for (int i = 0; i < all_basis_.size(); i++) {
		int index = all_basis_[i]->index();
		// 0.125 comes from 2 factor from foward dcts. This funcion assumes doing dcts along three
		// directions.
		double C_x = all_basis_[i]->GetInvNorm()*0.125;
		fieldCoef[i] += phiCoef_[index][Coefidx[index]].coef*C_x*dR_*dTheta_*dPhi_;
    Coefidx[index]++;
	}
}

void SphereBasisSet3D::clearPairCoef() {
	for (auto& v : phiCoef_)
		for (auto& p : v) {
			p.coef = 0;
		}
}

// TODO: Do trimmed weight like fftw plans ?
void SphereBasisSet3D::weightByR(double* buf) {
	for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        double r = ((double)(k) + 0.5)*dR_;
        buf[i + j*nPhi_ + k*nPhi_*nTheta_] *= M_PI*r;
      }
}

void SphereBasisSet3D::weightR(const double* rVal, double* buf) {
	for (int k = 0; k < nR_; k++)
    for (int j = 0; j < (thetaK_*2 + 4); j++)
      for (int i = 0; i < (phiK_*2 + 4); i++) {
        buf[i + j*nPhi_ + k*nPhi_*nTheta_] *= rVal[k];
      }
}

// These work for both Neumann and Dirichlet because the grid is doubled along k dimension
// and we dont need to  weight the field on the extension part of transformation of half
// wavenumber is needed.
// weight with r^2sin(t),
void SphereBasisSet3D::weightR2SinT(double* buf) {
	for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        double r = ((double)(k) + 0.5)*dR_;
        buf[i + j*nPhi_ + k*nPhi_*nTheta_] *= r*r*sinTVal_[j];
      }
}

void SphereBasisSet3D::addSlabRT(const double* slab, double* a) {
	for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
    	double val = slab[j + k*nTheta_ ];
      for (int i = 0; i < nPhi_; i++) {
      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += val;
 			}
 		}
}

void SphereBasisSet3D::projectSlabRT(const double* field, double* slab) {
	for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
    	double result = 0;
      for (int i = 0; i < nPhi_; i++) {
      	result += field[i + j*nPhi_ + k*nPhiTheta_];
 			}
 			slab[j + k*nTheta_ ] = result;
 		}
}

void SphereBasisSet3D::addOuterRT(const double* rV, const double* tV, double* a) {
	for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
    	double val = rV[k]*tV[j];
      for (int i = 0; i < nPhi_; i++) {
      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += val;
 			}
 		}
}

void SphereBasisSet3D::addOuterRTCRDivH(const double* rV, const double* tV, double* a) {
	for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++) {
	    	double r = ((double)(k) + 0.5)*dR_;
	    	double val = rV[k]*tV[j]*c_*r/h_[j + k*nTheta_];
	      for (int i = 0; i < nPhi_; i++) {
	      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += val;
	 			}
	 		}
}

void SphereBasisSet3D::addOuterRTSqrtCRDivH(const double* rV, const double* tV, double* a) {
 	for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++) {
	    	double val = rV[k]*tV[j]*sqrtCR_[k]/h_[j + k*nTheta_];
	      for (int i = 0; i < nPhi_; i++) {
	      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += val;
	 			}
	 }
}

void SphereBasisSet3D::addOuterDivH(const double* rV, const double* tV, double* a) {
 	for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++) {
	    	double val = rV[k]*tV[j]/h_[j + k*nTheta_];
	      for (int i = 0; i < nPhi_; i++) {
	      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += val;
	 			}
	 }
}

void SphereBasisSet3D::projectRT(const double* field, const double* tV, double* rV) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j];
      for (int i = 0; i < nPhi_; i++) {
      	result += field[i + j*nPhi_ + k*nPhiTheta_]*tval;
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::projectRTCRDivH(const double* field, const double* tV, double* rV) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
		double r = ((double)(k) + 0.5)*dR_;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j]*c_*r/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	result += field[i + j*nPhi_ + k*nPhiTheta_]*tval;
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::projectRTSqrtCRDivH(const double* field, const double* tV, double* rV) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
		double r = ((double)(k) + 0.5)*dR_;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j]*sqrtCR_[k]/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	result += field[i + j*nPhi_ + k*nPhiTheta_]*tval;
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::projectRTDivH(const double* field, const double* tV, double* rV) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
		double r = ((double)(k) + 0.5)*dR_;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j]/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	result += field[i + j*nPhi_ + k*nPhiTheta_]*tval;
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::addOuterRTP(const double* rV, const double* tV, const double* pV, double* a) {
	for (int k = 0; k < nR_; k++) {
		double rval = rV[k];
    for (int j = 0; j < nTheta_; j++) {
    	double sval = rval*tV[j];
      for (int i = 0; i < nPhi_; i++) {
      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += sval*pV[i];
 			}
 		}
 	}
}

void SphereBasisSet3D::addOuterRTPSqrtCRDivH(const double* rV, const double* tV, const double* pV, double* a) {
	for (int k = 0; k < nR_; k++) {
		double rval = rV[k];
    for (int j = 0; j < nTheta_; j++) {
    	double sval = rval*tV[j]*sqrtCR_[k]/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += sval*pV[i];
 			}
 		}
 	}
}

void SphereBasisSet3D::addOuterRTPCRDivH(const double* rV, const double* tV, const double* pV, double* a) {
	for (int k = 0; k < nR_; k++) {
		double rval = rV[k];
		double r = ((double)(k) + 0.5)*dR_;
    for (int j = 0; j < nTheta_; j++) {
    	double sval = rval*tV[j]*c_*r/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += sval*pV[i];
 			}
 		}
 	}
}

void SphereBasisSet3D::projectTPtoR(const double* field, const double* tV, const double* pV, double* rV ) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j];
      for (int i = 0; i < nPhi_; i++) {
      	result += tval*pV[i]*field[i + j*nPhi_ + k*nPhiTheta_];
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::projectTPtoRSqrtCRDivH(const double* field, const double* tV, const double* pV, double* rV ) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j]*sqrtCR_[k]/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	result += tval*pV[i]*field[i + j*nPhi_ + k*nPhiTheta_];
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::projectTPtoRCRDivH(const double* field, const double* tV, const double* pV, double* rV ) {
	for (int k = 0; k < nR_; k++) {
		double result = 0;
		double r = ((double)(k) + 0.5)*dR_;
    for (int j = 0; j < nTheta_; j++) {
    	double tval = tV[j]*c_*r/h_[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	result += tval*pV[i]*field[i + j*nPhi_ + k*nPhiTheta_];
 			}
 		}
 		rV[k] = result;
 	}
}

void SphereBasisSet3D::addOuterSlabP(const double* slab, const double* pV, double* a) {
	for (int k = 0; k < nR_; k++) {
    for (int j = 0; j < nTheta_; j++) {
    	double sval = slab[j + k*nTheta_];
      for (int i = 0; i < nPhi_; i++) {
      	a[i + j*nPhi_ + k*nPhi_*nTheta_] += sval*pV[i];
 			}
 		}
 	}
}

void SphereBasisSet3D::projectSlabP(const double* field, const double* pV, double* slab) {
	for (int k = 0; k < nR_; k++) {
    for (int j = 0; j < nTheta_; j++) {
    	double result = 0;
      for (int i = 0; i < nPhi_; i++) {
      	result += field[i + j*nPhi_ + k*nPhiTheta_]*pV[i];
 			}
 			slab[j + k*nTheta_] = result;
 		}
 	}
}

#define GETVR(srcF, tVal,  pVal, resultF)\
if (is_prolate_)\
	addOuterRTPSqrtCRDivH(srcF, tVal, pVal, resultF);\
else if (is_oblate_)\
	addOuterRTPCRDivH(srcF, tVal, pVal, resultF);\
else\
	addOuterRTP(srcF, tVal, pVal, resultF);\

#define GETVT(srcF, tVal,  pVal, resultF)\
if (is_prolate_)\
	addOuterRTPCRDivH(srcF, tVal, pVal, resultF);\
else if (is_oblate_)\
	addOuterRTPSqrtCRDivH(srcF, tVal, pVal, resultF);\
else\
	addOuterRTP(srcF, tVal, pVal, resultF);\

#define GETVP(sgn)\
if (is_prolate_) {\
	for (int k = 0; k < nR_; k++) {\
		double r = ((double)(k) + 0.5)*dR_;\
		for (int j = 0; j < nTheta_; j++) {\
			rtTemp_[j + k*nTheta_] = sgn*(rtemp1_[k]*(cosTVal_[j]*cosTVal_[j]*c_*c_*r*r + sinTVal_[j]*sinTVal_[j]) +\
				 rtemp0_[k]*(1.0 + c_*c_*r*r - cosTVal_[j]*cosTVal_[j]))/h_[j + k*nTheta_]/h_[j + k*nTheta_];\
		}\
	}\
} else if (is_oblate_) {\
	for (int k = 0; k < nR_; k++) {\
		double r = ((double)(k) + 0.5)*dR_;\
		for (int j = 0; j < nTheta_; j++) {\
			rtTemp_[j + k*nTheta_] = sgn*(rtemp1_[k]*cosTVal_[j]*cosTVal_[j]*(1.0 + c_*c_*r*r)\
				+ rtemp0_[k]*(c_*c_*r*r + cosTVal_[j]*cosTVal_[j]))/h_[j + k*nTheta_]/h_[j + k*nTheta_];\
		}\
	}\
} else {\
	/* (-i1 r sin(i1 r)cos^2(t) + cos(i1 r))*/\
	for (int k = 0; k < nR_; k++) {\
		for (int j = 0; j < nTheta_; j++) {\
			rtTemp_[j + k*nTheta_] = sgn*(rtemp1_[k]*cosTVal_[j]*cosTVal_[j] + rtemp0_[k]);\
		}\
	}\
}

// This pretty much reduced the cost of DCT down to 1D.
// The cost is now pretty O(totalSize_)
// TODO: iterate over the field smaller number of times ?
// Do Phi5 and 6 seperately, as doing them together like Phi0,1 will likely lead to negligible
// improvements. 
void SphereBasisSet3D::InverseTransformPhi5() {
	// Phi^5, DCT norm for this guy is 0.125, because three wavenumbers are non-zero.
	// this is why we are multiplying 4.0 here, because we aren't doing dcts along
	// the other directions.
	// ur
	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	int divd = boundaryCnd_ ? 1 : 2;
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp1_, rsize);
	vector<pairedCoef>* coefVec = &phiCoef_[5];

	for (const auto& p : *coefVec) {
		// cos(r)
		rtemp0_[p.i1x2/divd] += p.coef*4.0;
		//-i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			rtemp1_[p.i1x2/divd - 1] += -p.coef*2.0*p.i1x2;
	}
	fftw_execute_r2r(IcosR1D_, rtemp0_, rtemp0_);
	fftw_execute_r2r(IsinR1D_, rtemp1_, rtemp1_);

	for (int k = 0; k < nR_; k++) {
		double r = ((double)(k) + 0.5)*dR_;
		rtemp1_[k] *= M_PI*r;
	}

	GETVR(rtemp0_, sinTVal_, sinPVal_, vrTemp_);

  // ut, -i1*r sin(i1*r) + cos(i1*r)
  clearPointerSize(rtemp2_, nR_);
	for (int k = 0; k < nR_; k++) {
		rtemp2_[k] = rtemp1_[k] + rtemp0_[k];
	}
	GETVT(rtemp2_, cosTVal_, sinPVal_, vtTemp_);

	// up
	clearPointerSize(rtTemp_, nR_*nTheta_);
	GETVP(1);
	addOuterSlabP(rtTemp_, cosPVal_, vpTemp_);
}

// This is the same as phi5 except the swap of phi mode.
void SphereBasisSet3D::InverseTransformPhi6() {
	// Phi^5, DCT norm for this guy is 0.125, because three wavenumbers are non-zero.
	// this is why we are multiplying 4.0 here, because we aren't doing dcts along
	// the other directions.
	// ur
	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	int divd = boundaryCnd_ ? 1 : 2;
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp1_, rsize);
	vector<pairedCoef>* coefVec = &phiCoef_[6];
	for (const auto& p : *coefVec) {
		// cos(r)
		rtemp0_[p.i1x2/divd] += p.coef*4.0;
		//-i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			rtemp1_[p.i1x2/divd - 1] += -p.coef*2.0*p.i1x2;
	}
	fftw_execute_r2r(IcosR1D_, rtemp0_, rtemp0_);
	fftw_execute_r2r(IsinR1D_, rtemp1_, rtemp1_);

	// -i1*r sin(i1*r)
	for (int k = 0; k < nR_; k++) {
		double r = ((double)(k) + 0.5)*dR_;
		rtemp1_[k] *= M_PI*r;
	}

  GETVR(rtemp0_,sinTVal_, cosPVal_, vrTemp_);

  // ut, -i1*r sin(i1*r) + cos(i1*r)
  clearPointerSize(rtemp2_, nR_);
	for (int k = 0; k < nR_; k++) {
		rtemp2_[k] = rtemp1_[k] + rtemp0_[k];
	}
	GETVT(rtemp2_, cosTVal_, cosPVal_, vtTemp_);

	// up
	clearPointerSize(rtTemp_, nR_*nTheta_);
	GETVP(-1);
	addOuterSlabP(rtTemp_, sinPVal_, vpTemp_);
}

#define PROJ_R(srcF, tVal,  pVal, resultF)\
if (is_prolate_)\
	projectTPtoRSqrtCRDivH(srcF, tVal, pVal, resultF);\
else if (is_oblate_)\
	projectTPtoRCRDivH(srcF, tVal, pVal, resultF);\
else\
	projectTPtoR(srcF, tVal, pVal, resultF);\

#define PROJ_T(srcF, tVal,  pVal, resultF)\
if (is_prolate_)\
	projectTPtoRCRDivH(srcF, tVal, pVal, resultF);\
else if (is_oblate_)\
	projectTPtoRSqrtCRDivH(srcF, tVal, pVal, resultF);\
else\
	projectTPtoR(srcF, tVal, pVal, resultF);\

#define PROJ_P \
if (is_prolate_) {\
	for (int k = 0; k < nR_; k++) {\
		double r0V = 0, r1V = 0;\
		double r = ((double)(k) + 0.5)*dR_;\
		for (int j = 0; j < nTheta_; j++) {\
			double invh2 = 1.0/h_[j + k*nTheta_]/h_[j + k*nTheta_];\
			r0V += rtTemp_[j + k*nTheta_]*(1.0 + c_*c_*r*r - cosTVal_[j]*cosTVal_[j])*invh2;  /* cos(i1 r)*/\
			r1V += rtTemp_[j + k*nTheta_]*(c_*c_*r*r*cosTVal_[j]*cosTVal_[j] + sinTVal_[j]*sinTVal_[j])*M_PI*r*invh2; /*sin(i1r)*/\
		}\
		rtemp0_[k] = r0V;\
		rtemp1_[k] = r1V;\
	}\
} else if (is_oblate_) {\
	for (int k = 0; k < nR_; k++) {\
		double r0V = 0, r1V = 0;\
		double r = ((double)(k) + 0.5)*dR_;\
		for (int j = 0; j < nTheta_; j++) {\
			double invh2 = 1.0/h_[j + k*nTheta_]/h_[j + k*nTheta_];\
			r0V += rtTemp_[j + k*nTheta_]*(c_*c_*r*r + cosTVal_[j]*cosTVal_[j])*invh2;  /* cos(i1 r)*/\
			r1V += rtTemp_[j + k*nTheta_]*(c_*c_*r*r + 1.0)*cosTVal_[j]*cosTVal_[j]*M_PI*r*invh2; /*sin(i1r)*/\
		}\
		rtemp0_[k] = r0V;\
		rtemp1_[k] = r1V;\
	}\
} else {\
	for (int k = 0; k < nR_; k++) {\
		double r0V = 0, r1V = 0;\
		double r = ((double)(k) + 0.5)*dR_;\
		for (int j = 0; j < nTheta_; j++) {\
			r0V += rtTemp_[j + k*nTheta_];  /* cos(i1 r)*/\
			r1V += rtTemp_[j + k*nTheta_]*cosTVal_[j]*cosTVal_[j]*M_PI*r; /*sin(i1r)*/\
		}\
		rtemp0_[k] = r0V;\
		rtemp1_[k] = r1V;\
	}\
}

void SphereBasisSet3D::ForwardTransformPhi5() {
	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	int divd = boundaryCnd_ ? 1 : 2;

	// ur
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp2_, rsize);
	clearPointerSize(rtemp1_, rsize);

	PROJ_R(vrTemp_, sinTVal_, sinPVal_, rtemp0_);
	PROJ_T(vtTemp_, cosTVal_, sinPVal_, rtemp2_);

  fftw_execute_r2r(FcosR1D_, rtemp0_, rtemp0_);
	fftw_execute_r2r(FcosR1D_, rtemp2_, rtemp1_);  // cos
	for (int k = 0; k < nR_; k++) {
		double r = ((double)(k) + 0.5)*dR_;
		rtemp2_[k] *= M_PI*r;
	}
	fftw_execute_r2r(FsinR1D_, rtemp2_, rtemp2_);  // sin

	vector<pairedCoef>* coefVec = &phiCoef_[5];

	for (auto& p : *coefVec) {
		// cos(r)
		p.coef += rtemp0_[p.i1x2/divd]*4.0;
		p.coef += rtemp1_[p.i1x2/divd]*4.0;
		//-i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			p.coef += -rtemp2_[p.i1x2/divd - 1]*2.0*p.i1x2;
	}
	
	// up
	clearPointerSize(rtTemp_, nR_*nTheta_);
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp1_, rsize);
	projectSlabP(vpTemp_, cosPVal_, rtTemp_);

	PROJ_P;
  
  fftw_execute_r2r(FcosR1D_, rtemp0_, rtemp0_);
	fftw_execute_r2r(FsinR1D_, rtemp1_, rtemp1_);  // sin(i1r)

	for (auto& p : *coefVec) {
		// cos(r)
		p.coef += rtemp0_[p.i1x2/divd]*4.0;
		//-i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			p.coef += -rtemp1_[p.i1x2/divd - 1]*2.0*p.i1x2;
	}
}

void SphereBasisSet3D::ForwardTransformPhi6() {
	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	int divd = boundaryCnd_ ? 1 : 2;

	// ur
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp2_, rsize);
	clearPointerSize(rtemp1_, rsize);

	PROJ_R(vrTemp_, sinTVal_, cosPVal_, rtemp0_);

	// ut
	PROJ_T(vtTemp_, cosTVal_, cosPVal_, rtemp2_);

  fftw_execute_r2r(FcosR1D_, rtemp0_, rtemp0_);
	fftw_execute_r2r(FcosR1D_, rtemp2_, rtemp1_);  // cos
	for (int k = 0; k < nR_; k++) {
		double r = ((double)(k) + 0.5)*dR_;
		rtemp2_[k] *= M_PI*r;
	}
	fftw_execute_r2r(FsinR1D_, rtemp2_, rtemp2_);  // sin

	vector<pairedCoef>* coefVec = &phiCoef_[6];

	for (auto& p : *coefVec) {
		// cos(r)
		p.coef += rtemp0_[p.i1x2/divd]*4.0;
		p.coef += rtemp1_[p.i1x2/divd]*4.0;
		//-i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			p.coef += -rtemp2_[p.i1x2/divd - 1]*2.0*p.i1x2;
	}
	
	// up
	clearPointerSize(rtTemp_, nR_*nTheta_);
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp1_, rsize);

	projectSlabP(vpTemp_, sinPVal_, rtTemp_);
	// negate
	for (int id = 0; id < nR_*nTheta_; id++)
		rtTemp_[id] = -rtTemp_[id];

	PROJ_P;

  fftw_execute_r2r(FcosR1D_, rtemp0_, rtemp0_);
	fftw_execute_r2r(FsinR1D_, rtemp1_, rtemp1_);  // cos

	for (auto& p : *coefVec) {
		// cos(r)
		p.coef += rtemp0_[p.i1x2/divd]*4.0;
		//-i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			p.coef += -rtemp1_[p.i1x2/divd - 1]*2.0*p.i1x2;
	}
}

// this handles everything from Phi^4-7
void SphereBasisSet3D::InverseTransformEnrich() {

 	clearPointer(temp0_);
	Eigen::Map<Eigen::VectorXd> temp0V(temp0_, totalSize_);
	Eigen::Map<Eigen::VectorXd> vrTempV(vrTemp_, totalSize_);
	Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	int divd = boundaryCnd_ ? 1 : 2;
	// Phi^4 DCT norm for this guy is 0.5, because two wavenumbers are zero.
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp1_, rsize);
	for (const auto& p : phiCoef_[4]) {
		// cos(r)
		rtemp0_[p.i1x2/divd] += p.coef;
		// 0.5 i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			rtemp1_[p.i1x2/divd - 1] += p.coef*0.25*p.i1x2;
	}
	fftw_execute_r2r(IcosR1D_, rtemp0_, rtemp0_); // cos
	fftw_execute_r2r(IsinR1D_, rtemp1_, rtemp1_); // i1 sin

	// vr component
	clearPointerSize(rtTemp_, nR_*nTheta_);
	// outer product.
	if (is_prolate_)
		addOuterRTCRDivH(rtemp0_, cosTVal_, vrTemp_);
	else if (is_oblate_)
		addOuterRTSqrtCRDivH(rtemp0_, cosTVal_, vrTemp_);
	else
		addOuterRT(rtemp0_, cosTVal_, vrTemp_);

	// vt component.
	// (-cos(r) + 0.5rsin(r))
	if (is_oblate_) {
		for (int k = 0; k < nR_; k++) {
			double r = ((double)(k) + 0.5)*dR_;
			rtemp1_[k] *= M_PI/c_*(1.0 + c_*c_*r*r);
			rtemp1_[k] -= c_*r*rtemp0_[k];  // cos
		}
	} else {
		for (int k = 0; k < nR_; k++) {
			double r = ((double)(k) + 0.5)*dR_;
			rtemp1_[k] *= M_PI*r;
			rtemp1_[k] -= rtemp0_[k];
		}
	}
	//clearPointer(temp0_);
	clearPointerSize(rtTemp_, nR_*nTheta_);
	if (is_prolate_)
		addOuterRTSqrtCRDivH(rtemp1_, sinTVal_, vtTemp_);
	else if (is_oblate_)
		addOuterDivH(rtemp1_, sinTVal_, vtTemp_);
	else
		addOuterRT(rtemp1_, sinTVal_, vtTemp_);

	// Phi^5
	InverseTransformPhi5();
	// Phi^6
	InverseTransformPhi6();

	// Phi^7
	clearPointerSize(rtTemp_, nR_*nTheta_);
	// sin(r)sin(t)
	for (const auto& p : phiCoef_[7]) {
		rtTemp_[p.i2x2/2 - 1 + (p.i1x2/2 - 1)*nTheta_] += p.coef;
	}
	fftw_execute_r2r(IsinRsinT_, rtTemp_, rtTemp_);
	
#ifdef USE_R_WEIGHT
	for (int j = 0; j < nR_; j++)
		for (int i = 0; i < nTheta_; i++) {
			const double r = ((double)(j) + 0.5)*dR_;
			rtTemp_[i + j*nTheta_] *= sinPi2r_[j];
		}
#endif

	addSlabRT(rtTemp_, vpTemp_);
}

void SphereBasisSet3D::ForwardTransformEnrich() {
	int rsize = boundaryCnd_ ? 2*nR_ : nR_;
	int divd = boundaryCnd_ ? 1 : 2;
	
	clearPointerSize(rtemp0_, rsize);
	clearPointerSize(rtemp1_, rsize);
	// project.
	if (is_prolate_)
		projectRTCRDivH(vrTemp_, cosTVal_, rtemp0_);
	else if (is_oblate_)
		projectRTSqrtCRDivH(vrTemp_, cosTVal_, rtemp0_);
	else
		projectRT(vrTemp_, cosTVal_, rtemp0_);

	if (is_prolate_)
		projectRTSqrtCRDivH(vtTemp_, sinTVal_, rtemp1_);
	else if (is_oblate_)
		projectRTDivH(vtTemp_, sinTVal_, rtemp1_);
	else
		projectRT(vtTemp_, sinTVal_, rtemp1_);

	fftw_execute_r2r(FcosR1D_, rtemp0_, rtemp0_); // cos
	memcpy(rtemp2_, rtemp1_, sizeof(double)*nR_);
	if (is_oblate_) {
		for (int k = 0; k < nR_; k++) {
			double r = ((double)(k) + 0.5)*dR_;
			rtemp2_[k] *= c_*r;
		}
	}
	fftw_execute_r2r(FcosR1D_, rtemp2_, rtemp2_); // cos t
	if (is_oblate_) {
		for (int k = 0; k < nR_; k++) {
			double r = ((double)(k) + 0.5)*dR_;
			rtemp1_[k] *= M_PI/c_*(1.0 + c_*c_*r*r);
		}
	} else {
		for (int k = 0; k < nR_; k++) {
			double r = ((double)(k) + 0.5)*dR_;
			rtemp1_[k] *= M_PI*r;
		}
	}
	fftw_execute_r2r(FsinR1D_, rtemp1_, rtemp1_); // sin(r)

	// Phi^4 DCT norm for this guy is 0.5, because two wavenumbers are zero.
	// need to multiply 4.0 because we are not doing dct along two other directions.
	// this accounts for 2 DCT factor.
	for (auto& p : phiCoef_[4]) {
		// cos(r)
		p.coef += rtemp0_[p.i1x2/divd]*4.0;
		p.coef -= rtemp2_[p.i1x2/divd]*4.0;
		// 0.5 i1 r sin(i1 r)
		if (p.i1x2/divd >= 1)
			p.coef += rtemp1_[p.i1x2/divd - 1]*p.i1x2;
	}

	ForwardTransformPhi5();
	ForwardTransformPhi6();
	
	clearPointerSize(rtTemp_, nR_*nTheta_);
	projectSlabRT(vpTemp_, rtTemp_);
	
#ifdef USE_R_WEIGHT
	for (int j = 0; j < nR_; j++)
		for (int i = 0; i < nTheta_; i++) {
			const double r = ((double)(j) + 0.5)*dR_;
			rtTemp_[i + j*nTheta_] *= sinPi2r_[j];
		}
#endif

	fftw_execute_r2r(FsinRsinT_, rtTemp_, rtTemp_);
	// again, we are projecting along theta direction without dct, but other function
	// assume the 2 factor from fftw forward dcts....
	for (auto& p : phiCoef_[7]) {
		p.coef += rtTemp_[p.i2x2/2 - 1 + (p.i1x2/2 - 1)*nTheta_]*2.0;
	}
}

void SphereBasisSet3D::TransP(fftw_plan plan, double* in, double* out) {
	//fftw_plan trimP = inverse ? IcosPE_ : FcosPE_;
	for (int i = 0; i < rK_*2 + 4; i++) {
		fftw_execute_r2r(plan, &in[i*nPhi_*nTheta_], &out[i*nPhi_*nTheta_]);
	}
}

void SphereBasisSet3D::weightVRFactor(double* ptr) {
	if (is_prolate_) {
	  for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	        double r = ((double)(k) + 0.5)*dR_; // [0-1]
	        ptr[i + j*nPhi_ + k*nPhiTheta_] *= c_*r*r/h_[j + k*nTheta_];
	      }

	} else if (is_oblate_) {
		for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	      	double r = ((double)(k) + 0.5)*dR_; // [0-1]
	      	ptr[i + j*nPhi_ + k*nPhiTheta_] *= c_*c_*r*r*r/h_[j + k*nTheta_]/sqrtCR_[k];
	      }
	} else {
#ifdef USE_R_WEIGHT
		for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	      	double r = ((double)(k) + 0.5)*dR_; // [0-1]
	      	ptr[i + j*nPhi_ + k*nPhiTheta_] *= sinPi2r_[k];
	      }
#endif
	}
}

// This handles r component of Phi^0-Phi^3
void SphereBasisSet3D::InverseTransformVR() {
// first transoform to vR.
	clearPointer(vrTemp_);
	clearPointer(temp0_);
	clearPointer(temp1_);
	clearPointer(inTemp_);
	Eigen::Map<Eigen::VectorXd> inV(inTemp_, totalSize_);
	Eigen::Map<Eigen::VectorXd> temp0V(temp0_, totalSize_);
	Eigen::Map<Eigen::VectorXd> temp1V(temp1_, totalSize_);
	Eigen::Map<Eigen::VectorXd> vrTempV(vrTemp_, totalSize_);
	// Let's first transform r component of Phi^0-Phi^3
	// This looks confusing but please refer to better transformations in basisAnalysis_3D.pdf
	// and tricks in basisAnalysis_sphere.pdf
	// sin(p)sin(t)sin(r)
	// Phi^0, let's assume dirichlet for now.
	int divd = !boundaryCnd_ ? 1 : 2;

	for (const auto& p : phiCoef_[0]) {
		inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += p.coef*0.5;
		if (p.i2x2/2 > 1) {
			inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] -= p.coef*0.5;
		}
	}
	// sin(p)sin(t)sin(r)
	// Phi^2
	for (const auto& p : phiCoef_[2]) {
		if (p.i2x2 > 0)
			inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += p.coef;
	}

	TransP(IsinPE_, inTemp_, temp0_);
	clearPointer(inTemp_);
	// cos(p)sin(t)sin(r)
	// Phi^1
	for (const auto& p : phiCoef_[1]) {
		inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += p.coef*0.5;
		if (p.i2x2/2 > 1) {
			inTemp_[p.i3x2 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] -= p.coef*0.5;
		}
	}
	// cos(p)sin(t)sin(r)
	// Phi^3
	for (const auto& p : phiCoef_[3]) {
		if (p.i2x2/2 > 1) {
			inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += p.coef;
		}
	}

	TransP(IcosPE_, inTemp_, temp1_);
	// contains Phi^0, Phi^1
	temp0V += temp1V;

  // Reduce the number of dcts along r direction if use trimmed plans.
  // This is different than ITransT because array is now filled in range phi.
  int numExec = useTrimmedPlan ? rK_*2 + 4 : nR_;
  for (int i = 0; i < numExec && i < nR_; i++) {
    fftw_execute_r2r(IsinT_, &temp0_[i*nPhiTheta_], &temp0_[i*nPhiTheta_]);
  }

	clearPointer(inTemp_);

	for (const auto& p : phiCoef_[8]) {
		double coefMinus = p.i2x2 <= 2 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -p.coef*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += p.coef*coefMinus*0.5;
	}
	TransP(IsinPE_, inTemp_, inTemp_);
  // Reduce the number of dcts along r direction if use trimmed plans.
  // This is different than ITransT because array is now filled in range phi.
  for (int i = 0; i < numExec && i < nR_; i++) {
    fftw_execute_r2r(IcosT_, &inTemp_[i*nPhiTheta_], &inTemp_[i*nPhiTheta_]);
  }
  temp0V += inV;

  clearPointer(inTemp_);
	for (const auto& p : phiCoef_[9]) {
		double coefMinus = p.i2x2 <= 2 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -p.coef*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += p.coef*coefMinus*0.5;
	}
	TransP(IcosPE_, inTemp_, inTemp_);
	for (int i = 0; i < numExec && i < nR_; i++) {
    fftw_execute_r2r(IcosT_, &inTemp_[i*nPhiTheta_], &inTemp_[i*nPhiTheta_]);
  }
	temp0V += inV;

	fftw_execute_r2r(IsinR_, temp0_, vrTemp_);
	//VR now contains the r component of velocity from both Phi^0-Phi^3
	weightVRFactor(vrTemp_);
}

// assume the field need to transform is already in vrTemp_, also weighted with r^2 sin(t)
// This handles r component of Phi^0-Phi^3
void SphereBasisSet3D::ForwardTransformVR() {
	clearPointer(temp0_);
	clearPointer(inTemp_);
	int divd = !boundaryCnd_ ? 1 : 2;
	memcpy(temp1_, vrTemp_, totalSize_*sizeof(double));
	weightVRFactor(temp1_);

	fftw_execute_r2r(FsinR_, temp1_, temp0_);
	memcpy(temp1_, temp0_, totalSize_*sizeof(double));
	// Reduce the number of dcts along r direction if use trimmed plans.
  // This is different than ITransT because array is now filled in range phi.
  int numExec = useTrimmedPlan ? rK_*2 + 4 : nR_;
  for (int i = 0; i < numExec && i < nR_; i++) {
    fftw_execute_r2r(FsinT_, &temp0_[i*nPhiTheta_], &temp0_[i*nPhiTheta_]);
    fftw_execute_r2r(FcosT_, &temp1_[i*nPhiTheta_], &temp1_[i*nPhiTheta_]);
  }

  TransP(FsinPE_, temp0_, inTemp_);

  for (auto& p : phiCoef_[0]) {
  	p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
		if (p.i2x2/2 > 1) {
			p.coef -= inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
		}
	}
	// sin(p)sin(t)sin(r)
	// Phi^2
	for (auto& p : phiCoef_[2]) {
		if (p.i2x2 > 0) {
			p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_];
		}
	}

	clearPointer(inTemp_);
	TransP(FsinPE_, temp1_, inTemp_);

	for (auto& p : phiCoef_[8]) {
		p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
		p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
	}
 	clearPointer(inTemp_);
 	TransP(FcosPE_, temp1_, inTemp_);
	for (auto& p : phiCoef_[9]) {
		p.coef += -inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
	}

	clearPointer(inTemp_);
	TransP(FcosPE_, temp0_, inTemp_);
	// cos(p)sin(t)sin(r)
	// Phi^1
	for (auto& p : phiCoef_[1]) {
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
		if (p.i2x2/2 > 1) {
			p.coef -= inTemp_[p.i3x2 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*0.5;
		}
	}
	// cos(p)sin(t)sin(r)
	// Phi^3
	for (auto& p : phiCoef_[3]) {
		if (p.i2x2 > 0) {
			p.coef += inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_];
		}
	}
}

void SphereBasisSet3D::TransR(fftw_plan plan, double* in, double* out) {
	// use trimmed plan
	//fftw_plan trimP = inverse ? IcosRE_ : FcosRE_;
	for (int i = 0; i < (thetaK_*2 + 4) && i < nTheta_;  i++)
		fftw_execute_r2r(plan, &in[i*nPhi_], &out[i*nPhi_]);
}

void SphereBasisSet3D::TransT(fftw_plan plan, double* in, double* out) {

	//fftw_plan trimP = inverse ? IcosTE_ : FcosTE_;
	for (int i = 0; i < nR_; i++)
		fftw_execute_r2r(plan, &in[i*nPhiTheta_], &out[i*nPhiTheta_]);
}

void SphereBasisSet3D::weightVTFactor(double* ptr) {
  if (is_prolate_) {
	  for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	      	double r = ((double)(k) + 0.5)*dR_; // [0-1]
	        ptr[i + j*nPhi_ + k*nPhiTheta_] *= r*sqrtCR_[k]/h_[j + k*nTheta_];
	      }

	} else if (is_oblate_) {
		for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	      	double r = ((double)(k) + 0.5)*dR_; // [0-1]
	      	ptr[i + j*nPhi_ + k*nPhiTheta_] *= c_*r*r/h_[j + k*nTheta_];
	      }
	} else {
#ifdef USE_R_WEIGHT
#endif
	}
}

// This handles theta component of Phi^0, Phi^2, Phi^1, Phi^3
void SphereBasisSet3D::InverseTransformVT() {

#ifdef USE_R_WEIGHT
	const double RsinCoef = 1.0;
#else
	const double RsinCoef = 2.0;
#endif

	clearPointer(vtTemp_);
	clearPointer(temp0_);
	clearPointer(temp1_);
	int divd = !boundaryCnd_ ? 1 : 2;

	// Phi^0, Phi^2------------------------------------------------------------------------------------
	clearPointer(inTemp_);
	// sin(p)cos(t)(2sin(r))
	for (const auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 <= 2 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] -= -invi2*p.coef*RsinCoef*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*p.coef*coefMinus*RsinCoef*0.5;
	}
	for (const auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*p.coef*RsinCoef;
	}
	TransR(IsinRE_, inTemp_, temp0_);
	clearPointer(inTemp_);
	// sin(p)cos(t)(rcos(r))
	for (const auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 <= 2 ? 1.0 : 0.5;
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] -= -invi2*i1*p.coef*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -invi2*i1*p.coef*coefMinus;
	}
	for (const auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += invi2*i1*p.coef;
	}
	TransR(IcosRE_, inTemp_, temp1_);
	// weight by r.
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, temp0_);

  Eigen::Map<Eigen::VectorXd> temp0V(temp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> temp1V(temp1_, totalSize_);
  Eigen::Map<Eigen::VectorXd> inV(inTemp_, totalSize_);
  // add together, now we have (rcosr + 2sin(r))
  temp0V += temp1V;

  TransT(IcosTE_, temp0_, temp0_);

  clearPointer(inTemp_); // -1 + 1, -1 - 1
  clearPointer(temp1_);
  for (const auto& p : phiCoef_[8]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
  	double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*p.coef*0.5;
		if (p.i2x2/2 > 1)
			inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*p.coef*0.5;
	
		temp1_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += i1*invi2*p.coef*0.5;
		if (p.i2x2/2 > 1)
			temp1_[p.i3x2 - 1 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -i1*invi2*p.coef*0.5;
	}

	TransR(IsinRE_, inTemp_, inTemp_); // long weight
	TransR(IcosRE_, temp1_, temp1_); // short weight.
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, inTemp_);
	temp1V += inV;
	TransT(IsinTE_, temp1_, temp1_);
	temp0V += temp1V;

  fftw_execute_r2r(IsinP_, temp0_, vtTemp_);

	// Phi^1, Phi^3-------------------------------------------------------------------
  clearPointer(inTemp_);
  clearPointer(temp0_);
  // cos(p)cos(t)(2sin(r))
	for (const auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 <= 2 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] -= -invi2*p.coef*RsinCoef*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*p.coef*coefMinus*RsinCoef*0.5;
	}
	for (const auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*p.coef*RsinCoef;
	}
	TransR(IsinRE_, inTemp_, temp0_);
	clearPointer(inTemp_);
	clearPointer(temp1_);
	// cos(p)cos(t)cos(r)
	for (const auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 <= 2 ? 1.0 : 0.5;
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] -= -invi2*i1*p.coef*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -invi2*i1*p.coef*coefMinus;
	}
	for (const auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += invi2*i1*p.coef;	
	}
	TransR(IcosRE_, inTemp_, temp1_);
	// weight by r.
	//weightByR(temp1_);
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, temp0_);

  // add together, now we have (rcosr + 2sin(r))
  temp0V += temp1V;
  TransT(IcosTE_, temp0_, temp0_);

  clearPointer(inTemp_); // -1 + 1, -1 - 1
  clearPointer(temp1_);
  for (const auto& p : phiCoef_[9]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
  	double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*p.coef*0.5;
		if (p.i2x2/2 > 1)
			inTemp_[p.i3x2 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*p.coef*0.5;
	
		temp1_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += i1*invi2*p.coef*0.5;
		if (p.i2x2/2 > 1)
			temp1_[p.i3x2 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -i1*invi2*p.coef*0.5;
	}

	TransR(IsinRE_, inTemp_, inTemp_); // long weight
	TransR(IcosRE_, temp1_, temp1_); // short weight.
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, inTemp_);
	temp1V += inV;
	TransT(IsinTE_, temp1_, temp1_);
	temp0V += temp1V;

  fftw_execute_r2r(IcosP_, temp0_, temp0_);
 
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  vtTempV += temp0V;

	weightVTFactor(vtTemp_);
}

void SphereBasisSet3D::ForwardTransformVT() {
#ifdef USE_R_WEIGHT
	const double RsinCoef = 1.0;
#else
	const double RsinCoef = 2.0;
#endif

	clearPointer(temp0_);
	int divd = !boundaryCnd_ ? 1 : 2;
	memcpy(temp1_, vtTemp_, totalSize_*sizeof(double));
	// temp1_ holds the factor weighted results.
	weightVTFactor(temp1_);
	// Phi^0, Phi^2------------------------------------------------------------------------------------
  fftw_execute_r2r(FsinP_, temp1_, temp0_);
  
  clearPointer(inTemp_);
  clearPointer(temp2_);

  memcpy(temp2_, temp0_, totalSize_*sizeof(double));
  TransT(FsinTE_, temp2_, temp2_);
  memcpy(inTemp_, temp2_, totalSize_*sizeof(double));
  
  weightR(pir2Cos2Sin_, inTemp_);
	TransR(FsinRE_, inTemp_, inTemp_); // sin(i1 pi r)
	for (auto& p : phiCoef_[8]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
  	double i1 = p.i1x2*0.5;
		p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*0.5;
		if (p.i2x2/2 > 1)
			p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*0.5;
	}
	weightR(pirSinPi2r_, temp2_);
	TransR(FcosRE_, temp2_, temp2_);
	for (auto& p : phiCoef_[8]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
  	double i1 = p.i1x2*0.5;
		p.coef += temp2_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*0.5;
		if (p.i2x2/2 > 1)
			p.coef += -temp2_[p.i3x2 - 1 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*0.5;
	}

  TransT(FcosTE_, temp0_, temp0_);

  clearPointer(inTemp_);
	memcpy(inTemp_, temp0_, totalSize_*sizeof(double));
	weightR(pir2Cos2Sin_, inTemp_);

  TransR(FsinRE_, inTemp_, inTemp_);
  // 2*sin(i1 r)
  for (auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		p.coef -= -inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
		p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
	}
	for (auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef;
	}
	clearPointer(inTemp_);
	
	// weight by r.
	//weightByR(temp0_);
	weightR(pirSinPi2r_, temp0_);
	
	TransR(FcosRE_, temp0_, inTemp_);
	// sin(p)cos(t)(rcos(r))
	for (auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		p.coef -= -inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;
		p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;
	}
	for (auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1;
	}

	// Phi^1, Phi^3-------------------------------------------------------------------
  clearPointer(inTemp_);
  clearPointer(temp0_);
  
  fftw_execute_r2r(FcosP_, temp1_, temp0_);
  clearPointer(temp2_);
  memcpy(temp2_, temp0_, sizeof(double)*totalSize_);
  TransT(FsinTE_, temp2_, temp2_);
  memcpy(inTemp_, temp2_, sizeof(double)*totalSize_);
  weightR(pir2Cos2Sin_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  for (auto& p : phiCoef_[9]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
  	double i1 = p.i1x2*0.5;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*0.5;
		if (p.i2x2/2 > 1)
			p.coef += -inTemp_[p.i3x2 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*0.5;
	}
	weightR(pirSinPi2r_, temp2_);
	TransR(FcosRE_, temp2_, temp2_);
	for (auto& p : phiCoef_[9]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
  	double i1 = p.i1x2*0.5;
		p.coef += temp2_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*0.5;
		if (p.i2x2/2 > 1)
			p.coef += -temp2_[p.i3x2 + (p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*0.5;
	}

	clearPointer(inTemp_);
  TransT(FcosTE_, temp0_, temp0_);
  memcpy(inTemp_, temp0_,  totalSize_*sizeof(double));
  weightR(pir2Cos2Sin_, inTemp_);

  TransR(FsinRE_, inTemp_, inTemp_);
  // cos(p)cos(t)(2sin(r))
	for (auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		p.coef -= -inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
		p.coef += -inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
	}
	for (auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef;
	}

	clearPointer(inTemp_);
	// weight by r.
	weightR(pirSinPi2r_, temp0_);
	TransR(FcosRE_, temp0_, inTemp_);
	// cos(p)cos(t)cos(r)
	for (auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		p.coef -= -inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;
		p.coef += -inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;
	}
	for (auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1;	
	}
}

void SphereBasisSet3D::weightVPFactor(double* ptr) {
	if (is_prolate_ || is_oblate_) { // this part shares.
	  for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	        double r = ((double)(k) + 0.5)*dR_; // [0-1]
	        ptr[i + j*nPhi_ + k*nPhiTheta_] *= c_*r*r*sqrtCR_[k]/h_[j + k*nTheta_]/h_[j + k*nTheta_];
	      }
	} else {
#ifdef USE_R_WEIGHT
#endif
	}
}

// This handles phi componenet of Phi^0, Phi^2, Phi^1, Phi^3
void SphereBasisSet3D::InverseTransformVP() {

#ifdef USE_R_WEIGHT
	const double RsinCoef = 1.0;
#else
	const double RsinCoef = 2.0;
#endif

	clearPointer(vpTemp_);
	clearPointer(temp0_);
	clearPointer(temp1_);
	int divd = !boundaryCnd_ ? 1 : 2;
	// Phi^0, Phi^2 -----------------------------------------------------------------------------------
	// cos(p)cos(t)(2sin(r))
	clearPointer(inTemp_);
	for (const auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double coefMinus = p.i2x2 == 4 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] -= -invi2*invi3*p.coef*RsinCoef*0.5;
		inTemp_[p.i3x2 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*invi3*p.coef*coefMinus*RsinCoef*0.5;
	}
	for (const auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 == 2 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*p.coef*RsinCoef*0.5;
		if (p.i2x2 > 0)
			inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*p.coef*coefMinus*RsinCoef*0.5;
	}
	
	TransR(IsinRE_, inTemp_, temp0_);

	clearPointer(inTemp_);
	// cos(p)cos(t)(rcos(r))
	for (const auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double coefMinus = p.i2x2 == 4 ? 1.0 : 0.5;	 // This part is tricky because the first wavenumber can go to zero.
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] -= -invi2*invi3*i1*p.coef*0.5;
		inTemp_[p.i3x2 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -invi2*invi3*i1*p.coef*coefMinus;
	}
	for (const auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 == 2 ? 1.0 : 0.5;	 // This part is tricky because the first wavenumber can go to zero.
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += invi2*i1*p.coef*0.5;
		if (p.i2x2 > 0)
			inTemp_[p.i3x2 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += invi2*i1*p.coef*coefMinus;	
	}
	
	TransR(IcosRE_, inTemp_, temp1_);
	// weight by r.
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, temp0_);

  Eigen::Map<Eigen::VectorXd> temp0V(temp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> temp1V(temp1_, totalSize_);
  Eigen::Map<Eigen::VectorXd> inV(inTemp_, totalSize_);
  // add together, now we have (rcosr + 2sin(r))
  temp0V += temp1V;

  TransT(IcosTE_, temp0_, temp0_);

  clearPointer(inTemp_);
  clearPointer(temp1_);
  // -1 + 2 = 1, -1 - 2 = -3.
  for (const auto& p : phiCoef_[8]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*invi3*p.coef*0.5;
		temp1_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += i1*invi2*invi3*p.coef*0.5;
		if (p.i2x2 == 2) {// 
			inTemp_[p.i3x2 + 0*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*invi3*p.coef*0.5;
			temp1_[p.i3x2 +  0*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += i1*invi2*invi3*p.coef*0.5;
		}
		if (p.i2x2 > 4) {
			inTemp_[p.i3x2 + (p.i2x2/2 - 3)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*invi3*p.coef*0.5;
			temp1_[p.i3x2 + (p.i2x2/2 -3)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -i1*invi2*invi3*p.coef*0.5;
		}
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, temp1_, temp1_);
  // weight by r.
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, inTemp_);

  temp1V += inV;
  TransT(IsinTE_, temp1_, temp1_);
  temp0V += temp1V;

  fftw_execute_r2r(IcosP_, temp0_, vpTemp_);

	// Phi^1, Phi^3 -------------------------------------------------------------------
  clearPointer(inTemp_);
  // sin(r)cos(t)sin(p)
  for (const auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double coefMinus = p.i2x2 == 4 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] -= invi2*invi3*p.coef*RsinCoef*0.5;
		inTemp_[p.i3x2 - 1 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*invi3*p.coef*coefMinus*RsinCoef*0.5;
	}
	for (const auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 == 2 ? 2.0 : 1.0;	 // This part is tricky because the first wavenumber can go to zero.
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*p.coef*RsinCoef*0.5;
		if (p.i2x2 > 0)
			inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*p.coef*coefMinus*RsinCoef*0.5;		
	}
	clearPointer(temp0_);
	
	TransR(IsinRE_, inTemp_, temp0_);

	clearPointer(inTemp_);
	// sin(p)cos(t)(rcos(r))
	for (const auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double coefMinus = p.i2x2 == 4 ? 1.0 : 0.5;	 // This part is tricky because the first wavenumber can go to zero.
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] -= invi2*invi3*i1*p.coef*0.5;
		inTemp_[p.i3x2 - 1 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += invi2*invi3*i1*p.coef*coefMinus;
	}
	for (const auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double coefMinus = p.i2x2 == 2 ? 1.0 : 0.5;	 // This part is tricky because the first wavenumber can go to zero.
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -invi2*i1*p.coef*0.5;
		if (p.i2x2 > 0)
			inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -invi2*i1*p.coef*coefMinus;	
	}

	clearPointer(temp1_);
	
	TransR(IcosRE_, inTemp_, temp1_);

	//weightByR(temp1_);
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, temp0_);

	// add together, now we have (rcosr + 2sin(r))
  temp0V += temp1V;

  TransT(IcosTE_, temp0_, temp0_);

  clearPointer(inTemp_);
  clearPointer(temp1_);
  // -1 + 2 = 1, -1 - 2 = -3.
  for (const auto& p : phiCoef_[9]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*invi3*p.coef*0.5;
		temp1_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -i1*invi2*invi3*p.coef*0.5;
		if (p.i2x2 == 2) {// 
			inTemp_[p.i3x2 - 1 + 0*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += -invi2*invi3*p.coef*0.5;
			temp1_[p.i3x2 - 1 +  0*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += -i1*invi2*invi3*p.coef*0.5;
		}
		if (p.i2x2 > 4) {
			inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 3)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_] += invi2*invi3*p.coef*0.5;
			temp1_[p.i3x2 - 1 + (p.i2x2/2 -3)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_] += i1*invi2*invi3*p.coef*0.5;
		}
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, temp1_, temp1_);
  // weight by r.
	weightR(pirSinPi2r_, temp1_);
	weightR(pir2Cos2Sin_, inTemp_);

  temp1V += inV;
  TransT(IsinTE_, temp1_, temp1_);
  temp0V += temp1V;

	fftw_execute_r2r(IsinP_, temp0_, temp0_);
	Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
	vpTempV += temp0V;
	weightVPFactor(vpTemp_);
}

void SphereBasisSet3D::ForwardTransformVP() {

#ifdef USE_R_WEIGHT
	const double RsinCoef = 1.0;
#else
	const double RsinCoef = 2.0;
#endif

	clearPointer(temp0_);
	clearPointer(inTemp_);
	int divd = !boundaryCnd_ ? 1 : 2;
	memcpy(temp1_, vpTemp_, sizeof(double)*totalSize_);
	// temp1_ holds the weighted results.
	weightVPFactor(temp1_);
	// Phi^0, Phi^2 -----------------------------------------------------------------------------------
	// cos(p)cos(t)(2sin(r))
	fftw_execute_r2r(FcosP_,temp1_, temp0_);

  clearPointer(inTemp_);
  clearPointer(temp2_);
	memcpy(temp2_, temp0_, sizeof(double)*totalSize_);
	TransT(FsinTE_, temp2_, temp2_);
	memcpy(inTemp_, temp2_, sizeof(double)*totalSize_);
	weightR(pir2Cos2Sin_, inTemp_);
	TransR(FsinRE_, inTemp_, inTemp_);

	for (auto& p : phiCoef_[8]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*0.5;
		if (p.i2x2 == 2) {// 
			p.coef += inTemp_[p.i3x2 + 0*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*0.5;
		}
		if (p.i2x2 > 4) {
			p.coef += -inTemp_[p.i3x2 + (p.i2x2/2 - 3)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*0.5;
		}
  }

  weightR(pirSinPi2r_, temp2_);
  TransR(FcosRE_, temp2_, temp2_);
  for (auto& p : phiCoef_[8]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		p.coef += temp2_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*invi3*0.5;
		if (p.i2x2 == 2) {// 
			p.coef += temp2_[p.i3x2 +  0*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*invi3*0.5;
		}
		if (p.i2x2 > 4) {
			p.coef += -temp2_[p.i3x2 + (p.i2x2/2 -3)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*invi3*0.5;
		}
  }

	clearPointer(inTemp_);
  TransT(FcosTE_, temp0_, temp0_);
  memcpy(inTemp_, temp0_, sizeof(double)*totalSize_);
  weightR(pir2Cos2Sin_, inTemp_);
	TransR(FsinRE_, inTemp_, inTemp_);
	
	for (auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		p.coef -= -inTemp_[p.i3x2 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*RsinCoef*0.5;
		p.coef += -inTemp_[p.i3x2 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*RsinCoef*0.5;
	}

	for (auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
		p.coef += inTemp_[p.i3x2 + abs(p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
	}
	
	clearPointer(inTemp_);
	// weight by r.
	weightR(pirSinPi2r_, temp0_);
	TransR(FcosRE_, temp0_, inTemp_);
	// cos(p)cos(t)(rcos(r))
	for (auto& p : phiCoef_[0]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		p.coef -= -inTemp_[p.i3x2 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*invi3*i1*0.5;
		p.coef += -inTemp_[p.i3x2 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*invi3*i1*0.5;
	}
	for (auto& p : phiCoef_[2]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		p.coef += inTemp_[p.i3x2 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;
		p.coef += inTemp_[p.i3x2 + abs(p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;	
	}

	// Phi^1, Phi^3 -------------------------------------------------------------------
  clearPointer(inTemp_);
  clearPointer(temp2_);
 	fftw_execute_r2r(FsinP_, temp1_, temp0_);

 	memcpy(temp2_, temp0_, sizeof(double)*totalSize_);
 	TransT(FsinTE_, temp2_, temp2_);
 	memcpy(inTemp_, temp2_, sizeof(double)*totalSize_);
 	weightR(pir2Cos2Sin_, inTemp_);
 	TransR(FsinRE_, inTemp_, inTemp_);
 	for (auto& p : phiCoef_[9]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*0.5;
		if (p.i2x2 == 2) {// 
			p.coef += -inTemp_[p.i3x2 - 1 + 0*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*0.5;
		}
		if (p.i2x2 > 4) {
			p.coef += inTemp_[p.i3x2 - 1 + (p.i2x2/2 - 3)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*0.5;
		}
  }
  weightR(pirSinPi2r_, temp2_);
  TransR(FcosRE_, temp2_, temp2_);
  for (auto& p : phiCoef_[9]) {
  	double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		p.coef += -temp2_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*invi3*0.5;
		if (p.i2x2 == 2) {// 
			p.coef += -temp2_[p.i3x2 - 1 +  0*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*invi3*0.5;
		}
		if (p.i2x2 > 4) {
			p.coef += temp2_[p.i3x2 - 1 + (p.i2x2/2 -3)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*i1*invi2*invi3*0.5;
		}
  }

  clearPointer(inTemp_);
  TransT(FcosTE_, temp0_, temp0_);
  memcpy(inTemp_, temp0_, sizeof(double)*totalSize_);
  weightR(pir2Cos2Sin_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);

  for (auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		p.coef -= inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*RsinCoef*0.5;
		p.coef += inTemp_[p.i3x2 - 1 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*invi3*RsinCoef*0.5;
	}
	for (auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;
		p.coef += -inTemp_[p.i3x2 - 1 + abs(p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd - 1)*nPhi_*nTheta_]*invi2*RsinCoef*0.5;		
	}

	clearPointer(inTemp_);
	weightR(pirSinPi2r_, temp0_);
	TransR(FcosRE_, temp0_, inTemp_);
	// sin(p)cos(t)(rcos(r))
	for (auto& p : phiCoef_[1]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double invi3 = p.i3x2 == 0 ? 1.0 : 2.0/p.i3x2;
		double i1 = p.i1x2*0.5;
		p.coef -= inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*invi3*i1*0.5;
		p.coef += inTemp_[p.i3x2 - 1 + abs(p.i2x2/2 - 2)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*invi3*i1*0.5;
	}

	for (auto& p : phiCoef_[3]) {
		double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
		double i1 = p.i1x2*0.5;
		p.coef += -inTemp_[p.i3x2 - 1 + (p.i2x2/2 + 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;
		p.coef += -inTemp_[p.i3x2 - 1 + abs(p.i2x2/2 - 1)*nPhi_ + (p.i1x2/divd)*nPhi_*nTheta_]*invi2*i1*0.5;	
	}
}

//#define TEST

void SphereBasisSet3D::InverseTransformToVelocity(Eigen::VectorXd& fieldCoef) {
	
	CHECK(fieldCoef.size() == all_basis_.size());
	// test code
#ifdef TEST	
	srand(time(NULL));
  fieldCoef = Eigen::VectorXd::Random(fieldCoef.size());
  double *ur, *ut, *up;
  ur = (double*) fftw_malloc(sizeof(double)*totalSize_);
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> urV(ur, totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  urV.setZero();
  utV.setZero();
  upV.setZero();
  computeUniformRTNumerical(fieldCoef, nR_, nTheta_, nPhi_, ur, ut,up); 
#endif

	collectPairedCoef(fieldCoef);
	InverseTransformVR();
	InverseTransformVT();
	InverseTransformVP();
	InverseTransformEnrich();
	//SphereBasis3D basis(2, 20, 2, 0);
	//basis.AddUniformU(1, nR_, nTheta_, nPhi_, vrTemp_, vtTemp_, vpTemp_);
#ifdef TEST	
	Eigen::Map<Eigen::VectorXd> vrTempV(vrTemp_, totalSize_);
	Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
	Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
	LOG(INFO) << "diff r " << (urV - vrTempV).norm() << " " << urV.norm() << " " << vrTempV.norm();
	LOG(INFO) << "diff t " << (utV - vtTempV).norm() << " " << utV.norm() << " " << vtTempV.norm();
	LOG(INFO) << "diff p " << (upV - vpTempV).norm() << " " << upV.norm() << " " << vpTempV.norm();
	//exit(0);
#endif
}

void SphereBasisSet3D::interpolateToCartesian(VECTOR3_FIELD_3D* field) {
	if (! is_prolate_ && ! is_oblate_)
		sphereToCartesian(field);
	else
		proOblateToCartesian(field);
}

void SphereBasisSet3D::weightJacobian(double* ur, double* ut, double* up) {
	if (is_prolate_) {
		for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	        double r = ((double)(k) + 0.5)*dR_;
	        double J = a_*b_*b_*h_[j + k*nTheta_]*h_[j + k*nTheta_]/sqrtCR_[k]*r*sinTVal_[j];
	        const int idx = i + j*nPhi_ + k*nPhi_*nTheta_;
	        ur[idx] *= J;
	        ut[idx] *= J;
	        up[idx] *= J;
	      }
	} else if (is_oblate_) {
		for (int k = 0; k < nR_; k++)
	    for (int j = 0; j < nTheta_; j++)
	      for (int i = 0; i < nPhi_; i++) {
	        double r = ((double)(k) + 0.5)*dR_;
	        double J = a_*a_*b_*h_[j + k*nTheta_]*h_[j + k*nTheta_]*sinTVal_[j];
	        const int idx = i + j*nPhi_ + k*nPhi_*nTheta_;
	        ur[idx] *= J;
	        ut[idx] *= J;
	        up[idx] *= J;
	      }
	} else {
		weightR2SinT(ur);
	  weightR2SinT(ut);
	  weightR2SinT(up);
	}
}
//#define TEST
// Input a vector field, transform and output the basis coefficients.
void SphereBasisSet3D::ForwardTransformtoFrequency(
    const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) {

	if (! is_oblate_ && ! is_prolate_)	
		interpolateToSphere(field);
	else
		CartesianToProOblate(field);

	Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
	clearPairCoef();

	// test code
#ifdef TEST
	srand(time(NULL));
  double *ur, *ut, *up;
  ur = (double*) fftw_malloc(sizeof(double)*totalSize_);
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> urV(ur, totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  urV.setZero();
  utV.setZero();
  upV.setZero();

  srand((unsigned int) (time(0)));
  Eigen::VectorXd basisCoef1 = Eigen::VectorXd::Random(all_basis_.size());
  computeUniformRTNumerical(basisCoef1, nR_, nTheta_, nPhi_, ur, ut,up); 
  memcpy(vrTemp_, ur, sizeof(double)*totalSize_);
  memcpy(vtTemp_, ut, sizeof(double)*totalSize_);
  memcpy(vpTemp_, up, sizeof(double)*totalSize_);
  weightJacobian(ur, ut, up);

#endif
	weightJacobian(vrTemp_, vtTemp_, vpTemp_);

  ForwardTransformVR();
  ForwardTransformVT();
  ForwardTransformVP();
  ForwardTransformEnrich();
  assignPairCoef(fieldCoef);

#ifdef TEST
  Eigen::VectorXd projCoef = Eigen::VectorXd::Zero(all_basis_.size());
  projectUniformRTNumerical(nR_, nTheta_, nPhi_, ur,ut,up, projCoef);
  LOG(INFO) << "diff: " << (projCoef - fieldCoef).norm() << " " << projCoef.norm() << " " << fieldCoef.norm();
  //exit(0);
#endif

  *coefficients = A_*fieldCoef;
}

// xRes, yRes, zRes lines up with (nphi, ntheta, nr)
void SphereBasisSet3D::ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) {
  CHECK(df.xRes() == nPhi_);
  CHECK(df.yRes() == nTheta_);
  CHECK(df.zRes() == nR_);

  for (int i = 0; i < totalSize_; i++) {
    vrTemp_[i] = df[i][0];
    vtTemp_[i] = df[i][1];
    vpTemp_[i] = df[i][2];
  }

	Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
	clearPairCoef();

	weightJacobian(vrTemp_, vtTemp_, vpTemp_);

  ForwardTransformVR();
  ForwardTransformVT();
  ForwardTransformVP();
  ForwardTransformEnrich();
  assignPairCoef(fieldCoef);

  *coefficients = A_*fieldCoef;
}

void SphereBasisSet3D::initCartesian() {
	for (int k = 0; k < zRes_; k++)
		for (int j = 0; j < yRes_; j++)
		  for (int i = 0; i < xRes_; i++) {
		  	
		  	Eigen::Vector3d cat; // [-1,1]^3
		    cat << ((double)(i) + 0.5)*2*dx_ - 1.,
		           ((double)(j) + 0.5)*2*dx_ - 1.,
		           ((double)(k) + 0.5)*2*dx_ - 1.;
		    Eigen::Vector3d sph;
		    if (! is_prolate_ && ! is_oblate_)
		    	sph = Transform::Spherical::toSpherical(cat);
		    else if (is_prolate_)
		    	Transform::Spheroid::CatersianToProlate(a_, c_, cat, sph[0], sph[1], sph[2]);
		    else if (is_oblate_)
					Transform::Spheroid::CatersianToOblate(a_, c_, cat, sph[0], sph[1], sph[2]);

		    const int idx = i + j*xRes_ + k*xRes_*yRes_;
		    rCat_[idx] = sph[0];
		    tCat_[idx] = sph[1];
		    pCat_[idx] = sph[2];
			}
}

#define interPol(arg_)\
wr0*(wp0 * (wt0 * arg_[i000] + wt1 * arg_[i010]) +\
     wp1 * (wt0 * arg_[i100] + wt1 * arg_[i110]))+\
wr1*(wp0 * (wt0 * arg_[i001] + wt1 * arg_[i011]) +\
     wp1 * (wt0 * arg_[i101] + wt1 * arg_[i111]))
// i000 i100 --> ur0
// i001 i101 --> ur1
#define interPolPole(arg_, v0, v1)\
wr0*(wp0 * (wt0 * v0 + wt1 * arg_[i010]) +\
     wp1 * (wt0 * v0 + wt1 * arg_[i110]))+\
wr1*(wp0 * (wt0 * v1 + wt1 * arg_[i011]) +\
     wp1 * (wt0 * v1 + wt1 * arg_[i111]))
// i000 i010 i100 i110 -> one point.
#define interPolCenter(arg_, vc)\
wr0*vc +\
wr1*(wp0 * (wt0 * arg_[i001] + wt1 * arg_[i011]) +\
     wp1 * (wt0 * arg_[i101] + wt1 * arg_[i111]))

#define CLAMPR(rv) \
rv = (rv < 0) ? 0 : rv;\
rv = (rv > nR_ - 1) ? nR_ - 1 : rv;

#define CLAMPT(tv) \
tv = (tv < 0) ? 0 : tv;\
tv = (tv > nTheta_ - 1) ? nTheta_ - 1 : tv;

#define CLAMPP(pv) \
pv = (pv < 0) ? nPhi_ + pv : pv;\
pv = (pv > nPhi_ - 1) ? pv - nPhi_ : pv;

void SphereBasisSet3D::sphereToCartesian(VECTOR3_FIELD_3D* field) {
	CHECK(field->xRes() == xRes_ && field->yRes() == yRes_ && field->zRes() == zRes_);
	
	#pragma omp parallel for
	for (int k = 0; k < zRes_; k++)
		for (int j = 0; j < yRes_; j++)
		  for (int i = 0; i < xRes_; i++) {
		  	
				Eigen::Vector3d uSph(0,0,0);
				Eigen::Vector3d uCat(0,0,0);

		  	const int cidx = i + j*xRes_ + k*xRes_*yRes_;
		    const double r = rCat_[cidx]; // [0, 1]
		    if (r > 1.0)  // velocity is zero
		    	continue;
		    const double t = tCat_[cidx]; // [0, pi]
		    const double p = pCat_[cidx]; // [0, 2pi]

		    int r0 = (int)(r/dR_);
		    int r1 = r0 + 1;
		    int t0 = (int)(t/dTheta_);
		    int t1 = t0 + 1;
		    int p0 = (int)(p/dPhi_);
		    int p1 = p0 + 1;
		    
		    CLAMPR(r0);
		    CLAMPR(r1);
		    CLAMPT(t0);
		    CLAMPT(t1);
		    CLAMPP(p0);
		    CLAMPP(p1);

		    // get interpolation weights
			  const double wp1 = p/dPhi_ - p0;
			  const double wp0 = 1.0 - wp1;
			  const double wt1 = t/dTheta_ - t0;
			  const double wt0 = 1.0 - wt1;
			  const double wr1 = r/dR_ - r0;
			  const double wr0 = 1.0 - wr1;
		  	const int i000 = p0 + t0 * nPhi_ + r0 * nPhiTheta_;
				const int i010 = p0 + t1 * nPhi_ + r0 * nPhiTheta_;
				const int i100 = p1 + t0 * nPhi_ + r0 * nPhiTheta_;
				const int i110 = p1 + t1 * nPhi_ + r0 * nPhiTheta_;
				const int i001 = p0 + t0 * nPhi_ + r1 * nPhiTheta_;
			  const int i011 = p0 + t1 * nPhi_ + r1 * nPhiTheta_;
			  const int i101 = p1 + t0 * nPhi_ + r1 * nPhiTheta_;
			  const int i111 = p1 + t1 * nPhi_ + r1 * nPhiTheta_;
				
			  // out of pole line
			  if (t > dTheta_ && t < M_PI - dTheta_ && r > dR_) {
				  uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
			  } else if (r > dR_) {   // average along theta.
			  	// south or north pole
			    int thetaIdx = 0;
			    double wt1 = t/dTheta_;
			    if (t >= M_PI - dTheta_) { // south pole
			      thetaIdx = nTheta_ - 1;
			      wt1 = (M_PI - t)/dTheta_;
    			}
    			const double wt0 = 1.0 - wt1;

    			// compute the velocity at pole.
			   	Eigen::Vector3d ur0(0,0,0); Eigen::Vector3d ur1(0,0,0);
			    for (int pidx = 0; pidx < nPhi_; pidx ++) {
			    	const int idx0 = pidx + thetaIdx*nPhi_ + r0*nPhiTheta_;
			    	const int idx1 = pidx + thetaIdx*nPhi_ + r1*nPhiTheta_;
			    	ur0[0] += vrTemp_[idx0]; ur0[1] += vtTemp_[idx0]; ur0[2] += vpTemp_[idx0];
			    	ur1[0] += vrTemp_[idx1]; ur1[1] += vtTemp_[idx1]; ur1[2] += vpTemp_[idx1];
			    }
			    ur0 /= (double)nPhi_;
			    ur1 /= (double)nPhi_;
			    uSph << interPolPole(vrTemp_, ur0[0], ur1[0]),
			    				interPolPole(vtTemp_, ur0[1], ur1[1]),
			    				interPolPole(vpTemp_, ur0[2], ur1[2]);

			  } else {			// averaging in the center.
			  	// i000 i010 i100 i110 -> one point.
			  	Eigen::Vector3d uc(0,0,0);
			  	for (int tidx = 0; tidx < nTheta_; tidx++)
			  		for (int pidx = 0; pidx < nPhi_; pidx++) {
			  			const int idx = pidx + tidx*nPhi_ + r0*nPhiTheta_;
			  			uc[0] += vrTemp_[idx]; uc[1] += vtTemp_[idx]; uc[2] += vpTemp_[idx];
			  		}
			  		uc /= (double)(nPhiTheta_);

			  		uSph << interPolCenter(vrTemp_, uc[0]),
			  						interPolCenter(vtTemp_, uc[1]),
			  						interPolCenter(vpTemp_, uc[2]);
			  }
			  Eigen::Matrix3d transMat;
			  Transform::Spherical::toCartesianMat(t, p, transMat);
			  // toCartesian
			  uCat = transMat*uSph;
			  (*field)[cidx][0] = uCat[0];
				(*field)[cidx][1] = uCat[1];
				(*field)[cidx][2] = uCat[2];
		  }
}

void SphereBasisSet3D::proOblateToCartesian(VECTOR3_FIELD_3D* field) {
	CHECK(field->xRes() == xRes_ && field->yRes() == yRes_ && field->zRes() == zRes_);
	
	#pragma omp parallel for
	for (int k = 0; k < zRes_; k++)
		for (int j = 0; j < yRes_; j++)
		  for (int i = 0; i < xRes_; i++) {
		  	
				Eigen::Vector3d uSph(0,0,0);
				Eigen::Vector3d uCat(0,0,0);

		  	const int cidx = i + j*xRes_ + k*xRes_*yRes_;
		    const double r = rCat_[cidx]; // [0, 1]
		    if (r > 1.0)  // velocity is zero
		    	continue;
		    const double t = tCat_[cidx]; // [0, pi]
		    const double p = pCat_[cidx]; // [0, 2pi]

		    int r0 = (int)(r/dR_);
		    int r1 = r0 + 1;
		    int t0 = (int)(t/dTheta_);
		    int t1 = t0 + 1;
		    int p0 = (int)(p/dPhi_);
		    int p1 = p0 + 1;
		    
		    CLAMPR(r0);
		    CLAMPR(r1);
		    CLAMPT(t0);
		    CLAMPT(t1);
		    CLAMPP(p0);
		    CLAMPP(p1);

		    // get interpolation weights
			  const double wp1 = p/dPhi_ - p0;
			  const double wp0 = 1.0 - wp1;
			  const double wt1 = t/dTheta_ - t0;
			  const double wt0 = 1.0 - wt1;
			  const double wr1 = r/dR_ - r0;
			  const double wr0 = 1.0 - wr1;
		  	const int i000 = p0 + t0 * nPhi_ + r0 * nPhiTheta_;
				const int i010 = p0 + t1 * nPhi_ + r0 * nPhiTheta_;
				const int i100 = p1 + t0 * nPhi_ + r0 * nPhiTheta_;
				const int i110 = p1 + t1 * nPhi_ + r0 * nPhiTheta_;
				const int i001 = p0 + t0 * nPhi_ + r1 * nPhiTheta_;
			  const int i011 = p0 + t1 * nPhi_ + r1 * nPhiTheta_;
			  const int i101 = p1 + t0 * nPhi_ + r1 * nPhiTheta_;
			  const int i111 = p1 + t1 * nPhi_ + r1 * nPhiTheta_;
				
			  // out of pole line
			  if (t > dTheta_ && t < M_PI - dTheta_ ) {
				  uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
			  } else {   // average along phi.
			  	// south or north pole
			    int thetaIdx = 0;
			    double wt1 = t/dTheta_;
			    if (t >= M_PI - dTheta_) { // south pole
			      thetaIdx = nTheta_ - 1;
			      wt1 = (M_PI - t)/dTheta_;
    			}
    			const double wt0 = 1.0 - wt1;

    			// compute the velocity at pole.
			   	Eigen::Vector3d ur0(0,0,0); Eigen::Vector3d ur1(0,0,0);
			    for (int pidx = 0; pidx < nPhi_; pidx ++) {
			    	const int idx0 = pidx + thetaIdx*nPhi_ + r0*nPhiTheta_;
			    	const int idx1 = pidx + thetaIdx*nPhi_ + r1*nPhiTheta_;
			    	ur0[0] += vrTemp_[idx0]; ur0[1] += vtTemp_[idx0]; ur0[2] += vpTemp_[idx0];
			    	ur1[0] += vrTemp_[idx1]; ur1[1] += vtTemp_[idx1]; ur1[2] += vpTemp_[idx1];
			    }
			    ur0 /= (double)nPhi_;
			    ur1 /= (double)nPhi_;
			    uSph << interPolPole(vrTemp_, ur0[0], ur1[0]),
			    				interPolPole(vtTemp_, ur0[1], ur1[1]),
			    				interPolPole(vpTemp_, ur0[2], ur1[2]);

			  }
			  Eigen::Matrix3d transMat;
			  if (is_prolate_)
			  	Transform::Spheroid::toCartesianMatProlate(r, t, p, c_, transMat);
			  else if (is_oblate_)
			  	Transform::Spheroid::toCartesianMatOblate(r, t, p, c_, transMat);

			  // toCartesian
			  uCat = transMat*uSph;
			  (*field)[cidx][0] = uCat[0];
				(*field)[cidx][1] = uCat[1];
				(*field)[cidx][2] = uCat[2];
		  }	
}

void SphereBasisSet3D::interpolateToSphere(const VECTOR3_FIELD_3D& field) {
	clearPointer(vrTemp_);
	clearPointer(vtTemp_);
	clearPointer(vpTemp_);

	#pragma omp parallel for
	for (int k = 0; k < nR_; k++)
		for (int j = 0; j < nTheta_; j++)
			for (int i = 0; i < nPhi_; i++) {
				int index = i + j*nPhi_ + k*nPhiTheta_;
				Eigen::Vector3d sph;
				sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dPhi_;
				Eigen::Vector3d cat = Transform::Spherical::toCartesian(sph); // [-1,1]^3
				cat += Eigen::Vector3d(1.0,1.0,1.0);
				cat *= 0.5; // [0,1]^3

				Eigen::Matrix3d transMat;
			  Transform::Spherical::toCartesianMat(sph[1], sph[2], transMat);
			  VEC3 vcat = field.GetVelocity(cat[0]*xRes_, cat[1]*yRes_, cat[2]*zRes_);
			  Eigen::Vector3d uCat(vcat[0], vcat[1], vcat[2]);
			  Eigen::Vector3d uSph = transMat.transpose()*uCat;
			  vrTemp_[index] = uSph[0];
			  vtTemp_[index] = uSph[1];
			  vpTemp_[index] = uSph[2];
			}
}

void SphereBasisSet3D::CartesianToProOblate(const VECTOR3_FIELD_3D& field) {
	if (is_prolate_) {
		CartesianToProlate(field);
	} else {
		CartesianToOblate(field);
	}
	return;
}

void SphereBasisSet3D::CartesianToProlate(const VECTOR3_FIELD_3D& field) {
	clearPointer(vrTemp_);
	clearPointer(vtTemp_);
	clearPointer(vpTemp_);
	
	#pragma omp parallel for
	for (int k = 0; k < nR_; k++)
		for (int j = 0; j < nTheta_; j++)
			for (int i = 0; i < nPhi_; i++) {
				int index = i + j*nPhi_ + k*nPhiTheta_;
				Eigen::Vector3d sph;
				sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dPhi_;
				Eigen::Vector3d cat;
				Transform::Spheroid::ProlateToCatersian(a_, c_, sph, cat); // [-1,1]^3
				cat += Eigen::Vector3d(1.0,1.0,1.0);
				cat *= 0.5; // [0,1]^3

				Eigen::Matrix3d transMat;
			  Transform::Spheroid::toCartesianMatProlate(sph[0], sph[1], sph[2], c_, transMat);
			  VEC3 vcat = field.GetVelocity(cat[0]*xRes_, cat[1]*yRes_, cat[2]*zRes_);
			  Eigen::Vector3d uCat(vcat[0], vcat[1], vcat[2]);
			  Eigen::Vector3d uSph = transMat.transpose()*uCat;
			  vrTemp_[index] = uSph[0];
			  vtTemp_[index] = uSph[1];
			  vpTemp_[index] = uSph[2];
			}
}
 
void SphereBasisSet3D::CartesianToOblate(const VECTOR3_FIELD_3D& field) {
	clearPointer(vrTemp_);
	clearPointer(vtTemp_);
	clearPointer(vpTemp_);

	#pragma omp parallel for
	for (int k = 0; k < nR_; k++)
		for (int j = 0; j < nTheta_; j++)
			for (int i = 0; i < nPhi_; i++) {
				int index = i + j*nPhi_ + k*nPhiTheta_;
				Eigen::Vector3d sph;
				sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dPhi_;
				Eigen::Vector3d cat;
				Transform::Spheroid::OblateToCatersian(a_, c_, sph, cat); // [-1,1]^3
				cat += Eigen::Vector3d(1.0,1.0,1.0);
				cat *= 0.5; // [0,1]^3

				Eigen::Matrix3d transMat;
			  Transform::Spheroid::toCartesianMatOblate(sph[0], sph[1], sph[2], c_, transMat);
			  VEC3 vcat = field.GetVelocity(cat[0]*xRes_, cat[1]*yRes_, cat[2]*zRes_);
			  Eigen::Vector3d uCat(vcat[0], vcat[1], vcat[2]);
			  Eigen::Vector3d uSph = transMat.transpose()*uCat;
			  vrTemp_[index] = uSph[0];
			  vtTemp_[index] = uSph[1];
			  vpTemp_[index] = uSph[2];
			}
}

#include "tensorCompute/sph3DSRTensor.h"

void SphereBasisSet3D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {

	sph3DSRTensor tensorEvalR;

	CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;

#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    // compute half
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {
        //
        const SphereBasis3D& basis_i = *all_basis_[i];
        const SphereBasis3D& basis_g = *all_basis_[g];
        const SphereBasis3D& basis_h = *all_basis_[h];
        double Cigh = 0;
#ifdef FAST_TENSOR
				const double invWnProd = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
				const int idx = basis_i.index()*100 + basis_g.index()*10 + basis_h.index();
				Cigh = tensorEvalR.pointers_[idx](basis_i, basis_g, basis_h)*invWnProd;
#else
        Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);
#endif
        //double Cigh = SphereBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
        CHECK(std::isfinite(Cigh));

        if (abs(Cigh) <1e-12) {
          continue;
        }

        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  //BasisSet::VerifyAntisymmetric(*Adv_tensor);
  //exit(0);
}

void SphereBasisSet3D::FillTensorProOblate(std::vector<Adv_Tensor_Type> *Adv_tensor, const int iStart, const int iEnd) {
	sph3DSRTensor tensorEvalR;

	CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  CHECK(iStart < iEnd && iEnd <= numBasisAll_);

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  
#pragma omp parallel for
  for (int i = iStart; i < iEnd; i++) {
  	if (i % 10 == 0)
  		LOG(INFO) << i;
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    // compute half
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {

        double Cigh = 0;
        if (! is_prolate_ && ! is_oblate_) {
        	const SphereBasis3D& basis_i = *all_basis_[i];
	        const SphereBasis3D& basis_g = *all_basis_[g];
	        const SphereBasis3D& basis_h = *all_basis_[h];

					const double invWnProd = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
					const int idx = basis_i.index()*100 + basis_g.index()*10 + basis_h.index();
					Cigh = tensorEvalR.pointers_[idx](basis_i, basis_g, basis_h)*invWnProd;

        } else {
        
	        Cigh = static_pointer_cast<ProlateOblate3D>(all_basis_[i])->
	           computeTensorEntry(*static_pointer_cast<ProlateOblate3D>(all_basis_[g]), 
	                              *static_pointer_cast<ProlateOblate3D>(all_basis_[h]), *tensorData_);
        }

        CHECK(std::isfinite(Cigh));

        if (abs(Cigh) <1e-12) {
          continue;
        }

        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
}

void SphereBasisSet3D::computeLaplacianMatrix(Adv_Tensor_Type& sparseD_) {
	SphereBasis3DLap eval;
	sparseD_.resize(numBasisAll_, numBasisAll_);
	double Dij = 0;
	typedef Eigen::Triplet<double> T;
	
	std::vector<std::vector<T>> colList;
	colList.resize(numBasisAll_);

	#pragma omp parallel for
	for (int i = 0; i < numBasisAll_; i++)
		for (int j = 0; j < numBasisAll_; j++) {
      const SphereBasis3D& basis_i = *all_basis_[i];
	    const SphereBasis3D& basis_j = *all_basis_[j];
	    const double invWnProd = basis_i.getInvWaveN()*basis_j.getInvWaveN();
			const int idx = basis_i.index()*10 + basis_j.index();
			Dij = eval.pointers_[idx](basis_i, basis_j)*invWnProd*basis_i.GetInvNorm()*basis_j.GetInvNorm();
			if (abs(Dij) <1e-12) {
        continue;
      }

			CHECK(std::isfinite(Dij));
			colList[i].push_back(T(i,j, Dij));
		}

	std::vector<T> allList;
	for (int i = 0; i < numBasisAll_; i++)
		allList.insert(allList.end(), colList[i].begin(), colList[i].end());

	sparseD_.setFromTriplets(allList.begin(), allList.end());
	sparseD_.makeCompressed();

	//Eigen::SelfAdjointEigenSolver<Adv_Tensor_Type> es;
	//es.compute(sparseD_);
	//LOG(INFO) << es.eigenvalues().transpose();
	//exit(0);
}

void SphereBasisSet3D::outputTestTensorEntries(const int numWant, const string& fname,
        std::vector<Adv_Tensor_Type> *Adv_tensor) {

  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  vector<Eigen::Vector3i> indices;

  for (int i = 0; i < numBasisAll_; i++) {
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const SphereBasis3D& basis_i = *all_basis_[i];
        const SphereBasis3D& basis_g = *all_basis_[g];
        const SphereBasis3D& basis_h = *all_basis_[h];

        double Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);
        CHECK(std::isfinite(Cigh));

        if (abs(Cigh) < 1e-12) {
          continue;
        }

        indices.push_back(Eigen::Vector3i(i,g,h));
        tripletList.push_back(T(g,h, Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  BasisSet::VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    basisPtr3D basis_i = all_basis_[indices[i][0]];
    basisPtr3D basis_g = all_basis_[indices[i][1]];
    basisPtr3D basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " << basis_i->WN3x2() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " << basis_g->WN3x2() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " << basis_h->WN3x2() << " " <<
           std::setprecision(12) << basis_i->GetInvNorm() << " " << basis_g->GetInvNorm()
           << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}


double SphereBasisSet3D::tensorEntryCast(const basisPtr3D basis_i, const basisPtr3D basis_g, const basisPtr3D basis_h) {
  if (! is_prolate_ && ! is_oblate_)
    return SphereBasis3D::computeTensorEntry(*basis_i, *basis_g, *basis_h);
  else
    return static_pointer_cast<ProlateOblate3D>(basis_i)->
           computeTensorEntry(*static_pointer_cast<ProlateOblate3D>(basis_g), 
                              *static_pointer_cast<ProlateOblate3D>(basis_h), *tensorData_);
}

void SphereBasisSet3D::readFromFile(std::ifstream& in) {

	in.read(reinterpret_cast<char*>(&boundaryCnd_), sizeof(bool));
	in.read(reinterpret_cast<char*>(&rK_), sizeof(int));
	in.read(reinterpret_cast<char*>(&thetaK_), sizeof(int));
	in.read(reinterpret_cast<char*>(&phiK_), sizeof(int));
	in.read(reinterpret_cast<char*>(&numBasisAll_), sizeof(int));
	in.read(reinterpret_cast<char*>(&numBasisOrtho_), sizeof(int));
	in.read(reinterpret_cast<char *>(&is_prolate_), sizeof(bool));
  in.read(reinterpret_cast<char *>(&is_oblate_), sizeof(bool));
  in.read(reinterpret_cast<char *>(&a_), sizeof(double));
  in.read(reinterpret_cast<char *>(&b_), sizeof(double));
  in.read(reinterpret_cast<char *>(&c_), sizeof(double));

	CHECK(!(is_oblate_ && is_prolate_));
	LOG(INFO) << numBasisAll_;
  phiCoef_.resize(10);
  int modeSizes[8];
  in.read(reinterpret_cast<char*>(modeSizes), sizeof(int)*8);
  if (is_oblate_ || is_prolate_)
  	setUpTable();

  if (! is_oblate_ && ! is_prolate_) {
	  for (int i = 0; i < numBasisAll_; i++) {
			all_basis_.push_back(basisPtr3D(SphereBasis3D::fromFile(in)));
		}
	} else {  // prolate or oblate
		for (int i = 0; i < numBasisAll_; i++) {
			all_basis_.push_back(basisPtr3D(ProlateOblate3D::fromFile(in, is_prolate_, *dotData_)));
		}
	}
	initPhiCoef();

	readEigenDense_binary(in, H_);
  readEigenDense_binary(in, A_);
  // tensor is read elsewhere.
}

void SphereBasisSet3D::writeToFile(std::ofstream& out, const vector<Adv_Tensor_Type>& Adv_tensor_) const {

	out.write(reinterpret_cast<const char *>(&boundaryCnd_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&rK_), sizeof(int));
	out.write(reinterpret_cast<const char *>(&thetaK_), sizeof(int));
	out.write(reinterpret_cast<const char *>(&phiK_), sizeof(int));
	out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
	out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));
	out.write(reinterpret_cast<const char *>(&is_prolate_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&is_oblate_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&a_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&b_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&c_), sizeof(double));

	// write the size of each modes.
	int modeSizes[8];
	for (int i = 0; i < 8; i++)
		modeSizes[i] = phiCoef_[i].size();
	out.write(reinterpret_cast<const char *>(modeSizes), sizeof(int)*8);

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }

  writeEigenDense_binary(out, H_);
  writeEigenDense_binary(out, A_);
  int tensorType = (int)(boundaryCnd_);
  WriteTensor(Adv_tensor_, tensorType, out);
}

double SphereBasisSet3D::dotProdCast(const basisPtr3D a, const basisPtr3D b) const {
  if (! is_prolate_ && ! is_oblate_)
    return a->dotProd(*b)*a->GetInvNorm()*b->GetInvNorm();
  else
    return static_pointer_cast<ProlateOblate3D>(a)->dotProd(*static_pointer_cast<ProlateOblate3D>(b), *dotData_)*
            a->GetInvNorm()*b->GetInvNorm();
}

#define dotProdMarco(arg, i,j) dotProdCast(arg[i], arg[j])
// Run MGS on a set of basis functions stored in in, and orthogonalize them. The kept basis
// is stored in out. The basis functions with distinct part smalelr than thresh of existing basis
// are thrown away. Coef are a matrix which kepts the coefficients of MGS. m is the number of
// basis functions that are kept.
void SphereBasisSet3D::runMGS(const double thresh, const vector<basisPtr3D>& in, vector<basisPtr3D>& out,
            Eigen::MatrixXd& Coef, int& m) {
  out.clear();
  // inner product matrix of all basis.
  Eigen::MatrixXd H = Eigen::MatrixXd::Zero(in.size(), in.size());
  // temp buffer.
  Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(in.size(), in.size());
  // Coefficients matrix.
  Coef = Eigen::MatrixXd::Zero(in.size(), in.size());
  // map from row/col index of H matrix to basis index
  Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(in.size());
  Coef(0,0) = 1.0; 
  H(0,0) = dotProdMarco(in, 0,0);
  HC.col(0) = H*Coef.row(0).transpose();
  idxMap[0] = 0;
  // The first one.
  out.push_back(in[0]);
  // size of the final allocated basis.
  m = 1;

  for(int i = 1; i < in.size(); i++) {
    Coef(m,m) = 1.0;
    H(m,m) = dotProdMarco(in, i,i);
    for (int j = 0; j < m; j++)
      H(j,m) = H(m,j) = dotProdMarco(in, i,idxMap[j]);
    for (int j = 0; j < m; j++) {
      HC(m,j) = H.row(m)*Coef.row(j).transpose();
    }

    for (int j = 0; j < m; j++) {
      double dotProd = Coef.row(m)*HC.col(j);
      Coef.row(m) -= dotProd*Coef.row(j);
    }

    // compute norm.
    HC.col(m) = H*Coef.row(m).transpose();
    double norm2 = Coef.row(m)*HC.col(m);

    if (norm2 > thresh) {
      idxMap[m] = i;
      Coef.row(m) /= sqrt(norm2);
      HC.col(m) /= sqrt(norm2);
      m++;
      out.push_back(in[i]);
    }
    else {
      LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";
    }
  }
  CHECK(m <= in.size());
  CHECK(m == out.size());
  // test
  // Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  // for (int i = 0; i < reduced.rows(); i++) {
  //   reduced(i,i) -= 1.0;
  // }
  // LOG(INFO) << reduced.norm();
}

// set up query table for inner products etc.
void SphereBasisSet3D::setUpTable() {
	const string folder = "./Tensor/tables/prolate3D/";
	if (is_prolate_) {
	  dotTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
	                                        folder + "prolate3D_dot_1D_val.bin",
	                                        folder + "prolate3D_dot_1D.txt"));
	  dotTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "blistTableName.txt", 
	                                              folder + "prolate3D_dot_2D.txt", false));
		dotData_.reset(new IntTable1DData(b_));
		dotData_->setIntTable(dotTable1D_);
		dotData_->set2DTable(dotTable2D_);

		tensorTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
	                                        folder + "prolate3D_tensor_1D_val.bin",
	                                        folder + "prolate3D_tensor_1D.txt"));
		tensorTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "pro3DTensorName.txt", 
	                                              folder + "prolate_tensor_2D.txt", false));
		tensorData_.reset(new IntTable1DData(b_));
		tensorData_->setIntTable(tensorTable1D_);
		tensorData_->set2DTable(tensorTable2D_);

	} else if (is_oblate_) {
	  dotTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                        folder + "oblate3D_dot_1D_val.bin",
                                        folder + "oblate3D_dot_1D.txt"));
	  dotTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "blistTableOb.txt", 
                                              folder + "oblate3D_dot_2D.txt", false));
		dotData_.reset(new IntTable1DData(b_));
		dotData_->setIntTable(dotTable1D_);
		dotData_->set2DTable(dotTable2D_);

		tensorTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
	                                        folder + "oblate3D_tensor_1D_val.bin",
	                                        folder + "oblate3D_tensor_1D.txt"));
		tensorTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "ob3DTensorName.txt", 
	                                              folder + "oblate_tensor_2D.txt", false));
		tensorData_.reset(new IntTable1DData(b_));
		tensorData_->setIntTable(tensorTable1D_);
		tensorData_->set2DTable(tensorTable2D_);
	}
}

// compute the ur, ut on a uniform r, t grid, test only.
void SphereBasisSet3D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta,
			 const int nPhi, double* ur, double* ut, double* up) {
  memset(ur, 0x00, sizeof(double)*nTheta*nR*nPhi);
  memset(ut, 0x00, sizeof(double)*nTheta*nR*nPhi);
	memset(up, 0x00, sizeof(double)*nTheta*nR*nPhi);

  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    if (! is_prolate_ && ! is_oblate_) {
      all_basis_[i]->AddUniformU(fullCoef[i], nR, nTheta, nPhi, ur, ut, up);
    } else {
      static_pointer_cast<ProlateOblate3D>(all_basis_[i])->AddUniformU(fullCoef[i], nR, nTheta, nPhi, ur, ut, up);
    }
  }
}

void SphereBasisSet3D::projectUniformRTNumerical(const int nR, const int nTheta, const int nPhi, double* fr,
																					 double* ft, double* fp, Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    if (! is_prolate_ && ! is_oblate_)
      fullCoef[i] = all_basis_[i]->ProjectUniformU(nR, nTheta, nPhi, fr, ft, fp);
    else
      fullCoef[i] = static_pointer_cast<ProlateOblate3D>(all_basis_[i])->ProjectUniformU(nR, nTheta, nPhi, fr, ft, fp);
  }
}

void SphereBasisSet3D::ReSeedParticles(vector<ParticleSph3D>& particles, vector<Eigen::Vector3d>& initPos) {
	  // Reseed the particles at random position.
  uniform_real_distribution<double> u(0., 1.);
  for (int i = 0; i < particles.size(); i++) {
    Eigen::Vector3d pos = sampleOnSphere(m_gen_);
    pos *= pow(u(m_gen_), 1/3.0);
  if (! is_prolate_ && ! is_oblate_) {
    particles[i].position[0] = pos[0];
    particles[i].position[1] = pos[1];
    particles[i].position[2] = pos[2];
  } else if (is_prolate_) {
    particles[i].position[0] = pos[0]*b_;
    particles[i].position[1] = pos[1]*b_;
    particles[i].position[2] = pos[2];
  } else {
    particles[i].position[0] = pos[0];
    particles[i].position[1] = pos[1];
    particles[i].position[2] = pos[2]*b_;
  }

    particles[i].velocity.setZero();
    initPos[i] = particles[i].position;
  }
}

void SphereBasisSet3D::projBackParticles(const vector<Eigen::Vector3d>& initPos, vector<ParticleSph3D>& particles) {
  for (int i = 0; i < particles.size(); i++) {
    double dist = 0;
    const Eigen::Vector3d& p = particles[i].position;
    if (! is_prolate_ && ! is_oblate_)
      dist = p.norm();
    else if (is_prolate_)
      dist = (p[0]*p[0] + p[1]*p[1])/b_/b_ + p[2]*p[2];
    else
      dist = p[0]*p[0] + p[1]*p[1] + p[2]*p[2]/b_/b_;

    if (dist > 0.99) {
      particles[i].position = initPos[i];
      particles[i].velocity.setZero();
    }
  }
}

VEC3 SphereBasisSet3D::getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) {
  // (-1. 1) to (0, 1)
  VEC3 nPos = (p + VEC3(1,1,1))*0.5;
  return velocity.GetVelocity(nPos[0]*xRes_, nPos[1]*yRes_, nPos[2]*zRes_);
}

// should be [-1, 1]^3
template<typename DT, typename VT, typename MT>
void SphereBasisSet3D::getVelocityPosT(const VT& pos, VT& uCat) {
	VT uSph(0,0,0);
  uCat.setZero();

  // parameter space.
  VT sphCord;// = Transform::Spherical::toSpherical(pos);
  if (! is_prolate_ && ! is_oblate_)
  	sphCord = Transform::Spherical::toSpherical(pos);
  else if (is_prolate_)
  	Transform::Spheroid::CatersianToProlate(a_, c_, pos, sphCord[0], sphCord[1], sphCord[2]);
  else if (is_oblate_)
		Transform::Spheroid::CatersianToOblate(a_, c_, pos, sphCord[0], sphCord[1], sphCord[2]);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, pi]
  const DT& p = sphCord[2]; // [0, 2*pi]
  //CHECK(isfinite(r) && isfinite(t) && isfinite(p)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.
  if (r > 1.0)  // velocity is zero
    return;

  int r0 = (int)(r/dR_);
  int r1 = r0 + 1;
  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int p0 = (int)(p/dPhi_);
  int p1 = p0 + 1;

  CLAMPR(r0);
  CLAMPR(r1);
  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPP(p0);
  CLAMPP(p1);

  // get interpolation weights
  const DT wp1 = p/dPhi_ - p0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;
  const DT wr1 = r/dR_ - r0;
  const DT wr0 = 1.0 - wr1;

  const int i000 = p0 + t0 * nPhi_ + r0 * nPhiTheta_;
	const int i010 = p0 + t1 * nPhi_ + r0 * nPhiTheta_;
	const int i100 = p1 + t0 * nPhi_ + r0 * nPhiTheta_;
	const int i110 = p1 + t1 * nPhi_ + r0 * nPhiTheta_;
	const int i001 = p0 + t0 * nPhi_ + r1 * nPhiTheta_;
  const int i011 = p0 + t1 * nPhi_ + r1 * nPhiTheta_;
  const int i101 = p1 + t0 * nPhi_ + r1 * nPhiTheta_;
  const int i111 = p1 + t1 * nPhi_ + r1 * nPhiTheta_;

  uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
  MT transMat;
  if (is_prolate_)
  	Transform::Spheroid::toCartesianMatProlate(r, t, p, c_, transMat);
  else if (is_oblate_)
  	Transform::Spheroid::toCartesianMatOblate(r, t, p, c_, transMat);
  else
  	Transform::Spherical::toCartesianMat(t, p, transMat);
  // toCartesian
  uCat = transMat*uSph;
}

template void SphereBasisSet3D::getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(const Eigen::Vector3d&, Eigen::Vector3d&);
template void SphereBasisSet3D::getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(const Eigen::Vector3f&, Eigen::Vector3f&);

Eigen::Vector3d SphereBasisSet3D::getVelocityPos(const Eigen::Vector3d& pos) {
  Eigen::Vector3d result(0,0,0);
  getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(pos, result);
  return result;
}

Eigen::Vector3f SphereBasisSet3D::getVelocityPos(const Eigen::Vector3f& pos) {
  Eigen::Vector3f result(0,0,0);
  getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(pos, result);
  return result;
}

template<typename DT, typename VT>
void SphereBasisSet3D::addParticleForce(const double& ptlWeight, const VT& pos, const VT& f, const bool isCartesian, VECTOR3_FIELD_3D& buf) {
  // parameter space.
  VT posOrig = pos/scale_;
  // parameter space.
  VT sphCord;
  if (! is_prolate_ && ! is_oblate_)
  	sphCord = Transform::Spherical::toSpherical(pos);
  else if (is_prolate_)
  	Transform::Spheroid::CatersianToProlate(a_, c_, pos, sphCord[0], sphCord[1], sphCord[2]);
  else if (is_oblate_)
		Transform::Spheroid::CatersianToOblate(a_, c_, pos, sphCord[0], sphCord[1], sphCord[2]);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, 2pi]
  const DT& p = sphCord[2]; // [0, 2pi]
  CHECK(isfinite(r) && isfinite(t) && isfinite(p)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.
  if (r > 1.0)  // velocity is zero
    return;

  int r0 = (int)(r/dR_);
  int r1 = r0 + 1;
  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int p0 = (int)(p/dPhi_);
  int p1 = p0 + 1;
  
  // clamp
  CLAMPR(r0);
  CLAMPR(r1);
  // periodic bc
  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPP(p0);
  CLAMPP(p1);

  // get interpolation weights
  const DT wp1 = p/dPhi_ - p0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;
  const DT wr1 = r/dR_ - r0;
  const DT wr0 = 1.0 - wr1;

  const int i000 = p0 + t0 * nPhi_ + r0 * nThetaPhi_;
  const int i010 = p0 + t1 * nPhi_ + r0 * nThetaPhi_;
  const int i100 = p1 + t0 * nPhi_ + r0 * nThetaPhi_;
  const int i110 = p1 + t1 * nPhi_ + r0 * nThetaPhi_;
  const int i001 = p0 + t0 * nPhi_ + r1 * nThetaPhi_;
  const int i011 = p0 + t1 * nPhi_ + r1 * nThetaPhi_;
  const int i101 = p1 + t0 * nPhi_ + r1 * nThetaPhi_;
  const int i111 = p1 + t1 * nPhi_ + r1 * nThetaPhi_;
  
  VT fCpy = f;
  if (isCartesian) {
	  Eigen::Matrix3f transMat;
	  if (is_prolate_)
	  	Transform::Spheroid::toCartesianMatProlate(r, t, p, c_, transMat);
	  else if (is_oblate_)
	  	Transform::Spheroid::toCartesianMatOblate(r, t, p, c_, transMat);
	  else
	  	Transform::Spherical::toCartesianMat(t, p, transMat);
	  fCpy = transMat.transpose()*f;
	}

  for (int i = 0; i < 3; i++) {
    buf[i000][i] += ptlWeight*wr0*wp0*wt0*fCpy[i];
    buf[i010][i] += ptlWeight*wr0*wp0*wt1*fCpy[i];
    buf[i100][i] += ptlWeight*wr0*wp1*wt0*fCpy[i];
    buf[i110][i] += ptlWeight*wr0*wp1*wt1*fCpy[i];
    buf[i001][i] += ptlWeight*wr1*wp0*wt0*fCpy[i];
    buf[i011][i] += ptlWeight*wr1*wp0*wt1*fCpy[i];
    buf[i101][i] += ptlWeight*wr1*wp1*wt0*fCpy[i];
    buf[i111][i] += ptlWeight*wr1*wp1*wt1*fCpy[i];
  }
}

//template void SphereBasisSet3D::addParticleForce<double, Eigen::Vector3d>(const double&, const Eigen::Vector3d&, 
//				 const Eigen::Vector3d&, const bool, VECTOR3_FIELD_3D&);
template void SphereBasisSet3D::addParticleForce<float, Eigen::Vector3f>(const double&, const Eigen::Vector3f&,
				 const Eigen::Vector3f&, const bool, VECTOR3_FIELD_3D&);

void SphereBasisSet3D::projPosBack(ParaParticle3Dd& p) {
  Eigen::Vector3d sphCord;
  if (! is_prolate_ && ! is_oblate_)
  	sphCord = Transform::Spherical::toSpherical(p.position_);
  else if (is_prolate_)
  	Transform::Spheroid::CatersianToProlate(a_, c_, p.position_, sphCord[0], sphCord[1], sphCord[2]);
  else if (is_oblate_)
		Transform::Spheroid::CatersianToOblate(a_, c_, p.position_, sphCord[0], sphCord[1], sphCord[2]);
  
  if (sphCord[0] <= 1.0)
    return;

  p.life_ = 0;
}

void SphereBasisSet3D::projPosBack(ParaParticle3Df& p) {
	 Eigen::Vector3f sphCord;
  if (! is_prolate_ && ! is_oblate_)
  	sphCord = Transform::Spherical::toSpherical(p.position_);
  else if (is_prolate_)
  	Transform::Spheroid::CatersianToProlate(a_, c_, p.position_, sphCord[0], sphCord[1], sphCord[2]);
  else if (is_oblate_)
		Transform::Spheroid::CatersianToOblate(a_, c_, p.position_, sphCord[0], sphCord[1], sphCord[2]);
  
  if (sphCord[0] <= 1.0)
    return;

  p.life_ = 0;
}

void SphereBasisSet3D::computeBasisWeight(Eigen::VectorXd& weights) {
	weights = Eigen::VectorXd::Zero(numBasisAll_);
	for (int i = 0; i < numBasisAll_; i++) {
		const double k3 = all_basis_[i]->WN3D();
		weights[i] = 1.0;
		if (k3 > 1.0)
			weights[i] /= pow(k3, 0.25);
	}
}