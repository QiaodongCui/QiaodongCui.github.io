#include <vector>
#include "tensorCompute/sph3D_evalR.h"
sph3DrEval::sph3DrEval() {
pointers_.resize(41);
pointers_[0] = &evalR_0;
pointers_[1] = &evalR_1;
pointers_[2] = &evalR_2;
pointers_[3] = &evalR_3;
pointers_[4] = &evalR_4;
pointers_[5] = &evalR_5;
pointers_[6] = &evalR_6;
pointers_[7] = &evalR_7;
pointers_[8] = &evalR_8;
pointers_[9] = &evalR_9;
pointers_[10] = &evalR_10;
pointers_[11] = &evalR_11;
pointers_[12] = &evalR_12;
pointers_[13] = &evalR_13;
pointers_[14] = &evalR_14;
pointers_[15] = &evalR_15;
pointers_[16] = &evalR_16;
pointers_[17] = &evalR_17;
pointers_[18] = &evalR_18;
pointers_[19] = &evalR_19;
pointers_[20] = &evalR_20;
pointers_[21] = &evalR_21;
pointers_[22] = &evalR_22;
pointers_[23] = &evalR_23;
pointers_[24] = &evalR_24;
pointers_[25] = &evalR_25;
pointers_[26] = &evalR_26;
pointers_[27] = &evalR_27;
pointers_[28] = &evalR_28;
pointers_[29] = &evalR_29;
pointers_[30] = &evalR_30;
pointers_[31] = &evalR_31;
pointers_[32] = &evalR_32;
pointers_[33] = &evalR_33;
pointers_[34] = &evalR_34;
pointers_[35] = &evalR_35;
pointers_[36] = &evalR_36;
pointers_[37] = &evalR_37;
pointers_[38] = &evalR_38;
pointers_[39] = &evalR_39;
pointers_[40] = &evalR_40;
}


