#ifndef PARTICLE_RK4_H
#define PARTICLE_RK4_H

#define RK4_PARTICLES_2D(particles_, vf)\
for (int i = 0; i < particles_.size(); i++) {\
  const VEC2& position = particles_[i]->position;\
  VEC2 p_v = vf.GetVelocity(position[0]*vxRes, position[1]*vyRes);\
  VEC2 K1 = p_v*h;\
  VEC2 pos1 = position + K1*0.5;\
  p_v = vf.GetVelocity(pos1[0]*vxRes, pos1[1]*vyRes);\
\
  VEC2 K2 = p_v*h;\
  VEC2 pos2 = position + K2*0.5;\
  p_v = vf.GetVelocity(pos2[0]*vxRes, pos2[1]*vyRes);\
\
  VEC2 K3 = p_v*h;\
  VEC2 pos3 = position + K3;\
  p_v = vf.GetVelocity(pos3[0]*vxRes, pos3[1]*vyRes);\
  VEC2 K4 = p_v*h;\
\
  particles_[i]->position += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;\
  particles_[i]->velocity = p_v;\
}

#define RK4_PARTICLES_2D_WORLD(particles_, vf, maxSize)\
for (int i = 0; i < particles_.size(); i++) {\
  const VEC2& position = particles_[i]->position;\
  VEC2 p_v = vf.GetVelocity(position[0]*maxSize, position[1]*maxSize);\
  VEC2 K1 = p_v*h;\
  VEC2 pos1 = position + K1*0.5;\
  p_v = vf.GetVelocity(pos1[0]*maxSize, pos1[1]*maxSize);\
  VEC2 K2 = p_v*h;\
  VEC2 pos2 = position + K2*0.5;\
  p_v = vf.GetVelocity(pos2[0]*maxSize, pos2[1]*maxSize);\
  VEC2 K3 = p_v*h;\
  VEC2 pos3 = position + K3;\
  p_v = vf.GetVelocity(pos3[0]*maxSize, pos3[1]*maxSize);\
  VEC2 K4 = p_v*h;\
\
  particles_[i]->position += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;\
  particles_[i]->velocity = p_v;\
}

#endif  // PARTICLE_RK4_H
