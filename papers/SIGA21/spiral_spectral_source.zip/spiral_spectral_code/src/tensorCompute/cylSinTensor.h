#ifndef CYLSIN_3D_TENSOR
#define CYLSIN_3D_TENSOR

#include <cmath>
#include "tensorCompute/cylSin_evalR.h"
#include "tensorCompute/cylSin_evalT.h"
#include "tensorCompute/cylSin_evalP.h"
#include "sphere_3D/basis_3D.h"
#define Pi M_PI


#define getWaveN \
const int i1x2 = phiI.WN1x2();\
const int i2x2 = phiI.WN2x2();\
const int i3x2 = phiI.WN3x2();\
const int g1x2 = phiG.WN1x2();\
const int g2x2 = phiG.WN2x2();\
const int g3x2 = phiG.WN3x2();\
const int h1x2 = phiH.WN1x2();\
const int h2x2 = phiH.WN2x2();\
const int h3x2 = phiH.WN3x2();\
const double i1 = phiI.WN1D();\
const double i2 = phiI.WN2D();\
const double i3 = phiI.WN3D();\
const double g1 = phiG.WN1D();\
const double g2 = phiG.WN2D();\
const double g3 = phiG.WN3D();\
const double h1 = phiH.WN1D();\
const double h2 = phiH.WN2D();\
const double h3 = phiH.WN3D();

class cylSinTensor{
public:
cylSinTensor();
~cylSinTensor(){};
#include "tensorCompute/cylSinTensorApp.h"
std::vector<double (*)(const Basis3D&, const Basis3D&, const Basis3D&, const double& b)> pointers_;
};

#endif // CYLSIN_3D_TENSOR