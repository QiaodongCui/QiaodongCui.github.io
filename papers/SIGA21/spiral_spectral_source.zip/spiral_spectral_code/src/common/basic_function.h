#ifndef BASIC_FUNCTION_3D_H
#define BASIC_FUNCTION_3D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>
#include <unordered_map>
#include <unordered_set>

#include "3D/trig_integral_3d.h"
#include "util/util.h"

enum FUNTYPE {SIN, COS, ZERO, ONE};
enum DIRTYPE {R, T, P};

// basic functions
// SIN  -> sin(i1*pi*r) or sin(i2*t)
// COS  -> cos(i1*pi*r) or cos(i2*t)
// ZERO -> 0
// ONE  -> const with coef

// int_{r = 0}^{1} cos(a*pi*r) dr 
#define IR0S(a2) IntegralS_D2(a2)/PI
#define IR0C(a2) IntegralC_D2(a2)/PI

// int_{r = 0}^{1} cos(a*pi*r)  r dr 
#define IR1S(a2) IntegralRS_D2(a2)/PI2
#define IR1C(a2) IntegralRC_D2(a2)/PI2

// int_{r = 0}^{1} cos(a*pi*r)  r^2 dr 
#define IR2S(a2) IntegralR2S_D2(a2)/PI3
#define IR2C(a2) IntegralR2C_D2(a2)/PI3

// int_{r = 0}^{1} r*cos(a*pi*r) r^2 dr = 1/pi^4 int_{y = 0}^{pi} cos(a*y) y^3 dy
#define IR3C(a2) IntegralR3C_D2(a2)/PI4
#define IR3S(a2) IntegralR3S_D2(a2)/PI4

// int_{r = 0}^{1} r*cos(a*pi*r) r^3 dr = 1/pi^5 int_{y = 0}^{pi} cos(a*y) y^4 dy
#define IR4C(a2) IntegralR4C_D2_ONE(a2)
#define IR4S(a2) IntegralR4S_D2_ONE(a2)

#define IR5C(a2) IntegralR5C_D2_ONE(a2)
#define IR5S(a2) IntegralR5S_D2_ONE(a2)

#define IR6C(a2) IntegralR6C_D2_ONE(a2)
#define IR6S(a2) IntegralR6S_D2_ONE(a2)

#define IR7C(a2) IntegralR7C_D2_ONE(a2)
#define IR7S(a2) IntegralR7S_D2_ONE(a2)

#define IR8C(a2) IntegralR8C_D2_ONE(a2)
#define IR8S(a2) IntegralR8S_D2_ONE(a2)

#define IR9C(a2) IntegralR9C_D2_ONE(a2)
#define IR9S(a2) IntegralR9S_D2_ONE(a2)



struct BasicFunc {
  
  BasicFunc():type(ZERO), dir(P), wnx2(0), coef(0), rPower(0) {
  }

  BasicFunc(FUNTYPE t, DIRTYPE d, int w, double c):type(t), dir(d),
            wnx2(w), coef(c), rPower(0) {
    if(rPower != 0)
      CHECK(dir == R);
  }

  BasicFunc(FUNTYPE t, DIRTYPE d, int w, double c, int rpow):type(t), dir(d),
  wnx2(w), coef(c), rPower(rpow) {
    if(rPower != 0)
      CHECK(dir == R);
  }

  // copy
  BasicFunc(const BasicFunc& a):type(a.type), dir(a.dir),
            wnx2(a.wnx2),coef(a.coef),rPower(a.rPower) {}
  
  BasicFunc operator-() const {
    BasicFunc result(*this);
    result.coef = - result.coef;
    return result;
  }

  BasicFunc& operator*=(double factor) {
    this->coef *=factor;
    return *this;
  }

  void simplifyMode() {
    if (type == COS && wnx2 == 0)
      type = ONE;
    
    if (type == SIN && wnx2 == 0) {
      type = ZERO;
      rPower = 0;
      coef = 0;
    }

    if (fabs(coef) < 1e-16) {
      type = ZERO;
      rPower = 0;
      coef = 0;
    }
    if (type == ONE || type == ZERO)
      wnx2 = 0;
  }

  FUNTYPE type;
  DIRTYPE dir;
  // twice of the wavenumber.
  int wnx2;
  // coef of this term.
  double coef;
  int rPower;
  
  uint toHash() const {
    uint result = 0;
    result |= (0x80000000 & static_cast<uint>(rPower)); // sign bit
    result |= (0x7f000000 & static_cast<uint>(abs(rPower)) << 24);
    result |= (0x00800000 & static_cast<uint>(wnx2) >> 8); // sign bit
    result |= (0x007ffff0 & static_cast<uint>(abs(wnx2)) << 4);
    result |= (0x0000000c & static_cast<uint>(dir) << 2);
    result |= (0x00000003 & static_cast<uint>(type));
    return result;
  }

  static BasicFunc fromHash(const uint& h) {
    BasicFunc fun;
    bool sgn1 = static_cast<bool>(0x00000001 & h >> 31);
    fun.rPower = static_cast<int>(0x0000007f & (h >> 24));
    if (sgn1)
      fun.rPower = - fun.rPower;

    bool sgn = static_cast<bool>(0x00000001 & h >> 23); 
    fun.wnx2 = static_cast<int>(0x0007ffff & (h >> 4));
    if (sgn)
      fun.wnx2 = - fun.wnx2;
    fun.dir = static_cast<DIRTYPE>(0x00000003 & (h >> 2));
    fun.type = static_cast<FUNTYPE>(0x0000003 & h);
    fun.coef = 0;
    return fun;
  }

  static bool equalFun(const BasicFunc& a, const BasicFunc& b) {
    return (a.type == b.type && a.dir == b.dir && a.wnx2 == b.wnx2 && a.rPower == b.rPower);
  }

  // a*b return add sequence.
  static std::vector<BasicFunc> multiply(const BasicFunc& a, const BasicFunc& b) {
    CHECK(a.dir == b.dir);
    if (a.type == ZERO || b.type == ZERO)
      return {BasicFunc(ZERO, a.dir, 0,0)};

    if (a.type == ONE) {
      BasicFunc f(b);
      f.coef *= a.coef;
      f.rPower += a.rPower;
      return {f};
    }

    if (b.type == ONE) {
      BasicFunc f(a);
      f.coef *= b.coef;
      f.rPower += b.rPower;
      return {f};
    }
    double coefProd = a.coef*b.coef;
    int rPowAdd = a.rPower + b.rPower;

    if (a.type == COS && b.type == COS ) {
      BasicFunc cPlus(COS, a.dir, a.wnx2 + b.wnx2, coefProd*0.5, rPowAdd);
      BasicFunc cMinu(COS, a.dir, abs(a.wnx2 - b.wnx2), coefProd*0.5, rPowAdd);
      cPlus.simplifyMode();
      cMinu.simplifyMode();
      return {cMinu, cPlus};
    } else if (a.type == SIN && b.type == SIN) {
      BasicFunc cPlus(COS, a.dir, a.wnx2 + b.wnx2, -0.5*coefProd, rPowAdd);
      BasicFunc cMinu(COS, a.dir, abs(a.wnx2 - b.wnx2), 0.5*coefProd, rPowAdd);
      cPlus.simplifyMode();
      cMinu.simplifyMode();
      return {cMinu, cPlus};
    } else if (a.type == COS && b.type == SIN) {
      BasicFunc cPlus(SIN, a.dir, a.wnx2 + b.wnx2, 0.5*coefProd, rPowAdd);
      int wnMinus = a.wnx2 - b.wnx2;
      if (wnMinus == 0)  // other mode is zero.
        return {cPlus};
      double coefMinus = -0.5*coefProd;
      if (wnMinus < 0) {
        wnMinus = -wnMinus;
        coefMinus = -coefMinus;
      }
      BasicFunc cMinu(SIN, a.dir, wnMinus, coefMinus, rPowAdd);
      return {cMinu, cPlus};

    } else if (a.type == SIN && b.type == COS) {
      BasicFunc cPlus(SIN, a.dir, a.wnx2 + b.wnx2, 0.5*coefProd, rPowAdd);
      int wnMinus = a.wnx2 - b.wnx2;
      if (wnMinus == 0)  // other mode is zero.
        return {cPlus};
      double coefMinus = 0.5*coefProd;
      if (wnMinus < 0) {
        wnMinus = -wnMinus;
        coefMinus = -coefMinus;
      }
      BasicFunc cMinu(SIN, a.dir, wnMinus, coefMinus, rPowAdd);
      return {cMinu, cPlus};
    }

    LOG(FATAL) << "not supported";
    return {};
  }

  static std::vector<BasicFunc> vecMultOne(const std::vector<BasicFunc>& vec, const BasicFunc& m) {
    if (vec.size() == 0)
      return {};

    if (m.type == ZERO)
      return {BasicFunc(ZERO, m.dir, 0,0)};

    if (m.type == ONE) {
      std::vector<BasicFunc> results = vec;
      for (auto& r : results) {
        CHECK(m.dir == r.dir);
        r.coef *= m.coef;
        r.rPower += m.rPower;
      }
      return results;
    } else {
      std::vector<BasicFunc> results;
      results.reserve(vec.size()*2);
      for (const auto& v : vec) {
        if (v.type == ZERO)
          continue;
        std::vector<BasicFunc> multOne = multiply(v, m);
        results.insert(results.end(), multOne.begin(), multOne.end());
      }
      return results;
    }
  }

  static void vecMultOne(const std::vector<BasicFunc>& vec, const BasicFunc& m, std::vector<BasicFunc>& results) {
    if (vec.size() == 0)
      return;

    if (m.type == ZERO) 
      return;

    if (m.type == ONE) {
      results = vec;
      for (auto& r : results) {
        CHECK(m.dir == r.dir);
        r.coef *= m.coef;
        r.rPower += m.rPower;
      }
      return;
    } else {
      results.reserve(vec.size()*2);
      for (const auto& v : vec) {
        if (v.type == ZERO)
          continue;
        std::vector<BasicFunc> multOne = multiply(v, m);
        results.insert(results.end(), multOne.begin(), multOne.end());
      }
      return;
    }
  }

  static void hashSimplify(std::vector<BasicFunc>& vect) {
    std::unordered_map<uint, double> coefToF;
    for (auto& f : vect) {
      f.simplifyMode();
      uint hash = f.toHash();
      if (coefToF.find(hash) != coefToF.end())
        coefToF[hash] += f.coef;
      else
        coefToF[hash] = f.coef;
    }
    vect.clear();
    vect.reserve(coefToF.size());
    for (const auto& p : coefToF) {
      BasicFunc fr = BasicFunc::fromHash(p.first);
      fr.coef = p.second;
      fr.simplifyMode();
      if (fr.type != ZERO)
        vect.push_back(fr);
    }
  }
  
  static std::vector<BasicFunc> vecVecMult(const std::vector<BasicFunc>& v1, const std::vector<BasicFunc>& v2) {
    if (v1.size() == 0 || v2.size() == 0)
      return {};
    std::vector<BasicFunc> results;
    for (const auto& v : v2) {
      if (v.type == ZERO)
        continue;
      std::vector<BasicFunc> multOne = vecMultOne(v1, v);
      results.insert(results.end(), multOne.begin(), multOne.end());
    }
    return results;
  }

  static std::vector<BasicFunc> multToAdd(const std::vector<BasicFunc>& mseq, const int curIdx) {
    if (mseq.size() == 0 || curIdx >= mseq.size())
      return {};
    if (curIdx == mseq.size() - 1)
      return {mseq[curIdx]};

    std::vector<BasicFunc> rest = multToAdd(mseq, curIdx + 1);
    return vecMultOne(rest, mseq[curIdx]);
  }

  // integrate along the specified direction
  double integrate() const {
    if (type == ZERO)
      return 0.0;
    
    // int_{p = 0}^{2 pi} fun dp
    if (dir == P) {
      if (type == ZERO)
        return 0;
      if (type == ONE)
        return 2.0*M_PI*coef;
      else if (type == SIN)
        return wnx2 % 2 == 0 ? 0 : 4.0/wnx2*coef;
      else {
        return wnx2 == 0 ? 2.0*M_PI*coef : 0;
      }
    } else if (dir == T) {   // int_{t = 0}^{pi} fun dt
      if (type == ONE)
        return M_PI*coef;
      else if (type == SIN)
        return ((wnx2/2)%2 == 0 ? 0 : coef*2.0/(wnx2/2));
      else  // cos
        return (wnx2 == 0 ? coef*M_PI : 0);
    } else {     // int_{r=0}^{1} fun dr
      if (type == ONE && rPower >= 0)   // int_r^p
        return coef*1.0/(1 + rPower);
      else if (type == ONE && rPower == -1)
        return coef*computeRSINCOS(COS, rPower, 0);
      else// (type == SIN || type == COS)
        return coef*computeRSINCOS(type, rPower, wnx2);
    }
  }

  double integrateP2Pi() const {
    if (type == ZERO)
      return 0;
    if (type == ONE)
      return 2.0*M_PI*coef;
    else if (type == SIN)
      return wnx2 % 2 == 0 ? 0 : 4.0/wnx2*coef;
    else {
      return wnx2 == 0 ? 2.0*M_PI*coef : 0;
    }
  }
  // int fun*r^rpow dr
  double integrateRPow(const int p) const {
    if (type == ZERO)
      return 0.0;
    const int powAdd = p + rPower;
    if (type == ONE)   // int_r^p
      return coef*1.0/(1 + powAdd);
    else// (type == SIN || type == COS)
      return coef*computeRSINCOS(type, powAdd, wnx2);
  }

  // BasicFunc(FUNTYPE t, DIRTYPE d, int w, double c, int rpow):type(t), dir(d),
  // wnx2(w), coef(c), rPower(rpow)
  // derivative
  std::vector<BasicFunc> deriv() const {
    // derivative is zero.
    if (type == ZERO || (type == ONE && rPower == 0)) {
      return {BasicFunc(ZERO, dir, 0,0)};
    }

    if (type == ONE && rPower != 0) {
      return {BasicFunc(ONE, dir, 0, rPower*coef, rPower - 1.0)};
    }

    if (dir == R) {
      if (rPower == 0) {
        if (type == SIN)
          return {BasicFunc(COS, dir, wnx2, wnx2*0.5*PI*coef)};
        else
          return {BasicFunc(SIN, dir, wnx2, -wnx2*0.5*PI*coef)};
      } else {
        if (type == SIN)
          return {BasicFunc(COS, dir, wnx2, wnx2*0.5*PI*coef, rPower), BasicFunc(SIN, dir, wnx2, rPower*coef, rPower - 1)};
        else
          return {BasicFunc(SIN, dir, wnx2,-wnx2*0.5*PI*coef, rPower), BasicFunc(COS, dir, wnx2, rPower*coef, rPower - 1)};
      }
    } else { // shares for theta and phi.
      if (type == SIN)
        return {BasicFunc(COS, dir, wnx2, wnx2*0.5*coef)};
      else
        return {BasicFunc(SIN, dir, wnx2, -wnx2*0.5*coef)};
    }
  }

  BasicFunc derivT() const {
    CHECK(dir == T);
    // derivative is zero.
    if (type == ZERO || type == ONE) {
      return BasicFunc(ZERO, dir, 0,0);
    }

    if (type == SIN)
      return BasicFunc(COS, dir, wnx2, wnx2*0.5*coef);
    else
      return BasicFunc(SIN, dir, wnx2, -wnx2*0.5*coef);
  };

  BasicFunc derivR() const {
    CHECK(dir == R && rPower == 0);
    if (type == ZERO || type == ONE) {
      return BasicFunc(ZERO, dir, 0,0);
    }

    if (type == SIN)
      return BasicFunc(COS, dir, wnx2, wnx2*0.5*coef);
    else
      return BasicFunc(SIN, dir, wnx2, -wnx2*0.5*coef);
  }

  void print() const {
    if (type == ZERO)
      printf("0 ");
    else if (type == ONE) {
      if (rPower == 0)
        printf("%.16g ", coef);
      else
        printf("%.16gr^%d ", coef, rPower);
    } else {
      std::string str;
      if (type == COS)
        str = "Cos";
      else
        str = "Sin";
      std::string dirStr;
      if (dir == R)
        dirStr = "*Pi*r";
      if (dir == T)
        dirStr = "*t";
      if (dir == P)
        dirStr = "*p";

      if (rPower == 0)
        printf("%.16g%s[%d/2%s]",coef, str.c_str(), wnx2, dirStr.c_str());
      else
        printf("%.16gr^%d%s[%d/2%s]",coef, rPower, str.c_str(), wnx2, dirStr.c_str());
    }
  }

  static void printVec(const std::vector<BasicFunc>& vec) {
    for (const auto& f : vec) {
      printf("+");
      f.print();
    }
  }

  static double computeRSINCOS(const FUNTYPE& type, const int rpow, const int a2);
  static double computeRSIN(const int a2, const int rpow);
  static double computeRCOS(const int a2, const int rpow);
  
};

struct RTMultiply {
  // this is (sum rComp)*(sum tComp)
  std::vector<BasicFunc> rComp;
  std::vector<BasicFunc> tComp;
  static RTMultiply mult(const RTMultiply& rt1, const RTMultiply& rt2) {
    RTMultiply result;
    result.rComp = BasicFunc::vecVecMult(rt1.rComp, rt2.rComp);
    result.tComp = BasicFunc::vecVecMult(rt1.tComp, rt2.tComp);

    return result;
  }

  static std::vector<RTMultiply> multV(const std::vector<RTMultiply>& v1, const std::vector<RTMultiply>& v2) {
    std::vector<RTMultiply> result;
    for (const auto vf1 : v1)
      for (const auto vf2 : v2) {
        result.push_back(RTMultiply::mult(vf1, vf2));
      }

      return result;
  }

  // d tComp/dt
  void derivT() {
    std::vector<BasicFunc> tDeriv;
    for (const auto& f : tComp) {
      BasicFunc df = f.derivT();
      if (df.type != ZERO)
        tDeriv.push_back(df);
    }
    tComp = tDeriv;
    if (tComp.size() == 0)
      rComp.clear();
  }

  // integrate as is, without the sin(t) term.
  double integrateT() const {
    double result = 0;
    for (const auto& f : tComp)
      result += f.integrate();

    return result;
  }

  double integrateT2Pi() const {
    double result = 0;
    for (const auto& f : tComp)
      result += f.integrateP2Pi();
    return result;
  }

  double integrateR() const {
    double result = 0;
    for (const auto& f : rComp)
      result += f.integrate();

    return result;
  }
  
  static void derivTVec(std::vector<RTMultiply>& dvec) {
    for (auto& rtm : dvec)
      rtm.derivT();
  }

  void derivR() {
    std::vector<BasicFunc> rDeriv;
    for (const auto& f : rComp) {
      std::vector<BasicFunc> df = f.deriv();
      rDeriv.insert(rDeriv.end(), df.begin(), df.end());
    }
    rComp = rDeriv;
  }

  static void derivRVec(std::vector<RTMultiply>& dvec) {
    for (auto& rtm : dvec)
      rtm.derivR();
  }

  void multR(int rPow) {
    for (auto& rfun : rComp)
      rfun.rPower += rPow;
  }

  static void multRVec(const int rPow, std::vector<RTMultiply>& mvec) {
    for (auto& rtm : mvec)
      rtm.multR(rPow);
  }
  
  void multTheta(const BasicFunc& mult) {
    tComp = BasicFunc::vecMultOne(tComp, mult);
  }

  static void multThetaVec(const BasicFunc& mult, std::vector<RTMultiply>& mvec) {
    for (auto& rtm : mvec)
      rtm.multTheta(mult);
  }
  
  void hashSimplify() {
    BasicFunc::hashSimplify(rComp);
    BasicFunc::hashSimplify(tComp);
  }

  void print() const {
    if (rComp.size() == 0 || tComp.size() == 0) {
      printf("0");
      return;
    }

    printf("(");
    for (const auto& f : rComp) {
      printf("+");
      f.print();
    }
    printf(")*(");
    for (const auto& f : tComp) {
      printf("+");
      f.print();
    }
    printf(")");
  }
};

// A factor like coef*h^{hpow}*sqrt{1 + c^2 r^2}^{sqrtCRpow}*r^{rpow}
struct EllipticFactor {
  // power of h
  int hPow_ = 0;
  // power of sqrt{1+c^2 r^2}
  int sqrtCRPow_ = 0;
  // power of r
  int rPow_ = 0;

  // coefficients.
  double coef_ = 0.0;
  EllipticFactor(const int hp, const int sqrtP, const int rP, const double coef):
    hPow_(hp), sqrtCRPow_(sqrtP), rPow_(rP), coef_(coef) {
  };

  EllipticFactor():hPow_(0), sqrtCRPow_(0), rPow_(0), coef_(0){};
  // copy
  EllipticFactor(const EllipticFactor& a):hPow_(a.hPow_), sqrtCRPow_(a.sqrtCRPow_),
            rPow_(a.rPow_),coef_(a.coef_){};

  EllipticFactor& operator*=(const double factor) {
    this->coef_ *=factor;
    return *this;
  };

  EllipticFactor& operator*=(const EllipticFactor& other) {
    hPow_ += other.hPow_;
    sqrtCRPow_ += other.sqrtCRPow_;
    rPow_ += other.rPow_;
    coef_ *= other.coef_;
    return *this;
  };

  void print() const {
    printf("%.16g*h[r,t]^%d*Sqrt[1.0 + c^2*r^2]^%d*r^%d ", coef_, hPow_, sqrtCRPow_, rPow_);
  }

  //coef*sqrt{1 + c^2 r^2}^{sqrtCRpow}*r^{rpow} D[h^{hpow},t]
  // D[h^{hpow},t] = 0.5*hpow*h^{hpow-2}sin(2v)
  // will spawn T function that needed to multiplied with other part.
  BasicFunc derivT() {
    if (hPow_ != 0) {
      coef_ *= hPow_*0.5;
      hPow_ -= 2;
      return BasicFunc(SIN, T, 2, 1.0);
    } else {  // hpow = 0, derivative is zero.
      coef_ = 0;
      return BasicFunc(ZERO, T, 0, 0);
    }
  }
  
  void derivT(BasicFunc& f1, EllipticFactor& d1) const {
    if (hPow_ != 0) {
      d1 = *this;
      d1.coef_ *= hPow_*0.5;
      d1.hPow_ -= 2;
      f1 = BasicFunc(SIN, T, 2, 1.0);
    } {
      d1.coef_ = 0;
      f1 = BasicFunc(ZERO, T, 0, 0);
    }
  }

  // coef*D[r^{rpow}*sqrt{1 + c^2 r^2}^{sqrtCRpow}*h^{hpow}, r] = 
  // coef*sqrt{1 + c^2 r^2}^{sqrtCRpow}*h^{hpow}*D[r^{rpow}] + 
  // coef*r^{rpow}*h^{hpow}*D[sqrt{1 + c^2 r^2}^{sqrtCRpow}, r] +
  // coef*r^{rpow}*sqrt{1 + c^2 r^2}^{sqrtCRpow}*D[h^{hpow}, r]
  void derivR(const double& c, EllipticFactor& d1, EllipticFactor& d2, EllipticFactor& d3) const {
    // D[r^{rpow}] = rpow*r^{rpow-1}
    if (rPow_ != 0) {
      d1 = *this;
      d1.coef_ *= rPow_;
      d1.rPow_ -= 1;
    } else {
      d1.coef_ = 0;
    }
    // D[sqrt{1 + c^2 r^2}^{p}, r] = c^2*p*r*sqrt{1 + c^2 r^2}^{p-2} 
    if (sqrtCRPow_ != 0) {
      d2 = *this;
      d2.coef_ *= c*c*sqrtCRPow_;
      d2.rPow_ += 1;
      d2.sqrtCRPow_ -= 2;
    } else {
      d2.coef_ = 0;
    }
    // D[h^{hpow}, r] = c^2*r*hpow*h^{hpow-2}
    if (hPow_ != 0) {
      d3 = *this;
      d3.coef_ *= c*c*hPow_;
      d3.rPow_ += 1;
      d3.hPow_ -= 2;
    } else {
      d3.coef_ = 0;
    }
  }

  static void vecMultiply(const EllipticFactor& ef, std::vector<EllipticFactor>& efv) {
    for (auto& ef2 : efv)
      ef2 *= ef;
  }

  static void vecVecMultiply(const EllipticFactor& ef, std::vector<std::vector<EllipticFactor>>& efv) {
    for (auto& ef2 : efv)
      vecMultiply(ef, ef2);
  }
  
  static EllipticFactor mult(const EllipticFactor& a, const EllipticFactor& b) {
    EllipticFactor result = a;
    result *= b;
    return result;
  }

};
  
struct TripleCoef {
  TripleCoef(const BasicFunc& rf, const BasicFunc& tf, const EllipticFactor& ef):rf_(rf), tf_(tf), ef_(ef)
  {};

  BasicFunc rf_;
  BasicFunc tf_;
  EllipticFactor ef_;
  void print() {
    ef_.print();
    rf_.print();
    tf_.print();
  }
  
  static void multiply(const TripleCoef& t1, const TripleCoef& t2, std::vector<TripleCoef>& result) {
    
    EllipticFactor ef1 = t1.ef_;
    ef1 *= t2.ef_;
    // shared ef.
    // TrigReduce
    std::vector<BasicFunc> rv = BasicFunc::multiply(t1.rf_, t2.rf_);
    std::vector<BasicFunc> tv = BasicFunc::multiply(t1.tf_, t2.tf_);
    // ef1*<rv>*<tv>
    // distribution law
    for (int i = 0; i < rv.size(); i++) {
      if (rv[i].type == ZERO || rv[i].coef == 0)
        continue;
      for (int j = 0; j < tv.size(); j++) {
        if (tv[j].type == ZERO || tv[j].coef == 0)
          continue;
        result.push_back(TripleCoef(rv[i], tv[j], ef1));
      }
    }
  }

  double totalCoef() {
    return rf_.coef*tf_.coef*ef_.coef_;
  }

};

#endif // BASIC_FUNCTION_3D_H