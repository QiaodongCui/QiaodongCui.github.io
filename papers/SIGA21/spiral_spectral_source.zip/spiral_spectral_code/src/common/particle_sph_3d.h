#ifndef PARTICLE_SPH_3D_H
#define PARTICLE_SPH_3D_H

#include <Eigen/Eigen>
#include <random>

#include "Alg/VEC2.h"
#include "util/colorMap.h"

class ParticleSph3D {
public:
  ParticleSph3D(const float px, const float py, const float pz){
    position[0] = px;
    position[1] = py;
    position[2] = pz;
  }
  ParticleSph3D() {
    position.setZero();
  }
  ~ParticleSph3D(){}
  Eigen::Vector3d position;
  Eigen::Vector3d velocity;

  double theta;
  double phi;
  int gridIdx;
  // Real r;
  void computeSphCoord() {
    theta = acos(position[2]);   // [0, pi]
    phi = atan2(position[1], position[0]);
    if (position[1] < 0)   // [0, 2pi]
      phi += 2*M_PI;
  }
};

struct ParaParticle2D {
  ParaParticle2D(const double& theta, const double& p) {
    cord_[0] = theta;
    cord_[1] = p;
  };
  ParaParticle2D() {
    cord_[0] = 0;
    cord_[1] = 0;
  }

  VEC2 cord_;
  uint gridIdx_;
};

template<typename T>
struct ParaParticle3D
{
  ParaParticle3D(const T& pos):position_(pos) {
  }

  ParaParticle3D(const T& pos, short life):position_(pos), life_(life) {
  }

  ParaParticle3D() {
    position_[0] = 0;
    position_[1] = 0;
    position_[2] = 0;
    //gridIdx_ = 0;
  }

  T position_;
  float weight_ = 1.0;
  float life_ = 1.0;
  //uint64_t gridIdx_;
};

typedef ParaParticle3D<Eigen::Vector3d> ParaParticle3Dd;
typedef ParaParticle3D<Eigen::Vector3f> ParaParticle3Df;

class ParticleSystem {
public:
  ParticleSystem(const double seedRad):seedRad_(seedRad)
  {particles_.resize(1);};

  ~ParticleSystem(){};

  void seedSphere(const int nParticle, const float rad, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec);
  static void seedRing(const int nParticle, const double a_, const double scale, std::default_random_engine &gen,
                std::vector<ParaParticle3Df>& pVec);
  static void seedCylinder(const int nParticle, const double rad, const double h, const double scale, const bool random, std::default_random_engine &gen,
                std::vector<ParaParticle3Df>& pVec);

  static void seedCylinderColor(const int nParticle, const double rad, const double h, const double scale,
                           const bool random, std::default_random_engine &gen, const ColorMap& cmap, std::vector<ParaParticle3Df>& pVec,
                           std::vector<Eigen::Vector3f>& colorF);

  static void seedDome(const int nParticle, const float tmin, const float tmax,
                       std::default_random_engine &gen, const bool random, std::vector<ParaParticle3Df>& pVec);
  static void seedDomeColor(const int nParticle, const float tmin, const float tmax,
                       std::default_random_engine &gen, const bool random, std::vector<ParaParticle3Df>& pVec,
                       std::vector<Eigen::Vector3f>& colorF);

  static void seedDomeRing(const int nParticle, const float tmin, const float tmax, const float zmin, const float zmax, 
                           const float a, const float scale,
                          std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec);
  void seedCube(const int nParticle, const float xL, const float yL, const float zL,
                       std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec);
  void seedCubeColor(const int nParticle, const float xL, const float yL, const float zL,
                       std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec, std::vector<Eigen::Vector3f>& colorF);
  static void seedSphPatch(const int nParticle, const float rmin, const float rmax, const float tmin, const float tmax, 
                           const float pmin, const float pmax, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec);

  
  void resetAtSeed(ParaParticle3Df& ptl, const float rad,  std::default_random_engine &gen);
  static void resetAtRing(ParaParticle3Df& ptl, const double a_, const double scale, std::default_random_engine &gen);
  static void resetAtCylinder(ParaParticle3Df& ptl, const double rad, const double h, const double scale, std::default_random_engine &gen);
  static void resetAtCylinderColor(ParaParticle3Df& ptl, Eigen::Vector3f& colorF, const ColorMap& cmap,
                const double rad, const double h, const double scale, std::default_random_engine &gen);
  
  static void resetDome(ParaParticle3Df& ptl, const float tmin, const float tmax, const bool random, std::default_random_engine &gen);
  
  static void resetDomeColor(ParaParticle3Df& ptl, Eigen::Vector3f& colorF, const float tmin, const float tmax,
                             const bool random, std::default_random_engine &gen);

  static void resetSphPatch(ParaParticle3Df& ptl, const float rmin, const float rmax, const float tmin, const float tmax, 
                           const float pmin, const float pmax, std::default_random_engine &gen);
  static void resetIntoSphere(ParaParticle3Df& ptl, std::default_random_engine &gen);

  static void samplesSurface(const int x, const int y, const int width, const int height, 
                             const int nTheta_, const int nPhi_, const int maxParticlePerCell,
                             std::default_random_engine &gen, 
                             std::vector<ParaParticle3Df>& densityParticles);

  static void seedSurface(const int nParticle, const float tim, const float tmax, const float pmin, const float pmax, 
                          const bool random, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec);
  
  static void resetSurface(ParaParticle3Df& ptl, const float tim, const float tmax, const float pmin, const float pmax, 
                          const bool random, std::default_random_engine &gen);

  static void seedSurface(const int nParticle,
                          const bool random, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec);
  
  static void seedTorusSurf(const int nParticle, const float tim, const float tmax, const float pmin, const float pmax, 
                            const double a_, const float scale, 
                            const bool random, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec,
                            std::vector<Eigen::Vector3f>& colorF);
  
  static void seedTorusSurf(const int nParticle, const double a_, const float scale, const bool random,
                            std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec, const ColorMap& cmap,
                            std::vector<Eigen::Vector3f>& colorF);

  uint64_t totalSize() {
    uint64_t result = 0;
    for (int i = 0; i < particles_.size(); i++)
      result += particles_[i].size();
    return result;
  }

  ParaParticle3Df seedParticle_;
  std::vector<std::vector<ParaParticle3Df>> particles_;
  std::vector<ParaParticle3Df> heatParticles_;
  double seedRad_;

  void saveParticleLocation(const std::string& fname, const uint64_t numToSave);

};


#endif
