#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "tensorCompute/torus2DTensor.h"
#include "polar_2D/torus_basis_2D.h"
#include "polar_2D/torus_basis_set_2D.h"
#include "util/timer.h"

namespace {

void test() {

  const double a_ = 3.0;
  const int phiK_ = 20;
  const int thetaK_ = 20;

  std::vector<torusPtr2D> all_basis_;

// Phi^0, Phi^3
  for (int j = 1; j < phiK_; j++) {
    
    // Phi^3
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        all_basis_.push_back(torusPtr2D(new TorusBasis2D(i, 2*j, 3, a_)));
      }
    }
    // Phi^0
    for (int i = 1; i <= thetaK_; i++) { 
      all_basis_.push_back(torusPtr2D(new TorusBasis2D(i, 2*j, 0, a_)));
    }
  }

  // Phi^1, Phi^2
  for (int j = 1; j < phiK_; j++) {
        
    // Phi^2
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        all_basis_.push_back(torusPtr2D(new TorusBasis2D(i, 2, 2, a_)));
      }
    }

    // Phi^1
    for (int i = 1; i <= thetaK_; i++) {
      all_basis_.push_back(torusPtr2D(new TorusBasis2D(i, 2*j, 1, a_)));
    }
  }
  
  {
    // Phi^4
    for (int i = 0; i < thetaK_; i++) {
      all_basis_.push_back(torusPtr2D(new TorusBasis2D(i, 0, 4, a_)));
    }
    // Phi^5
    for (int i = 1; i < thetaK_; i++) {
      all_basis_.push_back(torusPtr2D(new TorusBasis2D(i, 0, 5, a_)));
    }
  }


  const int numBasisAll_ = all_basis_.size();

Timer timer;
timer.Reset();
  LOG(INFO) << numBasisAll_;

  torus2DTensor tensorEval;

  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
  	//LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const TorusBasis2D& basis_i = *all_basis_[i];
        const TorusBasis2D& basis_g = *all_basis_[g];
        const TorusBasis2D& basis_h = *all_basis_[h];
        volatile double Cigh = TorusBasis2D::computeTensorEntry(basis_i, basis_g, basis_h);
				const int idx = basis_i.index()*36 + basis_g.index()*6 + basis_h.index();
        double invWn = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
        volatile double Cnew = tensorEval.pointers_[idx](basis_i, basis_g, basis_h, a_)*invWn;
        CHECK(fabs(Cigh -  Cnew) < 1e-6) << Cigh << " " << Cnew << " " << i << " " << g << " " << h;
      }
    }
  }
  LOG(INFO) << timer.ElapsedTimeInSeconds();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
	
	test();

  return 0;
}