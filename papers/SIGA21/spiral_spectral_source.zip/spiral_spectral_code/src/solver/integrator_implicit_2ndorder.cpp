/*#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>

#include "integrator_implicit_2ndorder.h"
#include "util/util.h"

// Integrator for first order system.
void IntegratorImplicit2ndOrder::IntegrateForward(
    CTF::Tensor<double>& C, const Eigen::VectorXd& coefficients_old,
    const double dt, Eigen::VectorXd* coefficients_new) {
    const int num_basis = coefficients_old.size();
  CTF::Vector<double> Xt(num_basis);
  CopyEigenVectorToCTF(coefficients_old, &Xt);
  CTF::Matrix<double> P(num_basis, num_basis);
  P["kj"] = C["ijk"]*Xt["i"];
  Eigen::MatrixXd A(num_basis, num_basis);
  A.setIdentity();
  Eigen::MatrixXd PE(num_basis, num_basis);
  CopyCTFMatrixToEigen(P, &PE);
  
  A = A - dt*PE;
  Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  solver.compute(A);
  (*coefficients_new) = solver.solve(coefficients_old);
}

void IntegratorImplicit2ndOrder::IntegrateForward(
  CTF::Tensor<double>& Q, const Eigen::VectorXd& coefficients_old,
  const Eigen::VectorXd& coefficients_dot_old, const double dt,
  Eigen::VectorXd* coefficients_new, Eigen::VectorXd* coefficients_dot_new) {

  const int num_basis = coefficients_old.size();
  CTF::Vector<double> Xt(num_basis);
  CTF::Vector<double> Xt1(num_basis);
  CTF::Matrix<double> C(num_basis, num_basis);
  Eigen::MatrixXd CE(num_basis, num_basis);
  Eigen::MatrixXd A(num_basis, num_basis);
  A.setIdentity();

  CopyEigenVectorToCTF(coefficients_old, &Xt);
  // Compute tensor double contraction to get matrix C.
  TensorContractionToMatrix(Q, Xt, &C);
  CopyCTFMatrixToEigen(C,&CE);
  // Right hand side.
  Eigen::VectorXd b(num_basis);
  // b = x^t + \Delta t v^t.
  b = coefficients_old + dt * coefficients_dot_old;
  // A = (I - \Delta t^2 C)
  A = A - dt*dt* CE;
  Eigen::VectorXd Acc(num_basis);
  
  // Solve using bicgstab.
  Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  solver.compute(A);
  (*coefficients_new) = solver.solve(b);
  Acc = CE*(*coefficients_new);
  (*coefficients_dot_new) = coefficients_dot_old + dt*Acc;
  LOG(INFO) << "Angle1: " << Acc.dot(*coefficients_new) / (Acc.norm() * coefficients_new->norm()) 
      << " Magnitute: " << Acc.norm();
  LOG(INFO) << "Angle2: " << coefficients_new->dot(*coefficients_dot_new) / 
      (coefficients_dot_new->norm() * coefficients_new->norm())
      << " Magnitute: " << coefficients_dot_new->norm();
}
*/
