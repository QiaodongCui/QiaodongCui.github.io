#include "elliptic/elliptic_basis_2D.h"
#include "elliptic/prolate_oblate_2D.h"
#include "elliptic/prolate_sphere_2D_share.h"
#include "sphere_3D/sphere_basis_3D.h"

std::vector<std::vector<int>> normTestWn = {{2, 2}, {2, 4}, {2, 6}, {2, 8}, {2, 10}, {4, 2}, {4, 4}, {4, 6}, {4, 
  8}, {4, 10}, {6, 2}, {6, 4}, {6, 6}, {6, 8}, {6, 10}, {8, 2}, {8, 
  4}, {8, 6}, {8, 8}, {8, 10}, {10, 2}, {10, 4}, {10, 6}, {10, 
  8}, {10, 10}};

std::vector<double> val1 = {7.71343, 5.35127, 4.91383, 4.76073, 4.68986, 12.3651, 5.7669, \
4.54502, 4.11736, 3.91941, 21.8312, 8.05579, 5.50479, 4.61193, \
4.19867, 35.2279, 11.3764, 6.95949, 5.41356, 4.69802, 52.5072, \
15.683, 8.86366, 6.4769, 5.37218};

std::vector<double> val2 = {7.69269, 7.69269, 7.69269, 7.69269, 7.69269, 6.2991, 6.2991, 6.2991, \
6.2991, 6.2991, 6.03623, 6.03623, 6.03623, 6.03623, 6.03623, 5.95239, \
5.95239, 5.95239, 5.95239, 5.95239, 5.91523, 5.91523, 5.91523, \
5.91523, 5.91523};

std::vector<double> val3 = {4.89128, 4.89128, 4.89128, 4.89128, 4.89128, 11.7787, 11.7787, \
11.7787, 11.7787, 11.7787, 21.5442, 21.5442, 21.5442, 21.5442, \
21.5442, 35.072, 35.072, 35.072, 35.072, 35.072, 52.4098, 52.4098, \
52.4098, 52.4098, 52.4098};

std::vector<std::vector<int>> AR = {{5, 40, 14, 5, 48, 6}, {12, 10, 56, 27, 2, 32}, {20, 60, 20, 30, 
    50, 20}, {14, 42, 36, 21, 26, 54}, {30, 36, 2, 30, 10, 22}, {7, 
    38, 40, 1, 12, 8}, {17, 54, 6, 28, 34, 12}, {7, 16, 22, 22, 20, 
    58}, {9, 18, 36, 10, 4, 28}, {17, 2, 20, 12, 60, 14}, {4, 52, 6, 
    19, 4, 18}, {3, 26, 20, 27, 18, 8}, {23, 56, 52, 11, 22, 40}, {24,
     22, 4, 15, 46, 60}, {26, 10, 50, 27, 42, 48}, {14, 32, 30, 8, 20,
     14}, {25, 14, 18, 28, 2, 56}, {8, 30, 4, 8, 44, 38}, {27, 2, 52, 
    21, 8, 22}, {25, 42, 60, 20, 26, 54}, {13, 20, 60, 22, 56, 
    26}, {4, 36, 18, 8, 30, 32}, {1, 16, 26, 11, 42, 38}, {24, 42, 38,
     23, 52, 4}, {4, 18, 8, 11, 16, 46}, {29, 60, 26, 27, 38, 
    50}, {21, 12, 24, 14, 42, 34}};

std::vector<double> val4 = {0., 0., 0., 0., 0., 0., 0., 0., 0., -2.84332, 0., 0., 0., 0., 0., \
0., 0., 0., 1.86195e-13, 0., 0., 0., 0., 0., 0., 0., 0.};

std::vector<double> val5 = {7.40876, 4.74438, 4.25098, 4.07828, 3.99835, 13.576, 5.76618, \
4.31993, 3.81374, 3.57944, 24.6309, 8.42707, 5.42637, 4.37612, \
3.89001, 40.5217, 12.369, 7.15553, 5.33081, 4.48623, 60.9787, \
17.4694, 9.41213, 6.59208, 5.2868};

std::vector<double> val6 = {9.10496, 9.10496, 9.10496, 9.10496, 9.10496, 7.10502, 7.10502, \
7.10502, 7.10502, 7.10502, 6.9111, 6.9111, 6.9111, 6.9111, 6.9111, \
6.83243, 6.83243, 6.83243, 6.83243, 6.83243, 6.79681, 6.79681, \
6.79681, 6.79681, 6.79681};

std::vector<double> val7 = {5.19371, 5.19371, 5.19371, 5.19371, 5.19371, 12.6839, 12.6839, \
12.6839, 12.6839, 12.6839, 24.3914, 24.3914, 24.3914, 24.3914, \
24.3914, 40.3679, 40.3679, 40.3679, 40.3679, 40.3679, 60.8832, \
60.8832, 60.8832, 60.8832, 60.8832};

std::vector<double> val8 = {0., 0., 0., 0., 0., 0., 0., 0., 0., 3.99262, 0., 0., 0., 0., 0., 0., \
0., 0., 3.87293e-13, 0., 0., 0., 0., 0., 0., 0., 0.};

namespace {
  
void collectPattern() {
  std::vector<prolate2DPtr> basis;
  int  phiK_ = 6;
  int thetaK_ = 3;
  double b = 0.9;
  const bool isProlate = false;
  // Phi^0, Psi^0
  for (int j = 1; j < phiK_; j++) {
    // Psi^0
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        basis.push_back(prolate2DPtr(new ProlateOblate2D(2*i, 2, 3, b, isProlate)));
      }
    }
    for (int i = 1; i <= thetaK_; i++) { 
      // init, 2*wavenumber.
      basis.push_back(prolate2DPtr(new ProlateOblate2D(2*i, 2*j, 0, b, isProlate)));
    }
  }
  // Phi^1, Psi^1
  for (int j = 1; j < phiK_; j++) {
    // Psi^1
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        basis.push_back(prolate2DPtr(new ProlateOblate2D(2*i, 2, 4, b, isProlate)));
      }
    }
    for (int i = 1; i <= thetaK_; i++) {
      // Phi^1
      basis.push_back(prolate2DPtr(new ProlateOblate2D(2*i, 2*j, 1, b, isProlate)));
    }
  }
  // Phi^2 last one.
  for (int i = 1; i <= thetaK_; i++) {
    basis.push_back(prolate2DPtr(new ProlateOblate2D(2*i, 0, 2, b, isProlate)));
  }

  std::unordered_set<uint64_t> set;
  for (int i = 0; i < basis.size(); i++) {
    for (int j = i; j < basis.size(); j++) {
      basis[i]->dotProdPattern(*basis[j], set);
    }
  }
  EllipticBasis2D::exportNumericalPatternTensor(set, "./oblate2DDot.txt");

  std::unordered_set<uint64_t> tensorSet;
  for (int i = 0; i < basis.size(); i++) {
    for (int g = 0; g < basis.size(); g++) {
      for (int h = 0; h < basis.size(); h++) {
        ProlateOblate2D::computeTensorPattern(*basis[i], *basis[g], *basis[h], tensorSet);
      }
    }
  }

  EllipticBasis2D::exportNumericalPatternTensor(tensorSet, "./oblateTensor2D.txt");
}

void openInnerTable() {
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  tab1D.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                              "./Tensor/tables/prolate2D/prolateDotTable.bin",
                                              "./Tensor/tables/prolate2D/prolate2DDot.txt"));
  const double b = 0.9;
  IntTable1DData tabData(b);
  tabData.setIntTable(tab1D);
}

void testInnerProd() {
  const double b = 0.9;
  IntTable1DData tabData(b);
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  tab1D.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                              "./Tensor/tables/prolate2D/prolateDotTable.bin",
                                              "./Tensor/tables/prolate2D/prolate2DDot.txt"));
  tabData.setIntTable(tab1D);

  ProlateOblate2D basis1(2, 2, 0, b);
  LOG(INFO) << basis1.dotProd(basis1, tabData);

  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], normTestWn[i][1], 0, b);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val1[i]) < 1e-4) << val1[i] << " " << basis1.dotProd(basis1, tabData);
  }
  
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], normTestWn[i][1], 1, b);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val1[i]) < 1e-4) << val1[i] << " " << basis1.dotProd(basis1, tabData);
  }
  
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], 0, 2, b);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val2[i]) < 1e-4) << val2[i] << " " << basis1.dotProd(basis1, tabData);
  }

  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], 2, 3, b);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val3[i]) < 1e-4) << val3[i] << " " << basis1.dotProd(basis1, tabData);
  }

  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], 2, 4, b);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val3[i]) < 1e-4) << val3[i] << " " << basis1.dotProd(basis1, tabData);
  }

  // 0x[1,2,3,4]
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, AR[i][4], 1, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 0, 2, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 3, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - val4[i]) < 1e-4) << val4[i] << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }

  // 1x[2,3,4]
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 1, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 0, 2, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 1, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 3, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 1, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - val4[i]) < 1e-4) << val4[i] << " " << basis1.dotProd(basis2, tabData);
  }
  
  // 2x[3,4]
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, 0, 2, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 3, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, 0, 2, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }

  // 3x4
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, 2, 3, tabData);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
}

void testOblateProd() {
  const double b = 0.9;
  IntTable1DData tabData(b);
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  tab1D.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                        "./Tensor/tables/prolate2D/OblateDotTable.bin",
                                        "./Tensor/tables/prolate2D/prolate2DDot.txt"));
  tabData.setIntTable(tab1D);

  ProlateOblate2D basis1(2, 2, 0, b, false);
  LOG(INFO) << basis1.dotProd(basis1, tabData);
  
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], normTestWn[i][1], 0, b, false);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val5[i]) < 1e-4) << val5[i] << " " << basis1.dotProd(basis1, tabData);
  }
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], normTestWn[i][1], 1, b, false);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val5[i]) < 1e-4) << val5[i] << " " << basis1.dotProd(basis1, tabData);
  }
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], 0, 2, b, false);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val6[i]) < 1e-4) << val6[i] << " " << basis1.dotProd(basis1, tabData);
  }
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], 2, 3, b, false);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val7[i]) < 1e-4) << val7[i] << " " << basis1.dotProd(basis1, tabData);
  }
  for (int i = 0; i < normTestWn.size(); i++) {
    ProlateOblate2D basis1(normTestWn[i][0], 2, 4, b, false);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val7[i]) < 1e-4) << val7[i] << " " << basis1.dotProd(basis1, tabData);
  }

  // 0x[1,2,3,4]
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, AR[i][4], 1, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 0, 2, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 3, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - val8[i]) < 1e-4) << val8[i] << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 0, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }

  // 1x[2,3,4]
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 1, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 0, 2, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 1, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 3, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, AR[i][1], 1, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - val8[i]) < 1e-4) << val8[i] << " " << basis1.dotProd(basis2, tabData);
  }

  // 2x[3,4]
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, 0, 2, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 3, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, 0, 2, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }

  // 3x4
  for (int i = 0; i < AR.size(); i++) {
    ProlateOblate2D basis1(AR[i][0]*2, 2, 3, tabData, false);
    ProlateOblate2D basis2(AR[i][3]*2, 2, 4, tabData, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << 0 << " " << basis1.dotProd(basis2, tabData);
  }
  
}

}; // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  collectPattern();
  //openInnerTable();
  testInnerProd();
  testOblateProd();
  /*double b = 0.6;
  double a = sqrt(1.0-b*b);
  double c = b/sqrt(1.0-b*b);
  VEC3 pos(-1,0,0);
  double r, theta, phi;
  ProlateOblate2D::CatersianToOblate(a, c, pos, r, theta, phi);
  LOG(INFO) << r << " " << theta << " " << phi;*/
  return 0;
}