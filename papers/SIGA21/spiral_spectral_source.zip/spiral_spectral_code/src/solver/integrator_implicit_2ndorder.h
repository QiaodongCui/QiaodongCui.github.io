#ifndef INTEGRATOR_IMPLICIT_2NDORDER_H
#define INTEGRATOR_IMPLICIT_2NDORDER_H
/*
#include <ctf.hpp>
#include <Eigen/Eigen>
#include <vector>

#include "setting.h"

class IntegratorImplicit2ndOrder {
public:
  IntegratorImplicit2ndOrder(){};
  ~IntegratorImplicit2ndOrder(){};
  // This is the method for second order system.
  void IntegrateForward(CTF::Tensor<double>& Q, const Eigen::VectorXd& coefficients_old,
                        const Eigen::VectorXd& coefficients_dot_old, const double dt,
                        Eigen::VectorXd* coefficients_new, Eigen::VectorXd* coefficients_dot_new);
  // This is the method for first order system.
  void IntegrateForward(CTF::Tensor<double>& C, const Eigen::VectorXd& coefficients_old,
                        const double dt, Eigen::VectorXd* coefficients_new);
protected:
};
*/
#endif  // INTEGRATOR_IMPLICIT_2NDORDER_H
