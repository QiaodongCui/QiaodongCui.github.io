#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <omp.h>
#include <vector>

#include "solver/integrator_2d.h"
#include "solver/symmetric_cg.h"
#include "util/timer.h"

void SymmetricCG::IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) {
  Timer timer;
  const int num_basis = coefficients_old.size();
  // Allocate the contracted tensor. Generally, it should be dense.
  Eigen::MatrixXd w_C(num_basis, num_basis);
  w_C.setIdentity();
  Eigen::MatrixXd P(num_basis, num_basis);
  P.setZero();
  Eigen::VectorXd w(num_basis);
  w.setZero();
  w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);
  timer.Reset();
  #pragma omp parallel for
  for (int i = 0; i < num_basis; i++) {
    P.row(i).noalias() = w.transpose() * Adv_tensor[i]; 
  }
  // P = TransferMatrix.transpose() * P;
  *contraction_time = timer.ElapsedTimeInSeconds();
  
  w_C = w_C - P*dt;
  Eigen::DiagonalPreconditioner<Eigen::MatrixXd::RealScalar> precond(w_C);
  int maxIters = 200;
  double tol_error = 1e-10;
  timer.Reset();
  conjugate_gradient_NE(w_C, w_C.transpose()*w, *coefficients_new, precond, maxIters, tol_error);
  *solver_time = timer.ElapsedTimeInSeconds();
  
  // LOG(INFO) << maxIters;
  // LOG(INFO) << tol_error;
  
  //Eigen::VectorXd w_comp(num_basis);
  //Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  //solver.compute(w_C);
  //w_comp = solver.solve(w);
  //*condition_number_ = (w_comp - *coefficients_new).norm();
  
  // LOG(INFO) << "solver time: " << timer.ElapsedTimeInSeconds()
  
  //
  //w_C = w_C*w_C.transpose();
  //Eigen::ConjugateGradient<Eigen::MatrixXd> solver;
  //solver.compute(w_C);
  //(*coefficients_new) = solver.solve(w);
  // LOG(INFO) << "#iterations: " << solver.iterations();
  // LOG(INFO) << "estimated error: " << solver.error();*/
}
