import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt
import struct
import matplotlib.cm as cm 
import sys

idx = 5

def plotDiv():
	fin = open("div.bin", "rb")
	xres = struct.unpack('i', fin.read(4))[0]
	yres = struct.unpack('i', fin.read(4))[0]
	field = np.fromfile(fin, dtype=np.float64, count=xres*yres).reshape([xres, yres])
	x = np.linspace(-1., 1., xres) 
	y = np.linspace(-1., 1., yres) 
	X, Y = np.meshgrid(y, x)
	#plt.axes().set_aspect('equal', 'datalim')
	normalize = matplotlib.colors.Normalize(vmin=field.min(), vmax=field.max())
	plt.pcolormesh(X, Y, field, norm=normalize, cmap = cm.gray) 
	#plt.show()
	plt.savefig("./div.png", bbox_inches='tight')


def main(argv):
	pathF = "./preview/projNew5/"
	if (len(argv) > 0):
		idx = int(argv[0])
	fin = open("full.bin", "rb")
	xres = struct.unpack('i', fin.read(4))[0]
	yres = struct.unpack('i', fin.read(4))[0]
	field = np.fromfile(fin, dtype=np.float64, count=xres*yres).reshape([xres, yres])

	x = np.linspace(-1., 1., xres) 
	y = np.linspace(-1., 1., yres) 
	X, Y = np.meshgrid(x, y)
	plt.axes().set_aspect('equal', 'datalim')
	normalize = matplotlib.colors.Normalize(vmin=field.min(), vmax=field.max())
	plt.pcolormesh(X, Y, field, norm=normalize, cmap = cm.gray) 
	#plt.show()
	plt.savefig(pathF + "full_%d.png" %(idx), bbox_inches='tight')

	fin = open("recon.bin", "rb")
	xres = struct.unpack('i', fin.read(4))[0]
	yres = struct.unpack('i', fin.read(4))[0]
	field = np.fromfile(fin, dtype=np.float64, count=xres*yres).reshape([xres, yres])
	print(field.shape)

	x = np.linspace(-1., 1., xres) 
	y = np.linspace(-1., 1., yres) 
	X, Y = np.meshgrid(x, y)
	plt.axes().set_aspect('equal', 'datalim')
	plt.pcolormesh(X, Y, field, norm=normalize, cmap = cm.gray) 
	#plt.pcolormesh(X, Y, field, cmap = cm.gray) 
	plt.savefig(pathF + "recon_%d.png" %(idx), bbox_inches='tight')

	fin = open("residual.bin", "rb")
	xres = struct.unpack('i', fin.read(4))[0]
	yres = struct.unpack('i', fin.read(4))[0]
	field = np.fromfile(fin, dtype=np.float64, count=xres*yres).reshape([xres, yres])
	print(field.shape)

	x = np.linspace(-1., 1., xres) 
	y = np.linspace(-1., 1., yres) 
	X, Y = np.meshgrid(x, y)
	plt.axes().set_aspect('equal', 'datalim')
	plt.pcolormesh(X, Y, field*30.0, norm=normalize, cmap = cm.gray) 
	#plt.pcolormesh(X, Y, field, cmap = cm.gray) 
	plt.savefig(pathF + "residual_%d.png"%(idx), bbox_inches='tight')
	#plotDiv()

if __name__ == "__main__":
  main(sys.argv[1:])