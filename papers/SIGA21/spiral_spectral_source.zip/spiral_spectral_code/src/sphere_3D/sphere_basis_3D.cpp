#include <Eigen/Eigen>
#include <math.h>

#include "common/basic_function.h"
#include "3D/trig_integral_3d.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "util/transform.h"
#include "util/util.h"

using namespace std;

#define USE_R_WEIGHT
#define USE_SIN_WEIGHT

namespace {
// {SIN, COS, ZERO, ONE};
// int_{phi = 0}^{2 \Pi} type1(i1*\phi) d\phi 
double computePhiOneInt(const FUNTYPE type1, const int i1) {
  if (type1 == SIN || type1 == ZERO)
    return 0;
  else if (type1 == COS)
    return i1 == 0 ? 2.0*M_PI : 0;
  else if (type1 == ONE)
    return 2.0*M_PI;

  LOG(FATAL) << "unsupported type";
  return 0.0;
};

// {SIN, COS, ZERO, ONE};
// int_{\theta = 0}^{Pi} fun1*sin(\theta) d\theta 
double computeThetaOneInt(const BasicFunc& fun1) {
  if (fun1.type == ZERO)
    return 0;
  else if (fun1.type == ONE)  // int_{t = 0}^{Pi} sin(t) dt = 2.0
    return fun1.coef*2.0;
  else if (fun1.type == COS)  // cos(i1 t)sin(t) -> sin
    return fun1.coef*0.5*(-IntegralSinInt(fun1.wnx2/2 - 1) + IntegralSinInt(fun1.wnx2/2 + 1));
  else if (fun1.type == SIN)  // sin(i1 t)sin(t) -> cos
    return fun1.coef*0.5*(IntegralCosInt(fun1.wnx2/2 + 1) - IntegralCosInt(fun1.wnx2/2 + 1));

  LOG(FATAL) << "unsupported type";
  return 0.0;  
};

// {SIN, COS, ZERO, ONE};
// int_{r = 0}^{1} fun1*r^2 dr 
double computeROneInt(const BasicFunc& fun1) {
  CHECK(fun1.dir == R);

  BasicFunc fr2(fun1);
  fr2.rPower += 2;
  return fr2.integrate();
};

};

void SphereBasis3D::initBasicCoef() {
  double invk2 = 1.0;
  if (k2x2 != 0)
    invk2 = 1.0/k2;
  double invk3 = 1.0;
  if (k3x2 != 0)
    invk3 = 1.0/k3;

  // seee from basisAnalysis_3D.pdf in the doc
  switch (index_) {
    // two regular basis
    case 0:
            phiFunc_[0] = BasicFunc(SIN, P, k3x2, 1);
            phiFunc_[1] = BasicFunc(SIN, P, k3x2, -invk2);
            phiFunc_[2] = BasicFunc(COS, P, k3x2, -invk2*invk3);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0);
    break;
  
    case 1:
            phiFunc_[0] = BasicFunc(COS, P, k3x2, 1);
            phiFunc_[1] = BasicFunc(COS, P, k3x2, -invk2);
            phiFunc_[2] = BasicFunc(SIN, P, k3x2, invk2*invk3);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0);
    break;
    // enrich along pole line
    case 2:
            phiFunc_[0] = BasicFunc(SIN, P, 2, 1);
            phiFunc_[1] = BasicFunc(SIN, P, 2, invk2);
            phiFunc_[2] = BasicFunc(COS, P, 2, invk2);
            CHECK(k1x2 > 0 && k2x2 >= 0 && k3x2 == 2);
    break;
    
    case 3:
            phiFunc_[0] = BasicFunc(COS, P, 2, 1);
            phiFunc_[1] = BasicFunc(COS, P, 2, invk2);
            phiFunc_[2] = BasicFunc(SIN, P, 2, -invk2);
            CHECK(k1x2 > 0 && k2x2 >= 0 && k3x2 == 2);
    break;

    // enrich at the center
    case 4:
            phiFunc_[0] = BasicFunc(ONE, P, 0, 1);
            phiFunc_[1] = BasicFunc(ONE, P, 0, 1);
            phiFunc_[2] = BasicFunc(ZERO, P, 0, 0);
            CHECK(k1x2 >= 0 && k2x2 == 0 && k3x2 == 0);
    break;

    case 5:
            phiFunc_[0] = BasicFunc(SIN, P, 2, 1);
            phiFunc_[1] = BasicFunc(SIN, P, 2, 1);
            phiFunc_[2] = BasicFunc(COS, P, 2, 1);
            CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 == 2);
    break;

    case 6:
            phiFunc_[0] = BasicFunc(COS, P, 2, 1);
            phiFunc_[1] = BasicFunc(COS, P, 2, 1);
            phiFunc_[2] = BasicFunc(SIN, P, 2, -1);
            CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 == 2);
    break;

    // a special one
    case 7:
            phiFunc_[0] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[1] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[2] = BasicFunc(ONE, P, 0, 1);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 == 0);
    break;

    case 8:
            phiFunc_[0] = BasicFunc(SIN, P, k3x2, 1);
            phiFunc_[1] = BasicFunc(SIN, P, k3x2, invk2);
            phiFunc_[2] = BasicFunc(COS, P, k3x2, invk2*invk3);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0); 
    break;

    case 9:
            phiFunc_[0] = BasicFunc(COS, P, k3x2, 1);
            phiFunc_[1] = BasicFunc(COS, P, k3x2, invk2);
            phiFunc_[2] = BasicFunc(SIN, P, k3x2, -invk2*invk3);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0);
    break;

    default:
    LOG(FATAL) << "idx " << index_ << "not supported";
  };

  if (index_ == 0 || index_ == 1) {  // shares expression
    RTMultiply r0;
    RTMultiply t0;
    RTMultiply p0;
    #ifdef USE_SIN_WEIGHT
    	// sin(pi/2*r)*sin(i1*Pi*r)
    	r0.rComp = {BasicFunc(COS, R, k1x2 - 1, 0.5), BasicFunc(COS, R, k1x2 + 1, -0.5)};
    	// r*pi*i1*sin(pi/2 r) cos(i1 pi r)
    	// pi/2*cos(pi/2 r)sin(i1 pi r)
    	// 2 sin(pi/2*r)*sin(i1*Pi*r)
    	t0.rComp = {BasicFunc(SIN, R, k1x2 + 1, M_PI*k1*0.5, 1), BasicFunc(SIN, R, k1x2 - 1, -M_PI*k1*0.5, 1),
    							BasicFunc(SIN, R, k1x2 + 1, 0.25*M_PI, 1), BasicFunc(SIN, R, k1x2 - 1, 0.25*M_PI, 1),
    							BasicFunc(COS, R, k1x2 - 1, 1.0), BasicFunc(COS, R, k1x2 + 1, -1.0)};

	    p0.rComp = t0.rComp;
    #else
			#ifdef USE_R_WEIGHT
			    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0, 1)};
			    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 2), BasicFunc(SIN, R, k1x2, 3.0, 1)};
			    p0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 2), BasicFunc(SIN, R, k1x2, 3.0, 1)};
			#else
			    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
			    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 2.0)};
			    p0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 2.0)};
			#endif
		#endif

    r0.tComp = {BasicFunc(SIN, T, k2x2-2, -0.5), BasicFunc(SIN, T,k2x2+2, 0.5)};
    t0.tComp = {BasicFunc(COS, T, k2x2-2,0.5), BasicFunc(COS,T, k2x2+2, -0.5)};
    p0.tComp = {BasicFunc(COS, T, k2x2-4,0.5), BasicFunc(COS,T,k2x2+4,-0.5)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 2 || index_ == 3) { // shares expression
    RTMultiply r0;
    RTMultiply t0;
    RTMultiply p0;
    #ifdef USE_SIN_WEIGHT
    	// sin(pi/2*r)*sin(i1*Pi*r)
    	r0.rComp = {BasicFunc(COS, R, k1x2 - 1, 0.5), BasicFunc(COS, R, k1x2 + 1, -0.5)};
    	// r*pi*i1*sin(pi/2 r) cos(i1 pi r)
    	// pi/2*cos(pi/2 r)sin(i1 pi r)
    	// 2 sin(pi/2*r)*sin(i1*Pi*r)
    	t0.rComp = {BasicFunc(SIN, R, k1x2 + 1, M_PI*k1*0.5, 1), BasicFunc(SIN, R, k1x2 - 1, -M_PI*k1*0.5, 1),
    							BasicFunc(SIN, R, k1x2 + 1, 0.25*M_PI, 1), BasicFunc(SIN, R, k1x2 - 1, 0.25*M_PI, 1),
    							BasicFunc(COS, R, k1x2 - 1, 1.0), BasicFunc(COS, R, k1x2 + 1, -1.0)};

	    p0.rComp = t0.rComp;
    #else
			#ifdef USE_R_WEIGHT
		    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0, 1)};
		    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 2), BasicFunc(SIN, R, k1x2, 3.0, 1)};
		    p0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 2), BasicFunc(SIN, R, k1x2, 3.0, 1)};
			#else
		    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
		    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 2.0)};
		    p0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 2.0)};
			#endif
    #endif

    r0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
    t0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
    p0.tComp = {BasicFunc(COS, T, k2x2-2, 0.5), BasicFunc(COS,T, k2x2+2, 0.5)};
    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 4) {
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(COS, T, 2, 1.0)};
  
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, -1.0), BasicFunc(SIN, R, k1x2, 0.5*k1*M_PI, 1)};
    t0.tComp = {BasicFunc(SIN, T, 2, 1.0)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {};
  } else if (index_ == 5 || index_ == 6) {
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, 2, 1.0)};
    
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(SIN, R, k1x2, -k1*M_PI, 1)};
    t0.tComp = {BasicFunc(COS, T, 2, 1.0)};
    
    RTMultiply p0, p1;
    p0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    p0.tComp = {BasicFunc(ONE, T, 2, 1.0)};
    p1.rComp = {BasicFunc(SIN, R, k1x2, -k1*M_PI, 1)};
    p1.tComp = {BasicFunc(COS, T, 4, 0.5), BasicFunc(ONE, T, 2, 0.5)};
  
    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0, p1};
  } else if (index_ == 7) {
    
    RTMultiply p0;

#ifdef USE_SIN_WEIGHT
  p0.rComp = {BasicFunc(COS, R, k1x2 - 1, 0.5), BasicFunc(COS, R, k1x2 + 1, -0.5)};
#else
	#ifdef USE_R_WEIGHT
	    p0.rComp = {BasicFunc(SIN, R, k1x2, 1.0, 1)};
	#else
	    p0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
	#endif
#endif

    p0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RT_[0] = {}; RT_[1] = {}; RT_[2] = {p0};
  } else if (index_ == 8 || index_ == 9) {
    
    RTMultiply r0;
    RTMultiply t0;
    RTMultiply p0;
    // sin(pi/2*r)*sin(i1*Pi*r)
    r0.rComp = {BasicFunc(COS, R, k1x2 - 1, 0.5), BasicFunc(COS, R, k1x2 + 1, -0.5)};
    // r*pi*i1*sin(pi/2 r) cos(i1 pi r)
    // pi/2*cos(pi/2 r)sin(i1 pi r)
    // 2 sin(pi/2*r)*sin(i1*Pi*r)
    t0.rComp = {BasicFunc(SIN, R, k1x2 + 1, M_PI*k1*0.5, 1), BasicFunc(SIN, R, k1x2 - 1, -M_PI*k1*0.5, 1),
                BasicFunc(SIN, R, k1x2 + 1, 0.25*M_PI, 1), BasicFunc(SIN, R, k1x2 - 1, 0.25*M_PI, 1),
                BasicFunc(COS, R, k1x2 - 1, 1.0), BasicFunc(COS, R, k1x2 + 1, -1.0)};

    p0.rComp = t0.rComp;

    r0.tComp = {BasicFunc(COS, T, k2x2-2, 0.5), BasicFunc(COS, T,k2x2+2, -0.5)};
    t0.tComp = {BasicFunc(SIN, T, k2x2-2, -0.5), BasicFunc(SIN, T,k2x2+2, 0.5)};
    p0.tComp = {BasicFunc(SIN, T, k2x2-4, -0.5), BasicFunc(SIN, T, k2x2+4, 0.5)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else {
    LOG(FATAL) << "idx " << index_ << "not supported";
  }
}

#define Cos cos
#define Sin sin
#define Pi M_PI
#define i3 k3
#define i2 k2
#define i1 k1

#define FR (i1*Pi*r*Cos(i1*Pi*r)*Sin((Pi*r)/2.) + ((Pi*r*Cos((Pi*r)/2.))/2. + 2*Sin((Pi*r)/2.))*Sin(i1*Pi*r))

#ifdef USE_SIN_WEIGHT

  #define PHI0 Sin((Pi*r)*0.5)*Sin(i1*Pi*r)*Cos(i2*t)*Sin(i3*p)*Sin(t),\
               -invk2*FR*Sin(i3*p)*Sin(t)*Sin(i2*t),\
               -invk2*invk3*FR*Cos(i3*p)*Sin(2*t)*Sin(i2*t)

	#define PHI1 Sin((Pi*r)*0.5)*Cos(i3*p)*Cos(i2*t)*Sin(i1*Pi*r)*Sin(t),\
	             -invk2*Cos(i3*p)*FR*Sin(t)*Sin(i2*t),\
	              invk2*invk3*Sin(i3*p)*FR*Sin(2*t)*Sin(i2*t)
	
	#define PHI2 Sin((Pi*r)*0.5)*Sin(p)*Sin(i1*Pi*r)*Sin(i2*t),\
	             invk2*Cos(i2*t)*Sin(p)*FR,\
	             invk2*Cos(p)*Cos(t)*Cos(i2*t)*FR

  #define PHI3 Sin((Pi*r)*0.5)*Cos(p)*Sin(i1*Pi*r)*Sin(i2*t),\
               invk2*Cos(p)*Cos(i2*t)*FR,\
               -invk2*Cos(t)*Cos(i2*t)*Sin(p)*FR
	
	#define PHI7 0,\
               0,\
               Sin((Pi*r)*0.5)*Sin(i1*Pi*r)*Sin(i2*t)

  #define PHI8 Sin((Pi*r)*0.5)*Sin(i1*Pi*r)*Sin(i2*t)*Sin(i3*p)*Sin(t),\
               invk2*FR*Sin(i3*p)*Sin(t)*Cos(i2*t),\
               invk2*invk3*FR*Cos(i3*p)*Sin(2*t)*Cos(i2*t)

  #define PHI9 Sin((Pi*r)*0.5)*Cos(i3*p)*Sin(i2*t)*Sin(i1*Pi*r)*Sin(t),\
               invk2*Cos(i3*p)*FR*Sin(t)*Cos(i2*t),\
               -invk2*invk3*Sin(i3*p)*FR*Sin(2*t)*Cos(i2*t)

#else

	#ifdef USE_R_WEIGHT

	  #define PHI0 r*Cos(i2*t)*Sin(i3*p)*Sin(i1*Pi*r)*Sin(t),\
	               -invk2*r*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t),\
	               -invk2*invk3*(r*Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t))

	  #define PHI1 r*Cos(i3*p)*Cos(i2*t)*Sin(i1*Pi*r)*Sin(t),\
	               -invk2*r*Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t),\
	               invk2*invk3*r*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t)

	  #define PHI2 r*Sin(p)*Sin(i1*Pi*r)*Sin(i2*t),\
	               invk2*r*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)),\
	               invk2*r*Cos(p)*Cos(t)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))

	  #define PHI3 r*Cos(p)*Sin(i1*Pi*r)*Sin(i2*t),\
	               invk2*r*Cos(p)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)),\
	               -invk2*(r*Cos(t)*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)))
	 
	  #define PHI7 0,\
	               0,\
	               r*Sin(i1*Pi*r)*Sin(i2*t)

	#else

	  #define PHI0 Cos(i2*t)*Sin(i3*p)*Sin(i1*Pi*r)*Sin(t),\
	               -invk2*(Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t)),\
	               -invk2*invk3*(Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t))

	  #define PHI1 Cos(i3*p)*Cos(i2*t)*Sin(i1*Pi*r)*Sin(t),\
	               -invk2*(Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t)),\
	               invk2*invk3*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t)

	  #define PHI2 Sin(p)*Sin(i1*Pi*r)*Sin(i2*t),\
	               invk2*(Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r))),\
	               invk2*Cos(p)*Cos(t)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r))

	  #define PHI3 Cos(p)*Sin(i1*Pi*r)*Sin(i2*t),\
	               invk2*Cos(p)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r)),\
	               -invk2*(Cos(t)*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 2*Sin(i1*Pi*r)))

	  #define PHI7 0,\
	               0,\
	               Sin(i1*Pi*r)*Sin(i2*t)
	#endif

#endif

#define PHI4 Cos(i1*Pi*r)*Cos(t),\
             (-Cos(i1*Pi*r) + (i1*Pi*r*Sin(i1*Pi*r))*0.5)*Sin(t),\
             0

#define PHI5 Cos(i1*Pi*r)*Sin(p)*Sin(t),\
             Cos(t)*Sin(p)*(Cos(i1*Pi*r) - i1*Pi*r*Sin(i1*Pi*r)),\
             Cos(p)*(Cos(i1*Pi*r) - i1*Pi*r*Cos(t)*Cos(t)*Sin(i1*Pi*r))

#define PHI6 Cos(p)*Cos(i1*Pi*r)*Sin(t),\
             Cos(p)*Cos(t)*(Cos(i1*Pi*r) - i1*Pi*r*Sin(i1*Pi*r)),\
             Sin(p)*(-Cos(i1*Pi*r) + i1*Pi*r*Cos(t)*Cos(t)*Sin(i1*Pi*r))

#define computeBasis switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4;\
          break;\
\
          case 5:\
            v << PHI5;\
          break;\
\
          case 6:\
            v << PHI6;\
          break;\
\
          case 7:\
            v << PHI7;\
          break;\
\
          case 8:\
            v << PHI8;\
          break;\
\
          case 9:\
            v << PHI9;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }

void SphereBasis3D::DiscretizeAdd(const double coef, FIELD_3D& radius, FIELD_3D& theta, FIELD_3D& phi,
            VECTOR3_FIELD_3D* vfield) {
  
  //double dx = 2.0 / vfield->xRes();
  //double dy = 2.0 / vfield->yRes();
  //double dz = 2.0 / vfield->zRes();
  Eigen::Matrix3d trans;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < vfield->zRes(); k++)
    for (int j = 0; j < vfield->yRes(); j++)
      for (int i = 0; i < vfield->xRes(); i++) {

        double r = radius(i,j,k);
        double t = theta(i,j,k);
        double p = phi(i,j,k);

        if (r > 1.0)
          continue;
        //r *= M_PI;

        Eigen::Vector3d v;
        v.setZero();
        computeBasis;

        Transform::Spherical::toCartesianMat(t,p, trans);
        Eigen::Vector3d uCartesian = invNorm_*coef*trans*v;
        (*vfield)(i,j,k)[0] = uCartesian[0];
        (*vfield)(i,j,k)[1] = uCartesian[1];
        (*vfield)(i,j,k)[2] = uCartesian[2];
      }
}

// compute on a spherical grid.
void SphereBasis3D::AddUniformU(const double coef, const int nR, const int nTheta,
                                const int nPhi, double* ur, double* ut, double* up) const {
  double dR = 1.0 / nR;
  double dT = M_PI / nTheta;
  double dP = 2.0*M_PI/nPhi;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nPhi; i++) {
        
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-pi]
        double p = ((double)(i) + 0.5)*dP; // [0, 2*pi]

        //r *= M_PI;
        Eigen::Vector3d v;
        v.setZero();
        computeBasis;
        v *= coef*invNorm_;
        int idx = i + j*nPhi + k*nPhi*nTheta;
        ur[idx] += v[0];
        ut[idx] += v[1];
        up[idx] += v[2];
      }
    }
  }
}

double SphereBasis3D::ProjectUniformU(const int nR, const int nTheta, const int nPhi,
                                      const double* fr, const double* ft, const double* fp) const {
  double dR = 1.0 / nR;
  double dT = M_PI / nTheta;
  double dP = 2.0*M_PI/nPhi;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;
  double result = 0;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nPhi; i++) {
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-pi]
        double p = ((double)(i) + 0.5)*dP; // [0, 2*pi]

        //r *= M_PI;
        Eigen::Vector3d v;
        v.setZero();
        computeBasis;
        // v *= coef*invNorm_;
        int idx = i + j*nPhi + k*nPhi*nTheta;
        result += v[0]*fr[idx] + v[1]*ft[idx] + v[2]*fp[idx];
      }
    }
  }
  result *= invNorm_;
  result *= dR*dT*dP;

  return result;
}

#undef i3
#undef i2
#undef i1

// {SIN, COS, ZERO, ONE};
// int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
double SphereBasis3D::computePhiInt(const BasicFunc& fun1, const BasicFunc& fun2) {
 
  vector<BasicFunc> mult = BasicFunc::multiply(fun1, fun2);
  double result = 0;
  for (auto& f : mult) {
    result += f.integrate();
  }
  return result;
}

// enum FUNTYPE {SIN, COS, ZERO, ONE};
// int_{\theta = 0}^{Pi} fun1*fun2*sin(\theta) d\theta 
double SphereBasis3D::computeThetaInt(const BasicFunc& fun1, const BasicFunc& fun2) {
  CHECK(fun1.dir == T && fun2.dir == T);

  BasicFunc sinT(SIN, T, 2, 1.0);
  vector<BasicFunc> addVec = BasicFunc::multToAdd({fun1, fun2, sinT}, 0);
  double result = 0;

  for (const auto& f : addVec) {
    result += f.integrate();
  }

  return result;
}

double SphereBasis3D::computeThetaInt(const BasicFunc& fun1) {
  CHECK(fun1.dir == T);

  BasicFunc sinT(SIN, T, 2, 1.0); // jacobian
  vector<BasicFunc> addVec = BasicFunc::multiply(fun1, sinT);
  double result = 0;

  for (const auto& f : addVec) {
    result += f.integrate();
  }

  return result;
}

// {SIN, COS, ZERO, ONE};
// int_{r = 0}^{1} fun1*fun2*r^2 dr 
double SphereBasis3D::computeRInt(const BasicFunc& fun1, const BasicFunc& fun2) {
  CHECK(fun1.dir == R && fun2.dir == R);

  vector<BasicFunc> mult = BasicFunc::multiply(fun1, fun2);
  double result = 0;
  for (auto& f : mult) {
    f.rPower += 2;  // jacobian
    result += f.integrate();
  }
  return result;
}

double SphereBasis3D::computeRInt(const BasicFunc& fun1) {
  CHECK(fun1.dir == R);
  BasicFunc fcpy = fun1;
  fcpy.rPower += 2;  // jacobian
  return fcpy.integrate();
}

// (vector of sum)*(vector of sum)
double SphereBasis3D::computeVThetaInt(const vector<BasicFunc>& t1, const vector<BasicFunc>& t2) {
  double result = 0;
  for (const auto& fun1 : t1)
    for (const auto& fun2 : t2)
      result += computeThetaInt(fun1, fun2);

  return result;
}

// (vector of sum)*(vector of sum)
double SphereBasis3D::computeVRInt(const vector<BasicFunc>& r1, const vector<BasicFunc>& r2) {
  double result = 0;
  for (const auto& fun1 : r1)
    for (const auto& fun2: r2)
      result += computeRInt(fun1, fun2);

  return result;
}

double SphereBasis3D::computeRTMultInt(const RTMultiply& rt1) {
  double thetaInt = 0;
  for (const auto& fun1 : rt1.tComp)
    thetaInt += computeThetaInt(fun1);

  double rInt = 0;
  for (const auto& fun1 : rt1.rComp)
    rInt += computeRInt(fun1);

  return thetaInt*rInt;
}

Eigen::Vector3d SphereBasis3D::computeRTP(const SphereBasis3D& other) const {
  Eigen::Vector3d result(0,0,0);

  for (int i = 0; i < 3; i++) {
    // <phi_i, phi_i>    
    double pINT = computePhiInt(phiFunc_[i], other.getPhiFunc(i));
    //LOG(INFO) << k3x2/2;

    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and phi.
      double rtINT = 0;
      vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
      for (const auto& rt1 : RTProd)
        rtINT += computeRTMultInt(rt1);

      result[i] = pINT*rtINT;
    }
  }

  return result;
}

double SphereBasis3D::dotProd(const SphereBasis3D& other) const {
  //LOG(INFO) << computeRTP(other);
  return computeRTP(other).sum();
}

void SphereBasis3D::Normalize() {
  norm2_ = dotProd(*this);
  invNorm_ = 1.0/sqrt(norm2_);
}
// This includes r^2 sin(t) term in integral, please refer to basisAnalysis_3DTensor.pdf
// this does not include the norm
void SphereBasis3D::curlSph() {
  
  // sign is grouped into phi func
  curlPhi_[0][0] = phiFunc_[2];
  curlPhi_[0][1] = phiFunc_[2];
  curlPhi_[0][2] = -phiFunc_[1].deriv()[0];
  curlPhi_[1][0] = phiFunc_[0].deriv()[0];
  curlPhi_[1][1] = -phiFunc_[2];
  curlPhi_[1][2] = -phiFunc_[2];
  curlPhi_[2][0] = phiFunc_[1];
  curlPhi_[2][1] = phiFunc_[1];
  curlPhi_[2][2] = -phiFunc_[0];

  // cos(theta), sin(theta)
  BasicFunc cosT(COS, T, 2, 1.0, 0);
  BasicFunc sinT(SIN, T, 2, 1.0, 0);
  
  // r sin(T) D[A_p, t]
  curlRT_[0][0] = RT_[2];
  RTMultiply::derivTVec(curlRT_[0][0]);
  RTMultiply::multRVec(1, curlRT_[0][0]);
  RTMultiply::multThetaVec(sinT, curlRT_[0][0]);
  // r cos(T)A_p
  curlRT_[0][1] = RT_[2];
  RTMultiply::multRVec(1, curlRT_[0][1]);
  RTMultiply::multThetaVec(cosT, curlRT_[0][1]);
  // -rD[A_t, p]
  curlRT_[0][2] = RT_[1];
  RTMultiply::multRVec(1, curlRT_[0][2]);

  // rD[A_r, p]
  curlRT_[1][0] = RT_[0];
  RTMultiply::multRVec(1, curlRT_[1][0]);
  // -rsin(T)A_p
  curlRT_[1][1] = RT_[2];
  RTMultiply::multRVec(1, curlRT_[1][1]);
  RTMultiply::multThetaVec(sinT, curlRT_[1][1]);
  // -r^2sin(T)D[A_p, r]
  curlRT_[1][2] = RT_[2];
  RTMultiply::derivRVec(curlRT_[1][2]);
  RTMultiply::multRVec(2, curlRT_[1][2]);
  RTMultiply::multThetaVec(sinT, curlRT_[1][2]);

  // rsin(T)A_t
  curlRT_[2][0] = RT_[1];
  RTMultiply::multRVec(1, curlRT_[2][0]);
  RTMultiply::multThetaVec(sinT, curlRT_[2][0]);
  // r^2sin(T)D[A_t, r]
  curlRT_[2][1] = RT_[1];
  RTMultiply::derivRVec(curlRT_[2][1]);
  RTMultiply::multRVec(2, curlRT_[2][1]);
  RTMultiply::multThetaVec(sinT, curlRT_[2][1]);
  // -rsin(T)D[A_r, t]
  curlRT_[2][2] = RT_[0];
  RTMultiply::derivTVec(curlRT_[2][2]);
  RTMultiply::multRVec(1, curlRT_[2][2]);
  RTMultiply::multThetaVec(sinT, curlRT_[2][2]);

  //curlPhi_[2][2].print();
  //exit(0);
}

#include "sphere_3D/sphereLapDot1.txt"
#define CosInvT IntegralSinInvCosT
#define SinInvT IntegralSinInvSinT
#define CosT IntegralC_D2
#define SinT IntegralS_D2
#define CosR BasicFunc::computeRCOS
#define SinR BasicFunc::computeRSIN
#define CosP IntegrateCos2Pi_D2
#define SinP IntegrateSin2Pi_D2

double SphereBasis3D::LaplacianDot(const SphereBasis3D& other) const {
  double val = 0;
  const int i1x2 = this->WN1x2();
  const int i2x2 = this->WN2x2();
  const int i3x2 = this->WN3x2();

  const int j1x2 = other.WN1x2();
  const int j2x2 = other.WN2x2();
  const int j3x2 = other.WN3x2();

  const double i1 = this->WN1D();
  const double i2 = this->WN2D();
  const double i3 = this->WN3D();
  
  const double j1 = other.WN1D();
  const double j2 = other.WN2D();
  const double j3 = other.WN3D();

  val = LAPLACIANDOT1;

  return val;
}

#undef CosInvT
#undef SinInvT
#undef CosR
#undef SinR
#undef CosP
#undef CosT
#undef SinT

// This also doesnt include norm
// a2 b3 - a3 b2
// a3 b1 - a1 b3
// a1 b2 - a2 b1
void SphereBasis3D::crossProdPhi(const SphereBasis3D& phiG, const SphereBasis3D& phiH,
                                 vector<BasicFunc> (&crossPhi)[3][2]) {
  crossPhi[0][0] = BasicFunc::multiply(phiG.getPhiFunc(1), phiH.getPhiFunc(2));
  crossPhi[0][1] = BasicFunc::multiply(phiG.getPhiFunc(2), -phiH.getPhiFunc(1));
  crossPhi[1][0] = BasicFunc::multiply(phiG.getPhiFunc(2), phiH.getPhiFunc(0));
  crossPhi[1][1] = BasicFunc::multiply(phiG.getPhiFunc(0), -phiH.getPhiFunc(2));
  crossPhi[2][0] = BasicFunc::multiply(phiG.getPhiFunc(0), phiH.getPhiFunc(1));
  crossPhi[2][1] = BasicFunc::multiply(phiG.getPhiFunc(1), -phiH.getPhiFunc(0));
}

// This also doesnt include norm
// These doesnt include the sin(t) weight included in integral, the term is baked into curl.
// sign is in phi component.
// (crossPhi[0][0])*(crossRT[0][0]);
// 
void SphereBasis3D::crossProdRT(const SphereBasis3D& phiG, const SphereBasis3D& phiH,
                                vector<RTMultiply> (&crossRT)[3][2]) {
  crossRT[0][0] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(2));
  crossRT[0][1] = RTMultiply::multV(phiG.getRT(2), phiH.getRT(1));
  crossRT[1][0] = RTMultiply::multV(phiG.getRT(2), phiH.getRT(0));
  crossRT[1][1] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(2));
  crossRT[2][0] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(1));
  crossRT[2][1] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(0));
}

double SphereBasis3D::integrateCurlCross(const BasicFunc& curlP, const vector<BasicFunc>& crossP,
                                         const vector<RTMultiply>& curlRT, const vector<RTMultiply>& crossRT) {
  // first integrate along phi.
  // int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += computePhiInt(curlP, cp);
  if (fabs(phiInt) < 1e-14)
    return 0.0;
  // integrate along theta, without sin(t) term, because its already in curl.
  double rtInt = 0;
  vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  for (const auto& rt : RTProd) {
    double tInt = rt.integrateT();
    if (fabs(tInt) < 1e-14)  // prod is zero.
      continue;
    double rInt = rt.integrateR();
    rtInt += tInt*rInt;
  }

  return phiInt*rtInt;
}

double SphereBasis3D::computeTensorEntry(const SphereBasis3D& phiI, const SphereBasis3D& phiG,
                                         const SphereBasis3D& phiH) {
  // compute cross product.
  vector<BasicFunc> crossPhi[3][2];
  vector<RTMultiply> crossRT[3][2];
  SphereBasis3D::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis3D::crossProdRT(phiG, phiH, crossRT);

  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 3; ind++) {
    rVal += integrateCurlCross(phiI.getCurPhi(0,ind), crossPhi[0][0], phiI.getCurRT(0,ind), crossRT[0][0]);
    rVal += integrateCurlCross(phiI.getCurPhi(0,ind), crossPhi[0][1], phiI.getCurRT(0,ind), crossRT[0][1]);
  }

  // t component.
  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_t * {phi_g \times phi_h}_t d omega
  double tVal = 0;
  for (int ind = 0; ind < 3; ind++) {
    tVal += integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][0], phiI.getCurRT(1,ind), crossRT[1][0]);
    tVal += integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][1], phiI.getCurRT(1,ind), crossRT[1][1]);
  }

  // p component.
  double pVal = 0;
  for (int ind = 0; ind < 3; ind++) {
    pVal += integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][0], phiI.getCurRT(2,ind), crossRT[2][0]);
    pVal += integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][1], phiI.getCurRT(2,ind), crossRT[2][1]);
  }

  return (rVal + tVal + pVal)*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
}

void SphereBasis3D::writeToFile(std::ofstream& out) const {
  out.write(reinterpret_cast<const char *>(&k1x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k2x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k3x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&index_), sizeof(int));
}

SphereBasis3D* SphereBasis3D::fromFile(std::ifstream& in) {
  int k1x2, k2x2, k3x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k3x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));

  return new SphereBasis3D(k1x2, k2x2, k3x2, index_);
}

void SphereBasis3D::FillFields(FIELD_3D& rad, FIELD_3D& theta, FIELD_3D& phi) {
  double dx = 2.0 / rad.xRes();
  double dy = 2.0 / rad.yRes();
  double dz = 2.0 / rad.zRes();

  for (int k = 0; k < rad.zRes(); k++)
    for (int j = 0; j < rad.yRes(); j++)
      for (int i = 0; i < rad.xRes(); i++) {
        Eigen::Vector3d pos(((double)(i) + 0.5)*dx - 1.0 , ((double)(j) + 0.5)*dx - 1.0,
                 ((double)(k) + 0.5)*dx - 1.0 );  // [-1, 1]^3
        Eigen::Vector3d sphCord = Transform::Spherical::toSpherical(pos);
        rad(i,j,k) = sphCord[0];
        theta(i,j,k) = sphCord[1];
        phi(i,j,k) = sphCord[2];
      }
}