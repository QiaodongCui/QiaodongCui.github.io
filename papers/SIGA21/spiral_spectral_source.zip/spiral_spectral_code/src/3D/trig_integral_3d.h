#ifndef TRIG_INTEGRAL_3D_H
#define TRIG_INTEGRAL_3D_H

#include <math.h>

// Compute the integral, index 6: 
// \int_{0}^{\pi}cos(i1*x)cos(mx)dx * 
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralCSS(const int i1, const int i2, const int i3,
                          const int m, const int n, const int l);

// Compute the integral, index 5: 
// \int_{0}^{\pi}sin(i1*x)sin(mx)dx * 
// \int_{0}^{\pi}cos(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralSCS(const int i1, const int i2, const int i3,
                          const int m, const int n, const int l);

// Compute the integral, index 4: 
// \int_{0}^{\pi}sin(i1*x)sin(mx)dx * 
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)cos(lz)dz
double ComputeIntegralSSC(const int i1, const int i2, const int i3,
                          const int m, const int n, const int l);
// Compute integral, SSS dot with CSS.
// \int_{0}^{\pi}sin(i1*x)cos(mx)dx *
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralSSSCSS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);
// Compute integral, CCS dot with SCS.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}cos(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralCCSSCS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);
// Compute integral, CSC dot with SSC.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)cos(lz)dz
double ComputeIntegralCSCSSC(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);

// Compute integral, SSC 4 dot with CSS 6.
// \int_{0}^{\pi}sin(i1*x)cos(mx)dx *
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralSSCCSS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);
// 6 with 4.
double ComputeIntegralCSSSSC(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) ;
                             
// Compute integral, CCC dot with SCS.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}cos(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralCCCSCS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);

// Compute integral, SCC 1 dot with CSS 6.
// \int_{0}^{\pi}sin(i1*x)cos(mx)dx *
// \int_{0}^{\pi}cos(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralSCCCSS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);

// Compute integral, CSC 2 dot with SCS 5.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}sin(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralCSCSCS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);

// Compute integral, CCS 3 dot with SSC 4.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}cos(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)cos(lz)dz
double ComputeIntegralCCSSSC(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l);

// Compute the integral, index 6: 
// \int_{0}^{\pi}cos((i1)*x)cos(mx)dx * 
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralCSSDOUBLE(const double i1, const int i2, const int i3,
                              const double m,
                              const int n, const int l);
// Compute the integral, index 5: 
// \int_{0}^{\pi}sin((i1)*x)sin(mx)dx * 
// \int_{0}^{\pi}cos(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralSCSDOUBLE(const double i1, const int i2, const int i3,
                          const double m, const int n, const int l);
// Compute the integral, index 4: 
// \int_{0}^{\pi}sin((i1)*x)sin(mx)dx * 
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)cos(lz)dz
double ComputeIntegralSSCDOUBLE(const double i1, const int i2, const int i3,
                          const double m, const int n, const int l);

// Used by 2D
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy
double ComputeIntegralCSSS(const int i1, const int i2, const int m, const int n);

// polar
// \int_{0}{1}cos(i1\pi r)*sin(g1 \pi r)*sin(h1 \pi r) dr =
// \frac{1}{\pi}\int_{0]{\pi} cos(i1 r) sin(g1 r) sin(h1 r) dr
double ComputeIntegralCSS(const int i1, const int g1, const int h1);

// \int_{0}{1} sin(i1\pi r)*sin(g1\pi r)*cos(h1\pi r) dr =
// \frac{1}{\pi} \int_{0}{\pi} sin(i1 y)*sin(g1 y)*cos(h1 y) dy =
// \frac{1}{4 \pi} \int_{0}{\pi}C{+--}-C{++-}+C{+-+}-C{+++} dy
double ComputeIntegralSSC(const int i1, const int g1, const int h1);

// \int_{0}{1} cos(i1\pi r)*cos(g1\pi r)*sin(h1\pi r) dr =
// \frac{1}{\pi} \int_{0}{\pi} cos(i1 y)*cos(g1 y)*sin(h1 y) dy =
// \frac{1}{4 \pi} \int_{0}{\pi} -S{+--} -S{++-} +S{+-+} +S{+++} dy
double ComputeIntegralCCS_D2(const int ix2, const int gx2, const int hx2);

// input is twice of the wavenumber.
// \int_{0}{1} sin(i1\pi r)*cos(g1\pi r)*cos(h1\pi r) dr = 
// \frac{1}{\pi} \int_{0}{1} sin(i1 y)*cos(g1 y)*cos(h1 y) dy =
// \frac{1}{4 \pi} \int_{0}{1} S{+--} + S{++-} + S{+-+} + S_{+++} dy 
double ComputeIntegralSCC_D2(const int ix2, const int gx2, const int hx2);
double ComputeIntegralCSS_D2(const int ix2, const int gx2, const int hx2);
// \int_{0}{\pi} y sin(a y) dy = 
double IntegralRS(const int a);

// \int_{0}{1} 1/r sin(a \pi r) dr = 
// \int_{0}^{pi} 1/y sin(a*y)dy =
// \int_{0}^{a \pi} 1/z sin(z) dz = Si(a \pi)
double IntegralRInvS(const int a);

// \int_{0}{\pi}y^2 cos(ay)dy
double IntegralR2C(const int a);

// \int_{0}{1}r sin(i1\pi r)*sin(g1 \pi r)*sin(h1 \pi r) dr =
// \frac{1}{\pi^2} \int_{0}{\pi} y sin(i1 y)*sin(g1 y )*sin(h1 y) dy = 
// \frac{1}{4\pi^2} \int_{0}{\pi}y(- S{+--} + S{++-} + S{+-+} - S{+++}) dy =
// \frac{1}{4\pi^2} \int_{0}{\pi}(- yS{+--} + yS{++-} + yS{+-+} - yS{+++}) dy =
double ComputeIntegralRSSS(const int i1, const int g1, const int h1);

// \int_{0}{1}r cos(i1\pi r)*cos(g1 \pi r)*cos(h1 \pi r) dr =
// \frac{1}{\pi^2} \int_{0}{\pi} y cos(i1 y)*cos(g1 y )*cos(h1 y) dy = 
// \frac{1}{4\pi^2} \int_{0}{\pi}y(C{+--} + C{++-} + C{+-+} + C{+++}) dy =
// \frac{1}{4\pi^2} \int_{0}{\pi}( yC{+--} + yC{++-} + yC{+-+} + yC{+++}) dy =
double ComputeIntegralRCCC_D2(const int ix2, const int gx2, const int hx2);
double ComputeIntegralRSSS_D2(const int ix2, const int gx2, const int hx2);

// \int_{0}{1}r cos(i1\pi r)*sin(g1 \pi r)*cos(h1 \pi r) dr 
// \frac{1}{\pi^2} \int_{0}{\pi} y cos(i1 y)*sin(g1 y )*cos(h1 y) dy = 
// \frac{1}{4\pi^2} \int_{0}{\pi} (- yS{+--} + yS{++-} - yS{+-+} + yS{+++}) dy = 
double ComputeIntegralRCSC(const int i1, const int g1, const int h1);

// input is twice of the wavenumber.
// \int_{0}{1}r sin(i1\pi r)*cos(g1 \pi r)*sin(h1 \pi r) dr 
// \frac{1}{\pi^2} \int_{0}{\pi} y sin(i1 y)*cos(g1 y )*sin(h1 y) dy = 
// \frac{1}{4\pi^2} \int_{0}{\pi} ( yC{+--} + yC{++-} - yC{+-+} - yC{+++}) dy = 
double ComputeIntegralRSCS_D2(const int ix2, const int gx2, const int hx2);
double ComputeIntegralRCSC_D2(const int ix2, const int gx2, const int hx2);


// \int_{0}{1}r^2 sin(i1\pi r)*sin(g1\pi r)*cos(h1\pi r) dr =
// \frac{1}{\pi^3} \int_{0}{\pi} y^2 sin(i1 y)*sin(g1 y)*cos(h1 y) dy =
// \frac{1}{4\pi^3} \int_{0}{\pi} (y^2C{+--} - y^2C{++-} + y^2C{+-+} - y^2C{+++}) dy
double ComputeIntegralR2SSC(const int i1, const int g1, const int h1);

// input is twice of the wavenumber.
// \int_{0}{1}r^2 cos(i1\pi r)*cos(g1\pi r)*sin(h1\pi r) dr =
// \frac{1}{\pi^3} \int_{0}{\pi} y^2 cos(i1 y)*cos(g1 y)*sin(h1 y) dy =
// \frac{1}{4\pi^3} \int_{0}{\pi} (- y^2 S{+--} - y^2 S{++-} + y^2 S{+-+} + y^2 S{+++}) dy
double ComputeIntegralR2CCS_D2(const int ix2, const int gx2, const int hx2);
double ComputeIntegralR2SSC_D2(const int ix2, const int gx2, const int hx2);

// \int_{0}{1} 1/r sin(i1\pi r)*sin(g1 \pi r)*sin(h1 \pi r) dr =
// \int_{0}{\pi} 1/y sin(i1 y)*sin(g1 y)*sin(h1 y) dy =
// 0.25*\int_{0}{\pi} 1/y (-S{+--} + S{++-} + S{+-+} - S{+++}) dy =
//double ComputeIntegralRInvSSS(const int i1, const int g1, const int h1);

// \int_{0}{1} 1/r cos(i1\pi r)*cos(g1 \pi r)*cos(h1 \pi r) dr =
// \int_{0}{\pi} 1/y cos(i1 y)*cos(g1 y)*cos(h1 y) dy =
// 0.25*\int_{0}{\pi} 1/y (C{+--} + C{++-} + C{+-+} + C{+++}) dy =
//double ComputeIntegralRInvCCC_D2(const int ix2, const int gx2, const int hx2);
//double ComputeIntegralRInvSSS_D2(const int ix2, const int gx2, const int hx2);

// \int_{0}^{2pi} sin(a t) dt
// a is integer or integer offset by 0.5
double IngtegralSin2Pi(int a, bool of);

// \int_{0}^{2pi} cos(i2 t)sin(g2 t)cos(h2 t) dt
double IntegralCSC2Pi(int i2, int g2, int h2, bool ofi, bool ofg, bool ofh);

// \int_{0}^{2pi} sin(i2 t)sin(g2 t)cos(h2 t) dt
// 0.25*\int_{0}^{2pi} C_{+--} - C_{++-} + C_{+-+} - C_{+++} dt
double IntegralSSC2Pi_D2(const int ix2, const int gx2, const int hx2);

// \int_{0}^{2pi} cos(i2 t)cos(g2 t)cos(h2 t) dt
// 0.25*\int_{0}^{2pi} C_{+--} + C_{++-} + C_{+-+} + C_{+++} dt
double IntegralCCC2Pi_D2(const int ix2, const int gx2, const int hx2);

//#define IntegralCosInt(k) (k == 0 ? M_PI : 0)
//#define IntegralSinInt(k) (k%2 == 0 ? 0 : 2.0/k)
// #define IntegralSinDivSin(k) (k%2 == 0 ? 0 : (k > 0 ? M_PI : -M_PI))

//#define IntegralCosInt2Pi(k) (k == 0 ? 2.0*M_PI : 0)
#define IntegralSinInt2Pi(k) 0

// eps = 10^-12
#define lnSinEPS 56.64833659297699

double IntegralCosDivSin(int k, double* HS);
double IntegralSinDivSin(int k);
double IntegralCosInt2Pi(int k);
double IntegralSinInt(int k);
double IntegralCosInt(int k);

// int_{\theta = 0}^{Pi} sin(i1*t)*sin(i2*t)*sin(\theta) d\theta 
double IntegSinSinWSin(const int i1, const int i2);

// int_{\theta = 0}^{Pi} cos(i1*t)*sin(i2*t)*sin(\theta) d\theta 
double IntegCosSinWSin(const int i1, const int i2);

// int_{\theta = 0}^{Pi} cos(i1*t)*cos(i2*t)*sin(\theta) d\theta 
double IntegCosCosWSin(const int i1, const int i2);

// \int_{0}{\pi} cos(a2/2 y) dy = 
double IntegralC_D2(const int a2);
double IntegralS_D2(const int a2);

double IntegralS_D2_ONE(const int a2);
double IntegralC_D2_ONE(const int a2);

// \int_{0}{\pi} y cos(a2/2 y) dy = 
double IntegralRC_D2(const int a2);
double IntegralRS_D2(const int a2);

double IntegralRS_D2_ONE(const int a2);
double IntegralRC_D2_ONE(const int a2);

// \int_{0}{\pi}y^2 sin(a2/2 y)dy
// this takes in the twice of the wavenumber.
double IntegralR2S_D2(const int a2);
double IntegralR2C_D2(const int a2);

double IntegralR2S_D2_ONE(const int a2);
double IntegralR2C_D2_ONE(const int a2);

// \int_{0}{\pi}y^3 sin(a2/2 y)dy
// this takes in the twice of the wavenumber.
double IntegralR3S_D2(const int a2);
double IntegralR3C_D2(const int a2);

double IntegralR3S_D2_ONE(const int a2);
double IntegralR3C_D2_ONE(const int a2);

// \int_{0}{\pi}y^4 sin(a2/2 y)dy
// this takes in the twice of the wavenumber.
double IntegralR4S_D2(const int a2);
double IntegralR4C_D2(const int a2);

double IntegralR4S_D2_ONE(const int a2);
double IntegralR4C_D2_ONE(const int a2);

double IntegralR5S_D2(const int a2);
double IntegralR5C_D2(const int a2);

double IntegralR5S_D2_ONE(const int a2);
double IntegralR5C_D2_ONE(const int a2);

double IntegralR6S_D2(const int a2);
double IntegralR6C_D2(const int a2);

double IntegralR6S_D2_ONE(const int a2);
double IntegralR6C_D2_ONE(const int a2);

double IntegralR7S_D2(const int a2);
double IntegralR7C_D2(const int a2);

double IntegralR7S_D2_ONE(const int a2);
double IntegralR7C_D2_ONE(const int a2);

// int_{r = 0}^{1} r^8*cos(a*pi*r) dr
double IntegralR8S_D2_ONE(const int a2);
double IntegralR8C_D2_ONE(const int a2);

// int_{r = 0}^{1} r^9*cos(a*pi*r) dr
double IntegralR9S_D2_ONE(const int a2);
double IntegralR9C_D2_ONE(const int a2);

// int_{t=0}^{2*Pi} sin(a2/2*t) dt
inline double IntegrateSin2Pi_D2(const int a2) {
  return a2 % 2 == 0 ? 0 : 4.0/a2;
}

// int_{t=0}^{2*Pi} cos(a2/2*t) dt
inline double IntegrateCos2Pi_D2(const int a2) {
  return a2 == 0 ? 2.0*M_PI : 0;
}

// int_{r = 0}^{1} 1/r*sin(a*pi*r) dr
double IntegralRInvS_D2(const int a2);

// \int_{eps}{1} 1/r cos(a \pi r) dr = 
// \int_{eps}^{pi} 1/y cos(a*y)dy =
// \int_{eps}^{a \pi} 1/z cos(z) dz = Ci(a \pi) - Ci(eps)
double IntegralRInvC_D2(const int a2);

double IntegralSinInvSinT(const int a2);

// This integral diverges at t = 0, t = pi.
// Computed form t = 10^-6, t = pi-10^-6.
double IntegralSinInvCosT(const int a2);

// Compute the integration of the following form:
// Int_{x = v1}^{v2} sin(A/B*x + c), B != 0.
double IntegralSinAny(const double A, const double B, const double c, const double v1, const double v2);

// Compute the integration of the following form:
// Int_{x = v1}^{v2} cos(A/B*x + c), B != 0.
double IntegralCosAny(const double A, const double B, const double c, const double v1, const double v2);

#endif  // TRIG_INTEGRAL_3D_H
