#ifndef PROLATE_OBLATE_2D_H
#define PROLATE_OBLATE_2D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>
#include <unordered_set>
#include <unordered_map>

#include "common/query_table.h"
#include "common/basic_function.h"
#include "elliptic/prolate_oblate_2D.h"
#include "polar_2D/sphere_basis_2D_all.h"
#include "sphere_3D/sphere_basis_3D.h"

#include <vector>

class ProlateOblate3D : public SphereBasis3D {
public:
  ProlateOblate3D(const int k12, const int k22, const int k32, const int idx,
    const double& b, const bool is_prolate):SphereBasis3D(k12, k22, k32, idx),
    b_(b), a_(sqrt(1.0-b*b)),c_(b/sqrt(1.0-b*b)), is_prolate_(is_prolate) {

    initBasicCoef();
    curlSph();
  };
  
  ProlateOblate3D(const int k12, const int k22, const int k32, const int idx,
    const IntTable1DData& tabData, const bool is_prolate):SphereBasis3D(k12, k22, k32, idx),
    b_(tabData.b), a_(tabData.a),c_(tabData.c), is_prolate_(is_prolate) {

    initBasicCoef();
    Normalize(tabData);
    curlSph();
  };

  ~ProlateOblate3D(){};

   // compute on a catersian grid.
  void DiscretizeAdd(const double coef, FIELD_3D& r, FIELD_3D& theta, FIELD_3D& phi,
              VECTOR3_FIELD_3D* vfield);
  
  void FillFields(FIELD_3D& r, FIELD_3D& theta, FIELD_3D& phi);

  // compute on a spherical grid.
  void AddUniformU(const double coef, const int nR, const int nTheta, const int nPhi, double* ur, double* ut, double* up) const;
  
  double ProjectUniformU(const int nR, const int nTheta, const int nPhi,
                       const double* ur, const double* ut, const double* up) const;
  
  // the velocity transformation matrix.
  void toCartesianMat(const double& r, const double& t, const double& p, Eigen::Matrix3d& mat);

  double dotProd(const ProlateOblate3D& other, const IntTable1DData& tabData) const;
  void dotProdPattern(const ProlateOblate3D& other, const bool is1DTable, std::unordered_set<uint64_t>& set) const;
  
  const EllipticFactor& getEFactor(const int idx) const {
    return eFact_[idx];
  };

  static void countRTPattern(const EllipticFactor& ef, const BasicFunc& rfun, const BasicFunc& tfun, const bool is1DTable,
                             const bool collectAll, std::unordered_set<uint64_t>& set);

  double integrateRT(const EllipticFactor& ef, const BasicFunc& rfun, const BasicFunc& tfun, const IntTable1DData& tabData) const;

  void Normalize(const IntTable1DData& tabData) {
    norm2_ = dotProd(*this, tabData);
    invNorm_ = 1.0/sqrt(norm2_);
  }

  void computeTensorPattern(const ProlateOblate3D& phiG,
       const ProlateOblate3D& phiH, std::unordered_set<uint64_t>& set) const;
  
  double computeTensorEntry(const ProlateOblate3D& phiG,
       const ProlateOblate3D& phiH, const IntTable1DData& tabData) const;

  const std::vector<RTMultiply>& getCurRT(int i, int j) const {
    return curlRT_[i][j];
  }

  const EllipticFactor& getcurlEF(int i, int j) const {
    return curlEF_[i][j];
  }

  void printFullForm() const;
  void printJCurl() const;
  static ProlateOblate3D* fromFile(std::ifstream& in, const bool is_prolate, const IntTable1DData& tabData);

  static void printCrossProd(const ProlateOblate3D& phiG, const ProlateOblate3D& phiH);

protected:
  void initBasicCoef();
  Eigen::Vector3d computeRTP(const ProlateOblate3D& other, const IntTable1DData& tabData) const;
  void computeRTPattern(const EllipticFactor& ef, const RTMultiply& rt1, const bool withJacobian, const bool is1DTable,
                        const bool collectAll, std::unordered_set<uint64_t>& set) const;
  double inetgrateRTMult(const EllipticFactor& ef, const RTMultiply& rt1, const bool withJacobian, const IntTable1DData& tabData) const;
  
  void patternCurlCross(const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT,
                       const EllipticFactor& curlEF, const EllipticFactor& crossEF, std::unordered_set<uint64_t>& set) const;

  double computeCurlCross(const BasicFunc& curlP, const std::vector<BasicFunc>& crossP,
                          const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT,
                          const EllipticFactor& curlEF, const EllipticFactor& crossEF, const IntTable1DData& tabData) const;

  static void getCrossEF(const ProlateOblate3D& phiG, const ProlateOblate3D& phiH, EllipticFactor (&crossEF)[3][2]);

  const double b_;
  // focus
  const double a_;
  // sinh(w) = b/a
  const double c_;
  // true, prolate, false: oblate
  const bool is_prolate_;
  // here we only have the factor per each velocity component
  EllipticFactor eFact_[3];
  void curlSphProlate();
  void curlSphOblate();
  void curlSph();
  // curl data
  // 3x3 matrix like info about curl, see prolate3D.pdf and prolateOblate3D_tensor.nb for details.
  //BasicFunc curlPhi_[3][3];
  // std::vector<RTMultiply> curlRT_[3][3];
  EllipticFactor curlEF_[3][3];
  void setRT01();

};

typedef std::shared_ptr<ProlateOblate3D> prolate3DPtr;

#endif // PROLATE_OBLATE_2D_H