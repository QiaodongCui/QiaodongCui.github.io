#include <Eigen/Eigen>
#include <glog/logging.h>
#include <sstream>
#include <sys/stat.h>

#include "util/util.h"

using namespace std;

float clamp(const float& in, float _min, float _max) {
  if(in<_min)
    return _min;
  if(in>_max)
    return _max;
  return in;
}

Eigen::Vector3d sampleOnSphere(std::default_random_engine &gen) {
    std::normal_distribution<double> dist(0.0, 1.0);
    Eigen::Vector3d dir (dist(gen), dist(gen), dist(gen));

    return dir.normalized();
}

Eigen::Vector3f sampleOnSpheref(std::default_random_engine &gen) {
  std::normal_distribution<float> dist(0.0, 1.0);
  Eigen::Vector3f dir (dist(gen), dist(gen), dist(gen));

  return dir.normalized();
}

void GetNormalizedRandomVector(const int size, Eigen::VectorXd* vect) {
  (*vect) = Eigen::VectorXd::Random(size);
  vect->normalize();
}

template <typename T, typename VT>
void sampleSpherePatch(const int nSample, const T tmin, const T tmax, const T pmin, const T pmax, 
                       std::default_random_engine &gen, std::vector<VT>& samples) {
  samples.clear();
  samples.resize(nSample);
  CHECK(tmin < tmax);
  CHECK(pmin < pmax);
  T u1min = 0.5 - 0.5*cos(tmin);
  T u1max = 0.5 - 0.5*cos(tmax);
  T u2min = pmin/M_PI*0.5;
  T u2max = pmax/M_PI*0.5;

  uniform_real_distribution<T> u1(u1min, u1max);
  uniform_real_distribution<T> u2(u2min, u2max);
  for (int i = 0; i < nSample; i++) {
    T rnd1 = u1(gen);
    T rnd2 = u2(gen);
    // theta, in radian
    samples[i][0] = acos(1.0 - 2.0*rnd1);
    // phi
    samples[i][1] = 2.0*M_PI*rnd2;
  }
}

template void sampleSpherePatch<double, VEC2>(const int, const double, const double, const double, const double, 
                       std::default_random_engine&, std::vector<VEC2>&);
template void sampleSpherePatch<float, Eigen::Vector2f>(const int, const float, const float, const float, const float, 
                       std::default_random_engine&, std::vector<Eigen::Vector2f>&);

void sampleRectangular(const int nSample, const double xMin, const double xMax, const double yMin, const double yMax,
                       std::default_random_engine &gen, vector<VEC2>& samples) {
  samples.clear();
  samples.resize(nSample);
  CHECK(xMin < xMax);
  CHECK(yMin < yMax);
  uniform_real_distribution<double> x(xMin, xMax);
  uniform_real_distribution<double> y(yMin, yMax);
  for (int i = 0; i < nSample; i++) {
    samples[i][0] = x(gen);
    samples[i][1] = y(gen);
  }
}

void CompareTensor(const std::vector<Adv_Tensor_Type>& tensor1, 
                   const std::vector<Adv_Tensor_Type>& tensor2) {
  const int basis_dim = tensor1.size();
  if (tensor2.size() != basis_dim) {
    LOG(INFO) << "Tensor dimention is different, do not compare.";
    return;
  }
  LOG(INFO) << "Begin compare tensor";
  double diff = 0;
  int num_diff = 0;
  for (int k = 0; k < basis_dim; k++) {
    for (int j = 0; j < basis_dim; j++) {
      for (int i = 0; i < basis_dim; i++) {
        double val1 = AccessMatrix(tensor1[k], i, j);
        double val2 = AccessMatrix(tensor2[k], i, j);
        double abs_dif = std::abs(val1 - val2);
        if (abs_dif > 1e-7) {
          num_diff ++;
            LOG(INFO) << "Error entry: i: " << i << " j: " 
               << j << " k: " << k << " value1: " << val1 << " value2: " << val2;
        }
        diff += abs_dif;
      }
    }
  }
  LOG(INFO) << "Total difference in tensor: " 
      << diff / basis_dim / basis_dim / basis_dim << " number different: " << num_diff;
}

bool PointInBox(const VEC3F& point, const VEC3F& box_center, const VEC3F& length_) {
  VEC3F pointTransformed = point - box_center;
  return ( fabs(pointTransformed[0]) <= length_[0]*0.5  &&
           fabs(pointTransformed[1]) <= length_[1]*0.5  &&
           fabs(pointTransformed[2]) <= length_[2]*0.5 );
}

// Whether two box intersect each other.
bool BoxIntersect(const VEC3F& center1_, const VEC3F& length1_,
                  const VEC3& center2_, const VEC3F& length2_) {
  
  VEC3F low1 = center1_ - length1_*0.5;
  VEC3F high1 = center1_ + length1_*0.5;
  VEC3F low2 = center2_ - length2_*0.5;
  VEC3F high2 = center2_ + length2_*0.5;
  // x
  if (low1[0] > high2[0]) {
    return false;
  }
  if (high1[0] < low2[0]) {
    return false;
  }
  // y
  if (low1[1] > high2[1]) {
    return false;
  }
  if (high1[1] < low2[1]) {
    return false;
  }
  // z
  if (low1[2] > high2[2]) {
    return false;
  }
  if (high1[2] < low2[2]) {
    return false;
  }
  return true;
}

void axisAngFromAxixs(const Eigen::Vector3f& from, const Eigen::Vector3f& to, Eigen::Vector3f& axis, float& angle) {
  Eigen::Vector3f fn = from.normalized();
  Eigen::Vector3f tn = to.normalized();
  axis = fn.cross(tn);
  angle = acos(fn.dot(tn))*2.0*M_PI;
}

vector<string> splitStringDelim(string str, const char delim) {
  vector<string> results;
    
  if (str.size() == 0)
    return results;

  char str1[str.size()+1];
  memcpy(str1, str.data(), sizeof(char)*str.size());
  str1[str.size()] = '\0';
  
  char* pch = NULL;
  char de[1] = {delim};
  pch = strtok(str1, de);
  while (pch != NULL) {
    results.push_back(string(pch));
    pch = strtok(NULL, de);
  }
  return results;
}

string getStrFromFile(const string& fname) {
  std::ifstream in(fname);
  string ss;
  while (in) {
    string tmp;
    in >> tmp;
    ss.append(tmp);
  }

  return ss;
}

void dumpOddHarmonicSeries(const string& name, int K) {
  double val = 0;
  vector<double> series;
  series.push_back(0.0);
  for (int i = 1; i <= K; i++) {
    val += 4.0*1.0/(2*i - 1);
    series.push_back(val);
  }
  ofstream out(name, std::ios::binary);
  out.write((char*)(&K), sizeof(int));
  out.write((char*)(series.data()), sizeof(double)*K);
  out.close();
}

void readOddHarmonicSeries(const string& name, vector<double>& series) {
  ifstream in(name, std::ios::binary);
  int K = 0;
  in.read((char*)(&K), sizeof(int));
  series.resize(K);
  in.read((char*)(series.data()), sizeof(double)*K);
  in.close();
}

double computeSpherePatchArea(const double& tmin, const double& tmax, const double& pmin, const double& pmax) {
  return (pmax - pmin)*(cos(tmin) - cos(tmax));
}

long getFileSize(const string& fname) {
  struct  stat stat_buf;
  int rc = stat(fname.c_str(), &stat_buf);
  return rc == 0 ? stat_buf.st_size : -1;
}

Eigen::Vector3f hsv2rgb(const Eigen::Vector3f& hsv) {

  float      hh, p, q, t, ff;
  long       i;
  Eigen::Vector3f rgb;

  if(hsv[1] < 0.0) {
      return Eigen::Vector3f(0,0,0);
  }

  hh = hsv[0]*360.0;
  if(hh >= 360.0) hh = 0.0;
  hh /= 60.0;
  i = (long)hh;
  ff = hh - i;
  p = hsv[2] * (1.0 - hsv[1]);
  q = hsv[2] * (1.0 - (hsv[1] * ff));
  t = hsv[2] * (1.0 - (hsv[1] * (1.0 - ff)));

  switch(i) {
  case 0:
      rgb << hsv[2], t, p;
      break;
  case 1:
      rgb << q, hsv[2], p;
      break;
  case 2:
      rgb << p, hsv[2], t;
      break;
  case 3:
      rgb << p, q, hsv[2];
      break;
  case 4:
      rgb << t, p, hsv[2];
      break;
  case 5:
  default:
      rgb << hsv[2], p, q;
      break;
  }
  return rgb;
}

void denseMatrixToSparse(const Eigen::MatrixXd& in, Adv_Tensor_Type& out) {
  out.resize(in.rows(), in.cols());
  out.setZero();
  typedef Eigen::Triplet<double> T;
  std::vector<T> tripletList;

  for (int i = 0; i < in.rows(); i++)
    for (int j = 0; j < in.cols(); j++) {
        const double vij = in(i,j);
        if (std::abs(vij) <1e-12) {
          continue;
        }
        tripletList.push_back(T(i,j, vij));
    }
  out.setFromTriplets(tripletList.begin(), tripletList.end());
  out.makeCompressed();
}

typedef Eigen::SparseMatrix<double, Eigen::RowMajor> RowSparseMat;
typedef Eigen::SparseMatrix<double, Eigen::ColMajor> ColSparseMat;

void copySparseMatrix(const RowSparseMat& in, RowSparseMat& out) {
  typedef Eigen::Triplet<double> T;
  CHECK(out.rows() >= in.rows());
  CHECK(out.cols() >= in.cols());
  vector<T> Clist;

  for (int k = 0; k < in.outerSize(); k++)
    for (RowSparseMat::InnerIterator it(in, k); it; ++it)
      Clist.push_back(T(it.row(), it.col(), it.value()));
  out.setFromTriplets(Clist.begin(), Clist.end());
  out.makeCompressed();
}

void copySparseMatrix(const ColSparseMat& in, ColSparseMat& out) {
  typedef Eigen::Triplet<double> T;
  CHECK(out.rows() >= in.rows());
  CHECK(out.cols() >= in.cols());
  vector<T> Clist;

  for (int k = 0; k < in.outerSize(); k++)
    for (ColSparseMat::InnerIterator it(in, k); it; ++it)
      Clist.push_back(T(it.row(), it.col(), it.value()));
  out.setFromTriplets(Clist.begin(), Clist.end());
  out.makeCompressed();
}

