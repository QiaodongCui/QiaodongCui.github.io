#ifndef ELLIPTIC_BASIS_2D_H
#define ELLIPTIC_BASIS_2D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>
#include <unordered_set>
#include <unordered_map>
#include "2D/FIELD2D.h"
#include "2D/VFIELD2D.h"
#include "common/query_table.h"
#include "common/basic_function.h"
#include "polar_2D/polar_basis_all.h"

#include <vector>

class EllipticBasis2D : public PolarBasisAll {
public:
  // b: length of short axis [0, 1)
  EllipticBasis2D(const int k12, const int k22, const int idx, const IntTable1DData& tabData):
                  PolarBasisAll(k12, k22, idx, false),b_(tabData.b), a_(tabData.a),c_(tabData.c) {
    initFactors(idx);
    curlSph();
    Normalize(tabData);
  }
  
  // not initialize norm, test only.
  EllipticBasis2D(const int k12, const int k22, const int idx, const double& b):
          PolarBasisAll(k12, k22, idx, false),b_(b), a_(sqrt(1.0-b*b)),c_(b/sqrt(1.0-b*b)) {
    initFactors(idx);
    invNorm_ = 0;
  }

  void initFactors(const int idx) {
    if (idx == 0 || idx == 1 || idx == 3) {
      eRFact_[0] = {{EllipticFactor(-1, 0, 1, c_)}};
      eRFact_[1] = {{EllipticFactor(-1, 1, 0, 1.0), EllipticFactor(-1, 1, 0, 1.0)}};
    } else if (idx == 2) {
      eRFact_[0] = {{EllipticFactor(-1, 1, 0, 1.0)}};
      eRFact_[1] = {{EllipticFactor(-1, 0, 1, c_), EllipticFactor(-1, 2, -1, 1.0/c_)}};
    } else if (idx == 4) {
      eRFact_[0] = {{}};
      eRFact_[1] = {{EllipticFactor(-1,0,1,c_)}};
    } else {
      LOG(FATAL) << "unknown idx " << idx;
    }
  }

  void Normalize(const IntTable1DData& tabData) {
    norm2_ = dotProd(*this, tabData);
    invNorm_ = 1.0/sqrt(norm2_);
  }

  ~EllipticBasis2D(){};

  // directly compute on Cartesian grid.
  // h -> scale factors.
  // sqrtCR -> sqrt(1+c^2 r^2)
  // er, ev -> normalized basis std::vector along r and v(theta) 
  void DiscretizeAdd(const double coef, const FIELD2D& r, const FIELD2D& theta,
                     VFIELD2D* vfield) const;
  
  void AddUniformU(const double coef, const int nR, const int nTheta, double* ur, double* ut) const;

  double ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const;

  static void CatersianToElliptic(const double a, const double c, const double x, const double y, double& r, double& v);
  
  static void FillFields(const int xRes, const int yRes, const double a, const double c,
                         FIELD2D& r, FIELD2D& theta, FIELD2D& h, FIELD2D& sqrtCR,
                         VFIELD2D& er, VFIELD2D& ev);

  // Assume j is already in ef.
  // int_{r=0}^{1} ef*fun(r)*fun(t) dr dt
  static double computeRInt(const EllipticFactor& ef1, const BasicFunc& rfun,
                            const IntTable1DData& tabData);

  // count the patterns in RT integral. if hpow == 0, then seperable, otherwise not.
  static void countRTPattern(const EllipticFactor& ef1, const BasicFunc& rfun, const BasicFunc& tfun,
                            std::unordered_set<uint64_t>& set);

  static uint64_t tripleCoefToHash(const TripleCoef& tcoef);
  static uint64_t tripleInfoToHash(const int hpow, const int sqrtpow, const int rpow, const FUNTYPE rType, const FUNTYPE tType);

  static TripleCoef hashToTriple(const uint64_t& hash);
  static void hashToTripleInfo(const uint64_t& hash, int& hpow, int& sqrtpow, int& rpow, FUNTYPE& rType, FUNTYPE& tType);

  static void enumeratePattern(std::unordered_set<uint64_t>& set);
  static void printPattern(std::unordered_set<uint64_t>& set);

  // export 1d pattern that has to be computed numerically.
  static void exportNumericalPattern1D(const std::unordered_set<uint64_t>& set, const std::string& fname);
  static void exportNumericalPatternTensor(const std::unordered_map<uint64_t, double>& set);
  static void exportNumericalPatternTensor(const std::unordered_set<uint64_t>& set, const std::string& fname);

  static void countTMultInt(const std::vector<EllipticFactor>& ef1, const std::vector<EllipticFactor>& ef2,
                          const RTMultiply& rt1, const RTMultiply& rt2,
                          std::unordered_set<uint64_t>& set);

  static double intCRPow(const EllipticFactor& ef, const BasicFunc& rfun, const double& c);
  
  double computeRTMultInt(const std::vector<EllipticFactor>& ef1, const std::vector<EllipticFactor>& ef2,
                          const RTMultiply& rt1, const RTMultiply& rt2,
                          const IntTable1DData& tabData) const;
  
  static double computeTripleMultInt(const TripleCoef& t1, const TripleCoef& t2, const IntTable1DData& tabData, const bool withJacobian);
  static void TripleToPatternSet(const TripleCoef& t1, const TripleCoef& t2, const bool withJacobian, std::unordered_map<uint64_t, double>& set);

  static double computeVTripleMultInt(const std::vector<TripleCoef>& vt1, const std::vector<TripleCoef>& vt2, 
                                      const IntTable1DData& tabData, const bool withJacobian);
  static void VTripleMultIntToPatternSet(const std::vector<TripleCoef>& vt1, const std::vector<TripleCoef>& vt2, const bool withJacobian, 
                                         std::unordered_map<uint64_t, double>& set);
  double dotProd(const EllipticBasis2D& other, const IntTable1DData& tabData) const;
  
  double dotProd1(const EllipticBasis2D& other, const IntTable1DData& tabData) const;

  const std::vector<std::vector<EllipticFactor>>& geteRFact(int idx) const {
    return eRFact_[idx];
  }
  
  const std::vector<TripleCoef>& getU(int idx) const {
    return U_[idx];
  }

  static void derivR(const EllipticFactor& ef, const BasicFunc& f, const double c,
                     std::vector<EllipticFactor>& efReturn, std::vector<BasicFunc>& bfReturn);
  
  static void derivR(const std::vector<EllipticFactor>& ef, const RTMultiply& rc, const double c,
                     std::vector<EllipticFactor>& efReturn, RTMultiply& RtResult);

  static void derivT(const EllipticFactor& ef, const BasicFunc& f,
                     std::vector<EllipticFactor>& efReturn, std::vector<BasicFunc>& bfReturn);

  static void RTMtoTriple(const RTMultiply& rt, const std::vector<EllipticFactor>& ef, std::vector<TripleCoef>& coefReturn);

  void writeToFile(std::ofstream& out);
  static EllipticBasis2D* fromFile(std::ifstream& in, const IntTable1DData& tabData);

  // <ellipf*rcomp><tcomp>*<ellipf*rcomp><tcomp>
  double computeTensorEntry(const EllipticBasis2D& phiG, const EllipticBasis2D& phiH, const IntTable1DData& tabData) const;
  void enumerateTensorEntry(const EllipticBasis2D& phiG, const EllipticBasis2D& phiH, std::unordered_map<uint64_t, double>& set);
protected:
  void curlSph();
  // phiG_r phiH_t - phiG_t PhiH_r
  static void crossProdRT(const EllipticBasis2D& phiG, const EllipticBasis2D& phiH,  std::vector<TripleCoef> (&result)[2]);
  const double b_;
  // focus
  const double a_;
  // sinh(w) = b/a
  const double c_;

  // 3, align with the total number of r function in RT[2]
  // EllipticFactor rtFact_[3];
  // std::vector<std::vector<BasicFunc>> RT_[2];
  std::vector<std::vector<EllipticFactor>> eRFact_[2];
  // used for cross prod
  std::vector<TripleCoef> U_[2]; // unrolled formula for fv, fu
  // curl data
  // it appears the curl takes simple forms, see ellipticTensor.nb
  std::vector<TripleCoef> curlRT_;
};

typedef std::shared_ptr<EllipticBasis2D> ellipticPtr;

#endif // ELLIPTIC_BASIS_2D_H