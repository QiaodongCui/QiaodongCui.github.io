#ifndef GLUT_DRAW_H
#define GLUT_DRAW_H

#if __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#include <GL/glu.h>
#endif

//  Draw a bounding box.
void DrawCube(const float boxXLength, const float boxYLength, const float boxZLength);

#endif  // GLUT_DRAW_H
