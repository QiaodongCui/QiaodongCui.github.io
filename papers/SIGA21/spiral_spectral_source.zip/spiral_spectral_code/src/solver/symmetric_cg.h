#ifndef SYMMETRIC_CG_H
#define SYMMETRIC_CG_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>

#include "integrator_2d.h"
#include "setting.h"
// This class try to implement a symmetrilized version of matrix solver.
// The idea is to add P^T \omega to both side of the matrix equation, so
// The matrix we solve for is (I - (P^T + P))\omega_x = \omega - P^T\omega.
// However, this won't work since we have proved P is antisymmetric if 
// Energy conservation is required.
class SymmetricCG : public Integrator2D {
public:
  SymmetricCG(){};
  ~SymmetricCG(){};
  void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) override;
protected:
  
};

#endif
