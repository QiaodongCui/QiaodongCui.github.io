#include <glog/logging.h>

#include "3D/trig_integral_3d.h"
#include "util/util.h"

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  
  CHECK_EQ(ComputeIntegralCSS(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralCSS(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralCSS(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralCSS(-1,1,1,1,1,3),0);
  CHECK_EQ(ComputeIntegralCSS(-1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSS(-1,1,-1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSS(1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSS(1,1,1,1,-1,-1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSS(0,-1,1,0,1,1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSS(0,1,1,0,1,-1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSS(0,-1,1,0,-1,1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSS(0,-1,1,0,1,-1),PI_CUBE*0.25);
  
  CHECK_EQ(ComputeIntegralSCS(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralSCS(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSCS(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSCS(-1,1,1,1,1,3),0);
  CHECK_EQ(ComputeIntegralSCS(-1,1,1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCS(-1,1,-1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCS(1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCS(1,1,1,1,-1,-1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCS(-1,0,1,1,0,1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCS(1,0,1,1,0,-1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCS(-1,0,1,-1,0,1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCS(-1,0,1,1,0,-1),PI_CUBE*0.25);
  
  CHECK_EQ(ComputeIntegralSSC(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSC(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSC(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSC(-1,1,1,1,1,3),0);
  CHECK_EQ(ComputeIntegralSSC(-1,1,1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSC(-1,1,-1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSC(1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSC(1,1,1,1,-1,-1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSC(-1,1,0,1,1,0),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSC(1,1,0,1,-1,0),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSC(1,-1,0,1,-1,0),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSC(-1,1,0,1,-1,0),PI_CUBE*0.25);
  
  CHECK_EQ(ComputeIntegralSSSCSS(1,1,1,1,2,3), 0);
  CHECK_EQ(ComputeIntegralSSSCSS(1,1,1,2,1,3), 0);
  CHECK_EQ(ComputeIntegralSSSCSS(1,1,1,2,2,-1), 0);
  CHECK_EQ(ComputeIntegralSSSCSS(1,1,1,1,1,1), 0);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,1,1,1), 4.0/3.0*0.25*PI_SQUARE);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,1,1,-1), -4.0/3.0*0.25*PI_SQUARE);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,1,-1,1), -4.0/3.0*0.25*PI_SQUARE);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,1,-1,-1), 4.0/3.0*0.25*PI_SQUARE);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,4,-1,-1), 0);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,8,-1,-1), 0);
  CHECK_EQ(ComputeIntegralSSSCSS(2,1,1,3,-1,-1), -4.0/5.0*0.25*PI_SQUARE);
  CHECK_EQ(ComputeIntegralSSSCSS(3,1,1,2,-1,-1), 6.0/5.0*0.25*PI_SQUARE);
  
  CHECK_EQ(ComputeIntegralCCSSCS(1,1,1,1,2,3), 0);
  CHECK_EQ(ComputeIntegralCCSSCS(1,1,1,2,1,3), 0);
  CHECK_EQ(ComputeIntegralCCSSCS(1,1,1,2,2,-1), 0);
  CHECK_EQ(ComputeIntegralCCSSCS(1,1,1,1,1,1), 0);
  // LOG(INFO) << ComputeIntegralCCSSCS(2,1,1,1,1,1) + 2.0/3.0*0.25*PI_SQUARE;
  // CHECK_EQ(ComputeIntegralCCSSCS(2,1,1,1,1,1), -2.0/3.0*0.25*PI_SQUARE);
  // CHECK_EQ(ComputeIntegralCCSSCS(2,1,1,1,1,-1), 2.0/3.0*0.25*PI_SQUARE);
  // CHECK_EQ(ComputeIntegralCCSSCS(2,1,1,1,-1,1), -2.0/3.0*0.25*PI_SQUARE);
  // CHECK_EQ(ComputeIntegralCCSSCS(2,1,1,1,-1,-1), 2.0/3.0*0.25*PI_SQUARE);
  // CHECK_EQ(ComputeIntegralCCSSCS(2,0,1,1,0,-1), 4.0/3.0*0.25*PI_SQUARE);

  CHECK_EQ(ComputeIntegralCSCSSC(1,1,1,1,2,3), 0);
  CHECK_EQ(ComputeIntegralCSCSSC(1,1,1,2,1,3), 0);
  CHECK_EQ(ComputeIntegralCSCSSC(1,1,1,2,2,-1), 0);
  CHECK_EQ(ComputeIntegralCSCSSC(1,1,1,1,1,1), 0);
 // CHECK_EQ(ComputeIntegralCSCSSC(2,1,1,1,1,1), -2.0/3.0*0.25*PI_SQUARE);
  
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(-1,1,1,1,1,3),0);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(-1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(-1,1,-1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(1,1,1,1,-1,-1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0,-1,1,0,1,1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0,1,1,0,1,-1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0,-1,1,0,-1,1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0,-1,1,0,1,-1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0.5,-1,1,0.5,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(0.5,1,1,1.5,1,-1),0);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(1,-1,1,1.5,-1,1), 0.25*PI_SQUARE*1.2);
  CHECK_EQ(ComputeIntegralCSSDOUBLE(1.5,-1,1,2,1,-1),0.25*PI_SQUARE*(1 - 1.0/7));
  
  CHECK_EQ(ComputeIntegralSCSDOUBLE(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,1,1,1,1,3),0);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,1,1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,1,-1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1,1,1,1,-1,-1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,0,1,1,0,1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1,0,1,1,0,-1),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,0,1,-1,0,1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(-1,0,1,1,0,-1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(0.5,0,1,0.5,0,1),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1.5,0,1,0.5,0,-1),0);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1,0,1,1.5,0,1), PI_SQUARE*0.5*0.8);
  CHECK_EQ(ComputeIntegralSCSDOUBLE(1.5,0,1,2,0,-1),-PI_SQUARE*0.5*(1+1.0/7.0));
  
  CHECK_EQ(ComputeIntegralSSCDOUBLE(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(-1,1,1,1,1,3),0);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(-1,1,1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(-1,1,-1,1,1,1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1,1,1,1,1,1),PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1,1,1,1,-1,-1),-PI_CUBE*0.125);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(-1,1,0,1,1,0),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1,1,0,1,-1,0),-PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1,-1,0,1,-1,0),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(-1,1,0,1,-1,0),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(0.5,1,0,0.5,1,0),PI_CUBE*0.25);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1.5,1,0,0.5,-1,0),0);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1,-1,0,1.5,-1,0),PI_SQUARE*0.5*0.8);
  CHECK_EQ(ComputeIntegralSSCDOUBLE(1.5,1,0,2,-1,0),-PI_SQUARE*0.5*(1+1.0/7.0));
  
  CHECK_EQ(ComputeIntegralSSCCSS(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSCCSS(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSCCSS(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralSSCCSS(-1,1,1,1,1,3),0);
  // CHECK_EQ(ComputeIntegralSSCCSS(2,1,2,1,1,3),0.5*M_PI*4.0/3.0*1.20);
  // CHECK_EQ(ComputeIntegralSSCCSS(2,1,2,1,-1,3),-0.5*M_PI*4.0/3.0*1.20);
  CHECK_EQ(ComputeIntegralSSCCSS(5,1,2,2,1,2),0);
  // CHECK_EQ(ComputeIntegralSSCCSS(5,1,2,2,1,3),0.5*M_PI*10.0/21.0*1.20);
  
  CHECK_EQ(ComputeIntegralCCCSCS(0,0,0,1,2,3),0);
  CHECK_EQ(ComputeIntegralCCCSCS(1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralCCCSCS(-1,1,1,1,2,3),0);
  CHECK_EQ(ComputeIntegralCCCSCS(-1,1,1,1,1,3),0);
  //CHECK_EQ(ComputeIntegralCCCSCS(2,1,2,1,1,3),-0.5*M_PI*2.0/3.0*1.2);
  // CHECK_EQ(ComputeIntegralCCCSCS(2,1,2,1,-1,3),-0.5*M_PI*2.0/3.0*1.2);
  // CHECK_EQ(ComputeIntegralCCCSCS(2,0,2,1,0,3),-M_PI*2.0/3.0*1.2);
  CHECK_EQ(ComputeIntegralCCCSCS(5,1,2,1,-1,3),0);
  // CHECK_EQ(ComputeIntegralCCCSCS(5,1,2,2,-1,3),-0.5*M_PI*4.0/21.0*1.2);
  
  CHECK_EQ(ComputeIntegralSCCCSS(1,1,1,1,2,2),0);
  CHECK_EQ(ComputeIntegralSCCCSS(1,1,1,2,1,2),0);
  CHECK_EQ(ComputeIntegralSCCCSS(1,1,1,2,2,1),0);
  CHECK_EQ(ComputeIntegralSCCCSS(1,1,1,2,2,2), - 32.0/27.0 );
  CHECK_EQ(ComputeIntegralSCCCSS(3,5,7,2,2,2), 1.2*16.0/21.0/45.0);
  CHECK_EQ(ComputeIntegralSCCCSS(1,2,1,2,5,2), -80.0/9.0/21.0 );
  
  CHECK_EQ(ComputeIntegralCSCSCS(1,1,1,1,2,2),0);
  CHECK_EQ(ComputeIntegralCSCSCS(1,1,1,2,1,2),0);
  CHECK_EQ(ComputeIntegralCSCSCS(1,1,1,2,2,1),0);
  CHECK_EQ(ComputeIntegralCSCSCS(1,1,1,2,2,2), -32.0/27.0 );
  // CHECK_EQ(ComputeIntegralCSCSCS(3,5,7,2,2,2), 32/21.0/45.0);
  CHECK_EQ(ComputeIntegralCSCSCS(1,2,1,2,5,2), -64.0/9.0/21.0 );
  
  CHECK_EQ(ComputeIntegralCCSSSC(1,1,1,1,2,2),0);
  CHECK_EQ(ComputeIntegralCCSSSC(1,1,1,2,1,2),0);
  CHECK_EQ(ComputeIntegralCCSSSC(1,1,1,2,2,1),0);
  // CHECK_EQ(ComputeIntegralCCSSSC(1,1,1,2,2,2), - 32.0/27.0 );
  //  CHECK_EQ(ComputeIntegralCCSSSC(3,5,7,2,2,2), 3.2/21*14/45);
  // CHECK_EQ(ComputeIntegralCCSSSC(1,2,1,2,5,2), -4.0/3.0*10.0/21.0*2.0/3.0);
  CHECK(fabs(IngtegralSin2Pi(2, true) - 0.8) < 1e-14);
  CHECK(fabs(IngtegralSin2Pi(2, false) - 0) < 1e-14);
  CHECK(fabs(IngtegralSin2Pi(0, false) - 0) < 1e-14);
  CHECK(fabs(IngtegralSin2Pi(0, true) - 4.0) < 1e-14);
  CHECK(fabs(IngtegralSin2Pi(1, true) - 4.0/3.0) < 1e-14);

  CHECK(fabs(IntegralCSC2Pi(0, 0, 0, true ,true, true) - 4.0 / 3.0) < 1e-14);
  CHECK(fabs(IntegralCSC2Pi(0, 0, 0, true ,true, false) - 0) < 1e-14);
  CHECK(fabs(IntegralCSC2Pi(0, 0, 0, true ,false, false) - 0) < 1e-14);
  CHECK(fabs(IntegralCSC2Pi(0, 0, 0, false ,false, false) - 0) < 1e-14);
  CHECK(fabs(IntegralCSC2Pi(1, 2, 3, true ,true, true) - 0.977777777) < 1e-6);
  CHECK(fabs(IntegralCSC2Pi(1, 2, 3, true ,true, false) - 0) < 1e-6);
  CHECK(fabs(IntegralCSC2Pi(1, 2, 3, false ,true, false) - 0.854701) < 1e-5);
  CHECK(fabs(IntegralCSC2Pi(1, 2, 3, true ,false, false) - 1.01978) < 1e-5);
  CHECK(fabs(IntegralCSC2Pi(1, 2, 3, false ,false, false) - 0) < 1e-5);
  CHECK(fabs(IntegralCSC2Pi(4, 6, 7, true ,false, false) - 0.139343) < 1e-5);
  CHECK(fabs(IntegralCSC2Pi(4, 6, 7, true ,true, true) - 0.131607) < 1e-5);
  CHECK(fabs(IntegralCSC2Pi(4, 6, 7, false ,false, false) - 0) < 1e-5);
  
  CHECK(fabs(IntegralRS(0) - 0) < 1e-15);
  CHECK(fabs(IntegralRS(1) - M_PI) < 1e-15);
  CHECK(fabs(IntegralRS(2) + 0.5*M_PI) < 1e-15);
  CHECK(fabs(IntegralRS(3) - M_PI/3.0) < 1e-15);
  CHECK(fabs(IntegralRS(4) + 0.25*M_PI) < 1e-15);
  CHECK(fabs(IntegralRS(-1) + M_PI) < 1e-15);

  //CHECK(fabs(IntegralRInvS(0) - 0) < 1e-15);
  //CHECK(fabs(IntegralRInvS(1) - 1.85194) < 1e-5);
  //CHECK(fabs(IntegralRInvS(2) - 1.41815) < 1e-5);
  //CHECK(fabs(IntegralRInvS(3) - 1.67476) < 1e-5);
  //CHECK(fabs(IntegralRInvS(4) - 1.49216) < 1e-5);
  //CHECK(fabs(IntegralRInvS(-1) + 1.85194) < 1e-5);

  CHECK(fabs(IntegralR2C(0) - PI_CUBE/3.0) < 1e-15);
  CHECK(fabs(IntegralR2C(1) + 2.0*M_PI) < 1e-15);
  CHECK(fabs(IntegralR2C(2) - 0.5*M_PI) < 1e-15);
  CHECK(fabs(IntegralR2C(3) + M_PI*2.0/9.0) < 1e-15);
  CHECK(fabs(IntegralR2C(4) - M_PI*0.125) < 1e-15);
  CHECK(fabs(IntegralR2C(-1) + 2.0*M_PI) < 1e-15);

  CHECK(fabs(ComputeIntegralCSS(0, 0, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(0, 0, 1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(0, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(0, 1, 1) - 0.5) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(1, 1, 1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(1, 2, 3) - 0.25) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(2, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(4, 2, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(4, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(4, 2, 2) + 0.25) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(4, 7, 8) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(15, 7, 8) + 0.25) < 1e-15);
  CHECK(fabs(ComputeIntegralCSS(7, 15, 8) - 0.25) < 1e-15);
  // ComputeIntegralSSC(const int i1, const int g1, const int h1);
  CHECK(fabs(ComputeIntegralSSC(0, 0, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(0, 0, 1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(0, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(1, 1, 0) - 0.5) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(1, 1, 1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(1, 2, 3) + 0.25) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(2, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(4, 2, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(4, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(4, 2, 2) - 0.25) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(4, 7, 8) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(15, 7, 8) - 0.25) < 1e-15);
  CHECK(fabs(ComputeIntegralSSC(7, 15, 8) - 0.25) < 1e-15);


  // double ComputeIntegralRSSS(const int i1, const int g1, const int h1);
  CHECK(fabs(ComputeIntegralRSSS(1, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(1, 1, 1) - 2.0/3.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(1, 2, 3) + 7.0/48.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(2, 4, 4) + 4.0/15.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(4, 2, 4) + 4.0/15.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(4, 4, 4) + 1.0/6.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(4, 2, 2) + 3.0/32.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(4, 7, 8) - 448.0/3135.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(15, 7, 8) + 169.0/6720.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRSSS(7, 15, 8) + 169.0/6720.0/M_PI) < 1e-15);

  // double ComputeIntegralRCSC(const int i1, const int g1, const int h1);
  CHECK(fabs(ComputeIntegralRCSC(0, 1, 0) - 1.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(1, 0 ,1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(1, 1, 0) + 0.25/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(1, 1, 1) - 1.0/3.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(1, 2, 3) - 1.0/48.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(2, 4, 4) + 1.0/15.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(4, 2, 4) + 7.0/30.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(4, 4, 4) + 1.0/12.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(4, 2, 2) + 1.0/32.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(4, 7, 8) - 217.0/3135.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(15, 7, 8) + 71.0/6720.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralRCSC(7, 15, 8) + 281.0/6720.0/M_PI) < 1e-15);
  
  // ComputeIntegralR2SSC(const int i1, const int g1, const int h1);
  CHECK(fabs(ComputeIntegralR2SSC(0, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralR2SSC(1, 0 ,1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralR2SSC(1, 1, 0) - 0.141336) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(1, 1, 1) + 0.0450316) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(1, 2, 3) + 0.0689091) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(2, 4, 4) - 0.000900633) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(4, 2, 4) - 0.000900633) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(4, 4, 4) - 0.00281448) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(4, 2, 2) - 0.0825418) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(4, 7, 8) - 0.00332418) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(15, 7, 8) - 0.0832165) < 1e-5);
  CHECK(fabs(ComputeIntegralR2SSC(7, 15, 8) - 0.0832165) < 1e-5);

  // ComputeIntegralRInvSSS(const int i1, const int g1, const int h1);
  //CHECK(fabs(ComputeIntegralRInvSSS(0, 1, 0) - 0) < 1e-15);
  //CHECK(fabs(ComputeIntegralRInvSSS(1, 0 ,1) - 0) < 1e-15);
  //CHECK(fabs(ComputeIntegralRInvSSS(1, 1, 0) - 0) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(1, 1, 1) - 0.970262) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(1, 2, 3) - 0.34807) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(2, 4, 4) - 0.703827) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(4, 2, 4) - 0.703827) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(4, 4, 4) - 0.733044) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(4, 2, 2) - 0.363298) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(4, 7, 8) - 0.830218) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(15, 7, 8) - 0.384703) < 1e-5);
  //CHECK(fabs(ComputeIntegralRInvSSS(7, 15, 8) - 0.384703) < 1e-5);

  // double ComputeIntegralSCC_D2(const int ix2, const int gx2, const int hx2);
  CHECK(fabs(ComputeIntegralSCC_D2(0, 0, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(0, 0, 1) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(0, 1, 0) - 0) < 1e-15);

  CHECK(fabs(ComputeIntegralSCC_D2(2, 2, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(2, 2, 2) - 2.0/(3.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(2, 4, 6) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(2, 4, 4) - 14.0/(15.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(4, 2, 4) - 4.0/(15.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(4, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(4, 2, 2) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(8, 14, 16) - 776.0/(3135.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(10, 14, 16) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(14, 12, 16) - 34.0/(315.0*M_PI)) < 1e-15);
  
  CHECK(fabs(ComputeIntegralSCC_D2(3, 3, 0) - 1.0/(3.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(3, 3, 3) - 2.0/(9.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(3, 5, 7) - 26.0/(45.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(1, 3, 3) - 34.0/(35.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(5, 3, 5) - 10.0/(91.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(5, 5, 5) - 2.0/(15.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(5, 3, 3) + 14.0/(55.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(7, 13, 15) - 46.0/(315.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(11, 15, 17) - 2882.0/(35217.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralSCC_D2(13, 11, 15) - 118.0/(1989.0*M_PI)) < 1e-15);

  CHECK(fabs(IntegralRC_D2(0) - PI_SQUARE*0.5) < 1e-15);
  CHECK(fabs(IntegralRC_D2(1) - 2.0*(M_PI - 2.0)) < 1e-15);
  CHECK(fabs(IntegralRC_D2(2) + 2.0) < 1e-15);
  CHECK(fabs(IntegralRC_D2(3) + 2.0/9.0*(2.0 + 3.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralRC_D2(4) - 0) < 1e-15);
  CHECK(fabs(IntegralRC_D2(5) - 2.0/25.0*(-2.0 + 5.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralRC_D2(6) + 2.0/9.0) < 1e-15);
  CHECK(fabs(IntegralRC_D2(7) + 2.0/49.0*(2.0 + 7.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralRC_D2(8) - 0) < 1e-15);
  CHECK(fabs(IntegralRC_D2(-1) - 2.0*(M_PI - 2.0)) < 1e-15);
  CHECK(fabs(IntegralRC_D2(-2) + 2.0) < 1e-15);
  CHECK(fabs(IntegralRC_D2(-3) + 2.0/9.0*(2.0 + 3.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralRC_D2(-4) - 0) < 1e-15);

  // double ComputeIntegralRSCS_D2(const int ix2, const int gx2, const int hx2);
  CHECK(fabs(ComputeIntegralRSCS_D2(0, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(1, 0 ,1) - 0.25 - 1/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(1, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(1, 1, 1) - (2*(-4.0 + 3.0*M_PI))/9.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(1, 2, 3) - 1.0/8.0 - 5.0/(9.0*PI_SQUARE)) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(2, 4, 4) + 8.0/(225.0*PI_SQUARE)) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(4, 2, 4) + 208/(225.0*PI_SQUARE)) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(4, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(4, 2, 2) - 1.0/8.0) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(4, 7, 8) + 128.0*(5882.0 + 21945.0*M_PI)/9828225.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(15, 7, 8) - 1.0/8.0 + 88.0/11025.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(7, 15, 8) + 1.0/8.0 + 88.0/11025.0/PI_SQUARE) < 1e-15);

  CHECK(fabs(ComputeIntegralRSCS_D2(1, 3, 5) - 2.0*(-1780.0 + 1071*M_PI)/3969.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(2, 4, 6) - 1.0/8.0) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(7, 5, 3) - 2.0*(-196.0 + 99.0*M_PI)/405.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(8, 6, 4) + 928.0/2025.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(2, 4, 8) + 5008.0/11025.0/PI_SQUARE) < 1e-15);
  CHECK(fabs(ComputeIntegralRSCS_D2(3, 5, 7) - 2.0*(-196.0 + 99.0*M_PI)/405.0/PI_SQUARE) < 1e-15);

  // double ComputeIntegralCCS_D2(const int ix2, const int gx2, const int hx2)
  CHECK(fabs(ComputeIntegralCCS_D2(0, 0, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(0, 0, 1) - 2.0/M_PI) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(0, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(2, 2, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(2, 2, 2) - 2.0/(3.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(2, 4, 6) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(2, 4, 4) - 4.0/(15.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(4, 2, 4) - 4.0/(15.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(4, 4, 4) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(4, 2, 2) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(8, 14, 16) - 16.0/(3135.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(10, 14, 16) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(14, 12, 16) - 16.0/(315.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(3, 3, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(3, 3, 3) - 2.0/(9.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(3, 5, 7) + 14.0/(45.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(1, 3, 3) - 6.0/(35.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(5, 3, 5) - 10.0/(91.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(5, 5, 5) - 2.0/(15.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(5, 3, 3) - 6.0/(11.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(7, 13, 15) + 2.0/(315.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(11, 15, 17) - 646.0/(35217.0*M_PI)) < 1e-15);
  CHECK(fabs(ComputeIntegralCCS_D2(13, 11, 15) - 50.0/(1989.0*M_PI)) < 1e-15);
  
  //double IntegralR2S_D2(const int a2);
  CHECK(fabs(IntegralR2S_D2(0) - 0) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(1) - 8.0*(M_PI - 2.0)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(2) + 4.0 - PI_SQUARE) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(3) + 8.0/27.0*(2.0 + 3.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(4) + PI_SQUARE*0.5) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(5) - 8.0/125.0*(-2.0 + 5.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(6) - 1.0/27.0*(-4.0 + 9.0*PI_SQUARE)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(7) + 8.0/343.0*(2.0 + 7.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(8) + PI_SQUARE*0.25) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(-1) + 8.0*(M_PI - 2.0)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(-2) - 4.0 + PI_SQUARE) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(-3) - 8.0/27.0*(2.0 + 3.0*M_PI)) < 1e-15);
  CHECK(fabs(IntegralR2S_D2(-4) - PI_SQUARE*0.5) < 1e-15);

  // double ComputeIntegralR2CCS_D2(const int ix2, const int gx2, const int hx2);
  CHECK(fabs(ComputeIntegralR2CCS_D2(0, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralR2CCS_D2(1, 0 ,1) - 0.0946519) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(1, 1, 0) - 0) < 1e-15);
  CHECK(fabs(ComputeIntegralR2CCS_D2(1, 1, 1) - 0.0463424) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(1, 2, 3) - 0.0328685) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(2, 4, 4) - 0.0409888) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(4, 2, 4) - 0.0409888) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(4, 4, 4) + 0.0530516) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(4, 2, 2) + 0.0198944) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(4, 7, 8)  - 0.0320157) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(15, 7, 8) + 0.0159258) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(7, 15, 8) + 0.0159258) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(1, 3, 5) - 0.0441555) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(2, 4, 6) + 0.072946) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(7, 5, 3) - 0.0774462) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(8, 6, 4) - 0.0657975) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(2, 4, 8) - 0.0995889) < 1e-5);
  CHECK(fabs(ComputeIntegralR2CCS_D2(3, 5, 7) + 0.0651766) < 1e-5);

  // double ComputeIntegralRCCC_D2(const int ix2, const int gx2, const int hx2)
  CHECK(fabs(ComputeIntegralRCCC_D2(0, 0, 0) - 0.5) < 1e-15);
  CHECK(fabs(ComputeIntegralRCCC_D2(0, 1, 0) - 0.231335) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(1, 0, 0) - 0.231335) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(1, 0 ,1) - 0.148679) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(1, 1, 0) - 0.148679) < 1e-5);

  CHECK(fabs(ComputeIntegralRCCC_D2(1, 1, 1) - 0.109192) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(1, 2, 3) - 0.0687105) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(2, 4, 4) + 0.108977) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(4, 2, 4) + 0.108977) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(4, 4, 4)  - 0.) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(4, 2, 2)  - 0.125) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(4, 7, 8)  + 0.0604947) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(15, 7, 8) - 0.123741) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(7, 15, 8) - 0.123741) < 1e-5);

  CHECK(fabs(ComputeIntegralRCCC_D2(1, 3, 5) + 0.014847) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(2, 4, 6) - 0.125) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(7, 5, 3) - 0.0909843) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(8, 6, 4) + 0.0589414) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(2, 4, 8) + 0.0593499) < 1e-5);
  CHECK(fabs(ComputeIntegralRCCC_D2(3, 5, 7) - 0.0909843) < 1e-5);

  // double IntegralRInvC_D2(const int a2);
  //CHECK(fabs(IntegralRInvC_D2(0) - 11.5129) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(1) - 10.9561) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(2) - 9.86465) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(3) - 9.18711) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(4) - 9.07527) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(5) - 8.99846) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(6) - 8.70299) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(7) - 8.44865) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(8) - 8.39857) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(-1)- 10.9561) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(-2) - 9.86465) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(-3) - 9.18711) < 1e-4);
  //CHECK(fabs(IntegralRInvC_D2(-4) - 9.07527) < 1e-4);


  //double ComputeIntegralRInvCCC_D2(const int ix2, const int gx2, const int hx2);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(0, 0, 0) - 11.5129) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(0, 1, 0) - 10.9561) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(1, 0, 0) - 10.9561) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(1, 0 ,1) - 10.6888) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(1, 1, 0) - 10.6888) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(1, 1, 1) - 10.5139) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(1, 2, 3) - 9.78896) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(2, 4, 4) - 9.15445) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(4, 2, 4) - 9.15445) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(4, 4, 4) - 8.80557) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(4, 2, 2) - 9.51551) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(4, 7, 8) - 8.43014) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(15, 7, 8) - 8.53835) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(7, 15, 8) - 8.53835) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(1, 3, 5) - 9.23721) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(2, 4, 6) - 9.2458 ) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(7, 5, 3) - 9.01134) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(8, 6, 4) - 8.58703) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(2, 4, 8) - 8.65006) < 1e-4);
  //CHECK(fabs(ComputeIntegralRInvCCC_D2(3, 5, 7) - 9.01134) < 1e-4);

  // double IntegralSSC2Pi_D2(const int ix2, const int gx2, const int hx2);
  CHECK(fabs(IntegralSSC2Pi_D2(0, 0, 0) - 0) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(0, 1, 0) - 0) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(1, 0, 0) - 0) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(1, 0 ,1) - 0) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(1, 1, 0) - 3.14159) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(1, 1, 1) - 0.0) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(1, 2, 3) + 1.5708) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(2, 4, 4) - 0.) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(4, 2, 4) - 0.) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(4, 4, 4) -  0. ) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(4, 2, 2) -  1.5708 ) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(4, 7, 8) -  0. ) < 1e-5);
  CHECK(fabs(IntegralSSC2Pi_D2(15, 7, 8) - 1.5708) < 1e-4);
  CHECK(fabs(IntegralSSC2Pi_D2(7, 15, 8) - 1.5708) < 1e-4);

  CHECK(fabs(IntegralSSC2Pi_D2(1, 3, 5) - 0.) < 1e-4);
  CHECK(fabs(IntegralSSC2Pi_D2(2, 4, 6) - -1.5708) < 1e-4);
  CHECK(fabs(IntegralSSC2Pi_D2(7, 5, 3) - 0.0) < 1e-4);
  CHECK(fabs(IntegralSSC2Pi_D2(8, 6, 4) - 0) < 1e-4);
  CHECK(fabs(IntegralSSC2Pi_D2(2, 4, 8) - 0) < 1e-4);
  CHECK(fabs(IntegralSSC2Pi_D2(3, 5, 7) - 0) < 1e-4);

  // double IntegralCCC2Pi_D2(const int ix2, const int gx2, const int hx2);
  CHECK(fabs(IntegralCCC2Pi_D2(0, 0, 0) - 6.28319) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(0, 1, 0) - 0.0) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(1, 0, 0) - 0.0) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(1, 0 ,1) - 3.14159) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(1, 1, 0) - 3.14159) < 1e-5);

  CHECK(fabs(IntegralCCC2Pi_D2(1, 1, 1) -  0.) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(1, 2, 3) -  1.5708) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(2, 4, 4) -  0.) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(4, 2, 4) -  0.) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(4, 4, 4) -  0.) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(4, 2, 2) -  1.5708) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(4, 7, 8) -  0.0) < 1e-5);
  CHECK(fabs(IntegralCCC2Pi_D2(15, 7, 8)-  1.5708) < 1e-4);
  CHECK(fabs(IntegralCCC2Pi_D2(7, 15, 8)-  1.5708) < 1e-4);
  
  CHECK(fabs(IntegralCCC2Pi_D2(1, 3, 5) - 0.0) < 1e-4);
  CHECK(fabs(IntegralCCC2Pi_D2(2, 4, 6) - 1.5708) < 1e-4);
  CHECK(fabs(IntegralCCC2Pi_D2(7, 5, 3) - 0.) < 1e-4);
  CHECK(fabs(IntegralCCC2Pi_D2(8, 6, 4) - 0.) < 1e-4);
  CHECK(fabs(IntegralCCC2Pi_D2(2, 4, 8) - 0.) < 1e-4);
  CHECK(fabs(IntegralCCC2Pi_D2(3, 5, 7) - 0.) < 1e-4);


  return 0;
}
