#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "tensorCompute/torus3DTensor.h"
#include "sphere_3D/torus_basis_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"
#include "util/timer.h"

namespace {

void test() {
	const int rK_ = 5;
	const int thetaK_ = 8;
	const int phiK_ = 8;
	const double a_ = 3.0;
	std::vector<basisPtr3DTor> all_basis_;


	// allocate Phi^0, Psi^2, Psi^5
  for (int i3 = 1; i3 < phiK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {
      if (i2 == 1) {
        // Phi^6
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 6, a_)));
        }
        // Phi^4
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 4, a_)));
        }
        // Phi^2
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2 - 1, i3*2, 2, a_)));
        }
      }

      if (i2 == 1) {
        // Phi^7
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 7, a_)));
        }
        
        // Phi^5
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2 - 1, 2, i3*2, 5, a_)));
        }
        
        // Phi^3
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2 - 1, i3*2, 3, a_)));
        }
      }

      // Phi^0
      for (int i1 = 1; i1 < rK_; i1++) {
        all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2, i3*2, 0, a_)));
      }
      // Phi^1
      for (int i1 = 1; i1 < rK_; i1++) {
        all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(i1*2, i2, i3*2, 1, a_)));
      }
    }

    for (int i2 = 1; i2 < thetaK_; i2++) {
      // Phi^9
      for (int i1 = 1; i1 < rK_; i1++) {
        all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(2*i1 - 2, i2 - 1, 0, 9, a_)));
      }
      // Phi^8
      for (int i1 = 1; i1 < rK_; i1++) {
        all_basis_.push_back(basisPtr3DTor(new TorusBasis3D(2*i1 - 2, i2, 0, 8, a_)));
      }
    }

  const int numBasisAll_ = all_basis_.size();
Timer timer;
timer.Reset();
  LOG(INFO) << numBasisAll_;

  torus3DTensor tensorEval;

  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
  	//LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const TorusBasis3D& basis_i = *all_basis_[i];
        const TorusBasis3D& basis_g = *all_basis_[g];
        const TorusBasis3D& basis_h = *all_basis_[h];

        double Cigh = TorusBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
				const int idx = basis_i.index()*100 + basis_g.index()*10 + basis_h.index();
        double Cnew = tensorEval.pointers_[idx](basis_i, basis_g, basis_h, a_);
        CHECK(fabs(Cigh -  Cnew) < 1e-6) << Cigh << " " << Cnew << " " << i << " " << g << " " << h;
      }
    }
  }
  LOG(INFO) << timer.ElapsedTimeInSeconds();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
	
	test();

  return 0;
}