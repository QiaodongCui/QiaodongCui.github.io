#include <vector>
#include "tensorCompute/cylSin_evalP.h"
cylSinpEval::cylSinpEval() {
pointers_.resize(4);
pointers_[0] = &evalP_0;
pointers_[1] = &evalP_1;
pointers_[2] = &evalP_2;
pointers_[3] = &evalP_3;
}


