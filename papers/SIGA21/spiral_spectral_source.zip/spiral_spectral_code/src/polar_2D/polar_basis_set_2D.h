#ifndef POLAR_BASIS_SET_2D_H
#define POLAR_BASIS_SET_2D_H

 #include <cstring>
#include <Eigen/Eigen>
#include <fftw3.h>
#include <vector>

#include "2D/VFIELD2D.h"
#include "common/basis_set.h"
#include "polar_2D/polar_basis_2D.h"
#include "polar_2D/polar_basis_all.h"

#include "setting.h"



// first wavenumber can be half integer due to neumann, dirichlet bc.
struct pairedCoefPolar {
  pairedCoefPolar(int i1, int i2, double coef):i1x2(i1), i2x2(i2), coef(coef) {
    ;
  }
  pairedCoefPolar(const PolarBasisAll& basis, double coef):i1x2(basis.WN1x2()), i2x2(basis.WN2x2()), coef(coef) {
    ;
  }
  pairedCoefPolar(){};

  int i1x2 = 0;
  int i2x2 = 0;
  double coef = 0.0;
  void debugPrint() const {
    LOG(INFO) << i1x2 << " " << i2x2 << " " << coef;
  }
};

class PolarBasisSet2D : public BasisSet {

public:
  PolarBasisSet2D(int N, int radiusK, int angK, bool bndCnd):N_(N),
     radK_(radiusK), angK_(angK), boundaryCnd_(bndCnd) {
  };
  
  void allocateNumerical() override;

  ~PolarBasisSet2D(){
    free(urTemp_);
    free(utTemp_);
    free(oddTemp_);
    free(extTemp_);
    free(utrWTemp_);
  };
  
  void allocateTemp(bool rTwice) {
    totalSize_ = nTheta_*nR_;
    // need twice of the memory along r to support 
    // half integer fast transformations.
    if (rTwice)
      totalSize_ *= 2;
    urTemp_ = (double*) malloc(sizeof(double)*totalSize_);
    std::memset(urTemp_, 0x00, sizeof(double)*totalSize_);
    utTemp_ = (double*) malloc(sizeof(double)*totalSize_);
    std::memset(utTemp_, 0x00, sizeof(double)*totalSize_);
    oddTemp_ = (double*) malloc(sizeof(double)*totalSize_);
    std::memset(oddTemp_, 0x00, sizeof(double)*totalSize_);
    extTemp_ = (double*) malloc(sizeof(double)*totalSize_);
    std::memset(extTemp_, 0x00, sizeof(double)*totalSize_);
    utrWTemp_= (double*) malloc(sizeof(double)*totalSize_);
    std::memset(utrWTemp_, 0x00, sizeof(double)*totalSize_);

    invTotalSize_ = 1.0 / totalSize_;
    polarV_ = VFIELD2D(nTheta_, nR_);
    dr_ = 1.0 / nR_;
    dTheta_ = 2.0*M_PI / nTheta_;
    polarF_ = VFIELD2D(nTheta_, nR_);
  }

  // clear both ur and ut buffers
  void ClearuR() {
    std::memset(urTemp_, 0x00, sizeof(double) * totalSize_);
  }
  void ClearuT() {
    std::memset(utTemp_, 0x00, sizeof(double) * totalSize_);
  }
  void ClearOdd() {
    // oddTemp_
    std::memset(oddTemp_, 0x00, sizeof(double) * totalSize_);
  }
  void ClearExt() {
    // extTemp_
    std::memset(extTemp_, 0x00, sizeof(double) * totalSize_);
  }

  void ClearWUtr() {
    std::memset(utrWTemp_, 0x00, sizeof(double)*totalSize_);
  }
  
  void setUpFFTWPlan();

  // interpolate the urTemp and utTemp to Cartesian field.
  void interpolateToCartesian(VFIELD2D* field);

  // interpolate the catersian force to polar coordinates.
  void interpolateToPolar(const VFIELD2D& field);
  
  // Interpolate velocity from the polar grid.
  // [x,y] \in [0,1]^2
  VEC2 fromPolar(const double x, const double y);
  
  void addForcePolar();
  
  static void clearPointerSize(double* ptr, const int sizeBuf) {
    std::memset(ptr, 0x00, sizeof(double)*sizeBuf);
  }
  const FIELD2D& getR() const {
    return r_;
  }
  static double computeEnergyPolar(const int nR, const int nTheta, const double* ur, const double* ut);
  static void computeJDivPolar(const int nR, const int nTheta, const double* ur, const double* ut, double* div);
  int nR() const {return nR_;}
  int nTheta() const {return nTheta_;}

  const double* getURPointer() const {return urTemp_;}
  const double* getUTPointer() const {return utTemp_;}
  void interpolateToCartesian(VFIELD2D* field, const double* ur, const double* ut);
protected:

  void clearPairCoef();
  void weightR(double* buf);

  // square grid dimensions.
  const int N_;

  // number of divisions along the uniform theta and r grid.
  int nTheta_;
  int nR_;
  double dr_;
  double dTheta_;

  int totalSize_;
  double invTotalSize_;

  // number of basis along r
  const int radK_;
  // number of basis along theta
  const int angK_;

  double *urTemp_;
  double *utTemp_;

  // This is the buffer to deal with k2=0.5, 1.5,2.5, etc
  double *oddTemp_;
  // for fast transform of ut, more buff is needed.
  double *extTemp_;

  // this holds the weight results from ur, ut.
  double *utrWTemp_;
  
  // inverse plans
  fftw_plan IsinTheta_;
  fftw_plan IcosTheta_;
  fftw_plan IsinThetaEn_;
  fftw_plan IcosThetaEn_;
  fftw_plan IsinR_;
  fftw_plan IcosR_;
  fftw_plan IsinREn_;
  fftw_plan IcosREn_;

  fftw_plan FsinR_;
  fftw_plan FcosR_;
  fftw_plan FsinREn_;
  fftw_plan FcosREn_;
  fftw_plan FsinTheta_;
  fftw_plan FcosTheta_;
  fftw_plan FsinThetaEn_;
  fftw_plan FcosThetaEn_;

  fftw_plan IsinR1D_;
  fftw_plan FsinR1D_;

  // Velocity field.
  VFIELD2D polarV_;
  VFIELD2D polarF_;

  // group those basis functions into paried coefficients std::vectors.
  std::vector<std::vector<pairedCoefPolar>> phiCoef_;

  bool boundaryCnd_;

  double* weightFunc_;
  double* weightDeriv_;
  // first mode of cosine/sine function.
  double* cosFunc_;
  double* sinFunc_;

  // 1D buff of size nr.
  double* rtemp0_;
  double* rtemp1_;
  
  // r and theta fields for the catersian grid.
  FIELD2D r_;
  FIELD2D t_;
  FIELD2D x_;
  FIELD2D y_;
};

#endif  // POLAR_BASIS_SET_2D_H