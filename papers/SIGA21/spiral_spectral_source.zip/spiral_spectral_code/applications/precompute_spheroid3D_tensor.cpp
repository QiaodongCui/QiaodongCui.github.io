#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <string>
#include <sstream>
#include <math.h>
#include <memory>

#include "common/basis_set.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/sphere_basis_set_3D.h"
#include "sphere_3D/cylinder_basis_set_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"

#include "setting.h"
#include "util/util.h"
#include "util/read_write_tensor.h"
#include "util/timer.h"

using namespace Eigen;
using namespace std;

DEFINE_int32(basis_dim_des, 20, "The number of basis desired.");
DEFINE_string(basis_type, "sphere_3d_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");

DEFINE_string(boundaryCnd, "dirichlet", "The boundary condition, dirichlet or neumann.");

DEFINE_string(Tensor_file,"", "The folder to put the tensor, with slash.");
DEFINE_int32(rK, 2, "Number of modes along r");
DEFINE_int32(thetaK, 4, "Number of modes along theta.");
DEFINE_int32(phiK, 8, "Number of modes along phi.");
DEFINE_bool(usignRKTKPK, false, "Use specified rk, thetak, phiK");
DEFINE_double(b, 0.9, "The shorter axis.");
DEFINE_double(majorA, 3.0, "The major axis");
DEFINE_bool(computeBasisOnly, false, "only compute the basis without tensor");
DEFINE_string(basis_file, "", "The basis file without tensor info.");

namespace {

std::string strWithoutDot(const double b) {
  std::stringstream bSStr;
  bSStr << b;
  std::string bStr = bSStr.str();

  vector<char> wodotB;
  for (int i = 0; i < bStr.size(); i++) {
    if (bStr[i] != '.')
      wodotB.push_back(bStr[i]);
  }
  std::string bwoDot(wodotB.begin(), wodotB.end());
  return bwoDot;
}

}  // namespace

int main(int argc, char ** argv){
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);

  int radK = ceil(pow((double)(FLAGS_basis_dim_des)/8.0, 1.0/3.0));
  bool boundaryCnd = true;
  if (FLAGS_boundaryCnd == "dirichlet")
    boundaryCnd = true;
  if (FLAGS_boundaryCnd == "neumann")
    boundaryCnd = false;
  
  bool is_prolate = false, is_oblate = false;

  if (FLAGS_basis_type == "prolate_3d")
    is_prolate = true;
  else if (FLAGS_basis_type == "oblate_3d")
    is_oblate = true;
  else if (FLAGS_basis_type == "sphere_3d") {
    ;
  }
  else
    LOG(FATAL) << "unknown type: " << FLAGS_basis_type;
  const int xRes = 64;
  const int iStart = std::stoi(argv[1]);
  const int iEnd = std::stoi(argv[2]);
  LOG(INFO) << "start " << iStart << " end " << iEnd;

  std::unique_ptr<SphereBasisSet3D> basis;
  if (FLAGS_basis_file.size() != 0) {
    ifstream in(FLAGS_basis_file);
    if (! in.is_open())
      LOG(FATAL) << "cannot open " << FLAGS_basis_file;
    basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, in));
  } else {
    if ((is_prolate || is_oblate))
      basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, FLAGS_rK, FLAGS_thetaK, FLAGS_phiK, boundaryCnd, is_prolate, is_oblate, FLAGS_b));
    else
      basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, FLAGS_rK, FLAGS_thetaK, FLAGS_phiK, boundaryCnd));
  }
  
  std::string bwoDot = strWithoutDot(FLAGS_b);

  vector<Adv_Tensor_Type> Adv_tensor_;
  if (! FLAGS_computeBasisOnly) {
    basis->FillTensorProOblate(&Adv_tensor_, iStart, iEnd);
    LOG(INFO) << Adv_tensor_.size();
  }

  std::stringstream file_name;
  file_name << FLAGS_Tensor_file << FLAGS_basis_type;
  file_name << "b" << bwoDot;
  file_name << "Dim" << basis->numBasisAll();
  if (FLAGS_computeBasisOnly) {
    file_name << "woTensor";
    ofstream out(file_name.str(), std::ios::binary);
    basis->writeToFile(out, Adv_tensor_);
    out.close();
    return 0;
  }
  file_name << "_" << iStart << "_" << iEnd;
  
  LOG(INFO) << "Writting tensor to file: " << file_name.str();

  ofstream out(file_name.str(), std::ios::binary);
  out.write(reinterpret_cast<const char*>(&iStart), sizeof(int));
  out.write(reinterpret_cast<const char*>(&iEnd), sizeof(int));
  //basis->writeToFile(out, Adv_tensor_);
  for (int i = iStart; i < iEnd; i++)
    WriteTensorSlice(Adv_tensor_[i], out);
  out.close();
  return 0;
}
