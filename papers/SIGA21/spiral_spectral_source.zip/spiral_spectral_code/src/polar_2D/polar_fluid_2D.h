#ifndef POLAR_FLUID_2D_H
#define POLAR_FLUID_2D_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>

#include "2D/drawer_2d.h"
#include "solver/integrator_2d.h"
#include "common/eigen_fluid.h"
#include "polar_2D/polar_basis_set_2D.h"
#include "elliptic/elliptic_basis_set_2D.h"
#include "elliptic/elliptic_basis_2D.h"

#include "2D/FIELD2D.h"
#include "2D/particle_2d.h"
#include "util/timer.h"
#include "setting.h"
#include "2D/VFIELD2D.h"


//#define ALLOCATE_ELLIPTIC

class PolarFluid2D : public EigenFluid {
public:
  PolarFluid2D(
    const int xRes, const int yRes, const int basis_dim,
    const double dt,
    const std::string& basis_type,
    const std::string& integrator_type,
    double buoyancy, double visc, 
    const int num_particles, const int total_frame,
    const std::string& tensor_fname, const double tensorW, const double b):
    EigenFluid(basis_dim, dt, buoyancy, visc, num_particles, total_frame, basis_type, tensor_fname,
                 tensorW, integrator_type),
    xRes_(xRes), yRes_(yRes), b_(b), a_(sqrt(1.0 - b*b)), c_(b/sqrt(1.0 - b*b))
    {
      // TODO: modify the LaplacianBasisSet2D to support differemt xRes and yRes.
      CHECK_EQ(xRes, yRes) << "Only support square domain for now.";
      dx_ = 1.0 / std::max(xRes_, yRes_);
      Initialize();
    }
  ~PolarFluid2D(){}
  // Perform the forward step.
  void Step();
  void DrawDensity();
  void DrawVelocity();
  
  void DrawParticles(const double ptl_length);
  void DrawCoefficients(const double multi_factor);
  void DrawObstacles() {};
  void AddBuoyancy();

  void AddSmokeTestCase(const int xpos, const int ypos, const int width,
                        const int height);
  
  void AddForce(const int xpos, const int ypos, const float fx, const float fy);
  void AddSmoke(const int xpos, const int ypos, const float amount);
  
  void ReSeedParticles();
  void projBackParticles();
  bool addBounyancyOnce = false;
  void reWeightTensor();
  const Eigen::VectorXd& projWav() const {
    return projWav_;
  }

protected:
  void Initialize();
  void InitSmoke();
  // The resolution of the velocity field.
  const int xRes_;
  const int yRes_;
  double dx_;
  
  //const int numBasisAllroot_;
  Eigen::VectorXd tempVector_;

  std::shared_ptr<PolarBasisSet2D> basis_;
  
  // Class to draw stuff.
  std::unique_ptr<Drawer2D> drawer_;
  
  // Velocity field.
  VFIELD2D velocity_;
  // Force field.
  VFIELD2D force_;
 
  // Density field.
  FIELD2D density_;
  FIELD2D density_old_;

  FIELD2D temp1;
  FIELD2D temp2;

  // Particles.
  std::vector<Particle2D> particles_;

  void AddExternalForce();
  void AddDensity(const int x, const int y, const int width,
                  const int height, FIELD2D* field);
  
  void AdvectDensity();
  void AdvectParticles();

  //----------------- Elliptic params.
  const double b_;
  const double a_;
  const double c_;
  bool is_elliptic_ = false;
};

#endif  // POLAR_FLUID_2D_H
