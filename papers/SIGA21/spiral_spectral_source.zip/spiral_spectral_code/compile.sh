cd build
make -j6
cd ..