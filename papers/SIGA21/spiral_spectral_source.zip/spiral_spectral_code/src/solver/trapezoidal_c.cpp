#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <omp.h>
#include <vector>

#include "solver/trapezoidal_c.h"
#include "util/timer.h"
#include "solver/integrator_2d.h"

void TrapezoidalC::IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd& CoefROld,
                        const Eigen::VectorXd& CoefIOld,
                        const double dt,
                        Eigen::VectorXd* CoefRNew,
                        Eigen::VectorXd* CoefINew,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) {
  Timer timer;
  const int num_basis = CoefROld.size();
  // Allocate the contracted matrix. Generally, it should be dense.
  Eigen::MatrixXd MatReal(num_basis, num_basis);
  MatReal.setZero();
  Eigen::MatrixXd MatImag(num_basis, num_basis);
  MatImag.setZero();
  
  #pragma omp parallel for
  for (int i = 0; i < num_basis; i++) {
    MatReal.row(i).noalias() = - CoefIOld.transpose() * Adv_tensor[i];
   // MatImag.row(i).noalias() = CoefROld.transpose() * Adv_tensor[i];
  }
  LOG(INFO) << (MatReal.transpose() + MatReal).norm();
  // LOG(INFO) << (MatImag.transpose() + MatImag).norm() <<  CoefROld.transpose() * MatImag * CoefIOld;
  
  Eigen::MatrixXd A(num_basis, num_basis);
  A.setIdentity();

  // System for both real and imag part have same system matrix I - \Delta t *0.5 * CR
  A = A - 0.5*dt*MatReal;
  
  Eigen::VectorXd bReal(num_basis);
  bReal.setZero();
  Eigen::VectorXd bImag(num_basis);
  bImag.setZero();
  
  bReal = CoefROld + 0.5*dt*MatReal*CoefROld - dt*MatImag*CoefIOld;
  bImag = CoefIOld + 0.5*dt*MatReal*CoefIOld + dt*MatImag*CoefROld;
  
  //LOG(INFO) << (dt*MatReal*CoefIOld + dt*MatImag*CoefROld + CoefIOld).mean();
  //LOG(INFO) << CoefIOld.mean();
  
  *contraction_time = timer.ElapsedTimeInSeconds();
  
  Eigen::DiagonalPreconditioner<Eigen::MatrixXd::RealScalar> precond(A);
  int maxIters = 200;
  double tol_error = 1e-10;
  timer.Reset();
  Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  solver.setTolerance(1e-10);
  solver.compute(A);
  (*CoefRNew) = solver.solve(bReal);
  (*CoefINew) = solver.solve(bImag);
  // Integrator2D::conjugate_gradient_NE(A, A.transpose()*bReal, *CoefRNew, precond, maxIters, tol_error);

  // Integrator2D::conjugate_gradient_NE(A, A.transpose()*bImag, *CoefINew, precond, maxIters, tol_error);
  
  *solver_time = timer.ElapsedTimeInSeconds();
  (*CoefINew) = CoefIOld + dt*MatReal*CoefIOld;// + dt*MatImag*CoefROld;
  (*CoefRNew) = CoefROld + dt*MatReal*CoefROld;// - dt*MatImag*CoefIOld;
}
