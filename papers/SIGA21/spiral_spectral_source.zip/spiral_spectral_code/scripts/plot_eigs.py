import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt

def read_from_file(fname):
    allEigs = []
    f = open(fname)
    for line in f:
        eig = []
        temp = line.split(" ")
        for n in temp[:-1]:
            eig.append((float)(n))
        allEigs.append(np.asarray(eig))
    f.close()
    return allEigs


EigV = read_from_file("./SliceEig.txt")
print("%d " % len(EigV))
print(EigV[0])
#error = error*100.
index = np.arange(0, EigV[0].size)

font_size = 16
linge_width = 2

for i in range(0, len(EigV)):
    fig, ax = plt.subplots()
    ax.set_ylabel('Singular values ', fontsize = font_size)
    EigV[i] /= EigV[i][0]
    #ax.set_xlabel('', fontsize = font_size)
    ax.set_title('Normalized singular values for tensor slice i = %d' %  i, fontsize = font_size )

    line1, = ax.plot(index, abs(EigV[i].transpose()), color = 'blue' ,label="k = 1600", lw = linge_width)
    #line2, = ax.plot(index, eig100.transpose(),color = 'green' ,label = "k = 100", lw = linge_width)

    #line3, = ax.plot(index, eig0.transpose(),color = 'red' ,label = "k = 0", lw = linge_width)

    ax.legend(loc='upper left', bbox_to_anchor=(0., 1.0), fontsize = font_size)

    #plt.xticks(np.arange(0, x_ceil, 200))
    for tick in ax.xaxis.get_major_ticks():
                    tick.label.set_fontsize(font_size)
    for tick in ax.yaxis.get_major_ticks():
                   tick.label.set_fontsize(font_size)   
    #plt.show()
    plt.savefig("./eigPlot/%d.png" % i, bbox_incles='tight')