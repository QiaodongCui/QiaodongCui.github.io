#ifndef sph3DSR_EVAL_T_H
#define sph3DSR_EVAL_T_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define SinTPi TrigInt::IntegrateSinPi_D2
#define CosTPi TrigInt::IntegrateCosPi_D2
#define Pi M_PI


class sph3DSRtEval{
public:
sph3DSRtEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~sph3DSRtEval(){};
/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_0(const int i2x2, const int g2x2, const int h2x2){
return (-3*CosTPi(4-g2x2-h2x2-i2x2))/64.+CosTPi(12-g2x2-h2x2-i2x2)/64.+(3*CosTPi(4+g2x2-h2x2-i2x2))/64.-CosTPi(12+g2x2-h2x2-i2x2)/64.+(3*CosTPi(4-g2x2+h2x2-i2x2))/64.-CosTPi(12-g2x2+h2x2-i2x2)/64.-(3*CosTPi(4+g2x2+h2x2-i2x2))/64.+CosTPi(12+g2x2+h2x2-i2x2)/64.+(3*CosTPi(4-g2x2-h2x2+i2x2))/64.-CosTPi(12-g2x2-h2x2+i2x2)/64.-(3*CosTPi(4+g2x2-h2x2+i2x2))/64.+CosTPi(12+g2x2-h2x2+i2x2)/64.-(3*CosTPi(4-g2x2+h2x2+i2x2))/64.+CosTPi(12-g2x2+h2x2+i2x2)/64.+(3*CosTPi(4+g2x2+h2x2+i2x2))/64.-CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_1(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/64.-CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(12-g2x2-h2x2-i2x2)/64.-CosTPi(4+g2x2-h2x2-i2x2)/64.+CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(12+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/64.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(12-g2x2+h2x2-i2x2)/64.+CosTPi(4+g2x2+h2x2-i2x2)/64.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(12+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/64.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(12-g2x2-h2x2+i2x2)/64.+CosTPi(4+g2x2-h2x2+i2x2)/64.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(12+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/64.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(12-g2x2+h2x2+i2x2)/64.-CosTPi(4+g2x2+h2x2+i2x2)/64.+CosTPi(8+g2x2+h2x2+i2x2)/32.-CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_2(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/64.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(12-g2x2-h2x2-i2x2)/64.-CosTPi(g2x2-h2x2-i2x2)/16.+CosTPi(4+g2x2-h2x2-i2x2)/64.+CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(12+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/64.-CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(12-g2x2+h2x2-i2x2)/64.+CosTPi(g2x2+h2x2-i2x2)/16.-CosTPi(4+g2x2+h2x2-i2x2)/64.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(12+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/64.-CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(12-g2x2-h2x2+i2x2)/64.+CosTPi(g2x2-h2x2+i2x2)/16.-CosTPi(4+g2x2-h2x2+i2x2)/64.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(12+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/64.+CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(12-g2x2+h2x2+i2x2)/64.-CosTPi(g2x2+h2x2+i2x2)/16.+CosTPi(4+g2x2+h2x2+i2x2)/64.+CosTPi(8+g2x2+h2x2+i2x2)/32.-CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_3(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_4(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/64.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(12-g2x2-h2x2-i2x2)/64.+CosTPi(g2x2-h2x2-i2x2)/16.-CosTPi(4+g2x2-h2x2-i2x2)/64.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(12+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/64.-CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(12-g2x2+h2x2-i2x2)/64.-CosTPi(g2x2+h2x2-i2x2)/16.+CosTPi(4+g2x2+h2x2-i2x2)/64.+CosTPi(8+g2x2+h2x2-i2x2)/32.-CosTPi(12+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/64.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(12-g2x2-h2x2+i2x2)/64.+CosTPi(g2x2-h2x2+i2x2)/16.-CosTPi(4+g2x2-h2x2+i2x2)/64.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(12+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/64.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(12-g2x2+h2x2+i2x2)/64.-CosTPi(g2x2+h2x2+i2x2)/16.+CosTPi(4+g2x2+h2x2+i2x2)/64.+CosTPi(8+g2x2+h2x2+i2x2)/32.-CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_5(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.-CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(4+g2x2-h2x2+i2x2)/16.-CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_6(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/64.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(12-g2x2-h2x2-i2x2)/64.+CosTPi(g2x2-h2x2-i2x2)/16.-CosTPi(4+g2x2-h2x2-i2x2)/64.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(12+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/64.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(12-g2x2+h2x2-i2x2)/64.+CosTPi(g2x2+h2x2-i2x2)/16.-CosTPi(4+g2x2+h2x2-i2x2)/64.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(12+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/64.-CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(12-g2x2-h2x2+i2x2)/64.-CosTPi(g2x2-h2x2+i2x2)/16.+CosTPi(4+g2x2-h2x2+i2x2)/64.+CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(12+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/64.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(12-g2x2+h2x2+i2x2)/64.-CosTPi(g2x2+h2x2+i2x2)/16.+CosTPi(4+g2x2+h2x2+i2x2)/64.+CosTPi(8+g2x2+h2x2+i2x2)/32.-CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_7(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.-CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(4-g2x2+h2x2+i2x2)/16.-CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_8(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.-CosTPi(8-g2x2-h2x2-i2x2)/64.-(3*CosTPi(g2x2-h2x2-i2x2))/32.+CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/64.+(3*CosTPi(g2x2+h2x2-i2x2))/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/64.+(3*CosTPi(g2x2-h2x2+i2x2))/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/16.-CosTPi(8-g2x2+h2x2+i2x2)/64.-(3*CosTPi(g2x2+h2x2+i2x2))/32.+CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_9(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.-CosTPi(8-g2x2-h2x2-i2x2)/64.+(3*CosTPi(g2x2-h2x2-i2x2))/32.-CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/64.+(3*CosTPi(g2x2+h2x2-i2x2))/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/64.-(3*CosTPi(g2x2-h2x2+i2x2))/32.+CosTPi(4+g2x2-h2x2+i2x2)/16.-CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/64.-(3*CosTPi(g2x2+h2x2+i2x2))/32.+CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_10(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/32.-CosTPi(8-g2x2-h2x2-i2x2)/64.+CosTPi(4+g2x2-h2x2-i2x2)/32.-CosTPi(8+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/32.+CosTPi(8-g2x2+h2x2-i2x2)/64.-CosTPi(4+g2x2+h2x2-i2x2)/32.+CosTPi(8+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/32.-CosTPi(8-g2x2-h2x2+i2x2)/64.+CosTPi(4+g2x2-h2x2+i2x2)/32.-CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/32.+CosTPi(8-g2x2+h2x2+i2x2)/64.-CosTPi(4+g2x2+h2x2+i2x2)/32.+CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_11(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/32.-CosTPi(8-g2x2-h2x2-i2x2)/64.-CosTPi(4+g2x2-h2x2-i2x2)/32.+CosTPi(8+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/32.-CosTPi(8-g2x2+h2x2-i2x2)/64.-CosTPi(4+g2x2+h2x2-i2x2)/32.+CosTPi(8+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/32.-CosTPi(8-g2x2-h2x2+i2x2)/64.-CosTPi(4+g2x2-h2x2+i2x2)/32.+CosTPi(8+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/32.-CosTPi(8-g2x2+h2x2+i2x2)/64.-CosTPi(4+g2x2+h2x2+i2x2)/32.+CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_12(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.-CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.-CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(10+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/32.+CosTPi(10-g2x2+h2x2+i2x2)/32.+CosTPi(2+g2x2+h2x2+i2x2)/16.+CosTPi(6+g2x2+h2x2+i2x2)/32.-CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_13(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.+CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/16.-CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/16.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.+CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/16.-CosTPi(2+g2x2-h2x2+i2x2)/16.+CosTPi(6+g2x2-h2x2+i2x2)/16.+CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/16.-CosTPi(2+g2x2+h2x2+i2x2)/16.+CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_14(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(10+g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_15(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.-CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/16.+CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(10+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/16.+CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_16(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.+CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/16.+CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/16.-CosTPi(2+g2x2+h2x2-i2x2)/16.+CosTPi(6+g2x2+h2x2-i2x2)/16.-CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/16.+CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/16.+CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/16.-CosTPi(2+g2x2+h2x2+i2x2)/16.+CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_17(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(10-g2x2-h2x2-i2x2)/32.-CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.-CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(10+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/16.+CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_18(const int i2x2, const int g2x2, const int h2x2){
return (-3*CosTPi(2-g2x2-h2x2-i2x2))/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.+(3*CosTPi(2+g2x2-h2x2-i2x2))/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.+(3*CosTPi(2-g2x2+h2x2-i2x2))/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.-(3*CosTPi(2+g2x2+h2x2-i2x2))/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.+(3*CosTPi(2-g2x2-h2x2+i2x2))/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.-(3*CosTPi(2+g2x2-h2x2+i2x2))/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.-(3*CosTPi(2-g2x2+h2x2+i2x2))/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.+(3*CosTPi(2+g2x2+h2x2+i2x2))/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_19(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-h2x2-i2x2))/32.-CosTPi(6-g2x2-h2x2-i2x2)/32.+(3*CosTPi(2+g2x2-h2x2-i2x2))/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.+(3*CosTPi(2-g2x2+h2x2-i2x2))/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.+(3*CosTPi(2+g2x2+h2x2-i2x2))/32.-CosTPi(6+g2x2+h2x2-i2x2)/32.-(3*CosTPi(2-g2x2-h2x2+i2x2))/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.-(3*CosTPi(2+g2x2-h2x2+i2x2))/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.-(3*CosTPi(2-g2x2+h2x2+i2x2))/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.-(3*CosTPi(2+g2x2+h2x2+i2x2))/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_20(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(2+g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_21(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.-CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.+CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_22(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.-CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/64.+CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.-CosTPi(2+g2x2-h2x2+i2x2)/32.+CosTPi(6+g2x2-h2x2+i2x2)/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/64.-CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_23(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_24(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(6-g2x2-h2x2-i2x2)/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.-CosTPi(6-g2x2+h2x2-i2x2)/64.+CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.-CosTPi(6+g2x2-h2x2+i2x2)/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(6-g2x2+h2x2+i2x2)/64.-CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_25(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/64.-CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(2+g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.-CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/64.+CosTPi(10-g2x2-h2x2+i2x2)/64.-CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.-CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_26(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/64.-CosTPi(10-g2x2-h2x2-i2x2)/64.-CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/64.+CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.-CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/64.+CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.-CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(2-g2x2+h2x2+i2x2)/32.+CosTPi(6-g2x2+h2x2+i2x2)/64.-CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_27(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)+3*SinTPi(4+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)+3*SinTPi(4-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)-3*SinTPi(4+g2x2+i2x2)+SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_28(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-i2x2)+SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)-SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)-SinTPi(8-g2x2+i2x2)-2*SinTPi(4+g2x2+i2x2)+SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_29(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-i2x2)-2*SinTPi(8-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+2*SinTPi(8+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+2*SinTPi(8-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)+SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_30(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-i2x2)+2*SinTPi(g2x2-i2x2)-SinTPi(8+g2x2-i2x2)+SinTPi(8-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_31(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)-SinTPi(12-g2x2-i2x2)+4*SinTPi(g2x2-i2x2)-SinTPi(4+g2x2-i2x2)-2*SinTPi(8+g2x2-i2x2)+SinTPi(12+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)+2*SinTPi(8-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+4*SinTPi(g2x2+i2x2)-SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)+SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_32(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-i2x2)+SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)-SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)-SinTPi(8-g2x2+i2x2)-2*SinTPi(4+g2x2+i2x2)+SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_33(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-g2x2-i2x2)-SinTPi(8-g2x2-i2x2)-6*SinTPi(g2x2-i2x2)+4*SinTPi(4+g2x2-i2x2)-SinTPi(8+g2x2-i2x2)-4*SinTPi(4-g2x2+i2x2)+SinTPi(8-g2x2+i2x2)+6*SinTPi(g2x2+i2x2)-4*SinTPi(4+g2x2+i2x2)+SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_34(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-i2x2)+2*SinTPi(g2x2-i2x2)-SinTPi(8+g2x2-i2x2)+SinTPi(8-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_35(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2-i2x2)-SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)-SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)-SinTPi(8-g2x2+i2x2)+2*SinTPi(4+g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_36(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)+2*CosTPi(8-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+4*CosTPi(g2x2-i2x2)-CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)+CosTPi(12+g2x2-i2x2)-CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)+CosTPi(12-g2x2+i2x2)-4*CosTPi(g2x2+i2x2)+CosTPi(4+g2x2+i2x2)+2*CosTPi(8+g2x2+i2x2)-CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_37(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)-CosTPi(8+g2x2-i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]*/
static double evalT_38(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+CosTPi(12-g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)-CosTPi(4+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_39(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+2*CosTPi(8-g2x2-i2x2)+CosTPi(12-g2x2-i2x2)+4*CosTPi(g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)-4*CosTPi(g2x2+i2x2)-CosTPi(4+g2x2+i2x2)+2*CosTPi(8+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_40(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)-CosTPi(8-g2x2-i2x2)-2*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)+2*CosTPi(4-g2x2+i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_41(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)-3*CosTPi(4+g2x2-i2x2)+CosTPi(12+g2x2-i2x2)+3*CosTPi(4-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)-3*CosTPi(4+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_42(const int i2x2, const int g2x2, const int h2x2){
return (4*CosTPi(4-g2x2-i2x2)-CosTPi(8-g2x2-i2x2)+6*CosTPi(g2x2-i2x2)-4*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)-4*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)-6*CosTPi(g2x2+i2x2)+4*CosTPi(4+g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_43(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)-CosTPi(8-g2x2-i2x2)+2*CosTPi(4+g2x2-i2x2)-CosTPi(8+g2x2-i2x2)-2*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_44(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)-CosTPi(8-g2x2-i2x2)-2*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)+2*CosTPi(4-g2x2+i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_45(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)-CosTPi(8+g2x2-i2x2)-CosTPi(8-g2x2+i2x2)+2*CosTPi(g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_46(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)-CosTPi(8+g2x2-i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]*/
static double evalT_47(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+CosTPi(12-g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)-CosTPi(4+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_48(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)-CosTPi(4+g2x2-i2x2)-CosTPi(4-g2x2+i2x2)-2*CosTPi(g2x2+i2x2)+CosTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_49(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)-2*CosTPi(g2x2-i2x2)+2*CosTPi(4+g2x2-i2x2)-CosTPi(8+g2x2-i2x2)+2*CosTPi(4-g2x2+i2x2)-CosTPi(8-g2x2+i2x2)+2*CosTPi(g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_50(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+3*CosTPi(4+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)-3*CosTPi(4-g2x2+i2x2)+CosTPi(12-g2x2+i2x2)-3*CosTPi(4+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_51(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+2*CosTPi(8-g2x2-i2x2)+CosTPi(12-g2x2-i2x2)+4*CosTPi(g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)-4*CosTPi(g2x2+i2x2)-CosTPi(4+g2x2+i2x2)+2*CosTPi(8+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_52(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)-CosTPi(8-g2x2-i2x2)+2*CosTPi(4+g2x2-i2x2)-CosTPi(8+g2x2-i2x2)-2*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_53(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)-3*CosTPi(4+g2x2-i2x2)+CosTPi(12+g2x2-i2x2)+3*CosTPi(4-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)-3*CosTPi(4+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_54(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)-CosTPi(4+g2x2-i2x2)-CosTPi(4-g2x2+i2x2)+2*CosTPi(g2x2+i2x2)-CosTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_55(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(4+g2x2-h2x2+i2x2)-SinTPi(4-g2x2+h2x2+i2x2)-2*SinTPi(g2x2+h2x2+i2x2)+SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_56(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/16.-SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(g2x2-h2x2-i2x2)/16.-SinTPi(4+g2x2-h2x2-i2x2)/16.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(4-g2x2+h2x2-i2x2)/16.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(g2x2+h2x2-i2x2)/16.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(4-g2x2-h2x2+i2x2)/16.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(g2x2-h2x2+i2x2)/16.+SinTPi(4+g2x2-h2x2+i2x2)/16.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(4-g2x2+h2x2+i2x2)/16.-SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(g2x2+h2x2+i2x2)/16.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_57(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/32.-SinTPi(4+g2x2-h2x2-i2x2)/16.+SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/32.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(4-g2x2-h2x2+i2x2)/16.-SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(4+g2x2-h2x2+i2x2)/16.-SinTPi(8+g2x2-h2x2+i2x2)/32.-SinTPi(4-g2x2+h2x2+i2x2)/16.+SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_58(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(4+g2x2+h2x2-i2x2)/16.+SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(4-g2x2-h2x2+i2x2)/16.+SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(4+g2x2-h2x2+i2x2)/16.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(4-g2x2+h2x2+i2x2)/16.-SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_59(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(8-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(8+g2x2-h2x2-i2x2)+SinTPi(8-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(8+g2x2+h2x2-i2x2)+SinTPi(8-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(8+g2x2-h2x2+i2x2)-SinTPi(8-g2x2+h2x2+i2x2)-2*SinTPi(g2x2+h2x2+i2x2)+SinTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_60(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)-SinTPi(4-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)-2*SinTPi(g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)-SinTPi(4-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_61(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/64.-SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(12-g2x2-h2x2-i2x2)/64.-SinTPi(g2x2-h2x2-i2x2)/16.+SinTPi(4+g2x2-h2x2-i2x2)/64.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(12+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/64.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(12-g2x2+h2x2-i2x2)/64.+SinTPi(g2x2+h2x2-i2x2)/16.-SinTPi(4+g2x2+h2x2-i2x2)/64.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(12+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/64.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(12-g2x2-h2x2+i2x2)/64.+SinTPi(g2x2-h2x2+i2x2)/16.-SinTPi(4+g2x2-h2x2+i2x2)/64.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(12+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/64.-SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(12-g2x2+h2x2+i2x2)/64.-SinTPi(g2x2+h2x2+i2x2)/16.+SinTPi(4+g2x2+h2x2+i2x2)/64.+SinTPi(8+g2x2+h2x2+i2x2)/32.-SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_62(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-g2x2-h2x2-i2x2))/64.+SinTPi(12-g2x2-h2x2-i2x2)/64.+(3*SinTPi(4+g2x2-h2x2-i2x2))/64.-SinTPi(12+g2x2-h2x2-i2x2)/64.-(3*SinTPi(4-g2x2+h2x2-i2x2))/64.+SinTPi(12-g2x2+h2x2-i2x2)/64.+(3*SinTPi(4+g2x2+h2x2-i2x2))/64.-SinTPi(12+g2x2+h2x2-i2x2)/64.+(3*SinTPi(4-g2x2-h2x2+i2x2))/64.-SinTPi(12-g2x2-h2x2+i2x2)/64.-(3*SinTPi(4+g2x2-h2x2+i2x2))/64.+SinTPi(12+g2x2-h2x2+i2x2)/64.+(3*SinTPi(4-g2x2+h2x2+i2x2))/64.-SinTPi(12-g2x2+h2x2+i2x2)/64.-(3*SinTPi(4+g2x2+h2x2+i2x2))/64.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_63(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/64.-SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(12-g2x2-h2x2-i2x2)/64.-SinTPi(4+g2x2-h2x2-i2x2)/64.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(12+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/64.-SinTPi(8-g2x2+h2x2-i2x2)/32.+SinTPi(12-g2x2+h2x2-i2x2)/64.-SinTPi(4+g2x2+h2x2-i2x2)/64.+SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(12+g2x2+h2x2-i2x2)/64.-SinTPi(4-g2x2-h2x2+i2x2)/64.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(12-g2x2-h2x2+i2x2)/64.+SinTPi(4+g2x2-h2x2+i2x2)/64.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(12+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/64.+SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(12-g2x2+h2x2+i2x2)/64.+SinTPi(4+g2x2+h2x2+i2x2)/64.-SinTPi(8+g2x2+h2x2+i2x2)/32.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_64(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(4-g2x2+h2x2-i2x2)/16.+SinTPi(8-g2x2+h2x2-i2x2)/32.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(4-g2x2-h2x2+i2x2)/16.-SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(4+g2x2-h2x2+i2x2)/16.+SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(4-g2x2+h2x2+i2x2)/16.-SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_65(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/64.+SinTPi(8-g2x2-h2x2-i2x2)/32.-SinTPi(12-g2x2-h2x2-i2x2)/64.+SinTPi(g2x2-h2x2-i2x2)/16.-SinTPi(4+g2x2-h2x2-i2x2)/64.-SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(12+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/64.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(12-g2x2+h2x2-i2x2)/64.+SinTPi(g2x2+h2x2-i2x2)/16.-SinTPi(4+g2x2+h2x2-i2x2)/64.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(12+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/64.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(12-g2x2-h2x2+i2x2)/64.+SinTPi(g2x2-h2x2+i2x2)/16.-SinTPi(4+g2x2-h2x2+i2x2)/64.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(12+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/64.+SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(12-g2x2+h2x2+i2x2)/64.+SinTPi(g2x2+h2x2+i2x2)/16.-SinTPi(4+g2x2+h2x2+i2x2)/64.-SinTPi(8+g2x2+h2x2+i2x2)/32.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_66(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/64.+SinTPi(8-g2x2-h2x2-i2x2)/32.-SinTPi(12-g2x2-h2x2-i2x2)/64.-SinTPi(g2x2-h2x2-i2x2)/16.+SinTPi(4+g2x2-h2x2-i2x2)/64.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(12+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/64.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(12-g2x2+h2x2-i2x2)/64.-SinTPi(g2x2+h2x2-i2x2)/16.+SinTPi(4+g2x2+h2x2-i2x2)/64.+SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(12+g2x2+h2x2-i2x2)/64.-SinTPi(4-g2x2-h2x2+i2x2)/64.-SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(12-g2x2-h2x2+i2x2)/64.+SinTPi(g2x2-h2x2+i2x2)/16.-SinTPi(4+g2x2-h2x2+i2x2)/64.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(12+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/64.-SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(12-g2x2+h2x2+i2x2)/64.+SinTPi(g2x2+h2x2+i2x2)/16.-SinTPi(4+g2x2+h2x2+i2x2)/64.-SinTPi(8+g2x2+h2x2+i2x2)/32.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_67(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/16.-SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/32.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(4-g2x2-h2x2+i2x2)/16.-SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(4+g2x2-h2x2+i2x2)/16.-SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(4-g2x2+h2x2+i2x2)/16.-SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(4+g2x2+h2x2+i2x2)/16.-SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_68(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/16.-SinTPi(8-g2x2-h2x2-i2x2)/64.-(3*SinTPi(g2x2-h2x2-i2x2))/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/64.-(3*SinTPi(g2x2+h2x2-i2x2))/32.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/64.-SinTPi(4-g2x2-h2x2+i2x2)/16.+SinTPi(8-g2x2-h2x2+i2x2)/64.+(3*SinTPi(g2x2-h2x2+i2x2))/32.-SinTPi(4+g2x2-h2x2+i2x2)/16.+SinTPi(8+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/16.+SinTPi(8-g2x2+h2x2+i2x2)/64.+(3*SinTPi(g2x2+h2x2+i2x2))/32.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_69(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/32.+SinTPi(8-g2x2-h2x2-i2x2)/64.+SinTPi(4+g2x2-h2x2-i2x2)/32.-SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/32.-SinTPi(8-g2x2+h2x2-i2x2)/64.-SinTPi(4+g2x2+h2x2-i2x2)/32.+SinTPi(8+g2x2+h2x2-i2x2)/64.-SinTPi(4-g2x2-h2x2+i2x2)/32.+SinTPi(8-g2x2-h2x2+i2x2)/64.+SinTPi(4+g2x2-h2x2+i2x2)/32.-SinTPi(8+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/32.-SinTPi(8-g2x2+h2x2+i2x2)/64.-SinTPi(4+g2x2+h2x2+i2x2)/32.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_70(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/64.-(3*SinTPi(g2x2-h2x2-i2x2))/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/64.+(3*SinTPi(g2x2+h2x2-i2x2))/32.-SinTPi(4+g2x2+h2x2-i2x2)/16.+SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/16.-SinTPi(8-g2x2-h2x2+i2x2)/64.+(3*SinTPi(g2x2-h2x2+i2x2))/32.-SinTPi(4+g2x2-h2x2+i2x2)/16.+SinTPi(8+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/16.+SinTPi(8-g2x2+h2x2+i2x2)/64.-(3*SinTPi(g2x2+h2x2+i2x2))/32.+SinTPi(4+g2x2+h2x2+i2x2)/16.-SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_71(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/32.-SinTPi(8-g2x2-h2x2-i2x2)/64.+SinTPi(4+g2x2-h2x2-i2x2)/32.-SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/32.-SinTPi(8-g2x2+h2x2-i2x2)/64.+SinTPi(4+g2x2+h2x2-i2x2)/32.-SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/32.-SinTPi(8-g2x2-h2x2+i2x2)/64.+SinTPi(4+g2x2-h2x2+i2x2)/32.-SinTPi(8+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/32.-SinTPi(8-g2x2+h2x2+i2x2)/64.+SinTPi(4+g2x2+h2x2+i2x2)/32.-SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_72(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.-CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/16.+CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/16.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.+CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/16.+CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/16.-CosTPi(2-g2x2+h2x2+i2x2)/16.+CosTPi(6-g2x2+h2x2+i2x2)/16.-CosTPi(2+g2x2+h2x2+i2x2)/16.+CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_73(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(10-g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(10+g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.+CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_74(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(10-g2x2-h2x2-i2x2)/32.-CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(10+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/16.+CosTPi(6-g2x2+h2x2+i2x2)/32.+CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/16.+CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_75(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.-CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(10-g2x2+h2x2-i2x2)/32.-CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/16.+CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(10+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/32.+CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_76(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_77(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.-CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/64.+CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/64.-CosTPi(10+g2x2-h2x2+i2x2)/64.-CosTPi(2-g2x2+h2x2+i2x2)/32.+CosTPi(6-g2x2+h2x2+i2x2)/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_78(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(6-g2x2-h2x2-i2x2)/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.-CosTPi(6+g2x2-h2x2-i2x2)/64.+CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(6+g2x2-h2x2+i2x2)/64.-CosTPi(10+g2x2-h2x2+i2x2)/64.-CosTPi(6-g2x2+h2x2+i2x2)/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_79(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/64.-CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.-CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/64.+CosTPi(10-g2x2+h2x2-i2x2)/64.-CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/64.+CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(2+g2x2-h2x2+i2x2)/32.+CosTPi(6+g2x2-h2x2+i2x2)/64.-CosTPi(10+g2x2-h2x2+i2x2)/64.-CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_80(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)-2*CosTPi(g2x2-h2x2-i2x2)+CosTPi(4+g2x2-h2x2-i2x2)-CosTPi(4-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)-CosTPi(4-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)+CosTPi(4-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_81(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(4+g2x2-h2x2-i2x2)+CosTPi(4-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)-CosTPi(4-g2x2-h2x2+i2x2)-2*CosTPi(g2x2-h2x2+i2x2)+CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_82(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)+CosTPi(4+g2x2-h2x2-i2x2)-CosTPi(4-g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)+CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)-CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_83(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)-CosTPi(4+g2x2-h2x2-i2x2)+CosTPi(4-g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)+CosTPi(4-g2x2+h2x2+i2x2)-CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_84(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2-i2x2)-2*CosTPi(g2x2-h2x2-i2x2)+CosTPi(8+g2x2-h2x2-i2x2)-CosTPi(8-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(8+g2x2-h2x2+i2x2)+CosTPi(8-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_85(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(8+g2x2-h2x2-i2x2)+CosTPi(8-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)-2*CosTPi(g2x2-h2x2+i2x2)+CosTPi(8+g2x2-h2x2+i2x2)-CosTPi(8-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_86(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)+CosTPi(4+g2x2-h2x2-i2x2)+CosTPi(4-g2x2+h2x2-i2x2)+CosTPi(4+g2x2+h2x2-i2x2)-CosTPi(4-g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)-CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_87(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2-i2x2)+CosTPi(8+g2x2-h2x2-i2x2)+CosTPi(8-g2x2+h2x2-i2x2)+CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)-CosTPi(8+g2x2-h2x2+i2x2)-CosTPi(8-g2x2+h2x2+i2x2)-CosTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_88(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/32.-CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.-CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(4-g2x2+h2x2+i2x2)/16.-CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_89(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(8+g2x2-h2x2-i2x2)-CosTPi(8-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(8+g2x2-h2x2+i2x2)-CosTPi(8-g2x2+h2x2+i2x2)+2*CosTPi(g2x2+h2x2+i2x2)-CosTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_90(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+3*SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)+3*SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)-3*SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_91(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)-SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)+SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_92(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)-SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_93(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_94(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)-2*SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_95(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)-SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)+SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_96(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)-SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)-SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_97(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(2+g2x2+i2x2)+CosTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_98(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-i2x2)-CosTPi(6-g2x2-i2x2)+3*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)-3*CosTPi(2-g2x2+i2x2)+CosTPi(6-g2x2+i2x2)-3*CosTPi(2+g2x2+i2x2)+CosTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_99(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)-CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)+CosTPi(6-g2x2+i2x2)-CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_100(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)-CosTPi(6-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)+CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_101(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)-CosTPi(6-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)+CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_102(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)-CosTPi(6-g2x2-i2x2)-CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)+2*CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_103(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)-CosTPi(2-g2x2+i2x2)-CosTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_104(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)+3*CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)+3*CosTPi(6+g2x2-i2x2)+CosTPi(10+g2x2-i2x2)-2*CosTPi(2-g2x2+i2x2)-3*CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)-3*CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_105(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)-CosTPi(2+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_106(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)-CosTPi(2+g2x2-i2x2)+CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)+CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_107(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)+CosTPi(6+g2x2-i2x2)+CosTPi(10+g2x2-i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)-CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_108(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(2+g2x2+i2x2)+CosTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_109(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)+CosTPi(6+g2x2+i2x2)+CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_110(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)+CosTPi(6+g2x2-i2x2)-CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_111(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)+CosTPi(6+g2x2-i2x2)-CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_112(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)-CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)+CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)-2*CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)+CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2)+CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_113(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/16.-SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/16.-SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/16.+SinTPi(2+g2x2+h2x2-i2x2)/16.-SinTPi(6+g2x2+h2x2-i2x2)/16.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.+SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/16.+SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/16.-SinTPi(2+g2x2+h2x2+i2x2)/16.+SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_114(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/16.-SinTPi(2+g2x2-h2x2-i2x2)/16.-SinTPi(6+g2x2-h2x2-i2x2)/16.+SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/16.+SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/16.+SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.+SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/16.-SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/16.-SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_115(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/16.+SinTPi(2+g2x2-h2x2-i2x2)/16.-SinTPi(6+g2x2-h2x2-i2x2)/16.-SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/16.-SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/16.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.-SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/16.+SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/16.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_116(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2-i2x2)-SinTPi(2+g2x2-h2x2-i2x2)+SinTPi(2-g2x2+h2x2-i2x2)+SinTPi(2+g2x2+h2x2-i2x2)+SinTPi(2-g2x2-h2x2+i2x2)+SinTPi(2+g2x2-h2x2+i2x2)-SinTPi(2-g2x2+h2x2+i2x2)-SinTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_117(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2-i2x2)+SinTPi(2+g2x2-h2x2-i2x2)+SinTPi(2-g2x2+h2x2-i2x2)-SinTPi(2+g2x2+h2x2-i2x2)-SinTPi(2-g2x2-h2x2+i2x2)+SinTPi(2+g2x2-h2x2+i2x2)+SinTPi(2-g2x2+h2x2+i2x2)-SinTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_118(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/16.-SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/16.+SinTPi(2-g2x2+h2x2-i2x2)/16.-SinTPi(6-g2x2+h2x2-i2x2)/16.+SinTPi(2+g2x2+h2x2-i2x2)/16.-SinTPi(6+g2x2+h2x2-i2x2)/16.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.-SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/16.+SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/16.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_119(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-h2x2-i2x2))/32.+SinTPi(6-g2x2-h2x2-i2x2)/32.-(3*SinTPi(2+g2x2-h2x2-i2x2))/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.+(3*SinTPi(2-g2x2+h2x2-i2x2))/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.+(3*SinTPi(2+g2x2+h2x2-i2x2))/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.+(3*SinTPi(2-g2x2-h2x2+i2x2))/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.+(3*SinTPi(2+g2x2-h2x2+i2x2))/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.-(3*SinTPi(2-g2x2+h2x2+i2x2))/32.+SinTPi(6-g2x2+h2x2+i2x2)/32.-(3*SinTPi(2+g2x2+h2x2+i2x2))/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_120(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-h2x2-i2x2))/32.+SinTPi(6-g2x2-h2x2-i2x2)/32.+(3*SinTPi(2+g2x2-h2x2-i2x2))/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.-(3*SinTPi(2-g2x2+h2x2-i2x2))/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.+(3*SinTPi(2+g2x2+h2x2-i2x2))/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.+(3*SinTPi(2-g2x2-h2x2+i2x2))/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.-(3*SinTPi(2+g2x2-h2x2+i2x2))/32.+SinTPi(6+g2x2-h2x2+i2x2)/32.+(3*SinTPi(2-g2x2+h2x2+i2x2))/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.-(3*SinTPi(2+g2x2+h2x2+i2x2))/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_121(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_122(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_123(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.-SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/64.+SinTPi(10+g2x2-h2x2-i2x2)/64.-SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/64.+SinTPi(10-g2x2+h2x2-i2x2)/64.-SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/64.+SinTPi(10+g2x2+h2x2-i2x2)/64.+SinTPi(2-g2x2-h2x2+i2x2)/32.-SinTPi(6-g2x2-h2x2+i2x2)/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_124(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.-SinTPi(6+g2x2-h2x2-i2x2)/64.+SinTPi(10+g2x2-h2x2-i2x2)/64.-SinTPi(6-g2x2+h2x2-i2x2)/64.+SinTPi(10-g2x2+h2x2-i2x2)/64.-SinTPi(6+g2x2+h2x2-i2x2)/64.+SinTPi(10+g2x2+h2x2-i2x2)/64.+SinTPi(6-g2x2-h2x2+i2x2)/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_125(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.-SinTPi(2+g2x2-h2x2-i2x2)/32.-SinTPi(6+g2x2-h2x2-i2x2)/64.+SinTPi(10+g2x2-h2x2-i2x2)/64.+SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/64.-SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.+SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.-SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/64.+SinTPi(10-g2x2+h2x2+i2x2)/64.-SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/64.+SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_126(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_127(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/64.-SinTPi(10-g2x2-h2x2-i2x2)/64.+SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/64.-SinTPi(10+g2x2-h2x2-i2x2)/64.+SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/64.-SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.+SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(2+g2x2+h2x2+i2x2)/32.+SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_128(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/16.-SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/16.-SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/16.-SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/16.+SinTPi(2-g2x2-h2x2+i2x2)/16.-SinTPi(6-g2x2-h2x2+i2x2)/16.+SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/16.+SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/16.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_129(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(10+g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(10-g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.+SinTPi(10+g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_130(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(10+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(10-g2x2+h2x2-i2x2)/32.-SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/32.+SinTPi(10+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/16.-SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_131(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/16.+SinTPi(2+g2x2-h2x2-i2x2)/16.-SinTPi(6+g2x2-h2x2-i2x2)/16.-SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/16.+SinTPi(2+g2x2+h2x2-i2x2)/16.-SinTPi(6+g2x2+h2x2-i2x2)/16.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.+SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/16.-SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/16.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_132(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(10+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/16.-SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(10-g2x2-h2x2+i2x2)/32.-SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/32.+SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_133(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/32.-SinTPi(10-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(10+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/16.+SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_134(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)+3*SinTPi(4+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)+3*SinTPi(4-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)-3*SinTPi(4+h2x2+i2x2)+SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_135(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2-i2x2)-2*SinTPi(8-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+2*SinTPi(8+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+2*SinTPi(8-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)+SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_136(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-h2x2-i2x2)+2*SinTPi(h2x2-i2x2)-SinTPi(8+h2x2-i2x2)+SinTPi(8-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_137(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-h2x2-i2x2)+SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)-SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)-SinTPi(8-h2x2+i2x2)-2*SinTPi(4+h2x2+i2x2)+SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_138(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)-SinTPi(12-h2x2-i2x2)+4*SinTPi(h2x2-i2x2)-SinTPi(4+h2x2-i2x2)-2*SinTPi(8+h2x2-i2x2)+SinTPi(12+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)+2*SinTPi(8-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+4*SinTPi(h2x2+i2x2)-SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)+SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_139(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-h2x2-i2x2)+SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)-SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)-SinTPi(8-h2x2+i2x2)-2*SinTPi(4+h2x2+i2x2)+SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_140(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-h2x2-i2x2)-SinTPi(8-h2x2-i2x2)-6*SinTPi(h2x2-i2x2)+4*SinTPi(4+h2x2-i2x2)-SinTPi(8+h2x2-i2x2)-4*SinTPi(4-h2x2+i2x2)+SinTPi(8-h2x2+i2x2)+6*SinTPi(h2x2+i2x2)-4*SinTPi(4+h2x2+i2x2)+SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_141(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-h2x2-i2x2)+2*SinTPi(h2x2-i2x2)-SinTPi(8+h2x2-i2x2)+SinTPi(8-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_142(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2-i2x2)-SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)-SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)-SinTPi(8-h2x2+i2x2)+2*SinTPi(4+h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_143(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+3*SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)+3*SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)-3*SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_144(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)-SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)+SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_145(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)-SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_146(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_147(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)-2*SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_148(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)-SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)-SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_149(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)-SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)+SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_150(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-i2x2)-CosTPi(8-i2x2)-2*CosTPi(4+i2x2)+CosTPi(8+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_151(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-i2x2)+2*CosTPi(i2x2)-CosTPi(8+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]*/
static double evalT_152(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-i2x2)-SinTPi(8-i2x2)+6*SinTPi(i2x2)-4*SinTPi(4+i2x2)+SinTPi(8+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_153(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-i2x2)+2*SinTPi(i2x2)-SinTPi(8+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_154(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-i2x2)-SinTPi(8-i2x2)+2*SinTPi(4+i2x2)-SinTPi(8+i2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_155(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-i2x2)+SinTPi(8-i2x2)+2*SinTPi(4+i2x2)+SinTPi(8+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_156(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-i2x2)+2*SinTPi(8-i2x2)+SinTPi(12-i2x2)+4*SinTPi(i2x2)+SinTPi(4+i2x2)-2*SinTPi(8+i2x2)-SinTPi(12+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]*/
static double evalT_157(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-i2x2)+SinTPi(12-i2x2)+SinTPi(4+i2x2)-SinTPi(12+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]*/
static double evalT_158(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-i2x2)+2*SinTPi(i2x2)-SinTPi(4+i2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_159(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-i2x2)+SinTPi(8-i2x2)-2*SinTPi(i2x2)+2*SinTPi(4+i2x2)-SinTPi(8+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_160(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-i2x2)-SinTPi(12-i2x2)+3*SinTPi(4+i2x2)-SinTPi(12+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_161(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-i2x2)+2*SinTPi(i2x2)-SinTPi(8+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[i2*t]*/
static double evalT_162(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-i2x2)-SinTPi(8-i2x2)+2*SinTPi(4+i2x2)-SinTPi(8+i2x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_163(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-i2x2)+SinTPi(4+i2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_164(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)-CosTPi(4+h2x2-i2x2)-CosTPi(4-h2x2+i2x2)-2*CosTPi(h2x2+i2x2)+CosTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_165(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)-CosTPi(8+h2x2-i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]*/
static double evalT_166(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)-2*CosTPi(h2x2-i2x2)+2*CosTPi(4+h2x2-i2x2)-CosTPi(8+h2x2-i2x2)+2*CosTPi(4-h2x2+i2x2)-CosTPi(8-h2x2+i2x2)+2*CosTPi(h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_167(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)-CosTPi(8-h2x2-i2x2)-2*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)+2*CosTPi(4-h2x2+i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_168(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)-CosTPi(4+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-CosTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_169(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+3*CosTPi(4+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)-3*CosTPi(4-h2x2+i2x2)+CosTPi(12-h2x2+i2x2)-3*CosTPi(4+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_170(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)-CosTPi(8-h2x2-i2x2)+2*CosTPi(4+h2x2-i2x2)-CosTPi(8+h2x2-i2x2)-2*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_171(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+2*CosTPi(8-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)-CosTPi(4+h2x2-i2x2)+2*CosTPi(8+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)+CosTPi(12-h2x2+i2x2)+CosTPi(4+h2x2+i2x2)-2*CosTPi(8+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_172(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)-CosTPi(8+h2x2-i2x2)-CosTPi(8-h2x2+i2x2)+2*CosTPi(h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_173(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)-2*CosTPi(8-h2x2-i2x2)+CosTPi(12-h2x2-i2x2)+4*CosTPi(h2x2-i2x2)-CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)+CosTPi(12+h2x2-i2x2)-CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)+CosTPi(12-h2x2+i2x2)+4*CosTPi(h2x2+i2x2)-CosTPi(4+h2x2+i2x2)-2*CosTPi(8+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_174(const int i2x2, const int g2x2, const int h2x2){
return (4*CosTPi(4-h2x2-i2x2)-CosTPi(8-h2x2-i2x2)+6*CosTPi(h2x2-i2x2)-4*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)-4*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)-6*CosTPi(h2x2+i2x2)+4*CosTPi(4+h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_175(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)-CosTPi(8-h2x2-i2x2)+2*CosTPi(4+h2x2-i2x2)-CosTPi(8+h2x2-i2x2)-2*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_176(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)-CosTPi(8-h2x2-i2x2)-2*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)+2*CosTPi(4-h2x2+i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_177(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)-CosTPi(8+h2x2-i2x2)-CosTPi(8-h2x2+i2x2)+2*CosTPi(h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_178(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)+2*CosTPi(8-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+4*CosTPi(h2x2-i2x2)-CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)+CosTPi(12+h2x2-i2x2)-CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)+CosTPi(12-h2x2+i2x2)-4*CosTPi(h2x2+i2x2)+CosTPi(4+h2x2+i2x2)+2*CosTPi(8+h2x2+i2x2)-CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]*/
static double evalT_179(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+CosTPi(12-h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)-CosTPi(4+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_180(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+2*CosTPi(8-h2x2-i2x2)+CosTPi(12-h2x2-i2x2)+4*CosTPi(h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)-4*CosTPi(h2x2+i2x2)-CosTPi(4+h2x2+i2x2)+2*CosTPi(8+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_181(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)-3*CosTPi(4+h2x2-i2x2)+CosTPi(12+h2x2-i2x2)+3*CosTPi(4-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)-3*CosTPi(4+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_182(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+2*CosTPi(8-h2x2-i2x2)+CosTPi(12-h2x2-i2x2)+4*CosTPi(h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)-4*CosTPi(h2x2+i2x2)-CosTPi(4+h2x2+i2x2)+2*CosTPi(8+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_183(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)-CosTPi(8+h2x2-i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]*/
static double evalT_184(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+CosTPi(12-h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)-CosTPi(4+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_185(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)-3*CosTPi(4+h2x2-i2x2)+CosTPi(12+h2x2-i2x2)+3*CosTPi(4-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)-3*CosTPi(4+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_186(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+3*CosTPi(4+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)-3*CosTPi(4-h2x2+i2x2)+CosTPi(12-h2x2+i2x2)-3*CosTPi(4+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_187(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)-CosTPi(4+h2x2-i2x2)-CosTPi(4-h2x2+i2x2)+2*CosTPi(h2x2+i2x2)-CosTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_188(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(2+h2x2+i2x2)+CosTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_189(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-h2x2-i2x2)-CosTPi(6-h2x2-i2x2)+3*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)-3*CosTPi(2-h2x2+i2x2)+CosTPi(6-h2x2+i2x2)-3*CosTPi(2+h2x2+i2x2)+CosTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_190(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)-CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)+CosTPi(6-h2x2+i2x2)-CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_191(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)-CosTPi(6-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)+CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_192(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)+CosTPi(6+h2x2+i2x2)+CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_193(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)-CosTPi(6-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)+CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_194(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)-CosTPi(6-h2x2-i2x2)-CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)+2*CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_195(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)-CosTPi(2-h2x2+i2x2)-CosTPi(2+h2x2+i2x2))/4.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_196(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(2+h2x2+i2x2)+CosTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_197(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)-CosTPi(2+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(2+h2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_198(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)+CosTPi(6+h2x2-i2x2)+CosTPi(10+h2x2-i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)-CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_199(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)+CosTPi(6+h2x2-i2x2)-CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_200(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)-CosTPi(2+h2x2-i2x2)+CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)+CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_201(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)+CosTPi(6+h2x2-i2x2)-CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_202(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)-CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)+CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)-2*CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)+CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2)+CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_203(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)+3*CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)+3*CosTPi(6+h2x2-i2x2)+CosTPi(10+h2x2-i2x2)-2*CosTPi(2-h2x2+i2x2)-3*CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)-3*CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_204(const int i2x2, const int g2x2, const int h2x2){
return (5*CosTPi(4-i2x2)+4*CosTPi(8-i2x2)+CosTPi(12-i2x2)-5*CosTPi(4+i2x2)-4*CosTPi(8+i2x2)-CosTPi(12+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_205(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-i2x2)+CosTPi(8-i2x2)-2*CosTPi(4+i2x2)-CosTPi(8+i2x2))/16.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_206(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-i2x2)+CosTPi(8-i2x2)-2*CosTPi(4+i2x2)-CosTPi(8+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_207(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-i2x2)+2*CosTPi(8-i2x2)+CosTPi(12-i2x2)-CosTPi(4+i2x2)-2*CosTPi(8+i2x2)-CosTPi(12+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_208(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-i2x2)-CosTPi(4+i2x2))/4.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]*/
static double evalT_209(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-i2x2)-CosTPi(8+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_210(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-i2x2)-CosTPi(12-i2x2)-3*CosTPi(4+i2x2)+CosTPi(12+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_211(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-i2x2)-2*CosTPi(8-i2x2)-CosTPi(12-i2x2)+4*CosTPi(i2x2)+CosTPi(4+i2x2)-2*CosTPi(8+i2x2)-CosTPi(12+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_212(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-i2x2)+2*CosTPi(i2x2)-CosTPi(8+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]*/
static double evalT_213(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-i2x2)-CosTPi(8-i2x2)-2*CosTPi(4+i2x2)+CosTPi(8+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[i2*t]*/
static double evalT_214(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-i2x2)+2*CosTPi(i2x2)-CosTPi(4+i2x2))/4.;
};

/* Sin[2*2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_215(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-h2x2-i2x2)-SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)+SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)+SinTPi(8-h2x2+i2x2)-2*SinTPi(4+h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_216(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+SinTPi(4+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)-SinTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]*/
static double evalT_217(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(8-h2x2-i2x2)+SinTPi(8+h2x2-i2x2)+SinTPi(8-h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_218(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2-i2x2)+2*SinTPi(h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)-SinTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_219(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)+3*SinTPi(4+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)+3*SinTPi(4-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)-3*SinTPi(4+h2x2+i2x2)+SinTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_220(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)-4*SinTPi(h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+2*SinTPi(8+h2x2-i2x2)+SinTPi(12+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)-2*SinTPi(8-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+4*SinTPi(h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_221(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-h2x2-i2x2)-2*SinTPi(h2x2-i2x2)+SinTPi(8+h2x2-i2x2)-SinTPi(8-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_222(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-h2x2-i2x2)-2*SinTPi(h2x2-i2x2)+SinTPi(8+h2x2-i2x2)-SinTPi(8-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_223(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+SinTPi(12+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_224(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2-i2x2)-2*SinTPi(h2x2-i2x2)+SinTPi(4+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)-SinTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_225(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-h2x2-i2x2)+SinTPi(8-h2x2-i2x2)+2*SinTPi(h2x2-i2x2)-2*SinTPi(4+h2x2-i2x2)+SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)-SinTPi(8-h2x2+i2x2)-2*SinTPi(h2x2+i2x2)+2*SinTPi(4+h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_226(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-h2x2-i2x2)-SinTPi(12-h2x2-i2x2)+3*SinTPi(4+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)+3*SinTPi(4-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+3*SinTPi(4+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_227(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2-i2x2)-SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)-SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)-SinTPi(8-h2x2+i2x2)+2*SinTPi(4+h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_228(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+SinTPi(12+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_229(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)-4*SinTPi(h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+2*SinTPi(8+h2x2-i2x2)+SinTPi(12+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)-2*SinTPi(8-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+4*SinTPi(h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_230(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)-SinTPi(12-h2x2-i2x2)-4*SinTPi(h2x2-i2x2)+SinTPi(4+h2x2-i2x2)+2*SinTPi(8+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)-2*SinTPi(8-h2x2+i2x2)+SinTPi(12-h2x2+i2x2)+4*SinTPi(h2x2+i2x2)-SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)+SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_231(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-h2x2-i2x2)-SinTPi(12-h2x2-i2x2)+3*SinTPi(4+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)+3*SinTPi(4-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)+3*SinTPi(4+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_232(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2-i2x2)+2*SinTPi(g2x2-h2x2-i2x2)-SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_233(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2-i2x2)+SinTPi(2+g2x2-h2x2-i2x2)-SinTPi(2-g2x2+h2x2-i2x2)+SinTPi(2+g2x2+h2x2-i2x2)+SinTPi(2-g2x2-h2x2+i2x2)-SinTPi(2+g2x2-h2x2+i2x2)+SinTPi(2-g2x2+h2x2+i2x2)-SinTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_234(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/16.+SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/16.-SinTPi(2-g2x2+h2x2-i2x2)/16.-SinTPi(6-g2x2+h2x2-i2x2)/16.+SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/16.+SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.-SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/16.+SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/16.-SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_235(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/16.-SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/16.+SinTPi(2-g2x2+h2x2-i2x2)/16.-SinTPi(6-g2x2+h2x2-i2x2)/16.-SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/16.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/16.+SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/16.-SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/16.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_236(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)-CosTPi(4+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-CosTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_237(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-i2x2)-SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)+SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)+SinTPi(8-g2x2+i2x2)-2*SinTPi(4+g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_238(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+SinTPi(4+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)-SinTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]*/
static double evalT_239(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(8-g2x2-i2x2)+SinTPi(8+g2x2-i2x2)+SinTPi(8-g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_240(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-i2x2)+2*SinTPi(g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)-SinTPi(4+g2x2+i2x2))/8.;
};

/* 1*/
static double evalT_241(const int i2x2, const int g2x2, const int h2x2){
return Pi;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*2*t]Cos[h2*t]*/
static double evalT_242(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(g2x2-h2x2-i2x2)/16.+CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(g2x2+h2x2-i2x2)/16.+CosTPi(4+g2x2+h2x2-i2x2)/16.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(g2x2-h2x2+i2x2)/16.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(4-g2x2+h2x2+i2x2)/16.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(g2x2+h2x2+i2x2)/16.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_243(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(4+g2x2-h2x2-i2x2)-CosTPi(4-g2x2+h2x2-i2x2)-2*CosTPi(g2x2+h2x2-i2x2)+CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_244(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-g2x2-h2x2-i2x2))/64.+SinTPi(12-g2x2-h2x2-i2x2)/64.-(3*SinTPi(4+g2x2-h2x2-i2x2))/64.+SinTPi(12+g2x2-h2x2-i2x2)/64.+(3*SinTPi(4-g2x2+h2x2-i2x2))/64.-SinTPi(12-g2x2+h2x2-i2x2)/64.+(3*SinTPi(4+g2x2+h2x2-i2x2))/64.-SinTPi(12+g2x2+h2x2-i2x2)/64.+(3*SinTPi(4-g2x2-h2x2+i2x2))/64.-SinTPi(12-g2x2-h2x2+i2x2)/64.+(3*SinTPi(4+g2x2-h2x2+i2x2))/64.-SinTPi(12+g2x2-h2x2+i2x2)/64.-(3*SinTPi(4-g2x2+h2x2+i2x2))/64.+SinTPi(12-g2x2+h2x2+i2x2)/64.-(3*SinTPi(4+g2x2+h2x2+i2x2))/64.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_245(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/64.-SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(12-g2x2-h2x2-i2x2)/64.+SinTPi(4+g2x2-h2x2-i2x2)/64.-SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(12+g2x2-h2x2-i2x2)/64.-SinTPi(4-g2x2+h2x2-i2x2)/64.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(12-g2x2+h2x2-i2x2)/64.-SinTPi(4+g2x2+h2x2-i2x2)/64.+SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(12+g2x2+h2x2-i2x2)/64.-SinTPi(4-g2x2-h2x2+i2x2)/64.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(12-g2x2-h2x2+i2x2)/64.-SinTPi(4+g2x2-h2x2+i2x2)/64.+SinTPi(8+g2x2-h2x2+i2x2)/32.-SinTPi(12+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/64.-SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(12-g2x2+h2x2+i2x2)/64.+SinTPi(4+g2x2+h2x2+i2x2)/64.-SinTPi(8+g2x2+h2x2+i2x2)/32.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_246(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/64.+SinTPi(8-g2x2-h2x2-i2x2)/32.-SinTPi(12-g2x2-h2x2-i2x2)/64.-SinTPi(g2x2-h2x2-i2x2)/16.+SinTPi(4+g2x2-h2x2-i2x2)/64.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(12+g2x2-h2x2-i2x2)/64.-SinTPi(4-g2x2+h2x2-i2x2)/64.-SinTPi(8-g2x2+h2x2-i2x2)/32.+SinTPi(12-g2x2+h2x2-i2x2)/64.+SinTPi(g2x2+h2x2-i2x2)/16.-SinTPi(4+g2x2+h2x2-i2x2)/64.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(12+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/64.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(12-g2x2-h2x2+i2x2)/64.-SinTPi(g2x2-h2x2+i2x2)/16.+SinTPi(4+g2x2-h2x2+i2x2)/64.+SinTPi(8+g2x2-h2x2+i2x2)/32.-SinTPi(12+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/64.-SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(12-g2x2+h2x2+i2x2)/64.+SinTPi(g2x2+h2x2+i2x2)/16.-SinTPi(4+g2x2+h2x2+i2x2)/64.-SinTPi(8+g2x2+h2x2+i2x2)/32.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_247(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.+SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/64.-SinTPi(10+g2x2-h2x2-i2x2)/64.-SinTPi(2-g2x2+h2x2-i2x2)/32.-SinTPi(6-g2x2+h2x2-i2x2)/64.+SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.+SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.-SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/64.+SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.-SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/64.+SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_248(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/16.-SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(10+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/16.+SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.-SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/32.+SinTPi(10-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/32.+SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_249(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+3*CosTPi(4+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)-3*CosTPi(4-g2x2+i2x2)+CosTPi(12-g2x2+i2x2)-3*CosTPi(4+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_250(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+2*CosTPi(8-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)-CosTPi(4+g2x2-i2x2)+2*CosTPi(8+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)+CosTPi(12-g2x2+i2x2)+CosTPi(4+g2x2+i2x2)-2*CosTPi(8+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_251(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)-CosTPi(8+g2x2-i2x2)-CosTPi(8-g2x2+i2x2)+2*CosTPi(g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_252(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)-2*CosTPi(8-g2x2-i2x2)+CosTPi(12-g2x2-i2x2)+4*CosTPi(g2x2-i2x2)-CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)+CosTPi(12+g2x2-i2x2)-CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)+CosTPi(12-g2x2+i2x2)+4*CosTPi(g2x2+i2x2)-CosTPi(4+g2x2+i2x2)-2*CosTPi(8+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_253(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)-4*SinTPi(g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+2*SinTPi(8+g2x2-i2x2)+SinTPi(12+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)-2*SinTPi(8-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+4*SinTPi(g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_254(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+SinTPi(12+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_255(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-i2x2)-2*SinTPi(g2x2-i2x2)+SinTPi(8+g2x2-i2x2)-SinTPi(8-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_256(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-i2x2)-2*SinTPi(g2x2-i2x2)+SinTPi(4+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)-SinTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_257(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)+3*SinTPi(4+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)+3*SinTPi(4-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)-3*SinTPi(4+g2x2+i2x2)+SinTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_258(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-i2x2)+SinTPi(8-g2x2-i2x2)+2*SinTPi(g2x2-i2x2)-2*SinTPi(4+g2x2-i2x2)+SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)-SinTPi(8-g2x2+i2x2)-2*SinTPi(g2x2+i2x2)+2*SinTPi(4+g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_259(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-i2x2)-2*SinTPi(g2x2-i2x2)+SinTPi(8+g2x2-i2x2)-SinTPi(8-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_260(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-g2x2-i2x2)-SinTPi(12-g2x2-i2x2)+3*SinTPi(4+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)+3*SinTPi(4-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+3*SinTPi(4+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_261(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2-i2x2)-SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)-SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)-SinTPi(8-g2x2+i2x2)+2*SinTPi(4+g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_262(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+SinTPi(12+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_263(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)-SinTPi(12-g2x2-i2x2)-4*SinTPi(g2x2-i2x2)+SinTPi(4+g2x2-i2x2)+2*SinTPi(8+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)-2*SinTPi(8-g2x2+i2x2)+SinTPi(12-g2x2+i2x2)+4*SinTPi(g2x2+i2x2)-SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)+SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_264(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)-4*SinTPi(g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+2*SinTPi(8+g2x2-i2x2)+SinTPi(12+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)-2*SinTPi(8-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+4*SinTPi(g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_265(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-g2x2-i2x2)-SinTPi(12-g2x2-i2x2)+3*SinTPi(4+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)+3*SinTPi(4-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)+3*SinTPi(4+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]*/
static double evalT_266(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(g2x2-h2x2-i2x2)/16.-CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(g2x2+h2x2-i2x2)/16.+CosTPi(4+g2x2+h2x2-i2x2)/16.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(g2x2-h2x2+i2x2)/16.+CosTPi(4+g2x2-h2x2+i2x2)/16.-CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(g2x2+h2x2+i2x2)/16.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_267(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-h2x2-i2x2))/64.-CosTPi(12-g2x2-h2x2-i2x2)/64.+(3*CosTPi(4+g2x2-h2x2-i2x2))/64.-CosTPi(12+g2x2-h2x2-i2x2)/64.+(3*CosTPi(4-g2x2+h2x2-i2x2))/64.-CosTPi(12-g2x2+h2x2-i2x2)/64.+(3*CosTPi(4+g2x2+h2x2-i2x2))/64.-CosTPi(12+g2x2+h2x2-i2x2)/64.-(3*CosTPi(4-g2x2-h2x2+i2x2))/64.+CosTPi(12-g2x2-h2x2+i2x2)/64.-(3*CosTPi(4+g2x2-h2x2+i2x2))/64.+CosTPi(12+g2x2-h2x2+i2x2)/64.-(3*CosTPi(4-g2x2+h2x2+i2x2))/64.+CosTPi(12-g2x2+h2x2+i2x2)/64.-(3*CosTPi(4+g2x2+h2x2+i2x2))/64.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_268(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.-CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(4+g2x2+h2x2-i2x2)/16.-CosTPi(8+g2x2+h2x2-i2x2)/32.-CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_269(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/64.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(12-g2x2-h2x2-i2x2)/64.-CosTPi(4+g2x2-h2x2-i2x2)/64.+CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(12+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/64.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(12-g2x2+h2x2-i2x2)/64.-CosTPi(4+g2x2+h2x2-i2x2)/64.+CosTPi(8+g2x2+h2x2-i2x2)/32.-CosTPi(12+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/64.-CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(12-g2x2-h2x2+i2x2)/64.+CosTPi(4+g2x2-h2x2+i2x2)/64.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(12+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/64.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(12-g2x2+h2x2+i2x2)/64.+CosTPi(4+g2x2+h2x2+i2x2)/64.-CosTPi(8+g2x2+h2x2+i2x2)/32.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_270(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/64.-CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(12-g2x2-h2x2-i2x2)/64.+CosTPi(g2x2-h2x2-i2x2)/16.-CosTPi(4+g2x2-h2x2-i2x2)/64.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(12+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/64.-CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(12-g2x2+h2x2-i2x2)/64.+CosTPi(g2x2+h2x2-i2x2)/16.-CosTPi(4+g2x2+h2x2-i2x2)/64.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(12+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/64.-CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(12-g2x2-h2x2+i2x2)/64.+CosTPi(g2x2-h2x2+i2x2)/16.-CosTPi(4+g2x2-h2x2+i2x2)/64.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(12+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/64.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(12-g2x2+h2x2+i2x2)/64.+CosTPi(g2x2+h2x2+i2x2)/16.-CosTPi(4+g2x2+h2x2+i2x2)/64.-CosTPi(8+g2x2+h2x2+i2x2)/32.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_271(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.-CosTPi(6-g2x2-h2x2-i2x2)/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.-CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/64.+CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.-CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.-CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.+CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/64.-CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_272(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+(3*CosTPi(6-g2x2-h2x2-i2x2))/64.-CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.-(3*CosTPi(6+g2x2-h2x2-i2x2))/64.+CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.-(3*CosTPi(6-g2x2+h2x2-i2x2))/64.+CosTPi(10-g2x2+h2x2-i2x2)/64.-CosTPi(2+g2x2+h2x2-i2x2)/32.+(3*CosTPi(6+g2x2+h2x2-i2x2))/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.-CosTPi(2-g2x2-h2x2+i2x2)/32.+(3*CosTPi(6-g2x2-h2x2+i2x2))/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(2+g2x2-h2x2+i2x2)/32.-(3*CosTPi(6+g2x2-h2x2+i2x2))/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(2-g2x2+h2x2+i2x2)/32.-(3*CosTPi(6-g2x2+h2x2+i2x2))/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.+(3*CosTPi(6+g2x2+h2x2+i2x2))/64.-CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_273(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.-CosTPi(2+g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/64.+CosTPi(10+g2x2+h2x2-i2x2)/64.-CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/64.+CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/64.-CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/64.-CosTPi(10-g2x2+h2x2+i2x2)/64.-CosTPi(2+g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_274(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-h2x2-i2x2))/32.-CosTPi(6-g2x2-h2x2-i2x2)/32.+(3*CosTPi(2+g2x2-h2x2-i2x2))/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.-(3*CosTPi(2-g2x2+h2x2-i2x2))/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.-(3*CosTPi(2+g2x2+h2x2-i2x2))/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.+(3*CosTPi(2-g2x2-h2x2+i2x2))/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.+(3*CosTPi(2+g2x2-h2x2+i2x2))/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.-(3*CosTPi(2-g2x2+h2x2+i2x2))/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.-(3*CosTPi(2+g2x2+h2x2+i2x2))/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_275(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-h2x2-i2x2))/32.-CosTPi(6-g2x2-h2x2-i2x2)/32.-(3*CosTPi(2+g2x2-h2x2-i2x2))/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.+(3*CosTPi(2-g2x2+h2x2-i2x2))/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.-(3*CosTPi(2+g2x2+h2x2-i2x2))/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.+(3*CosTPi(2-g2x2-h2x2+i2x2))/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.-(3*CosTPi(2+g2x2-h2x2+i2x2))/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.+(3*CosTPi(2-g2x2+h2x2+i2x2))/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.-(3*CosTPi(2+g2x2+h2x2+i2x2))/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_276(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-h2x2-i2x2)+CosTPi(4+g2x2-h2x2-i2x2)+CosTPi(4-g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)+CosTPi(4+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_277(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(8+g2x2-h2x2-i2x2)-CosTPi(8-g2x2+h2x2-i2x2)-2*CosTPi(g2x2+h2x2-i2x2)+CosTPi(8+g2x2+h2x2-i2x2)+CosTPi(8-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(8+g2x2-h2x2+i2x2)-CosTPi(8-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_278(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_279(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)-CosTPi(4+g2x2-h2x2-i2x2)+CosTPi(4-g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)+CosTPi(4-g2x2+h2x2+i2x2)-CosTPi(4+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_280(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(4+g2x2-h2x2-i2x2)-CosTPi(4-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)-CosTPi(4-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)+2*CosTPi(g2x2+h2x2+i2x2)-CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_281(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(8+g2x2-h2x2-i2x2)+CosTPi(8-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)-2*CosTPi(g2x2-h2x2+i2x2)+CosTPi(8+g2x2-h2x2+i2x2)-CosTPi(8-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(8+g2x2+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_282(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/32.+CosTPi(8-g2x2-h2x2-i2x2)/64.-CosTPi(4+g2x2-h2x2-i2x2)/32.-CosTPi(8+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/32.+CosTPi(8-g2x2+h2x2-i2x2)/64.-CosTPi(4+g2x2+h2x2-i2x2)/32.-CosTPi(8+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/32.+CosTPi(8-g2x2-h2x2+i2x2)/64.-CosTPi(4+g2x2-h2x2+i2x2)/32.-CosTPi(8+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/32.+CosTPi(8-g2x2+h2x2+i2x2)/64.-CosTPi(4+g2x2+h2x2+i2x2)/32.-CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_283(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2-h2x2-i2x2)+2*CosTPi(g2x2-h2x2-i2x2)-CosTPi(8+g2x2-h2x2-i2x2)-CosTPi(8-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(8+g2x2-h2x2+i2x2)-CosTPi(8-g2x2+h2x2+i2x2)+2*CosTPi(g2x2+h2x2+i2x2)-CosTPi(8+g2x2+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_284(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-i2x2)-SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)-SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)-2*SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2)+SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_285(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)-SinTPi(6-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_286(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-i2x2)+3*SinTPi(6-g2x2-i2x2)-SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)-3*SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)-2*SinTPi(2-g2x2+i2x2)+3*SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)-3*SinTPi(6+g2x2+i2x2)+SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_287(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)-SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_288(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)-SinTPi(10+g2x2-i2x2)-2*SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_289(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-g2x2-i2x2)-SinTPi(6-g2x2-i2x2)+3*SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)+3*SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)+3*SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_290(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)-CosTPi(10-g2x2-i2x2)-2*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)+CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2)+CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_291(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)+3*CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)-2*CosTPi(2+g2x2-i2x2)-3*CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)+3*CosTPi(6-g2x2+i2x2)+CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)-3*CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_292(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)-CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)+CosTPi(6-g2x2+i2x2)-CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_293(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-i2x2)-CosTPi(6-g2x2-i2x2)-3*CosTPi(2+g2x2-i2x2)+CosTPi(6+g2x2-i2x2)+3*CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-3*CosTPi(2+g2x2+i2x2)+CosTPi(6+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_294(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)+3*CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)-2*CosTPi(2+g2x2-i2x2)-3*CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)+3*CosTPi(6-g2x2+i2x2)+CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)-3*CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_295(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)-CosTPi(10-g2x2-i2x2)-2*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)+CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)+CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2)+CosTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_296(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(2-g2x2-i2x2)+CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)-2*CosTPi(2+g2x2+i2x2)+CosTPi(6+g2x2+i2x2)+CosTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_297(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)-CosTPi(6-g2x2-i2x2)-CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)-CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)-CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)+2*CosTPi(2+g2x2+i2x2)-CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_298(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_299(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-h2x2-i2x2))/32.+SinTPi(6-g2x2-h2x2-i2x2)/32.+(3*SinTPi(2+g2x2-h2x2-i2x2))/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.+(3*SinTPi(2-g2x2+h2x2-i2x2))/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.-(3*SinTPi(2+g2x2+h2x2-i2x2))/32.+SinTPi(6+g2x2+h2x2-i2x2)/32.-(3*SinTPi(2-g2x2-h2x2+i2x2))/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.+(3*SinTPi(2+g2x2-h2x2+i2x2))/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.+(3*SinTPi(2-g2x2+h2x2+i2x2))/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.-(3*SinTPi(2+g2x2+h2x2+i2x2))/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_300(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_301(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.+SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/64.-SinTPi(10+g2x2-h2x2-i2x2)/64.+SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/64.-SinTPi(10-g2x2+h2x2-i2x2)/64.-SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/64.+SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(2-g2x2-h2x2+i2x2)/32.-SinTPi(6-g2x2-h2x2+i2x2)/64.+SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.-SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/64.+SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_302(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+(3*SinTPi(6-g2x2-h2x2-i2x2))/64.-SinTPi(10-g2x2-h2x2-i2x2)/64.+SinTPi(2+g2x2-h2x2-i2x2)/32.-(3*SinTPi(6+g2x2-h2x2-i2x2))/64.+SinTPi(10+g2x2-h2x2-i2x2)/64.-SinTPi(2-g2x2+h2x2-i2x2)/32.+(3*SinTPi(6-g2x2+h2x2-i2x2))/64.-SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.-(3*SinTPi(6+g2x2+h2x2-i2x2))/64.+SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(2-g2x2-h2x2+i2x2)/32.+(3*SinTPi(6-g2x2-h2x2+i2x2))/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(2+g2x2-h2x2+i2x2)/32.-(3*SinTPi(6+g2x2-h2x2+i2x2))/64.+SinTPi(10+g2x2-h2x2+i2x2)/64.-SinTPi(2-g2x2+h2x2+i2x2)/32.+(3*SinTPi(6-g2x2+h2x2+i2x2))/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(2+g2x2+h2x2+i2x2)/32.-(3*SinTPi(6+g2x2+h2x2+i2x2))/64.+SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_303(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.+SinTPi(2+g2x2-h2x2-i2x2)/32.-SinTPi(6+g2x2-h2x2-i2x2)/64.-SinTPi(10+g2x2-h2x2-i2x2)/64.-SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/64.+SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/64.+SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.-SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/64.+SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_304(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-g2x2-h2x2-i2x2))/32.-SinTPi(6-g2x2-h2x2-i2x2)/32.+(3*SinTPi(2+g2x2-h2x2-i2x2))/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.+(3*SinTPi(2-g2x2+h2x2-i2x2))/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.+(3*SinTPi(2+g2x2+h2x2-i2x2))/32.-SinTPi(6+g2x2+h2x2-i2x2)/32.+(3*SinTPi(2-g2x2-h2x2+i2x2))/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.+(3*SinTPi(2+g2x2-h2x2+i2x2))/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.+(3*SinTPi(2-g2x2+h2x2+i2x2))/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.+(3*SinTPi(2+g2x2+h2x2+i2x2))/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_305(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.+CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/32.+CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(4-g2x2+h2x2+i2x2)/16.-CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_306(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2-i2x2)+CosTPi(4+g2x2-h2x2-i2x2)-CosTPi(4-g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)+CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)-CosTPi(4+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_307(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2-i2x2)-2*CosTPi(g2x2-h2x2-i2x2)+CosTPi(8+g2x2-h2x2-i2x2)-CosTPi(8-g2x2+h2x2-i2x2)+2*CosTPi(g2x2+h2x2-i2x2)-CosTPi(8+g2x2+h2x2-i2x2)-CosTPi(8-g2x2-h2x2+i2x2)+2*CosTPi(g2x2-h2x2+i2x2)-CosTPi(8+g2x2-h2x2+i2x2)+CosTPi(8-g2x2+h2x2+i2x2)-2*CosTPi(g2x2+h2x2+i2x2)+CosTPi(8+g2x2+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_308(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/32.+CosTPi(8-g2x2-h2x2-i2x2)/64.+CosTPi(4+g2x2-h2x2-i2x2)/32.+CosTPi(8+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/32.-CosTPi(8-g2x2+h2x2-i2x2)/64.-CosTPi(4+g2x2+h2x2-i2x2)/32.-CosTPi(8+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/32.+CosTPi(8-g2x2-h2x2+i2x2)/64.+CosTPi(4+g2x2-h2x2+i2x2)/32.+CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/32.-CosTPi(8-g2x2+h2x2+i2x2)/64.-CosTPi(4+g2x2+h2x2+i2x2)/32.-CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_309(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2-i2x2)+CosTPi(2+g2x2-h2x2-i2x2)-CosTPi(2-g2x2+h2x2-i2x2)-CosTPi(2+g2x2+h2x2-i2x2)+CosTPi(2-g2x2-h2x2+i2x2)+CosTPi(2+g2x2-h2x2+i2x2)-CosTPi(2-g2x2+h2x2+i2x2)-CosTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_310(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2-i2x2)-CosTPi(2+g2x2-h2x2-i2x2)+CosTPi(2-g2x2+h2x2-i2x2)-CosTPi(2+g2x2+h2x2-i2x2)+CosTPi(2-g2x2-h2x2+i2x2)-CosTPi(2+g2x2-h2x2+i2x2)+CosTPi(2-g2x2+h2x2+i2x2)-CosTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_311(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-h2x2-i2x2)-CosTPi(2+g2x2-h2x2-i2x2)+CosTPi(2-g2x2+h2x2-i2x2)+CosTPi(2+g2x2+h2x2-i2x2)+CosTPi(2-g2x2-h2x2+i2x2)+CosTPi(2+g2x2-h2x2+i2x2)-CosTPi(2-g2x2+h2x2+i2x2)-CosTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_312(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-h2x2-i2x2)+CosTPi(2+g2x2-h2x2-i2x2)-CosTPi(2-g2x2+h2x2-i2x2)+CosTPi(2+g2x2+h2x2-i2x2)+CosTPi(2-g2x2-h2x2+i2x2)-CosTPi(2+g2x2-h2x2+i2x2)+CosTPi(2-g2x2+h2x2+i2x2)-CosTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_313(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_314(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_315(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_316(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-h2x2-i2x2))/32.+CosTPi(6-g2x2-h2x2-i2x2)/32.+(3*CosTPi(2+g2x2-h2x2-i2x2))/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.+(3*CosTPi(2-g2x2+h2x2-i2x2))/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.+(3*CosTPi(2+g2x2+h2x2-i2x2))/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.+(3*CosTPi(2-g2x2-h2x2+i2x2))/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.+(3*CosTPi(2+g2x2-h2x2+i2x2))/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.+(3*CosTPi(2-g2x2+h2x2+i2x2))/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.+(3*CosTPi(2+g2x2+h2x2+i2x2))/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_317(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2-i2x2)+CosTPi(2+g2x2-h2x2-i2x2)+CosTPi(2-g2x2+h2x2-i2x2)+CosTPi(2+g2x2+h2x2-i2x2)+CosTPi(2-g2x2-h2x2+i2x2)+CosTPi(2+g2x2-h2x2+i2x2)+CosTPi(2-g2x2+h2x2+i2x2)+CosTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_318(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-i2x2)+SinTPi(4+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)+SinTPi(4+g2x2+i2x2))/8.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_319(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)-2*SinTPi(g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+SinTPi(4-g2x2+i2x2)+2*SinTPi(g2x2+i2x2)+SinTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_320(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2-i2x2)+SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)+SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)+SinTPi(8-g2x2+i2x2)+2*SinTPi(4+g2x2+i2x2)+SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_321(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)+CosTPi(4+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-2*CosTPi(g2x2+i2x2)-CosTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_322(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)+2*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)-2*CosTPi(4-g2x2+i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_323(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-CosTPi(4-g2x2+i2x2)-CosTPi(4+g2x2+i2x2))/8.;
};

/* Sin[g2*t]Sin[i2*t]*/
static double evalT_324(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(g2x2-i2x2)-CosTPi(g2x2+i2x2))/2.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_325(const int i2x2, const int g2x2, const int h2x2){
return (4*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)+6*CosTPi(g2x2-i2x2)+4*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)+4*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)+6*CosTPi(g2x2+i2x2)+4*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_326(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)+2*CosTPi(g2x2-i2x2)+CosTPi(4+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)+2*CosTPi(g2x2+i2x2)+CosTPi(4+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_327(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)-2*CosTPi(4+g2x2-i2x2)-CosTPi(8+g2x2-i2x2)+2*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/32.;
};

/* Cos[g2*t]Cos[i2*t]*/
static double evalT_328(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(g2x2-i2x2)+CosTPi(g2x2+i2x2))/2.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_329(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)-SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)-SinTPi(4-g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_330(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)-SinTPi(4+g2x2+h2x2-i2x2)-SinTPi(4-g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_331(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)-SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)-SinTPi(4-g2x2-h2x2+i2x2)-2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)+SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_332(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(g2x2-h2x2-i2x2)+SinTPi(g2x2+h2x2-i2x2)+SinTPi(g2x2-h2x2+i2x2)-SinTPi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_333(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(g2x2-h2x2-i2x2)+SinTPi(g2x2+h2x2-i2x2)-SinTPi(g2x2-h2x2+i2x2)+SinTPi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[2*2*t]Sin[g2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_334(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)-SinTPi(4-g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)-SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_335(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)+2*SinTPi(g2x2-h2x2-i2x2)-SinTPi(8+g2x2-h2x2-i2x2)+SinTPi(8-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(8+g2x2+h2x2-i2x2)+SinTPi(8-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(8+g2x2-h2x2+i2x2)+SinTPi(8-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_336(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.+SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(4-g2x2+h2x2-i2x2)/16.+SinTPi(8-g2x2+h2x2-i2x2)/32.+SinTPi(4+g2x2+h2x2-i2x2)/16.+SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(4-g2x2-h2x2+i2x2)/16.+SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(4+g2x2-h2x2+i2x2)/16.+SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(4-g2x2+h2x2+i2x2)/16.+SinTPi(8-g2x2+h2x2+i2x2)/32.+SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_337(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(8+g2x2-h2x2-i2x2)+SinTPi(8-g2x2+h2x2-i2x2)-2*SinTPi(g2x2+h2x2-i2x2)+SinTPi(8+g2x2+h2x2-i2x2)-SinTPi(8-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(8+g2x2-h2x2+i2x2)-SinTPi(8-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_338(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)+SinTPi(4+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_339(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(8+g2x2-h2x2-i2x2)+SinTPi(8-g2x2+h2x2-i2x2)-2*SinTPi(g2x2+h2x2-i2x2)+SinTPi(8+g2x2+h2x2-i2x2)-SinTPi(8-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(8+g2x2-h2x2+i2x2)-SinTPi(8-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(8+g2x2+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_340(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(8+g2x2-h2x2-i2x2)-SinTPi(8-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(8+g2x2+h2x2-i2x2)+SinTPi(8-g2x2-h2x2+i2x2)-2*SinTPi(g2x2-h2x2+i2x2)+SinTPi(8+g2x2-h2x2+i2x2)-SinTPi(8-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(8+g2x2+h2x2+i2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_341(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/32.+SinTPi(8-g2x2-h2x2-i2x2)/64.+SinTPi(4+g2x2-h2x2-i2x2)/32.+SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/32.+SinTPi(8-g2x2+h2x2-i2x2)/64.+SinTPi(4+g2x2+h2x2-i2x2)/32.+SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/32.+SinTPi(8-g2x2-h2x2+i2x2)/64.+SinTPi(4+g2x2-h2x2+i2x2)/32.+SinTPi(8+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/32.+SinTPi(8-g2x2+h2x2+i2x2)/64.+SinTPi(4+g2x2+h2x2+i2x2)/32.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_342(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)+SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_343(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-h2x2-i2x2)-SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)-SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)-2*SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2)+SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_344(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)-SinTPi(6-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_345(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)-SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_346(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-h2x2-i2x2)+3*SinTPi(6-h2x2-i2x2)-SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)-3*SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)-2*SinTPi(2-h2x2+i2x2)+3*SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)-3*SinTPi(6+h2x2+i2x2)+SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_347(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)-SinTPi(10+h2x2-i2x2)-2*SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_348(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-h2x2-i2x2)-SinTPi(6-h2x2-i2x2)+3*SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)+3*SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)+3*SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_349(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2-i2x2)+SinTPi(4+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)+SinTPi(4+h2x2+i2x2))/8.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_350(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)-2*SinTPi(h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+SinTPi(4-h2x2+i2x2)+2*SinTPi(h2x2+i2x2)+SinTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_351(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2-i2x2)+SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)+SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)+SinTPi(8-h2x2+i2x2)+2*SinTPi(4+h2x2+i2x2)+SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_352(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-i2x2)-CosTPi(6-i2x2)+CosTPi(2+i2x2)-CosTPi(6+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[i2*t]*/
static double evalT_353(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-i2x2)-SinTPi(6-i2x2)+3*SinTPi(2+i2x2)-SinTPi(6+i2x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_354(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-i2x2)+SinTPi(6-i2x2)+SinTPi(2+i2x2)+SinTPi(6+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_355(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-i2x2)+SinTPi(6-i2x2)+SinTPi(10-i2x2)+2*SinTPi(2+i2x2)-SinTPi(6+i2x2)-SinTPi(10+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_356(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-i2x2)+SinTPi(6-i2x2)+SinTPi(2+i2x2)-SinTPi(6+i2x2))/8.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_357(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-i2x2)-SinTPi(6-i2x2)+3*SinTPi(2+i2x2)+SinTPi(6+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_358(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-i2x2)+SinTPi(6-i2x2)-SinTPi(10-i2x2)+2*SinTPi(2+i2x2)+SinTPi(6+i2x2)-SinTPi(10+i2x2))/32.;
};

/* Sin[i2*t]Cos[2*t]*/
static double evalT_359(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-i2x2)+SinTPi(2+i2x2))/2.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_360(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-i2x2)+3*SinTPi(6-i2x2)+SinTPi(10-i2x2)+2*SinTPi(2+i2x2)+3*SinTPi(6+i2x2)+SinTPi(10+i2x2))/32.;
};

/* Sin[2*t]Cos[i2*t]*/
static double evalT_361(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-i2x2)+SinTPi(2+i2x2))/2.;
};

/* Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_362(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-h2x2-i2x2)+CosTPi(2+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)-CosTPi(2+h2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_363(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-h2x2-i2x2)-CosTPi(6-h2x2-i2x2)-3*CosTPi(2+h2x2-i2x2)+CosTPi(6+h2x2-i2x2)+3*CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-3*CosTPi(2+h2x2+i2x2)+CosTPi(6+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_364(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)-3*CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)-3*CosTPi(6+h2x2-i2x2)+CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)-3*CosTPi(6-h2x2+i2x2)+CosTPi(10-h2x2+i2x2)+2*CosTPi(2+h2x2+i2x2)-3*CosTPi(6+h2x2+i2x2)+CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_365(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)-CosTPi(10-h2x2-i2x2)-2*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)+CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2)+CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_366(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)+3*CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)-2*CosTPi(2+h2x2-i2x2)-3*CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)+3*CosTPi(6-h2x2+i2x2)+CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)-3*CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_367(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)-CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(2-h2x2+i2x2)+CosTPi(6-h2x2+i2x2)-CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_368(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)+CosTPi(6+h2x2+i2x2)+CosTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_369(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)+CosTPi(6-h2x2-i2x2)-CosTPi(10-h2x2-i2x2)-2*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)+CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)+CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2)+CosTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_370(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)-CosTPi(6-h2x2-i2x2)-CosTPi(10-h2x2-i2x2)+2*CosTPi(2+h2x2-i2x2)-CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)-CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)+2*CosTPi(2+h2x2+i2x2)-CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_371(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2-i2x2)+3*CosTPi(6-h2x2-i2x2)+CosTPi(10-h2x2-i2x2)-2*CosTPi(2+h2x2-i2x2)-3*CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+2*CosTPi(2-h2x2+i2x2)+3*CosTPi(6-h2x2+i2x2)+CosTPi(10-h2x2+i2x2)-2*CosTPi(2+h2x2+i2x2)-3*CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/64.;
};

/* Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_372(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)+CosTPi(4+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-2*CosTPi(h2x2+i2x2)-CosTPi(4+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_373(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)+2*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)-2*CosTPi(4-h2x2+i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_374(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-CosTPi(4-h2x2+i2x2)-CosTPi(4+h2x2+i2x2))/8.;
};

/* Sin[h2*t]Sin[i2*t]*/
static double evalT_375(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(h2x2-i2x2)-CosTPi(h2x2+i2x2))/2.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_376(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)-2*CosTPi(4+h2x2-i2x2)-CosTPi(8+h2x2-i2x2)+2*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_377(const int i2x2, const int g2x2, const int h2x2){
return (4*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)+6*CosTPi(h2x2-i2x2)+4*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)+4*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)+6*CosTPi(h2x2+i2x2)+4*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_378(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)+2*CosTPi(h2x2-i2x2)+CosTPi(4+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)+2*CosTPi(h2x2+i2x2)+CosTPi(4+h2x2+i2x2))/8.;
};

/* Cos[h2*t]Cos[i2*t]*/
static double evalT_379(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(h2x2-i2x2)+CosTPi(h2x2+i2x2))/2.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_380(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-i2x2)+3*CosTPi(6-i2x2)+CosTPi(10-i2x2)-2*CosTPi(2+i2x2)-3*CosTPi(6+i2x2)-CosTPi(10+i2x2))/32.;
};

/* Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_381(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-i2x2)+CosTPi(6-i2x2)-CosTPi(2+i2x2)-CosTPi(6+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_382(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-i2x2)-CosTPi(6-i2x2)-CosTPi(10-i2x2)+2*CosTPi(2+i2x2)-CosTPi(6+i2x2)-CosTPi(10+i2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_383(const int i2x2, const int g2x2, const int h2x2){
return (10*CosTPi(2-i2x2)+5*CosTPi(6-i2x2)+CosTPi(10-i2x2)+10*CosTPi(2+i2x2)+5*CosTPi(6+i2x2)+CosTPi(10+i2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_384(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-i2x2)+CosTPi(6-i2x2)+3*CosTPi(2+i2x2)+CosTPi(6+i2x2))/8.;
};

/* Cos[2*t]Cos[i2*t]*/
static double evalT_385(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-i2x2)+CosTPi(2+i2x2))/2.;
};

/* Sin[2*t]Sin[i2*t]*/
static double evalT_386(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-i2x2)-CosTPi(2+i2x2))/2.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_387(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)-SinTPi(2+h2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_388(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)-SinTPi(6-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_389(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-h2x2-i2x2)-SinTPi(6-h2x2-i2x2)+3*SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)-3*SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)+3*SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_390(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)-SinTPi(2-h2x2+i2x2)+SinTPi(2+h2x2+i2x2))/4.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[h2*t]*/
static double evalT_391(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)-SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)+SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_392(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-h2x2-i2x2)+3*SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)+3*SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)+3*SinTPi(6-h2x2+i2x2)+SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)+3*SinTPi(6+h2x2+i2x2)+SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_393(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_394(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)-2*SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)-SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_395(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)-SinTPi(10+h2x2-i2x2)-2*SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)-SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_396(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)-SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)-SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2)-SinTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_397(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-h2x2-i2x2)+3*SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)+2*SinTPi(2+h2x2-i2x2)+3*SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)+2*SinTPi(2-h2x2+i2x2)+3*SinTPi(6-h2x2+i2x2)+SinTPi(10-h2x2+i2x2)+2*SinTPi(2+h2x2+i2x2)+3*SinTPi(6+h2x2+i2x2)+SinTPi(10+h2x2+i2x2))/64.;
};

/* Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_398(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-h2x2-i2x2)+SinTPi(2+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)+SinTPi(2+h2x2+i2x2))/4.;
};

/* Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_399(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)+2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)-SinTPi(4-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)-SinTPi(4-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)-SinTPi(4-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)+SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_400(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)+SinTPi(4+g2x2-h2x2-i2x2)-SinTPi(4-g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)-SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_401(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(g2x2-h2x2-i2x2)+SinTPi(g2x2+h2x2-i2x2)+SinTPi(g2x2-h2x2+i2x2)+SinTPi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[g2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_402(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-i2x2)+CosTPi(2+g2x2-i2x2)+CosTPi(2-g2x2+i2x2)-CosTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]*/
static double evalT_403(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)-SinTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_404(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)-SinTPi(6-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_405(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-i2x2)-SinTPi(6-g2x2-i2x2)+3*SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)-3*SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)+3*SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[g2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_406(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)-SinTPi(2-g2x2+i2x2)+SinTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]*/
static double evalT_407(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-h2x2-i2x2)+CosTPi(2+g2x2-h2x2-i2x2)+CosTPi(2-g2x2+h2x2-i2x2)-CosTPi(2+g2x2+h2x2-i2x2)+CosTPi(2-g2x2-h2x2+i2x2)-CosTPi(2+g2x2-h2x2+i2x2)-CosTPi(2-g2x2+h2x2+i2x2)+CosTPi(2+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_408(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+(3*SinTPi(6-g2x2-h2x2-i2x2))/64.-SinTPi(10-g2x2-h2x2-i2x2)/64.-SinTPi(2+g2x2-h2x2-i2x2)/32.+(3*SinTPi(6+g2x2-h2x2-i2x2))/64.-SinTPi(10+g2x2-h2x2-i2x2)/64.+SinTPi(2-g2x2+h2x2-i2x2)/32.-(3*SinTPi(6-g2x2+h2x2-i2x2))/64.+SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.-(3*SinTPi(6+g2x2+h2x2-i2x2))/64.+SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(2-g2x2-h2x2+i2x2)/32.+(3*SinTPi(6-g2x2-h2x2+i2x2))/64.-SinTPi(10-g2x2-h2x2+i2x2)/64.-SinTPi(2+g2x2-h2x2+i2x2)/32.+(3*SinTPi(6+g2x2-h2x2+i2x2))/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(2-g2x2+h2x2+i2x2)/32.-(3*SinTPi(6-g2x2+h2x2+i2x2))/64.+SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(2+g2x2+h2x2+i2x2)/32.-(3*SinTPi(6+g2x2+h2x2+i2x2))/64.+SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_409(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.-SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/64.+SinTPi(10+g2x2-h2x2-i2x2)/64.+SinTPi(2-g2x2+h2x2-i2x2)/32.-SinTPi(6-g2x2+h2x2-i2x2)/64.-SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(2+g2x2+h2x2-i2x2)/32.-SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/64.+SinTPi(10-g2x2-h2x2+i2x2)/64.-SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/64.+SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[h2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_410(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)-SinTPi(4+g2x2-h2x2-i2x2)+SinTPi(4-g2x2+h2x2-i2x2)+SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)-SinTPi(4-g2x2+h2x2+i2x2)-SinTPi(4+g2x2+h2x2+i2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_411(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)+SinTPi(8+g2x2-h2x2-i2x2)-SinTPi(8-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(8+g2x2+h2x2-i2x2)+SinTPi(8-g2x2-h2x2+i2x2)-2*SinTPi(g2x2-h2x2+i2x2)+SinTPi(8+g2x2-h2x2+i2x2)-SinTPi(8-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_412(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)+2*SinTPi(g2x2-h2x2-i2x2)-SinTPi(8+g2x2-h2x2-i2x2)+SinTPi(8-g2x2+h2x2-i2x2)+2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(8+g2x2+h2x2-i2x2)+SinTPi(8-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)-SinTPi(8+g2x2-h2x2+i2x2)+SinTPi(8-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)-SinTPi(8+g2x2+h2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_413(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-i2x2)-3*CosTPi(6-g2x2-i2x2)+CosTPi(10-g2x2-i2x2)+2*CosTPi(2+g2x2-i2x2)-3*CosTPi(6+g2x2-i2x2)+CosTPi(10+g2x2-i2x2)+2*CosTPi(2-g2x2+i2x2)-3*CosTPi(6-g2x2+i2x2)+CosTPi(10-g2x2+i2x2)+2*CosTPi(2+g2x2+i2x2)-3*CosTPi(6+g2x2+i2x2)+CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]*/
static double evalT_414(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)-SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)+SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_415(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-i2x2)+3*SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)+3*SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)+3*SinTPi(6-g2x2+i2x2)+SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)+3*SinTPi(6+g2x2+i2x2)+SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_416(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_417(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)-2*SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)-SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_418(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)-SinTPi(10+g2x2-i2x2)-2*SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)-SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_419(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)-SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)-SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2)-SinTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_420(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-i2x2)+3*SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)+2*SinTPi(2+g2x2-i2x2)+3*SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)+2*SinTPi(2-g2x2+i2x2)+3*SinTPi(6-g2x2+i2x2)+SinTPi(10-g2x2+i2x2)+2*SinTPi(2+g2x2+i2x2)+3*SinTPi(6+g2x2+i2x2)+SinTPi(10+g2x2+i2x2))/64.;
};

/* Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_421(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-g2x2-i2x2)+SinTPi(2+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)+SinTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_422(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.-(3*CosTPi(6-g2x2-h2x2-i2x2))/64.+CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.-(3*CosTPi(6+g2x2-h2x2-i2x2))/64.+CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.-(3*CosTPi(6-g2x2+h2x2-i2x2))/64.+CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(2+g2x2+h2x2-i2x2)/32.-(3*CosTPi(6+g2x2+h2x2-i2x2))/64.+CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.-(3*CosTPi(6-g2x2-h2x2+i2x2))/64.+CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(2+g2x2-h2x2+i2x2)/32.-(3*CosTPi(6+g2x2-h2x2+i2x2))/64.+CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(2-g2x2+h2x2+i2x2)/32.-(3*CosTPi(6-g2x2+h2x2+i2x2))/64.+CosTPi(10-g2x2+h2x2+i2x2)/64.+CosTPi(2+g2x2+h2x2+i2x2)/32.-(3*CosTPi(6+g2x2+h2x2+i2x2))/64.+CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_423(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/32.-CosTPi(6-g2x2-h2x2-i2x2)/64.-CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(2+g2x2-h2x2-i2x2)/32.-CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(2-g2x2+h2x2-i2x2)/32.-CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(2+g2x2+h2x2-i2x2)/32.-CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(2-g2x2-h2x2+i2x2)/32.-CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(2+g2x2-h2x2+i2x2)/32.-CosTPi(6+g2x2-h2x2+i2x2)/64.-CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(2-g2x2+h2x2+i2x2)/32.-CosTPi(6-g2x2+h2x2+i2x2)/64.-CosTPi(10-g2x2+h2x2+i2x2)/64.+CosTPi(2+g2x2+h2x2+i2x2)/32.-CosTPi(6+g2x2+h2x2+i2x2)/64.-CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_424(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.-CosTPi(6-g2x2-h2x2-i2x2)/16.+CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/16.+CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/16.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.+CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/16.+CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/16.+CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/16.+CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]*/
static double evalT_425(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-g2x2-h2x2)-SinTPi(8-g2x2-h2x2)-6*SinTPi(g2x2-h2x2)+4*SinTPi(4+g2x2-h2x2)-SinTPi(8+g2x2-h2x2)-4*SinTPi(4-g2x2+h2x2)+SinTPi(8-g2x2+h2x2)+6*SinTPi(g2x2+h2x2)-4*SinTPi(4+g2x2+h2x2)+SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]*/
static double evalT_426(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-g2x2-h2x2)-SinTPi(8-g2x2-h2x2)+6*SinTPi(g2x2-h2x2)-4*SinTPi(4+g2x2-h2x2)+SinTPi(8+g2x2-h2x2)+4*SinTPi(4-g2x2+h2x2)-SinTPi(8-g2x2+h2x2)+6*SinTPi(g2x2+h2x2)-4*SinTPi(4+g2x2+h2x2)+SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]*/
static double evalT_427(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+3*SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)+3*SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)-3*SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_428(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-g2x2-h2x2)-SinTPi(6-g2x2-h2x2)+3*SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)+3*SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)+3*SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]*/
static double evalT_429(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2)-CosTPi(8-g2x2)-2*CosTPi(4+g2x2)+CosTPi(8+g2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]*/
static double evalT_430(const int i2x2, const int g2x2, const int h2x2){
return (-4*CosTPi(4-g2x2)+CosTPi(8-g2x2)+6*CosTPi(g2x2)-4*CosTPi(4+g2x2)+CosTPi(8+g2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]*/
static double evalT_431(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-g2x2)-SinTPi(8-g2x2)+6*SinTPi(g2x2)-4*SinTPi(4+g2x2)+SinTPi(8+g2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_432(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2)-SinTPi(8-g2x2)+2*SinTPi(4+g2x2)-SinTPi(8+g2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]*/
static double evalT_433(const int i2x2, const int g2x2, const int h2x2){
return (4*CosTPi(4-g2x2-h2x2)-CosTPi(8-g2x2-h2x2)+6*CosTPi(g2x2-h2x2)-4*CosTPi(4+g2x2-h2x2)+CosTPi(8+g2x2-h2x2)-4*CosTPi(4-g2x2+h2x2)+CosTPi(8-g2x2+h2x2)-6*CosTPi(g2x2+h2x2)+4*CosTPi(4+g2x2+h2x2)-CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_434(const int i2x2, const int g2x2, const int h2x2){
return (-4*CosTPi(4-g2x2-h2x2)+CosTPi(8-g2x2-h2x2)+6*CosTPi(g2x2-h2x2)-4*CosTPi(4+g2x2-h2x2)+CosTPi(8+g2x2-h2x2)-4*CosTPi(4-g2x2+h2x2)+CosTPi(8-g2x2+h2x2)+6*CosTPi(g2x2+h2x2)-4*CosTPi(4+g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]*/
static double evalT_435(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2)-2*SinTPi(g2x2-h2x2)+SinTPi(4+g2x2-h2x2)-SinTPi(4-g2x2+h2x2)+2*SinTPi(g2x2+h2x2)-SinTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]*/
static double evalT_436(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2)+2*SinTPi(g2x2-h2x2)-SinTPi(4+g2x2-h2x2)+SinTPi(4-g2x2+h2x2)+2*SinTPi(g2x2+h2x2)-SinTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]*/
static double evalT_437(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2)-CosTPi(6-g2x2)-3*CosTPi(2+g2x2)+CosTPi(6+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_438(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2)-CosTPi(6-g2x2)+CosTPi(2+g2x2)-CosTPi(6+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]*/
static double evalT_439(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2)+SinTPi(6-g2x2)+SinTPi(2+g2x2)-SinTPi(6+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]*/
static double evalT_440(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-g2x2)-SinTPi(6-g2x2)+3*SinTPi(2+g2x2)-SinTPi(6+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]*/
static double evalT_441(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-h2x2)-CosTPi(6-g2x2-h2x2)+3*CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)-3*CosTPi(2-g2x2+h2x2)+CosTPi(6-g2x2+h2x2)-3*CosTPi(2+g2x2+h2x2)+CosTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]*/
static double evalT_442(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2-h2x2)-CosTPi(6-g2x2-h2x2)-3*CosTPi(2+g2x2-h2x2)+CosTPi(6+g2x2-h2x2)+3*CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-3*CosTPi(2+g2x2+h2x2)+CosTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_443(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2)-CosTPi(8-h2x2)-2*CosTPi(4+h2x2)+CosTPi(8+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[h2*t]*/
static double evalT_444(const int i2x2, const int g2x2, const int h2x2){
return (-4*CosTPi(4-h2x2)+CosTPi(8-h2x2)+6*CosTPi(h2x2)-4*CosTPi(4+h2x2)+CosTPi(8+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]*/
static double evalT_445(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-h2x2)-CosTPi(6-h2x2)-3*CosTPi(2+h2x2)+CosTPi(6+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_446(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2)-CosTPi(6-h2x2)+CosTPi(2+h2x2)-CosTPi(6+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]*/
static double evalT_447(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]*/
static double evalT_448(const int i2x2, const int g2x2, const int h2x2){
return (3*Pi)/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_449(const int i2x2, const int g2x2, const int h2x2){
return Pi/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]*/
static double evalT_450(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-h2x2)-SinTPi(8-h2x2)+6*SinTPi(h2x2)-4*SinTPi(4+h2x2)+SinTPi(8+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_451(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2)-SinTPi(8-h2x2)+2*SinTPi(4+h2x2)-SinTPi(8+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_452(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2)+SinTPi(6-h2x2)+SinTPi(2+h2x2)-SinTPi(6+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[h2*t]*/
static double evalT_453(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(2-h2x2)-SinTPi(6-h2x2)+3*SinTPi(2+h2x2)-SinTPi(6+h2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_454(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-h2x2)+2*CosTPi(8-g2x2-h2x2)+CosTPi(12-g2x2-h2x2)+4*CosTPi(g2x2-h2x2)+CosTPi(4+g2x2-h2x2)-2*CosTPi(8+g2x2-h2x2)-CosTPi(12+g2x2-h2x2)+CosTPi(4-g2x2+h2x2)-2*CosTPi(8-g2x2+h2x2)-CosTPi(12-g2x2+h2x2)-4*CosTPi(g2x2+h2x2)-CosTPi(4+g2x2+h2x2)+2*CosTPi(8+g2x2+h2x2)+CosTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_455(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2)+2*CosTPi(8-g2x2-h2x2)-CosTPi(12-g2x2-h2x2)+4*CosTPi(g2x2-h2x2)-CosTPi(4+g2x2-h2x2)-2*CosTPi(8+g2x2-h2x2)+CosTPi(12+g2x2-h2x2)-CosTPi(4-g2x2+h2x2)-2*CosTPi(8-g2x2+h2x2)+CosTPi(12-g2x2+h2x2)-4*CosTPi(g2x2+h2x2)+CosTPi(4+g2x2+h2x2)+2*CosTPi(8+g2x2+h2x2)-CosTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_456(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2)+2*CosTPi(g2x2-h2x2)-CosTPi(8+g2x2-h2x2)-CosTPi(8-g2x2+h2x2)-2*CosTPi(g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]*/
static double evalT_457(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-h2x2)-CosTPi(8-g2x2-h2x2)+2*CosTPi(4+g2x2-h2x2)-CosTPi(8+g2x2-h2x2)-2*CosTPi(4-g2x2+h2x2)+CosTPi(8-g2x2+h2x2)-2*CosTPi(4+g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_458(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-h2x2)-CosTPi(12-g2x2-h2x2)+3*CosTPi(4+g2x2-h2x2)-CosTPi(12+g2x2-h2x2)-3*CosTPi(4-g2x2+h2x2)+CosTPi(12-g2x2+h2x2)-3*CosTPi(4+g2x2+h2x2)+CosTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]*/
static double evalT_459(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-h2x2)-CosTPi(8-g2x2-h2x2)-2*CosTPi(4+g2x2-h2x2)+CosTPi(8+g2x2-h2x2)+2*CosTPi(4-g2x2+h2x2)-CosTPi(8-g2x2+h2x2)-2*CosTPi(4+g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_460(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-h2x2)-CosTPi(12-g2x2-h2x2)-3*CosTPi(4+g2x2-h2x2)+CosTPi(12+g2x2-h2x2)+3*CosTPi(4-g2x2+h2x2)-CosTPi(12-g2x2+h2x2)-3*CosTPi(4+g2x2+h2x2)+CosTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_461(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-h2x2)-CosTPi(8-g2x2-h2x2)+2*CosTPi(4+g2x2-h2x2)-CosTPi(8+g2x2-h2x2)-2*CosTPi(4-g2x2+h2x2)+CosTPi(8-g2x2+h2x2)-2*CosTPi(4+g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_462(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-h2x2)-CosTPi(8-g2x2-h2x2)-2*CosTPi(4+g2x2-h2x2)+CosTPi(8+g2x2-h2x2)+2*CosTPi(4-g2x2+h2x2)-CosTPi(8-g2x2+h2x2)-2*CosTPi(4+g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_463(const int i2x2, const int g2x2, const int h2x2){
return (-2*CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)+CosTPi(10-g2x2-h2x2)+2*CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)-CosTPi(10+g2x2-h2x2)+2*CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)+CosTPi(6+g2x2+h2x2)+CosTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]*/
static double evalT_464(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)+CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-CosTPi(2+g2x2+h2x2)+CosTPi(6+g2x2+h2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_465(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)-CosTPi(10-g2x2-h2x2)-2*CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(10+g2x2-h2x2)+2*CosTPi(2-g2x2+h2x2)+CosTPi(6-g2x2+h2x2)-CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2)+CosTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_466(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+3*CosTPi(6-g2x2-h2x2)+CosTPi(10-g2x2-h2x2)-2*CosTPi(2+g2x2-h2x2)-3*CosTPi(6+g2x2-h2x2)-CosTPi(10+g2x2-h2x2)+2*CosTPi(2-g2x2+h2x2)+3*CosTPi(6-g2x2+h2x2)+CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-3*CosTPi(6+g2x2+h2x2)-CosTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_467(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)-CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(2-g2x2+h2x2)+CosTPi(6-g2x2+h2x2)-CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_468(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)+CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-CosTPi(2+g2x2+h2x2)+CosTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_469(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2)-CosTPi(6-g2x2-h2x2)+CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)+CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_470(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)-CosTPi(10-g2x2-h2x2)-2*CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(10+g2x2-h2x2)+2*CosTPi(2-g2x2+h2x2)+CosTPi(6-g2x2+h2x2)-CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2)+CosTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_471(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+3*CosTPi(6-g2x2-h2x2)+CosTPi(10-g2x2-h2x2)-2*CosTPi(2+g2x2-h2x2)-3*CosTPi(6+g2x2-h2x2)-CosTPi(10+g2x2-h2x2)+2*CosTPi(2-g2x2+h2x2)+3*CosTPi(6-g2x2+h2x2)+CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-3*CosTPi(6+g2x2+h2x2)-CosTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_472(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)-CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)+CosTPi(2-g2x2+h2x2)+CosTPi(6-g2x2+h2x2)-CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_473(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)-CosTPi(6-g2x2-h2x2)-CosTPi(10-g2x2-h2x2)+2*CosTPi(2+g2x2-h2x2)-CosTPi(6+g2x2-h2x2)-CosTPi(10+g2x2-h2x2)+2*CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-CosTPi(10-g2x2+h2x2)+2*CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2)-CosTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]*/
static double evalT_474(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2)+2*SinTPi(8-g2x2)-SinTPi(12-g2x2)+4*SinTPi(g2x2)-SinTPi(4+g2x2)-2*SinTPi(8+g2x2)+SinTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]*/
static double evalT_475(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2)+2*SinTPi(g2x2)-SinTPi(8+g2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_476(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2)+2*SinTPi(8-g2x2)+SinTPi(12-g2x2)+4*SinTPi(g2x2)+SinTPi(4+g2x2)-2*SinTPi(8+g2x2)-SinTPi(12+g2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]*/
static double evalT_477(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2)+2*SinTPi(g2x2)-SinTPi(8+g2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]*/
static double evalT_478(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2)-CosTPi(8-g2x2)-2*CosTPi(4+g2x2)+CosTPi(8+g2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]*/
static double evalT_479(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2)-CosTPi(12-g2x2)-3*CosTPi(4+g2x2)+CosTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_480(const int i2x2, const int g2x2, const int h2x2){
return (5*CosTPi(4-g2x2)+4*CosTPi(8-g2x2)+CosTPi(12-g2x2)-5*CosTPi(4+g2x2)-4*CosTPi(8+g2x2)-CosTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]*/
static double evalT_481(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2)+CosTPi(8-g2x2)-2*CosTPi(4+g2x2)-CosTPi(8+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_482(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2)+2*CosTPi(g2x2)-CosTPi(8+g2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_483(const int i2x2, const int g2x2, const int h2x2){
return (5*CosTPi(4-g2x2)+4*CosTPi(8-g2x2)+CosTPi(12-g2x2)-5*CosTPi(4+g2x2)-4*CosTPi(8+g2x2)-CosTPi(12+g2x2))/64.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_484(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2)+CosTPi(8-g2x2)-2*CosTPi(4+g2x2)-CosTPi(8+g2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]*/
static double evalT_485(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2)-CosTPi(4+g2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_486(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2)-CosTPi(12-g2x2)-3*CosTPi(4+g2x2)+CosTPi(12+g2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_487(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2)-2*CosTPi(8-g2x2)-CosTPi(12-g2x2)+4*CosTPi(g2x2)+CosTPi(4+g2x2)-2*CosTPi(8+g2x2)-CosTPi(12+g2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[g2*t]*/
static double evalT_488(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2)+2*CosTPi(g2x2)-CosTPi(4+g2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_489(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-h2x2)+SinTPi(8-g2x2-h2x2)+2*SinTPi(4+g2x2-h2x2)-SinTPi(8+g2x2-h2x2)+2*SinTPi(4-g2x2+h2x2)-SinTPi(8-g2x2+h2x2)-2*SinTPi(4+g2x2+h2x2)+SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_490(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-h2x2)-SinTPi(8-g2x2-h2x2)+2*SinTPi(4+g2x2-h2x2)+SinTPi(8+g2x2-h2x2)+2*SinTPi(4-g2x2+h2x2)+SinTPi(8-g2x2+h2x2)-2*SinTPi(4+g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_491(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2)+SinTPi(4+g2x2-h2x2)+SinTPi(4-g2x2+h2x2)-SinTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_492(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2)-2*SinTPi(g2x2-h2x2)+SinTPi(8+g2x2-h2x2)-SinTPi(8-g2x2+h2x2)+2*SinTPi(g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]*/
static double evalT_493(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-h2x2)+SinTPi(8-g2x2-h2x2)+2*SinTPi(4+g2x2-h2x2)-SinTPi(8+g2x2-h2x2)+2*SinTPi(4-g2x2+h2x2)-SinTPi(8-g2x2+h2x2)-2*SinTPi(4+g2x2+h2x2)+SinTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_494(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2)+2*SinTPi(8-g2x2-h2x2)-SinTPi(12-g2x2-h2x2)+4*SinTPi(g2x2-h2x2)-SinTPi(4+g2x2-h2x2)-2*SinTPi(8+g2x2-h2x2)+SinTPi(12+g2x2-h2x2)+SinTPi(4-g2x2+h2x2)+2*SinTPi(8-g2x2+h2x2)-SinTPi(12-g2x2+h2x2)+4*SinTPi(g2x2+h2x2)-SinTPi(4+g2x2+h2x2)-2*SinTPi(8+g2x2+h2x2)+SinTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_495(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2)+2*SinTPi(8-g2x2-h2x2)+SinTPi(12-g2x2-h2x2)+4*SinTPi(g2x2-h2x2)+SinTPi(4+g2x2-h2x2)-2*SinTPi(8+g2x2-h2x2)-SinTPi(12+g2x2-h2x2)-SinTPi(4-g2x2+h2x2)+2*SinTPi(8-g2x2+h2x2)+SinTPi(12-g2x2+h2x2)+4*SinTPi(g2x2+h2x2)+SinTPi(4+g2x2+h2x2)-2*SinTPi(8+g2x2+h2x2)-SinTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_496(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-g2x2-h2x2)+SinTPi(12-g2x2-h2x2)+3*SinTPi(4+g2x2-h2x2)-SinTPi(12+g2x2-h2x2)+3*SinTPi(4-g2x2+h2x2)-SinTPi(12-g2x2+h2x2)-3*SinTPi(4+g2x2+h2x2)+SinTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_497(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2)+2*SinTPi(g2x2-h2x2)-SinTPi(8+g2x2-h2x2)+SinTPi(8-g2x2+h2x2)+2*SinTPi(g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_498(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2-h2x2)-SinTPi(8-g2x2-h2x2)+2*SinTPi(4+g2x2-h2x2)-SinTPi(8+g2x2-h2x2)+2*SinTPi(4-g2x2+h2x2)-SinTPi(8-g2x2+h2x2)+2*SinTPi(4+g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_499(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-g2x2-h2x2)-SinTPi(12-g2x2-h2x2)+3*SinTPi(4+g2x2-h2x2)-SinTPi(12+g2x2-h2x2)+3*SinTPi(4-g2x2+h2x2)-SinTPi(12-g2x2+h2x2)+3*SinTPi(4+g2x2+h2x2)-SinTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_500(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2-h2x2)-SinTPi(8-g2x2-h2x2)+2*SinTPi(4+g2x2-h2x2)-SinTPi(8+g2x2-h2x2)+2*SinTPi(4-g2x2+h2x2)-SinTPi(8-g2x2+h2x2)+2*SinTPi(4+g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_501(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)-CosTPi(10-g2x2-h2x2)+2*CosTPi(2+g2x2-h2x2)+CosTPi(6+g2x2-h2x2)-CosTPi(10+g2x2-h2x2)-2*CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)+CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2)+CosTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_502(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+3*CosTPi(6-g2x2-h2x2)+CosTPi(10-g2x2-h2x2)+2*CosTPi(2+g2x2-h2x2)+3*CosTPi(6+g2x2-h2x2)+CosTPi(10+g2x2-h2x2)-2*CosTPi(2-g2x2+h2x2)-3*CosTPi(6-g2x2+h2x2)-CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-3*CosTPi(6+g2x2+h2x2)-CosTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_503(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)+CosTPi(2+g2x2-h2x2)+CosTPi(6+g2x2-h2x2)-CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_504(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)-CosTPi(10-g2x2-h2x2)+2*CosTPi(2+g2x2-h2x2)+CosTPi(6+g2x2-h2x2)-CosTPi(10+g2x2-h2x2)-2*CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)+CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2)+CosTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_505(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2-h2x2)+3*CosTPi(6-g2x2-h2x2)+CosTPi(10-g2x2-h2x2)+2*CosTPi(2+g2x2-h2x2)+3*CosTPi(6+g2x2-h2x2)+CosTPi(10+g2x2-h2x2)-2*CosTPi(2-g2x2+h2x2)-3*CosTPi(6-g2x2+h2x2)-CosTPi(10-g2x2+h2x2)-2*CosTPi(2+g2x2+h2x2)-3*CosTPi(6+g2x2+h2x2)-CosTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_506(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2-h2x2)+CosTPi(6-g2x2-h2x2)+CosTPi(2+g2x2-h2x2)+CosTPi(6+g2x2-h2x2)-CosTPi(2-g2x2+h2x2)-CosTPi(6-g2x2+h2x2)-CosTPi(2+g2x2+h2x2)-CosTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_507(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2)+CosTPi(4+g2x2-h2x2)-CosTPi(4-g2x2+h2x2)-CosTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_508(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2)-CosTPi(4+g2x2-h2x2)+CosTPi(4-g2x2+h2x2)-CosTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_509(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-h2x2)+CosTPi(8-g2x2-h2x2)+2*CosTPi(4+g2x2-h2x2)+CosTPi(8+g2x2-h2x2)-2*CosTPi(4-g2x2+h2x2)-CosTPi(8-g2x2+h2x2)-2*CosTPi(4+g2x2+h2x2)-CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_510(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-h2x2)+CosTPi(8-g2x2-h2x2)-2*CosTPi(4+g2x2-h2x2)-CosTPi(8+g2x2-h2x2)+2*CosTPi(4-g2x2+h2x2)+CosTPi(8-g2x2+h2x2)-2*CosTPi(4+g2x2+h2x2)-CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_511(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2-h2x2)+2*CosTPi(g2x2-h2x2)-CosTPi(8+g2x2-h2x2)-CosTPi(8-g2x2+h2x2)+2*CosTPi(g2x2+h2x2)-CosTPi(8+g2x2+h2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_512(const int i2x2, const int g2x2, const int h2x2){
return (4*CosTPi(4-g2x2-h2x2)+CosTPi(8-g2x2-h2x2)+6*CosTPi(g2x2-h2x2)+4*CosTPi(4+g2x2-h2x2)+CosTPi(8+g2x2-h2x2)+4*CosTPi(4-g2x2+h2x2)+CosTPi(8-g2x2+h2x2)+6*CosTPi(g2x2+h2x2)+4*CosTPi(4+g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_513(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2)+2*CosTPi(g2x2-h2x2)+CosTPi(4+g2x2-h2x2)+CosTPi(4-g2x2+h2x2)+2*CosTPi(g2x2+h2x2)+CosTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_514(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-g2x2)+SinTPi(6-g2x2)+SinTPi(2+g2x2)+SinTPi(6+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_515(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2)+SinTPi(6-g2x2)-SinTPi(10-g2x2)+2*SinTPi(2+g2x2)+SinTPi(6+g2x2)-SinTPi(10+g2x2))/32.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_516(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2)+3*SinTPi(6-g2x2)+SinTPi(10-g2x2)+2*SinTPi(2+g2x2)+3*SinTPi(6+g2x2)+SinTPi(10+g2x2))/32.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]*/
static double evalT_517(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2)+CosTPi(6-g2x2)-CosTPi(2+g2x2)-CosTPi(6+g2x2))/8.;
};

/* Sin[2*t]Sin[g2*t]*/
static double evalT_518(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2)-CosTPi(2+g2x2))/2.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_519(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2)+3*CosTPi(6-g2x2)+CosTPi(10-g2x2)-2*CosTPi(2+g2x2)-3*CosTPi(6+g2x2)-CosTPi(10+g2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_520(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-g2x2)-CosTPi(6-g2x2)-CosTPi(10-g2x2)+2*CosTPi(2+g2x2)-CosTPi(6+g2x2)-CosTPi(10+g2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_521(const int i2x2, const int g2x2, const int h2x2){
return (10*CosTPi(2-g2x2)+5*CosTPi(6-g2x2)+CosTPi(10-g2x2)+10*CosTPi(2+g2x2)+5*CosTPi(6+g2x2)+CosTPi(10+g2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_522(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-g2x2)+CosTPi(6-g2x2)+3*CosTPi(2+g2x2)+CosTPi(6+g2x2))/8.;
};

/* Cos[2*t]Cos[g2*t]*/
static double evalT_523(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-g2x2)+CosTPi(2+g2x2))/2.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_524(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)-SinTPi(6-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)-SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]*/
static double evalT_525(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)-SinTPi(2+g2x2+h2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_526(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)-SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)+SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_527(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-h2x2)-SinTPi(6-g2x2-h2x2)-3*SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)+3*SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+3*SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_528(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)-SinTPi(2+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)+SinTPi(2+g2x2+h2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_529(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)-SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]*/
static double evalT_530(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)-SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_531(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(10-g2x2-h2x2)+2*SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)-SinTPi(10+g2x2-h2x2)-2*SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2)-SinTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_532(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)-SinTPi(10-g2x2-h2x2)+2*SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)-SinTPi(10+g2x2-h2x2)+2*SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)-SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2)-SinTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_533(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-h2x2)+3*SinTPi(6-g2x2-h2x2)+SinTPi(10-g2x2-h2x2)+2*SinTPi(2+g2x2-h2x2)+3*SinTPi(6+g2x2-h2x2)+SinTPi(10+g2x2-h2x2)+2*SinTPi(2-g2x2+h2x2)+3*SinTPi(6-g2x2+h2x2)+SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)+3*SinTPi(6+g2x2+h2x2)+SinTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_534(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_535(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)-SinTPi(10-g2x2-h2x2)+2*SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)-SinTPi(10+g2x2-h2x2)+2*SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)-SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2)-SinTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_536(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(10-g2x2-h2x2)-2*SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(10+g2x2-h2x2)+2*SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)-SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2)-SinTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_537(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-g2x2-h2x2)+3*SinTPi(6-g2x2-h2x2)+SinTPi(10-g2x2-h2x2)+2*SinTPi(2+g2x2-h2x2)+3*SinTPi(6+g2x2-h2x2)+SinTPi(10+g2x2-h2x2)+2*SinTPi(2-g2x2+h2x2)+3*SinTPi(6-g2x2+h2x2)+SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)+3*SinTPi(6+g2x2+h2x2)+SinTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_538(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_539(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2)+2*SinTPi(8-h2x2)-SinTPi(12-h2x2)+4*SinTPi(h2x2)-SinTPi(4+h2x2)-2*SinTPi(8+h2x2)+SinTPi(12+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_540(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-h2x2)+2*SinTPi(h2x2)-SinTPi(8+h2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_541(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2)+2*SinTPi(8-h2x2)+SinTPi(12-h2x2)+4*SinTPi(h2x2)+SinTPi(4+h2x2)-2*SinTPi(8+h2x2)-SinTPi(12+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_542(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-h2x2)+2*SinTPi(h2x2)-SinTPi(8+h2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_543(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(2-h2x2)+SinTPi(6-h2x2)+SinTPi(2+h2x2)+SinTPi(6+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_544(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-h2x2)+SinTPi(6-h2x2)-SinTPi(10-h2x2)+2*SinTPi(2+h2x2)+SinTPi(6+h2x2)-SinTPi(10+h2x2))/32.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_545(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(2-h2x2)+3*SinTPi(6-h2x2)+SinTPi(10-h2x2)+2*SinTPi(2+h2x2)+3*SinTPi(6+h2x2)+SinTPi(10+h2x2))/32.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_546(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_547(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*t]Cos[2*t]*/
static double evalT_548(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_549(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]*/
static double evalT_550(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2)-CosTPi(4+h2x2))/4.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_551(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2)+CosTPi(8-h2x2)-2*CosTPi(4+h2x2)-CosTPi(8+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_552(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2)-2*CosTPi(8-h2x2)+CosTPi(12-h2x2)+4*CosTPi(h2x2)-CosTPi(4+h2x2)-2*CosTPi(8+h2x2)+CosTPi(12+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_553(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-h2x2)+2*CosTPi(h2x2)-CosTPi(8+h2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_554(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2)-2*CosTPi(8-h2x2)-CosTPi(12-h2x2)+4*CosTPi(h2x2)+CosTPi(4+h2x2)-2*CosTPi(8+h2x2)-CosTPi(12+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_555(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-h2x2)+2*CosTPi(h2x2)-CosTPi(8+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]*/
static double evalT_556(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2)-CosTPi(8-h2x2)-2*CosTPi(4+h2x2)+CosTPi(8+h2x2))/8.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_557(const int i2x2, const int g2x2, const int h2x2){
return (5*CosTPi(4-h2x2)+4*CosTPi(8-h2x2)+CosTPi(12-h2x2)-5*CosTPi(4+h2x2)-4*CosTPi(8+h2x2)-CosTPi(12+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_558(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-h2x2)-CosTPi(12-h2x2)-3*CosTPi(4+h2x2)+CosTPi(12+h2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_559(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2)+CosTPi(8-h2x2)-2*CosTPi(4+h2x2)-CosTPi(8+h2x2))/8.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_560(const int i2x2, const int g2x2, const int h2x2){
return (5*CosTPi(4-h2x2)+4*CosTPi(8-h2x2)+CosTPi(12-h2x2)-5*CosTPi(4+h2x2)-4*CosTPi(8+h2x2)-CosTPi(12+h2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_561(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-h2x2)-CosTPi(12-h2x2)-3*CosTPi(4+h2x2)+CosTPi(12+h2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[h2*t]*/
static double evalT_562(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2)+2*CosTPi(h2x2)-CosTPi(4+h2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_563(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2)-2*CosTPi(8-h2x2)-CosTPi(12-h2x2)+4*CosTPi(h2x2)+CosTPi(4+h2x2)-2*CosTPi(8+h2x2)-CosTPi(12+h2x2))/64.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_564(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2)+CosTPi(6-h2x2)-CosTPi(2+h2x2)-CosTPi(6+h2x2))/8.;
};

/* Sin[2*t]Sin[h2*t]*/
static double evalT_565(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2)-CosTPi(2+h2x2))/2.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_566(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2)+3*CosTPi(6-h2x2)+CosTPi(10-h2x2)-2*CosTPi(2+h2x2)-3*CosTPi(6+h2x2)-CosTPi(10+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_567(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(2-h2x2)-CosTPi(6-h2x2)-CosTPi(10-h2x2)+2*CosTPi(2+h2x2)-CosTPi(6+h2x2)-CosTPi(10+h2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_568(const int i2x2, const int g2x2, const int h2x2){
return (10*CosTPi(2-h2x2)+5*CosTPi(6-h2x2)+CosTPi(10-h2x2)+10*CosTPi(2+h2x2)+5*CosTPi(6+h2x2)+CosTPi(10+h2x2))/32.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_569(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(2-h2x2)+CosTPi(6-h2x2)+3*CosTPi(2+h2x2)+CosTPi(6+h2x2))/8.;
};

/* Cos[2*t]Cos[h2*t]*/
static double evalT_570(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(2-h2x2)+CosTPi(2+h2x2))/2.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_571(const int i2x2, const int g2x2, const int h2x2){
return (5*Pi)/16.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_572(const int i2x2, const int g2x2, const int h2x2){
return (3*Pi)/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_573(const int i2x2, const int g2x2, const int h2x2){
return Pi/16.;
};

/* Cos[2*t]Cos[2*t]*/
static double evalT_574(const int i2x2, const int g2x2, const int h2x2){
return Pi/2.;
};

/* Sin[2*t]Sin[2*t]*/
static double evalT_575(const int i2x2, const int g2x2, const int h2x2){
return Pi/2.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]*/
static double evalT_576(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2)+2*SinTPi(h2x2)-SinTPi(4+h2x2))/4.;
};

/* Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_577(const int i2x2, const int g2x2, const int h2x2){
return (-4*SinTPi(4-h2x2)-SinTPi(8-h2x2)+6*SinTPi(h2x2)+4*SinTPi(4+h2x2)+SinTPi(8+h2x2))/16.;
};

/* Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_578(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2)+2*SinTPi(h2x2)+SinTPi(4+h2x2))/4.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[h2*t]*/
static double evalT_579(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2)-SinTPi(8-h2x2)+2*SinTPi(4+h2x2)-SinTPi(8+h2x2))/8.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_580(const int i2x2, const int g2x2, const int h2x2){
return (5*SinTPi(4-h2x2)+4*SinTPi(8-h2x2)+SinTPi(12-h2x2)+5*SinTPi(4+h2x2)+4*SinTPi(8+h2x2)+SinTPi(12+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_581(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-h2x2)-SinTPi(12-h2x2)+3*SinTPi(4+h2x2)-SinTPi(12+h2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_582(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2)+SinTPi(8-h2x2)+2*SinTPi(4+h2x2)+SinTPi(8+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_583(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2)+2*SinTPi(8-h2x2)+SinTPi(12-h2x2)+4*SinTPi(h2x2)+SinTPi(4+h2x2)-2*SinTPi(8+h2x2)-SinTPi(12+h2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_584(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-h2x2)-SinTPi(12-h2x2)+3*SinTPi(4+h2x2)-SinTPi(12+h2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_585(const int i2x2, const int g2x2, const int h2x2){
return (5*SinTPi(4-h2x2)+4*SinTPi(8-h2x2)+SinTPi(12-h2x2)+5*SinTPi(4+h2x2)+4*SinTPi(8+h2x2)+SinTPi(12+h2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_586(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-h2x2)+SinTPi(8-h2x2)+2*SinTPi(4+h2x2)+SinTPi(8+h2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_587(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-h2x2)+SinTPi(4+h2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_588(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2)+2*SinTPi(g2x2-h2x2)-SinTPi(8+g2x2-h2x2)+SinTPi(8-g2x2+h2x2)+2*SinTPi(g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/32.;
};

/* Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_589(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-h2x2)-SinTPi(6-g2x2-h2x2)+3*SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)-3*SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)+3*SinTPi(2+g2x2+h2x2)+SinTPi(6+g2x2+h2x2))/16.;
};

/* Sin[g2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_590(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)+SinTPi(2+g2x2-h2x2)-SinTPi(2-g2x2+h2x2)+SinTPi(2+g2x2+h2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]*/
static double evalT_591(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2)+2*SinTPi(g2x2)-SinTPi(4+g2x2))/4.;
};

/* Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_592(const int i2x2, const int g2x2, const int h2x2){
return (-4*SinTPi(4-g2x2)-SinTPi(8-g2x2)+6*SinTPi(g2x2)+4*SinTPi(4+g2x2)+SinTPi(8+g2x2))/16.;
};

/* Sin[g2*t]Cos[2*t]Cos[2*t]*/
static double evalT_593(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2)+2*SinTPi(g2x2)+SinTPi(4+g2x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]*/
static double evalT_594(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2)+2*CosTPi(g2x2-h2x2)-CosTPi(4+g2x2-h2x2)-CosTPi(4-g2x2+h2x2)-2*CosTPi(g2x2+h2x2)+CosTPi(4+g2x2+h2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[2*t]*/
static double evalT_595(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-h2x2)+2*CosTPi(g2x2-h2x2)-CosTPi(8+g2x2-h2x2)-CosTPi(8-g2x2+h2x2)-2*CosTPi(g2x2+h2x2)+CosTPi(8+g2x2+h2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_596(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2)+2*SinTPi(8-g2x2-h2x2)+SinTPi(12-g2x2-h2x2)-4*SinTPi(g2x2-h2x2)-SinTPi(4+g2x2-h2x2)+2*SinTPi(8+g2x2-h2x2)+SinTPi(12+g2x2-h2x2)+SinTPi(4-g2x2+h2x2)-2*SinTPi(8-g2x2+h2x2)-SinTPi(12-g2x2+h2x2)+4*SinTPi(g2x2+h2x2)+SinTPi(4+g2x2+h2x2)-2*SinTPi(8+g2x2+h2x2)-SinTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_597(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2-h2x2)+2*SinTPi(8-g2x2-h2x2)-SinTPi(12-g2x2-h2x2)-4*SinTPi(g2x2-h2x2)+SinTPi(4+g2x2-h2x2)+2*SinTPi(8+g2x2-h2x2)-SinTPi(12+g2x2-h2x2)-SinTPi(4-g2x2+h2x2)-2*SinTPi(8-g2x2+h2x2)+SinTPi(12-g2x2+h2x2)+4*SinTPi(g2x2+h2x2)-SinTPi(4+g2x2+h2x2)-2*SinTPi(8+g2x2+h2x2)+SinTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_598(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2)-2*SinTPi(g2x2-h2x2)+SinTPi(8+g2x2-h2x2)-SinTPi(8-g2x2+h2x2)+2*SinTPi(g2x2+h2x2)-SinTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]*/
static double evalT_599(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)-SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)+SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_600(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(10-g2x2-h2x2)-2*SinTPi(2+g2x2-h2x2)+SinTPi(6+g2x2-h2x2)+SinTPi(10+g2x2-h2x2)+2*SinTPi(2-g2x2+h2x2)-SinTPi(6-g2x2+h2x2)-SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2)-SinTPi(10+g2x2+h2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_601(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(2-g2x2-h2x2)+SinTPi(6-g2x2-h2x2)+SinTPi(10-g2x2-h2x2)+2*SinTPi(2+g2x2-h2x2)-SinTPi(6+g2x2-h2x2)-SinTPi(10+g2x2-h2x2)-2*SinTPi(2-g2x2+h2x2)+SinTPi(6-g2x2+h2x2)+SinTPi(10-g2x2+h2x2)+2*SinTPi(2+g2x2+h2x2)-SinTPi(6+g2x2+h2x2)-SinTPi(10+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_602(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2)-2*CosTPi(8-g2x2)+CosTPi(12-g2x2)+4*CosTPi(g2x2)-CosTPi(4+g2x2)-2*CosTPi(8+g2x2)+CosTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_603(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2)+2*CosTPi(g2x2)-CosTPi(8+g2x2))/8.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_604(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2)-2*CosTPi(8-g2x2)-CosTPi(12-g2x2)+4*CosTPi(g2x2)+CosTPi(4+g2x2)-2*CosTPi(8+g2x2)-CosTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_605(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-g2x2)-SinTPi(12-g2x2)+3*SinTPi(4+g2x2)-SinTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[g2*t]*/
static double evalT_606(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2)-SinTPi(8-g2x2)+2*SinTPi(4+g2x2)-SinTPi(8+g2x2))/8.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_607(const int i2x2, const int g2x2, const int h2x2){
return (5*SinTPi(4-g2x2)+4*SinTPi(8-g2x2)+SinTPi(12-g2x2)+5*SinTPi(4+g2x2)+4*SinTPi(8+g2x2)+SinTPi(12+g2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_608(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2)+SinTPi(8-g2x2)+2*SinTPi(4+g2x2)+SinTPi(8+g2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_609(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2)+2*SinTPi(8-g2x2)+SinTPi(12-g2x2)+4*SinTPi(g2x2)+SinTPi(4+g2x2)-2*SinTPi(8+g2x2)-SinTPi(12+g2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_610(const int i2x2, const int g2x2, const int h2x2){
return (5*SinTPi(4-g2x2)+4*SinTPi(8-g2x2)+SinTPi(12-g2x2)+5*SinTPi(4+g2x2)+4*SinTPi(8+g2x2)+SinTPi(12+g2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_611(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-g2x2)-SinTPi(12-g2x2)+3*SinTPi(4+g2x2)-SinTPi(12+g2x2))/64.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_612(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-g2x2)+SinTPi(8-g2x2)+2*SinTPi(4+g2x2)+SinTPi(8+g2x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_613(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-g2x2)+SinTPi(4+g2x2))/4.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_614(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-h2x2)-2*CosTPi(8-g2x2-h2x2)+CosTPi(12-g2x2-h2x2)+4*CosTPi(g2x2-h2x2)-CosTPi(4+g2x2-h2x2)-2*CosTPi(8+g2x2-h2x2)+CosTPi(12+g2x2-h2x2)-CosTPi(4-g2x2+h2x2)-2*CosTPi(8-g2x2+h2x2)+CosTPi(12-g2x2+h2x2)+4*CosTPi(g2x2+h2x2)-CosTPi(4+g2x2+h2x2)-2*CosTPi(8+g2x2+h2x2)+CosTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_615(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-h2x2)-2*CosTPi(8-g2x2-h2x2)-CosTPi(12-g2x2-h2x2)+4*CosTPi(g2x2-h2x2)+CosTPi(4+g2x2-h2x2)-2*CosTPi(8+g2x2-h2x2)-CosTPi(12+g2x2-h2x2)+CosTPi(4-g2x2+h2x2)-2*CosTPi(8-g2x2+h2x2)-CosTPi(12-g2x2+h2x2)+4*CosTPi(g2x2+h2x2)+CosTPi(4+g2x2+h2x2)-2*CosTPi(8+g2x2+h2x2)-CosTPi(12+g2x2+h2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_616(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(8-g2x2-h2x2)+2*CosTPi(g2x2-h2x2)-CosTPi(8+g2x2-h2x2)-CosTPi(8-g2x2+h2x2)+2*CosTPi(g2x2+h2x2)-CosTPi(8+g2x2+h2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_617(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.-SinTPi(2+g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_618(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-i2x2)-SinTPi(8-g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)+SinTPi(8+g2x2-i2x2)+2*SinTPi(4-g2x2+i2x2)+SinTPi(8-g2x2+i2x2)-2*SinTPi(4+g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_619(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-h2x2-i2x2)+CosTPi(4+g2x2-h2x2-i2x2)+CosTPi(4-g2x2+h2x2-i2x2)-CosTPi(4+g2x2+h2x2-i2x2)+CosTPi(4-g2x2-h2x2+i2x2)-CosTPi(4+g2x2-h2x2+i2x2)-CosTPi(4-g2x2+h2x2+i2x2)+CosTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_620(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/32.+SinTPi(2-g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(2-g2x2+h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/32.-SinTPi(6+g2x2+h2x2+i2x2)/32.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_621(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-h2x2-i2x2)-2*SinTPi(g2x2-h2x2-i2x2)-SinTPi(4+g2x2-h2x2-i2x2)-SinTPi(4-g2x2+h2x2-i2x2)-2*SinTPi(g2x2+h2x2-i2x2)-SinTPi(4+g2x2+h2x2-i2x2)+SinTPi(4-g2x2-h2x2+i2x2)+2*SinTPi(g2x2-h2x2+i2x2)+SinTPi(4+g2x2-h2x2+i2x2)+SinTPi(4-g2x2+h2x2+i2x2)+2*SinTPi(g2x2+h2x2+i2x2)+SinTPi(4+g2x2+h2x2+i2x2))/16.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_622(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-g2x2-i2x2)-SinTPi(6-g2x2-i2x2)-3*SinTPi(2+g2x2-i2x2)-SinTPi(6+g2x2-i2x2)+3*SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)+3*SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2))/16.;
};

/* Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_623(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)-SinTPi(2+g2x2-i2x2)+SinTPi(2-g2x2+i2x2)+SinTPi(2+g2x2+i2x2))/4.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_624(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.+CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/16.+CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/16.+CosTPi(2+g2x2+h2x2-i2x2)/16.+CosTPi(6+g2x2+h2x2-i2x2)/16.-CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/16.-CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/16.-CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/16.-CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_625(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-h2x2-i2x2)-SinTPi(8-h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)+SinTPi(8+h2x2-i2x2)+2*SinTPi(4-h2x2+i2x2)+SinTPi(8-h2x2+i2x2)-2*SinTPi(4+h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_626(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)-SinTPi(2+h2x2-i2x2)+SinTPi(2-h2x2+i2x2)+SinTPi(2+h2x2+i2x2))/4.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_627(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(2-h2x2-i2x2)-SinTPi(6-h2x2-i2x2)-3*SinTPi(2+h2x2-i2x2)-SinTPi(6+h2x2-i2x2)+3*SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)+3*SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2))/16.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_628(const int i2x2, const int g2x2, const int h2x2){
return (-4*SinTPi(4-i2x2)-SinTPi(8-i2x2)+6*SinTPi(i2x2)+4*SinTPi(4+i2x2)+SinTPi(8+i2x2))/16.;
};

/* Sin[i2*t]Cos[2*t]Cos[2*t]*/
static double evalT_629(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-i2x2)+2*SinTPi(i2x2)+SinTPi(4+i2x2))/4.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_630(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)+2*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)-2*CosTPi(4-h2x2+i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[i2*t]Cos[2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_631(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)+2*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)-2*CosTPi(4-g2x2+i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_632(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/64.-SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(12-g2x2-h2x2-i2x2)/64.-SinTPi(4+g2x2-h2x2-i2x2)/64.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(12+g2x2-h2x2-i2x2)/64.-SinTPi(4-g2x2+h2x2-i2x2)/64.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(12-g2x2+h2x2-i2x2)/64.+SinTPi(4+g2x2+h2x2-i2x2)/64.-SinTPi(8+g2x2+h2x2-i2x2)/32.+SinTPi(12+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/64.-SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(12-g2x2-h2x2+i2x2)/64.-SinTPi(4+g2x2-h2x2+i2x2)/64.+SinTPi(8+g2x2-h2x2+i2x2)/32.-SinTPi(12+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/64.+SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(12-g2x2+h2x2+i2x2)/64.+SinTPi(4+g2x2+h2x2+i2x2)/64.-SinTPi(8+g2x2+h2x2+i2x2)/32.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_633(const int i2x2, const int g2x2, const int h2x2){
return (-3*SinTPi(4-g2x2-h2x2-i2x2))/64.+SinTPi(12-g2x2-h2x2-i2x2)/64.+(3*SinTPi(4+g2x2-h2x2-i2x2))/64.-SinTPi(12+g2x2-h2x2-i2x2)/64.+(3*SinTPi(4-g2x2+h2x2-i2x2))/64.-SinTPi(12-g2x2+h2x2-i2x2)/64.-(3*SinTPi(4+g2x2+h2x2-i2x2))/64.+SinTPi(12+g2x2+h2x2-i2x2)/64.-(3*SinTPi(4-g2x2-h2x2+i2x2))/64.+SinTPi(12-g2x2-h2x2+i2x2)/64.+(3*SinTPi(4+g2x2-h2x2+i2x2))/64.-SinTPi(12+g2x2-h2x2+i2x2)/64.+(3*SinTPi(4-g2x2+h2x2+i2x2))/64.-SinTPi(12-g2x2+h2x2+i2x2)/64.-(3*SinTPi(4+g2x2+h2x2+i2x2))/64.+SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]*/
static double evalT_634(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/32.+SinTPi(8-g2x2-h2x2-i2x2)/64.-SinTPi(4+g2x2-h2x2-i2x2)/32.+SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/32.-SinTPi(8-g2x2+h2x2-i2x2)/64.+SinTPi(4+g2x2+h2x2-i2x2)/32.-SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/32.-SinTPi(8-g2x2-h2x2+i2x2)/64.+SinTPi(4+g2x2-h2x2+i2x2)/32.-SinTPi(8+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/32.+SinTPi(8-g2x2+h2x2+i2x2)/64.-SinTPi(4+g2x2+h2x2+i2x2)/32.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[i2*t]Cos[2*t]Cos[h2*t]*/
static double evalT_635(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/32.+SinTPi(8-g2x2-h2x2-i2x2)/64.+SinTPi(4+g2x2-h2x2-i2x2)/32.-SinTPi(8+g2x2-h2x2-i2x2)/64.-SinTPi(4-g2x2+h2x2-i2x2)/32.+SinTPi(8-g2x2+h2x2-i2x2)/64.+SinTPi(4+g2x2+h2x2-i2x2)/32.-SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/32.-SinTPi(8-g2x2-h2x2+i2x2)/64.-SinTPi(4+g2x2-h2x2+i2x2)/32.+SinTPi(8+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/32.-SinTPi(8-g2x2+h2x2+i2x2)/64.-SinTPi(4+g2x2+h2x2+i2x2)/32.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_636(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/16.-SinTPi(8-g2x2-h2x2-i2x2)/64.-(3*SinTPi(g2x2-h2x2-i2x2))/32.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/64.-SinTPi(4-g2x2+h2x2-i2x2)/16.+SinTPi(8-g2x2+h2x2-i2x2)/64.+(3*SinTPi(g2x2+h2x2-i2x2))/32.-SinTPi(4+g2x2+h2x2-i2x2)/16.+SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/16.-SinTPi(8-g2x2-h2x2+i2x2)/64.-(3*SinTPi(g2x2-h2x2+i2x2))/32.+SinTPi(4+g2x2-h2x2+i2x2)/16.-SinTPi(8+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/16.+SinTPi(8-g2x2+h2x2+i2x2)/64.+(3*SinTPi(g2x2+h2x2+i2x2))/32.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_637(const int i2x2, const int g2x2, const int h2x2){
return SinTPi(4-g2x2-h2x2-i2x2)/16.-SinTPi(8-g2x2-h2x2-i2x2)/64.+(3*SinTPi(g2x2-h2x2-i2x2))/32.-SinTPi(4+g2x2-h2x2-i2x2)/16.+SinTPi(8+g2x2-h2x2-i2x2)/64.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/64.+(3*SinTPi(g2x2+h2x2-i2x2))/32.-SinTPi(4+g2x2+h2x2-i2x2)/16.+SinTPi(8+g2x2+h2x2-i2x2)/64.+SinTPi(4-g2x2-h2x2+i2x2)/16.-SinTPi(8-g2x2-h2x2+i2x2)/64.+(3*SinTPi(g2x2-h2x2+i2x2))/32.-SinTPi(4+g2x2-h2x2+i2x2)/16.+SinTPi(8+g2x2-h2x2+i2x2)/64.+SinTPi(4-g2x2+h2x2+i2x2)/16.-SinTPi(8-g2x2+h2x2+i2x2)/64.+(3*SinTPi(g2x2+h2x2+i2x2))/32.-SinTPi(4+g2x2+h2x2+i2x2)/16.+SinTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_638(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.-SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(10+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(10-g2x2+h2x2-i2x2)/32.-SinTPi(2+g2x2+h2x2-i2x2)/16.-SinTPi(6+g2x2+h2x2-i2x2)/32.+SinTPi(10+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/16.-SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.-SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/32.+SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_639(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.+SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(10+g2x2-h2x2-i2x2)/32.-SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.-SinTPi(6-g2x2+h2x2+i2x2)/32.+SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_640(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.+SinTPi(2+g2x2-h2x2-i2x2)/16.-SinTPi(6+g2x2-h2x2-i2x2)/32.-SinTPi(10+g2x2-h2x2-i2x2)/32.-SinTPi(2-g2x2+h2x2-i2x2)/16.+SinTPi(6-g2x2+h2x2-i2x2)/32.+SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/16.-SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(10-g2x2-h2x2+i2x2)/32.+SinTPi(2+g2x2-h2x2+i2x2)/16.-SinTPi(6+g2x2-h2x2+i2x2)/32.-SinTPi(10+g2x2-h2x2+i2x2)/32.-SinTPi(2-g2x2+h2x2+i2x2)/16.+SinTPi(6-g2x2+h2x2+i2x2)/32.+SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_641(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.+SinTPi(6+g2x2-h2x2-i2x2)/64.-SinTPi(10+g2x2-h2x2-i2x2)/64.-SinTPi(6-g2x2+h2x2-i2x2)/64.+SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(6-g2x2-h2x2+i2x2)/64.+SinTPi(10-g2x2-h2x2+i2x2)/64.+SinTPi(6+g2x2-h2x2+i2x2)/64.-SinTPi(10+g2x2-h2x2+i2x2)/64.-SinTPi(6-g2x2+h2x2+i2x2)/64.+SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_642(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-g2x2-i2x2)+2*CosTPi(8-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)+CosTPi(12+g2x2-i2x2)-CosTPi(4-g2x2+i2x2)+2*CosTPi(8-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)+CosTPi(4+g2x2+i2x2)-2*CosTPi(8+g2x2+i2x2)+CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_643(const int i2x2, const int g2x2, const int h2x2){
return (-4*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)+6*CosTPi(g2x2-i2x2)-4*CosTPi(4+g2x2-i2x2)+CosTPi(8+g2x2-i2x2)-4*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)+6*CosTPi(g2x2+i2x2)-4*CosTPi(4+g2x2+i2x2)+CosTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_644(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)+SinTPi(4+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+SinTPi(12-g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_645(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)+4*SinTPi(g2x2-i2x2)+SinTPi(4+g2x2-i2x2)-2*SinTPi(8+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+2*SinTPi(8-g2x2+i2x2)+SinTPi(12-g2x2+i2x2)+4*SinTPi(g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_646(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)+SinTPi(4+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+SinTPi(12-g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_647(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)+SinTPi(12-g2x2-i2x2)+4*SinTPi(g2x2-i2x2)+SinTPi(4+g2x2-i2x2)-2*SinTPi(8+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+2*SinTPi(8-g2x2+i2x2)+SinTPi(12-g2x2+i2x2)+4*SinTPi(g2x2+i2x2)+SinTPi(4+g2x2+i2x2)-2*SinTPi(8+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_648(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-g2x2-i2x2)+SinTPi(8-g2x2-i2x2)-2*SinTPi(g2x2-i2x2)+2*SinTPi(4+g2x2-i2x2)-SinTPi(8+g2x2-i2x2)-2*SinTPi(4-g2x2+i2x2)+SinTPi(8-g2x2+i2x2)-2*SinTPi(g2x2+i2x2)+2*SinTPi(4+g2x2+i2x2)-SinTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[i2*t]*/
static double evalT_649(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-g2x2-i2x2)-SinTPi(8-g2x2-i2x2)+6*SinTPi(g2x2-i2x2)-4*SinTPi(4+g2x2-i2x2)+SinTPi(8+g2x2-i2x2)+4*SinTPi(4-g2x2+i2x2)-SinTPi(8-g2x2+i2x2)+6*SinTPi(g2x2+i2x2)-4*SinTPi(4+g2x2+i2x2)+SinTPi(8+g2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_650(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(g2x2-h2x2-i2x2)/16.+CosTPi(4+g2x2-h2x2-i2x2)/16.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(4-g2x2+h2x2-i2x2)/16.-CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(g2x2+h2x2-i2x2)/16.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/32.-CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(g2x2-h2x2+i2x2)/16.+CosTPi(4+g2x2-h2x2+i2x2)/16.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(4-g2x2+h2x2+i2x2)/16.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(g2x2+h2x2+i2x2)/16.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_651(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-h2x2-i2x2))/64.-CosTPi(12-g2x2-h2x2-i2x2)/64.-(3*CosTPi(4+g2x2-h2x2-i2x2))/64.+CosTPi(12+g2x2-h2x2-i2x2)/64.+(3*CosTPi(4-g2x2+h2x2-i2x2))/64.-CosTPi(12-g2x2+h2x2-i2x2)/64.-(3*CosTPi(4+g2x2+h2x2-i2x2))/64.+CosTPi(12+g2x2+h2x2-i2x2)/64.+(3*CosTPi(4-g2x2-h2x2+i2x2))/64.-CosTPi(12-g2x2-h2x2+i2x2)/64.-(3*CosTPi(4+g2x2-h2x2+i2x2))/64.+CosTPi(12+g2x2-h2x2+i2x2)/64.+(3*CosTPi(4-g2x2+h2x2+i2x2))/64.-CosTPi(12-g2x2+h2x2+i2x2)/64.-(3*CosTPi(4+g2x2+h2x2+i2x2))/64.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_652(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/64.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(12-g2x2-h2x2-i2x2)/64.+CosTPi(4+g2x2-h2x2-i2x2)/64.-CosTPi(8+g2x2-h2x2-i2x2)/32.+CosTPi(12+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/64.+CosTPi(8-g2x2+h2x2-i2x2)/32.-CosTPi(12-g2x2+h2x2-i2x2)/64.+CosTPi(4+g2x2+h2x2-i2x2)/64.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(12+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/64.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(12-g2x2-h2x2+i2x2)/64.+CosTPi(4+g2x2-h2x2+i2x2)/64.-CosTPi(8+g2x2-h2x2+i2x2)/32.+CosTPi(12+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/64.+CosTPi(8-g2x2+h2x2+i2x2)/32.-CosTPi(12-g2x2+h2x2+i2x2)/64.+CosTPi(4+g2x2+h2x2+i2x2)/64.-CosTPi(8+g2x2+h2x2+i2x2)/32.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Sin[i2*t]Cos[2*t]*/
static double evalT_653(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/32.+CosTPi(8-g2x2-h2x2-i2x2)/64.+CosTPi(4+g2x2-h2x2-i2x2)/32.-CosTPi(8+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/32.-CosTPi(8-g2x2+h2x2-i2x2)/64.-CosTPi(4+g2x2+h2x2-i2x2)/32.+CosTPi(8+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/32.-CosTPi(8-g2x2-h2x2+i2x2)/64.-CosTPi(4+g2x2-h2x2+i2x2)/32.+CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/32.+CosTPi(8-g2x2+h2x2+i2x2)/64.+CosTPi(4+g2x2+h2x2+i2x2)/32.-CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_654(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/32.-CosTPi(8-g2x2-h2x2-i2x2)/64.+CosTPi(4+g2x2-h2x2-i2x2)/32.-CosTPi(8+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/32.-CosTPi(8-g2x2+h2x2-i2x2)/64.+CosTPi(4+g2x2+h2x2-i2x2)/32.-CosTPi(8+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/32.+CosTPi(8-g2x2-h2x2+i2x2)/64.-CosTPi(4+g2x2-h2x2+i2x2)/32.+CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/32.+CosTPi(8-g2x2+h2x2+i2x2)/64.-CosTPi(4+g2x2+h2x2+i2x2)/32.+CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[g2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_655(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(4-g2x2-h2x2-i2x2)/16.-CosTPi(8-g2x2-h2x2-i2x2)/64.+(3*CosTPi(g2x2-h2x2-i2x2))/32.-CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/64.-(3*CosTPi(g2x2+h2x2-i2x2))/32.+CosTPi(4+g2x2+h2x2-i2x2)/16.-CosTPi(8+g2x2+h2x2-i2x2)/64.+CosTPi(4-g2x2-h2x2+i2x2)/16.-CosTPi(8-g2x2-h2x2+i2x2)/64.+(3*CosTPi(g2x2-h2x2+i2x2))/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/64.-(3*CosTPi(g2x2+h2x2+i2x2))/32.+CosTPi(4+g2x2+h2x2+i2x2)/16.-CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_656(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/16.+CosTPi(8-g2x2-h2x2-i2x2)/64.+(3*CosTPi(g2x2-h2x2-i2x2))/32.-CosTPi(4+g2x2-h2x2-i2x2)/16.+CosTPi(8+g2x2-h2x2-i2x2)/64.-CosTPi(4-g2x2+h2x2-i2x2)/16.+CosTPi(8-g2x2+h2x2-i2x2)/64.+(3*CosTPi(g2x2+h2x2-i2x2))/32.-CosTPi(4+g2x2+h2x2-i2x2)/16.+CosTPi(8+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/16.+CosTPi(8-g2x2-h2x2+i2x2)/64.+(3*CosTPi(g2x2-h2x2+i2x2))/32.-CosTPi(4+g2x2-h2x2+i2x2)/16.+CosTPi(8+g2x2-h2x2+i2x2)/64.-CosTPi(4-g2x2+h2x2+i2x2)/16.+CosTPi(8-g2x2+h2x2+i2x2)/64.+(3*CosTPi(g2x2+h2x2+i2x2))/32.-CosTPi(4+g2x2+h2x2+i2x2)/16.+CosTPi(8+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_657(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.-SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(10+g2x2-h2x2-i2x2)/32.+SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.-SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(10-g2x2-h2x2+i2x2)/32.-SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_658(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(2-g2x2-h2x2-i2x2)/16.+SinTPi(6-g2x2-h2x2-i2x2)/32.+SinTPi(10-g2x2-h2x2-i2x2)/32.-SinTPi(2+g2x2-h2x2-i2x2)/16.+SinTPi(6+g2x2-h2x2-i2x2)/32.+SinTPi(10+g2x2-h2x2-i2x2)/32.+SinTPi(2-g2x2+h2x2-i2x2)/16.-SinTPi(6-g2x2+h2x2-i2x2)/32.-SinTPi(10-g2x2+h2x2-i2x2)/32.+SinTPi(2+g2x2+h2x2-i2x2)/16.-SinTPi(6+g2x2+h2x2-i2x2)/32.-SinTPi(10+g2x2+h2x2-i2x2)/32.-SinTPi(2-g2x2-h2x2+i2x2)/16.+SinTPi(6-g2x2-h2x2+i2x2)/32.+SinTPi(10-g2x2-h2x2+i2x2)/32.-SinTPi(2+g2x2-h2x2+i2x2)/16.+SinTPi(6+g2x2-h2x2+i2x2)/32.+SinTPi(10+g2x2-h2x2+i2x2)/32.+SinTPi(2-g2x2+h2x2+i2x2)/16.-SinTPi(6-g2x2+h2x2+i2x2)/32.-SinTPi(10-g2x2+h2x2+i2x2)/32.+SinTPi(2+g2x2+h2x2+i2x2)/16.-SinTPi(6+g2x2+h2x2+i2x2)/32.-SinTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_659(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(6-g2x2-h2x2-i2x2)/64.+SinTPi(10-g2x2-h2x2-i2x2)/64.-SinTPi(6+g2x2-h2x2-i2x2)/64.+SinTPi(10+g2x2-h2x2-i2x2)/64.+SinTPi(6-g2x2+h2x2-i2x2)/64.-SinTPi(10-g2x2+h2x2-i2x2)/64.+SinTPi(6+g2x2+h2x2-i2x2)/64.-SinTPi(10+g2x2+h2x2-i2x2)/64.-SinTPi(6-g2x2-h2x2+i2x2)/64.+SinTPi(10-g2x2-h2x2+i2x2)/64.-SinTPi(6+g2x2-h2x2+i2x2)/64.+SinTPi(10+g2x2-h2x2+i2x2)/64.+SinTPi(6-g2x2+h2x2+i2x2)/64.-SinTPi(10-g2x2+h2x2+i2x2)/64.+SinTPi(6+g2x2+h2x2+i2x2)/64.-SinTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_660(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-g2x2-h2x2-i2x2)+SinTPi(8+g2x2-h2x2-i2x2)+SinTPi(8-g2x2+h2x2-i2x2)+SinTPi(8+g2x2+h2x2-i2x2)+SinTPi(8-g2x2-h2x2+i2x2)+SinTPi(8+g2x2-h2x2+i2x2)+SinTPi(8-g2x2+h2x2+i2x2)+SinTPi(8+g2x2+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_661(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(6-g2x2-i2x2)-CosTPi(10-g2x2-i2x2)+CosTPi(6+g2x2-i2x2)-CosTPi(10+g2x2-i2x2)+CosTPi(6-g2x2+i2x2)-CosTPi(10-g2x2+i2x2)+CosTPi(6+g2x2+i2x2)-CosTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_662(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-g2x2-i2x2)+SinTPi(6-g2x2-i2x2)-SinTPi(2+g2x2-i2x2)+SinTPi(6+g2x2-i2x2)-SinTPi(2-g2x2+i2x2)+SinTPi(6-g2x2+i2x2)-SinTPi(2+g2x2+i2x2)+SinTPi(6+g2x2+i2x2))/8.;
};

/* Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_663(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(6-g2x2-i2x2)+SinTPi(10-g2x2-i2x2)+SinTPi(6+g2x2-i2x2)+SinTPi(10+g2x2-i2x2)+SinTPi(6-g2x2+i2x2)+SinTPi(10-g2x2+i2x2)+SinTPi(6+g2x2+i2x2)+SinTPi(10+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_664(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.+CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/16.-CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/16.-CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.+CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/16.+CosTPi(2+g2x2-h2x2+i2x2)/16.+CosTPi(6+g2x2-h2x2+i2x2)/16.-CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/16.-CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_665(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.-CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/16.+CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/16.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.-CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/16.-CosTPi(2+g2x2-h2x2+i2x2)/16.+CosTPi(6+g2x2-h2x2+i2x2)/16.+CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/16.+CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[i2*t]Cos[g2*t]Cos[h2*t]*/
static double evalT_666(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/16.+CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/16.+CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.-CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/32.+CosTPi(10-g2x2-h2x2+i2x2)/32.-CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/32.+CosTPi(10+g2x2-h2x2+i2x2)/32.-CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/32.+CosTPi(10-g2x2+h2x2+i2x2)/32.-CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/32.+CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_667(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.+CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(10+g2x2-h2x2+i2x2)/32.+CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(10-g2x2+h2x2+i2x2)/32.+CosTPi(6+g2x2+h2x2+i2x2)/32.-CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_668(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.-CosTPi(6-g2x2-h2x2-i2x2)/32.-CosTPi(10-g2x2-h2x2-i2x2)/32.+CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/32.-CosTPi(10+g2x2-h2x2-i2x2)/32.+CosTPi(2-g2x2+h2x2-i2x2)/16.-CosTPi(6-g2x2+h2x2-i2x2)/32.-CosTPi(10-g2x2+h2x2-i2x2)/32.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/32.-CosTPi(10+g2x2+h2x2-i2x2)/32.+CosTPi(2-g2x2-h2x2+i2x2)/16.-CosTPi(6-g2x2-h2x2+i2x2)/32.-CosTPi(10-g2x2-h2x2+i2x2)/32.+CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/32.-CosTPi(10+g2x2-h2x2+i2x2)/32.+CosTPi(2-g2x2+h2x2+i2x2)/16.-CosTPi(6-g2x2+h2x2+i2x2)/32.-CosTPi(10-g2x2+h2x2+i2x2)/32.+CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/32.-CosTPi(10+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_669(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(6-g2x2-h2x2-i2x2)/64.-CosTPi(10-g2x2-h2x2-i2x2)/64.+CosTPi(6+g2x2-h2x2-i2x2)/64.-CosTPi(10+g2x2-h2x2-i2x2)/64.+CosTPi(6-g2x2+h2x2-i2x2)/64.-CosTPi(10-g2x2+h2x2-i2x2)/64.+CosTPi(6+g2x2+h2x2-i2x2)/64.-CosTPi(10+g2x2+h2x2-i2x2)/64.+CosTPi(6-g2x2-h2x2+i2x2)/64.-CosTPi(10-g2x2-h2x2+i2x2)/64.+CosTPi(6+g2x2-h2x2+i2x2)/64.-CosTPi(10+g2x2-h2x2+i2x2)/64.+CosTPi(6-g2x2+h2x2+i2x2)/64.-CosTPi(10-g2x2+h2x2+i2x2)/64.+CosTPi(6+g2x2+h2x2+i2x2)/64.-CosTPi(10+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_670(const int i2x2, const int g2x2, const int h2x2){
return (-CosTPi(4-h2x2-i2x2)+2*CosTPi(8-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)+CosTPi(12+h2x2-i2x2)-CosTPi(4-h2x2+i2x2)+2*CosTPi(8-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)+CosTPi(4+h2x2+i2x2)-2*CosTPi(8+h2x2+i2x2)+CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_671(const int i2x2, const int g2x2, const int h2x2){
return (-4*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)+6*CosTPi(h2x2-i2x2)-4*CosTPi(4+h2x2-i2x2)+CosTPi(8+h2x2-i2x2)-4*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)+6*CosTPi(h2x2+i2x2)-4*CosTPi(4+h2x2+i2x2)+CosTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_672(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(6-h2x2-i2x2)-CosTPi(10-h2x2-i2x2)+CosTPi(6+h2x2-i2x2)-CosTPi(10+h2x2-i2x2)+CosTPi(6-h2x2+i2x2)-CosTPi(10-h2x2+i2x2)+CosTPi(6+h2x2+i2x2)-CosTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_673(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-i2x2)-CosTPi(12-i2x2)+CosTPi(4+i2x2)-CosTPi(12+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_674(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-i2x2)-CosTPi(8-i2x2)-2*CosTPi(i2x2)+2*CosTPi(4+i2x2)-CosTPi(8+i2x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Cos[i2*t]*/
static double evalT_675(const int i2x2, const int g2x2, const int h2x2){
return (-4*CosTPi(4-i2x2)+CosTPi(8-i2x2)+6*CosTPi(i2x2)-4*CosTPi(4+i2x2)+CosTPi(8+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[i2*t]*/
static double evalT_676(const int i2x2, const int g2x2, const int h2x2){
return (-2*SinTPi(4-h2x2-i2x2)+SinTPi(8-h2x2-i2x2)-2*SinTPi(h2x2-i2x2)+2*SinTPi(4+h2x2-i2x2)-SinTPi(8+h2x2-i2x2)-2*SinTPi(4-h2x2+i2x2)+SinTPi(8-h2x2+i2x2)-2*SinTPi(h2x2+i2x2)+2*SinTPi(4+h2x2+i2x2)-SinTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_677(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)-SinTPi(12-h2x2-i2x2)-SinTPi(4+h2x2-i2x2)+2*SinTPi(8+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+2*SinTPi(8-h2x2+i2x2)-SinTPi(12-h2x2+i2x2)-SinTPi(4+h2x2+i2x2)+2*SinTPi(8+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[i2*t]*/
static double evalT_678(const int i2x2, const int g2x2, const int h2x2){
return (4*SinTPi(4-h2x2-i2x2)-SinTPi(8-h2x2-i2x2)+6*SinTPi(h2x2-i2x2)-4*SinTPi(4+h2x2-i2x2)+SinTPi(8+h2x2-i2x2)+4*SinTPi(4-h2x2+i2x2)-SinTPi(8-h2x2+i2x2)+6*SinTPi(h2x2+i2x2)-4*SinTPi(4+h2x2+i2x2)+SinTPi(8+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_679(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)+SinTPi(4+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+SinTPi(12-h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_680(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)+4*SinTPi(h2x2-i2x2)+SinTPi(4+h2x2-i2x2)-2*SinTPi(8+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+2*SinTPi(8-h2x2+i2x2)+SinTPi(12-h2x2+i2x2)+4*SinTPi(h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_681(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+2*SinTPi(8-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)+4*SinTPi(h2x2-i2x2)+SinTPi(4+h2x2-i2x2)-2*SinTPi(8+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+2*SinTPi(8-h2x2+i2x2)+SinTPi(12-h2x2+i2x2)+4*SinTPi(h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-2*SinTPi(8+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_682(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-h2x2-i2x2)+SinTPi(12-h2x2-i2x2)+SinTPi(4+h2x2-i2x2)-SinTPi(12+h2x2-i2x2)-SinTPi(4-h2x2+i2x2)+SinTPi(12-h2x2+i2x2)+SinTPi(4+h2x2+i2x2)-SinTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_683(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(2-h2x2-i2x2)+SinTPi(6-h2x2-i2x2)-SinTPi(2+h2x2-i2x2)+SinTPi(6+h2x2-i2x2)-SinTPi(2-h2x2+i2x2)+SinTPi(6-h2x2+i2x2)-SinTPi(2+h2x2+i2x2)+SinTPi(6+h2x2+i2x2))/8.;
};

/* Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_684(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(6-h2x2-i2x2)+SinTPi(10-h2x2-i2x2)+SinTPi(6+h2x2-i2x2)+SinTPi(10+h2x2-i2x2)+SinTPi(6-h2x2+i2x2)+SinTPi(10-h2x2+i2x2)+SinTPi(6+h2x2+i2x2)+SinTPi(10+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_685(const int i2x2, const int g2x2, const int h2x2){
return (5*SinTPi(4-i2x2)+4*SinTPi(8-i2x2)+SinTPi(12-i2x2)+5*SinTPi(4+i2x2)+4*SinTPi(8+i2x2)+SinTPi(12+i2x2))/32.;
};

/* Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_686(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(4-i2x2)+2*SinTPi(8-i2x2)+SinTPi(12-i2x2)+SinTPi(4+i2x2)+2*SinTPi(8+i2x2)+SinTPi(12+i2x2))/32.;
};

/* Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_687(const int i2x2, const int g2x2, const int h2x2){
return (2*SinTPi(4-i2x2)+SinTPi(8-i2x2)+2*SinTPi(4+i2x2)+SinTPi(8+i2x2))/8.;
};

/* Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_688(const int i2x2, const int g2x2, const int h2x2){
return (SinTPi(8-i2x2)+SinTPi(8+i2x2))/8.;
};

/* Sin[2*2*t]Sin[h2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_689(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)+CosTPi(8-h2x2-i2x2)-2*CosTPi(4+h2x2-i2x2)-CosTPi(8+h2x2-i2x2)+2*CosTPi(4-h2x2+i2x2)+CosTPi(8-h2x2+i2x2)-2*CosTPi(4+h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_690(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-h2x2-i2x2)-CosTPi(8+h2x2-i2x2)+CosTPi(8-h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_691(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)+CosTPi(4+h2x2+i2x2)-CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_692(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)-2*CosTPi(8-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+4*CosTPi(h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)+4*CosTPi(h2x2+i2x2)+CosTPi(4+h2x2+i2x2)-2*CosTPi(8+h2x2+i2x2)-CosTPi(12+h2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_693(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)-2*CosTPi(8-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+4*CosTPi(h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-2*CosTPi(8+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-2*CosTPi(8-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)+4*CosTPi(h2x2+i2x2)+CosTPi(4+h2x2+i2x2)-2*CosTPi(8+h2x2+i2x2)-CosTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_694(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-h2x2-i2x2)-CosTPi(12-h2x2-i2x2)+CosTPi(4+h2x2-i2x2)-CosTPi(12+h2x2-i2x2)+CosTPi(4-h2x2+i2x2)-CosTPi(12-h2x2+i2x2)+CosTPi(4+h2x2+i2x2)-CosTPi(12+h2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_695(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-h2x2-i2x2)-CosTPi(8-h2x2-i2x2)-2*CosTPi(h2x2-i2x2)+2*CosTPi(4+h2x2-i2x2)-CosTPi(8+h2x2-i2x2)+2*CosTPi(4-h2x2+i2x2)-CosTPi(8-h2x2+i2x2)-2*CosTPi(h2x2+i2x2)+2*CosTPi(4+h2x2+i2x2)-CosTPi(8+h2x2+i2x2))/16.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_696(const int i2x2, const int g2x2, const int h2x2){
return CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.-CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/16.+CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/16.-CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.+CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/16.-CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/16.+CosTPi(2-g2x2+h2x2+i2x2)/16.+CosTPi(6-g2x2+h2x2+i2x2)/16.-CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_697(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(2-g2x2-h2x2-i2x2)/16.+CosTPi(6-g2x2-h2x2-i2x2)/16.+CosTPi(2+g2x2-h2x2-i2x2)/16.-CosTPi(6+g2x2-h2x2-i2x2)/16.-CosTPi(2-g2x2+h2x2-i2x2)/16.+CosTPi(6-g2x2+h2x2-i2x2)/16.+CosTPi(2+g2x2+h2x2-i2x2)/16.-CosTPi(6+g2x2+h2x2-i2x2)/16.-CosTPi(2-g2x2-h2x2+i2x2)/16.+CosTPi(6-g2x2-h2x2+i2x2)/16.+CosTPi(2+g2x2-h2x2+i2x2)/16.-CosTPi(6+g2x2-h2x2+i2x2)/16.-CosTPi(2-g2x2+h2x2+i2x2)/16.+CosTPi(6-g2x2+h2x2+i2x2)/16.+CosTPi(2+g2x2+h2x2+i2x2)/16.-CosTPi(6+g2x2+h2x2+i2x2)/16.;
};

/* Sin[2*2*t]Sin[g2*t]Cos[2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_698(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)+CosTPi(8-g2x2-i2x2)-2*CosTPi(4+g2x2-i2x2)-CosTPi(8+g2x2-i2x2)+2*CosTPi(4-g2x2+i2x2)+CosTPi(8-g2x2+i2x2)-2*CosTPi(4+g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[2*t]Cos[i2*t]*/
static double evalT_699(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(8-g2x2-i2x2)-CosTPi(8+g2x2-i2x2)+CosTPi(8-g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g2*t]Cos[2*2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_700(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/32.-SinTPi(g2x2-h2x2-i2x2)/16.+SinTPi(4+g2x2-h2x2-i2x2)/16.-SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(4-g2x2+h2x2-i2x2)/16.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(g2x2+h2x2-i2x2)/16.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(4-g2x2-h2x2+i2x2)/16.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(g2x2-h2x2+i2x2)/16.+SinTPi(4+g2x2-h2x2+i2x2)/16.-SinTPi(8+g2x2-h2x2+i2x2)/32.-SinTPi(4-g2x2+h2x2+i2x2)/16.+SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(g2x2+h2x2+i2x2)/16.+SinTPi(4+g2x2+h2x2+i2x2)/16.-SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Sin[h2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_701(const int i2x2, const int g2x2, const int h2x2){
return (3*CosTPi(4-g2x2-h2x2-i2x2))/64.-CosTPi(12-g2x2-h2x2-i2x2)/64.+(3*CosTPi(4+g2x2-h2x2-i2x2))/64.-CosTPi(12+g2x2-h2x2-i2x2)/64.-(3*CosTPi(4-g2x2+h2x2-i2x2))/64.+CosTPi(12-g2x2+h2x2-i2x2)/64.-(3*CosTPi(4+g2x2+h2x2-i2x2))/64.+CosTPi(12+g2x2+h2x2-i2x2)/64.+(3*CosTPi(4-g2x2-h2x2+i2x2))/64.-CosTPi(12-g2x2-h2x2+i2x2)/64.+(3*CosTPi(4+g2x2-h2x2+i2x2))/64.-CosTPi(12+g2x2-h2x2+i2x2)/64.-(3*CosTPi(4-g2x2+h2x2+i2x2))/64.+CosTPi(12-g2x2+h2x2+i2x2)/64.-(3*CosTPi(4+g2x2+h2x2+i2x2))/64.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_702(const int i2x2, const int g2x2, const int h2x2){
return -CosTPi(4-g2x2-h2x2-i2x2)/64.+CosTPi(8-g2x2-h2x2-i2x2)/32.-CosTPi(12-g2x2-h2x2-i2x2)/64.-CosTPi(4+g2x2-h2x2-i2x2)/64.+CosTPi(8+g2x2-h2x2-i2x2)/32.-CosTPi(12+g2x2-h2x2-i2x2)/64.+CosTPi(4-g2x2+h2x2-i2x2)/64.-CosTPi(8-g2x2+h2x2-i2x2)/32.+CosTPi(12-g2x2+h2x2-i2x2)/64.+CosTPi(4+g2x2+h2x2-i2x2)/64.-CosTPi(8+g2x2+h2x2-i2x2)/32.+CosTPi(12+g2x2+h2x2-i2x2)/64.-CosTPi(4-g2x2-h2x2+i2x2)/64.+CosTPi(8-g2x2-h2x2+i2x2)/32.-CosTPi(12-g2x2-h2x2+i2x2)/64.-CosTPi(4+g2x2-h2x2+i2x2)/64.+CosTPi(8+g2x2-h2x2+i2x2)/32.-CosTPi(12+g2x2-h2x2+i2x2)/64.+CosTPi(4-g2x2+h2x2+i2x2)/64.-CosTPi(8-g2x2+h2x2+i2x2)/32.+CosTPi(12-g2x2+h2x2+i2x2)/64.+CosTPi(4+g2x2+h2x2+i2x2)/64.-CosTPi(8+g2x2+h2x2+i2x2)/32.+CosTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_703(const int i2x2, const int g2x2, const int h2x2){
return (-SinTPi(4-g2x2-i2x2)+2*SinTPi(8-g2x2-i2x2)-SinTPi(12-g2x2-i2x2)-SinTPi(4+g2x2-i2x2)+2*SinTPi(8+g2x2-i2x2)-SinTPi(12+g2x2-i2x2)-SinTPi(4-g2x2+i2x2)+2*SinTPi(8-g2x2+i2x2)-SinTPi(12-g2x2+i2x2)-SinTPi(4+g2x2+i2x2)+2*SinTPi(8+g2x2+i2x2)-SinTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_704(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)+CosTPi(4+g2x2+i2x2)-CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_705(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)-2*CosTPi(8-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+4*CosTPi(g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)+4*CosTPi(g2x2+i2x2)+CosTPi(4+g2x2+i2x2)-2*CosTPi(8+g2x2+i2x2)-CosTPi(12+g2x2+i2x2))/32.;
};

/* Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_706(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)-2*CosTPi(8-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+4*CosTPi(g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-2*CosTPi(8+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-2*CosTPi(8-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)+4*CosTPi(g2x2+i2x2)+CosTPi(4+g2x2+i2x2)-2*CosTPi(8+g2x2+i2x2)-CosTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[2*t]Cos[2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_707(const int i2x2, const int g2x2, const int h2x2){
return (CosTPi(4-g2x2-i2x2)-CosTPi(12-g2x2-i2x2)+CosTPi(4+g2x2-i2x2)-CosTPi(12+g2x2-i2x2)+CosTPi(4-g2x2+i2x2)-CosTPi(12-g2x2+i2x2)+CosTPi(4+g2x2+i2x2)-CosTPi(12+g2x2+i2x2))/64.;
};

/* Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_708(const int i2x2, const int g2x2, const int h2x2){
return (2*CosTPi(4-g2x2-i2x2)-CosTPi(8-g2x2-i2x2)-2*CosTPi(g2x2-i2x2)+2*CosTPi(4+g2x2-i2x2)-CosTPi(8+g2x2-i2x2)+2*CosTPi(4-g2x2+i2x2)-CosTPi(8-g2x2+i2x2)-2*CosTPi(g2x2+i2x2)+2*CosTPi(4+g2x2+i2x2)-CosTPi(8+g2x2+i2x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h2*t]Cos[2*2*t]Cos[g2*t]Cos[i2*t]*/
static double evalT_709(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/16.+SinTPi(8-g2x2-h2x2-i2x2)/32.+SinTPi(g2x2-h2x2-i2x2)/16.-SinTPi(4+g2x2-h2x2-i2x2)/16.+SinTPi(8+g2x2-h2x2-i2x2)/32.+SinTPi(4-g2x2+h2x2-i2x2)/16.-SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(g2x2+h2x2-i2x2)/16.+SinTPi(4+g2x2+h2x2-i2x2)/16.-SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(4-g2x2-h2x2+i2x2)/16.+SinTPi(8-g2x2-h2x2+i2x2)/32.+SinTPi(g2x2-h2x2+i2x2)/16.-SinTPi(4+g2x2-h2x2+i2x2)/16.+SinTPi(8+g2x2-h2x2+i2x2)/32.+SinTPi(4-g2x2+h2x2+i2x2)/16.-SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(g2x2+h2x2+i2x2)/16.+SinTPi(4+g2x2+h2x2+i2x2)/16.-SinTPi(8+g2x2+h2x2+i2x2)/32.;
};

/* Sin[2*2*t]Sin[2*2*t]Sin[2*t]Cos[2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_710(const int i2x2, const int g2x2, const int h2x2){
return (3*SinTPi(4-g2x2-h2x2-i2x2))/64.-SinTPi(12-g2x2-h2x2-i2x2)/64.+(3*SinTPi(4+g2x2-h2x2-i2x2))/64.-SinTPi(12+g2x2-h2x2-i2x2)/64.+(3*SinTPi(4-g2x2+h2x2-i2x2))/64.-SinTPi(12-g2x2+h2x2-i2x2)/64.+(3*SinTPi(4+g2x2+h2x2-i2x2))/64.-SinTPi(12+g2x2+h2x2-i2x2)/64.+(3*SinTPi(4-g2x2-h2x2+i2x2))/64.-SinTPi(12-g2x2-h2x2+i2x2)/64.+(3*SinTPi(4+g2x2-h2x2+i2x2))/64.-SinTPi(12+g2x2-h2x2+i2x2)/64.+(3*SinTPi(4-g2x2+h2x2+i2x2))/64.-SinTPi(12-g2x2+h2x2+i2x2)/64.+(3*SinTPi(4+g2x2+h2x2+i2x2))/64.-SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

/* Sin[2*2*t]Sin[2*t]Sin[2*t]Cos[2*2*t]Cos[g2*t]Cos[h2*t]Cos[i2*t]*/
static double evalT_711(const int i2x2, const int g2x2, const int h2x2){
return -SinTPi(4-g2x2-h2x2-i2x2)/64.+SinTPi(8-g2x2-h2x2-i2x2)/32.-SinTPi(12-g2x2-h2x2-i2x2)/64.-SinTPi(4+g2x2-h2x2-i2x2)/64.+SinTPi(8+g2x2-h2x2-i2x2)/32.-SinTPi(12+g2x2-h2x2-i2x2)/64.-SinTPi(4-g2x2+h2x2-i2x2)/64.+SinTPi(8-g2x2+h2x2-i2x2)/32.-SinTPi(12-g2x2+h2x2-i2x2)/64.-SinTPi(4+g2x2+h2x2-i2x2)/64.+SinTPi(8+g2x2+h2x2-i2x2)/32.-SinTPi(12+g2x2+h2x2-i2x2)/64.-SinTPi(4-g2x2-h2x2+i2x2)/64.+SinTPi(8-g2x2-h2x2+i2x2)/32.-SinTPi(12-g2x2-h2x2+i2x2)/64.-SinTPi(4+g2x2-h2x2+i2x2)/64.+SinTPi(8+g2x2-h2x2+i2x2)/32.-SinTPi(12+g2x2-h2x2+i2x2)/64.-SinTPi(4-g2x2+h2x2+i2x2)/64.+SinTPi(8-g2x2+h2x2+i2x2)/32.-SinTPi(12-g2x2+h2x2+i2x2)/64.-SinTPi(4+g2x2+h2x2+i2x2)/64.+SinTPi(8+g2x2+h2x2+i2x2)/32.-SinTPi(12+g2x2+h2x2+i2x2)/64.;
};

};

#endif // sph3DSR_EVAL_T_H