#ifndef SOLVE_QUADRATIC_H
#define SOLVE_QUADRATIC_H

#include <glog/logging.h>
#include <math.h>

// Solve Ax^2 + bx + c = 0
void SolveQuadratic(const double A, const double b, const double c,
                    double* root_plus, double*root_minus);

#endif  // SOLVE_QUADRATIC_H
