#ifndef SPHERE_2D_TENSOR
#define SPHERE_2D_TENSOR

#include <cmath>
#include "tensorCompute/sph2D_evalT.h"
#include "tensorCompute/sph2D_evalP.h"
#include "2D/basis_2D.h"
#define Pi M_PI


#define getWaveN \
const int i1x2 = phiI.WN1x2();\
const int i2x2 = phiI.WN2x2();\
const int g1x2 = phiG.WN1x2();\
const int g2x2 = phiG.WN2x2();\
const int h1x2 = phiH.WN1x2();\
const int h2x2 = phiH.WN2x2();\
const double i1 = phiI.WN1D();\
const double i2 = phiI.WN2D();\
const double g1 = phiG.WN1D();\
const double g2 = phiG.WN2D();\
const double h1 = phiH.WN1D();\
const double h2 = phiH.WN2D();\

class sphere2DTensor{
public:
sphere2DTensor();
~sphere2DTensor(){};
#include "tensorCompute/sphere2DTensorApp.h"
std::vector<double (*)(const Basis2D&, const Basis2D&, const Basis2D&)> pointers_;
};

#endif // SPHERE_2D_TENSOR