//#include <math.h>
#include <cmath>
#include <gsl/gsl_sf.h>
#include <glog/logging.h>

#include "3D/trig_integral_3d.h"
#include "util/util.h"

#define INTEGRAL_SS(c_, i, n) \
int c_ = 0; \
if ((i - n) == 0) { \
  c_ ++; \
} \
if ((i + n) == 0) { \
  c_ --; \
} \
if (c_ == 0) return 0;
 
#define INTEGRAL_CC(c_, i, n) \
int c_ = 0; \
if ((i + n) == 0) {\
  c_ ++; \
} \
if ((i - n) == 0) {\
    c_ ++; \
} \
if (c_ == 0) return 0;

#define INTEGRAL_SC(c_, i, n) \
double c_ = 0; \
if ((i + n) != 0 && ((i + n) % 2 != 0)) { \
  c_ += 1.0 / (static_cast<double>(i + n)); \
} \
if ((i - n) != 0 && ((i - n) % 2 != 0)) { \
  c_ += 1.0 / (static_cast<double>(i - n)); \
}

#define INTEGRAL_CS(c_, i, n) \
double c_ = 0; \
if ((i + n) != 0 && ((i + n) % 2 != 0)) { \
  c_ += 1.0 / (static_cast<double>(i + n)); \
} \
if ((i - n) != 0 && ((i - n) % 2 != 0)) { \
  c_ -= 1.0 / (static_cast<double>(i - n)); \
}

namespace {
// This function takes a xt as input, xt can only be integer, or integer offset by 0.5;
// Evaluate sin(xt*M_PI);
inline double CheapSin(double xt) {
  const int dx = static_cast<int>(xt*2.0);
  if (dx % 2 == 0) {    // integer
    return 0;
  } else {  // integer offset by 0.5
    if (dx % 4 == 1) {
      return 1;
    } else {
      return -1;
    }
  }
}

// Evaluate cos(k*M_PI), where k can be an integer, or integer offset by half.
// The argument passed in is k*2. When k is an integer, kx2 will be even, otherwise it
// will be odd
inline double CheapCos_D2(int kx2) {
  // even function.
  kx2 = std::abs(kx2);
  // cos is always zero at half pi.
  if (kx2 % 2 != 0)
    return 0;
  int k = kx2/2;
  // cos(0), cos(2pi), etc
  if (k % 2 == 0)
    return 1.0;
  else
    return -1.0;
}

// Evaluate sin(k*M_PI), where k can be an integer, or integer offset by half.
// The argument passed in is k*2. When k is an integer, kx2 will be even, otherwise it
// will be odd
inline double CheapSin_D2(int kx2) {
  // odd function.
  if (kx2 < 0)
    return -CheapSin_D2(std::abs(kx2));
  // sin is always zero at pi.
  if (kx2 % 2 == 0)
    return 0;
  int k = kx2/2;
  // sin(0.5), sin(2.5pi), etc
  if (k % 2 == 0)
    return 1.0;
  else
    return -1.0;
}

}  // namespace

double ComputeIntegralSSSCSS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_SS(cy, i2, n)
  INTEGRAL_SS(cz, i3, l)
  double cx = 0;
  if ((i1 + m) != 0 && ((i1 + m) % 2 != 0)) {
    cx += 1.0 / (static_cast<double>(i1 + m));
  }
  if ((i1 - m) != 0 && ((i1 - m) % 2 != 0)) {
    cx += 1.0 / (static_cast<double>(i1 - m));
  }
  return cx*cy*cz*0.25*PI_SQUARE;
}

double ComputeIntegralCCSSCS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_CC(cy, i2, n)
  INTEGRAL_SS(cz, i3, l)
  double cx = 0;
  if ((i1 + m) != 0 && ((i1 + m) % 2 != 0)) {
    cx += 1.0 / (static_cast<double>(i1 + m));
  }
  if ((i1 - m) != 0 && ((i1 - m) % 2 != 0)) {
    cx -= 1.0 / (static_cast<double>(i1 - m));
  }
  return cx*cy*cz*0.25*PI_SQUARE;
}

double ComputeIntegralCSCSSC(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_SS(cy, i2, n)
  INTEGRAL_CC(cz, i3, l)
  double cx = 0;
  if ((i1 + m) != 0 && ((i1 + m) % 2 != 0)) {
    cx += 1.0 / (static_cast<double>(i1 + m));
  }
  if ((i1 - m) != 0 && ((i1 - m) % 2 != 0)) {
    cx -= 1.0 / (static_cast<double>(i1 - m));
  }
  return cx*cy*cz*0.25*PI_SQUARE;
}

// Compute integral, SSC dot with CSS.
// \int_{0}^{\pi}sin(i1*x)cos(mx)dx *
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralSSCCSS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_SS(cy, i2, n)
  INTEGRAL_SC(cx, i1, m)
  INTEGRAL_CS(cz, i3, l)
  return cx*cy*cz*0.5*M_PI;
}

double ComputeIntegralCSSSSC(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  return ComputeIntegralSSCCSS(m, n, l, i1, i2, i3);
}
// Compute integral, CCC dot with SCS.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}cos(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralCCCSCS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_CS(cx, i1, m)
  INTEGRAL_CC(cy, i2, n)
  INTEGRAL_CS(cz, i3, l)
  return cx*cy*cz*0.5*M_PI;
}
// Compute integral, SCC 1 dot with CSS 6.
// \int_{0}^{\pi}sin(i1*x)cos(mx)dx *
// \int_{0}^{\pi}cos(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralSCCCSS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_SC(cx, i1, m)
  INTEGRAL_CS(cy, i2, n)
  INTEGRAL_CS(cz, i3, l)
  return cx*cy*cz;
}

// Compute integral, CSC 2 dot with SCS 5.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}sin(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)sin(lz)dz
double ComputeIntegralCSCSCS(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_CS(cx, i1, m)
  INTEGRAL_SC(cy, i2, n)
  INTEGRAL_CS(cz, i3, l)
  return cx*cy*cz;
}

// Compute integral, CCS 3 dot with SSC 4.
// \int_{0}^{\pi}cos(i1*x)sin(mx)dx *
// \int_{0}^{\pi}cos(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)cos(lz)dz
double ComputeIntegralCCSSSC(const int i1, const int i2, const int i3,
                             const int m, const int n, const int l) {
  INTEGRAL_CS(cx, i1, m)
  INTEGRAL_CS(cy, i2, n)
  INTEGRAL_SC(cz, i3, l)
  return cx*cy*cz;
}

// \int_{0}^{\pi}cos(i1*x)cos(mx)dx * ...
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralCSSDOUBLE(const double i1, const int i2, const int i3,
                              const double m,
                              const int n, const int l) {
  INTEGRAL_SS(cy, i2, n)
  INTEGRAL_SS(cz, i3, l)
  double cx = 0;
  if (std::abs(i1 + m) < 1e-10) {
    cx += 0.5*M_PI;
  } else {
    cx += 0.5*CheapSin((i1+m)) / (i1 + m);
  }
  if (std::abs(i1 - m) < 1e-10) {
    cx += 0.5*M_PI;
  } else {
    cx += 0.5*CheapSin((i1-m)) / (i1 - m);
  }
  return cx*cy*cz*0.25*PI_SQUARE;

}

// \int_{0}^{\pi}sin((i1)*x)sin(mx)dx * 
// \int_{0}^{\pi}cos(i2*y)cos(ny)dy * 
// \int_{0}^{\pi}sin(i3*x)sin(lz)dz
double ComputeIntegralSCSDOUBLE(const double i1, const int i2, const int i3,
                          const double m, const int n, const int l) {
  INTEGRAL_CC(cy, i2, n)
  INTEGRAL_SS(cz, i3, l)
  double cx = 0;
  if (std::abs(i1 - m) < 1e-10) {
    cx += 0.5*M_PI;
  } else {
    cx += 0.5*CheapSin((i1 - m)) / (i1 - m);
  }
  if (std::abs(i1 + m) < 1e-10) {
    cx -= 0.5*M_PI;
  } else {
    cx -= 0.5*CheapSin((i1 + m)) / (i1 + m);
  }
  return cx*cy*cz*0.25*PI_SQUARE;
}

// \int_{0}^{\pi}sin((i1)*x)sin(mx)dx * 
// \int_{0}^{\pi}sin(i2*y)sin(ny)dy * 
// \int_{0}^{\pi}cos(i3*x)cos(lz)dz
double ComputeIntegralSSCDOUBLE(const double i1, const int i2, const int i3,
                          const double m, const int n, const int l) {
  INTEGRAL_SS(cy, i2, n)
  INTEGRAL_CC(cz, i3, l)
  double cx = 0;
  if (std::abs(i1 - m) < 1e-10) {
    cx += 0.5*M_PI;
  } else {
    cx += 0.5*CheapSin((i1 - m)) / (i1 - m);
  }
  if (std::abs(i1 + m) < 1e-10) {
    cx -= 0.5*M_PI;
  } else {
    cx -= 0.5*CheapSin((i1 + m)) / (i1 + m);
  }
  return cx*cy*cz*0.25*PI_SQUARE;
}

// type 4.
double ComputeIntegralSSC(const int i1, const int i2, const int i3,
                          const int m, const int n, const int l) {
  int cx = 0;
  if ((i1 - m) == 0) {
    cx ++;
  }
  if ((i1 + m) == 0) {
    cx --;
  }
  if (cx == 0) return 0;
  
  int cy = 0;
  if ((i2 - n) == 0) {
    cy ++;
  }
  if ((i2 + n) == 0) {
    cy --;
  }
  if (cy == 0) return 0;
  
  int cz = 0;
  if ((i3 + l) == 0) {
    cz ++;
  }
  if ((i3 - l) == 0) {
    cz ++;
  }
  if (cz == 0) return 0;
  
  return PI_CUBE*0.125*cx*cy*cz;
}

// type 5
double ComputeIntegralSCS(const int i1, const int i2, const int i3,
                          const int m, const int n, const int l) {
  int cx = 0;
  if ((i1 - m) == 0) {
    cx ++;
  }
  if ((i1 + m) == 0) {
    cx --;
  }
  if (cx == 0) return 0;
  
  int cy = 0;
  if ((i2 + n) == 0) {
    cy ++;
  }
  if ((i2 - n) == 0) {
    cy ++;
  }
  if (cy == 0) return 0;
  
  int cz = 0;
  if ((i3 - l) == 0) {
    cz ++;
  }
  if ((i3 + l) == 0) {
    cz --;
  }
  if (cz == 0) return 0;
  
  return PI_CUBE*0.125*cx*cy*cz;
}

// type 6
double ComputeIntegralCSS(const int i1, const int i2, const int i3,
                          const int m, const int n, const int l) {
  int cx = 0;
  if ((i1 + m) == 0) {
    cx ++;
  }
  if ((i1 - m) == 0) {
    cx ++;
  }
  if (cx == 0) return 0;
  
  int cy = 0;
  if ((i2 - n) == 0) {
    cy ++;
  }
  if ((i2 + n) == 0) {
    cy --;
  }
  if (cy == 0) return 0;
  
  int cz = 0;
  if ((i3 - l) == 0) {
    cz ++;
  }
  if ((i3 + l) == 0) {
    cz --;
  }
  if (cz == 0) return 0;
  
  return PI_CUBE*0.125*cx*cy*cz;
}

double ComputeIntegralCSSS(const int i1, const int i2, const int m, const int n) {
  INTEGRAL_CS(cx, i1, m)
  INTEGRAL_SS(cy, i2, n)
  return cx*cy*0.5*M_PI;
}

// \int_{0}{1}cos(i1\pi r)*sin(g1 \pi r)*sin(h1 \pi r) dr =
// \frac{1}{\pi}\int_{0]{\pi} cos(i1 r) sin(g1 r) sin(h1 r) dr =
// \frac{1}{4 \pi}\int_{0]{\pi}(- C{+--} + C{++-} + C{+-+} - C{+++}) dr
double ComputeIntegralCSS(const int i1, const int g1, const int h1) {
  int c = 0;
  // +--, -
  if ((i1 - g1 - h1) == 0)
    c--;
  // ++-, +
  if ((i1 + g1 - h1) == 0)
    c++;
  // +-+, +
  if ((i1 - g1 + h1) == 0)
    c++;
  // +++, -
  if ((i1 + g1 + h1) == 0)
    c--;
  return 0.25*(double)(c);
}

// \frac{1}{4 \pi} \int_{0}{\pi}C{+--}-C{++-}+C{+-+}-C{+++} dy
double ComputeIntegralSSC(const int i1, const int g1, const int h1) {
  int c = 0;
  // +--, +
  if ((i1 - g1 - h1) == 0)
    c++;
  //++-, -
  if ((i1 + g1 - h1) == 0)
    c--;;
  //+-+, +
  if ((i1 - g1 + h1) == 0)
    c++;
  // +++, -
  if ((i1 + g1 + h1) == 0)
    c--;
  return 0.25*(double)(c);
}

// \int_{0}{\pi} y sin(a y) dy = 
double IntegralRS(const int a) {
  if (a == 0)
    return 0;
  else {
    double result = - M_PI / (double)(a);
    if (a % 2 != 0)
      result = - result;
    return result;
  }
}

double IntegralRS_D2(const int a2) {
  if (a2 == 0)
    return 0;
  else {
    return CheapSin_D2(a2)/(a2*a2)*4.0 - M_PI*CheapCos_D2(a2)/(a2)*2.0;
  }
}

// \int_{0}{\pi} y cos(a2/2 y) dy = 
double IntegralRC_D2(const int a2) {
  if (a2 == 0)
    return 0.5*PI_SQUARE;
  else {
    return (CheapCos_D2(a2) - 1.0)/(a2*a2)*4.0 + M_PI*CheapSin_D2(a2)/(a2)*2.0;
  }
}

// \int_{0}^{pi} 1/y sin(a*y) dy
// \int_{0}^{a \pi} 1/z sin(z) dz = Si(a \pi)
double IntegralRInvS(const int a) {
  if (a == 0)
    return 0;
  else return
    gsl_sf_Si((double)(a)*M_PI);
}

// \int_{0}{\pi}y^2 cos(ay)dy
double IntegralR2C(const int a) {
  if (a == 0)
    return PI_CUBE / 3.0;
  else {
    double factor = 2.0*M_PI / (double)(a*a);
    if (a % 2 != 0)
      factor = -factor;

    return factor;
  }
}

double IntegralR2C_D2(const int a2) {
  if (a2 == 0)
    return PI_CUBE/3.0;
  else {
    return 2.0*M_PI*CheapCos_D2(a2)/(a2*a2)*4.0 + (-2.0 + a2*a2*PI_SQUARE*0.25)*CheapSin_D2(a2)/(a2*a2*a2)*8.0;
  }
}

// \int_{0}{\pi}y^2 sin(a2/2 y)dy
double IntegralR2S_D2(const int a2) {
  if (a2 == 0)
    return 0;
  double result = 0;
  result += 2.0*M_PI*CheapSin_D2(a2)/(a2*a2)*4.0;
  result -= (2.0 + (-2.0 + a2*a2*PI_SQUARE*0.25)*CheapCos_D2(a2))/(a2*a2*a2)*8.0;
  return result;
}

// \int_{0}{1}r sin(i1\pi r)*sin(g1 \pi r)*sin(h1 \pi r) dr =
// \frac{1}{\pi^2} \int_{0}{\pi} y sin(i1 y)*sin(g1 y )*sin(h1 y) dy = 
// \frac{1}{4\pi^2} \int_{0}{\pi}y(- S{+--} + S{++-} + S{+-+} - S{+++}) dy =
// \frac{1}{4\pi^2} \int_{0}{\pi}(- yS{+--} + yS{++-} + yS{+-+} - yS{+++}) dy =
double ComputeIntegralRSSS(const int i1, const int g1, const int h1) {
  if (i1 == 0 || g1 == 0 || h1 == 0)
    return 0.0;
  double result = 0;
  // -yS{+--}
  result -= IntegralRS(i1 - g1 - h1);
  // yS{++-}
  result += IntegralRS(i1 + g1 - h1);
  // yS{+-+}
  result += IntegralRS(i1 - g1 + h1);
  //- yS{+++}
  result -= IntegralRS(i1 + g1 + h1);

  // \frac{1}{4\pi^2} 
  result *= (0.25/PI_SQUARE);

  return result;
}

double ComputeIntegralRSSS_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  result -= IntegralRS_D2(gx2 - hx2 - ix2);
  result += IntegralRS_D2(gx2 + hx2 - ix2);
  result += IntegralRS_D2(gx2 - hx2 + ix2);
  result -= IntegralRS_D2(gx2 + hx2 + ix2);
  result *= (0.25/PI_SQUARE);
  return result;
}

// \frac{1}{4\pi^2} \int_{0}{\pi}( yC{+--} + yC{++-} + yC{+-+} + yC{+++}) dy =
double ComputeIntegralRCCC_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  // yC{+--}
  result += IntegralRC_D2(ix2 - gx2 - hx2);
  // yC{++-}
  result += IntegralRC_D2(ix2 + gx2 - hx2);
  // yC{+-+}
  result += IntegralRC_D2(ix2 - gx2 + hx2);
  // yC{+++}
  result += IntegralRC_D2(ix2 + gx2 + hx2);

  // \frac{1}{4\pi^2}
  result *= (0.25/PI_SQUARE);
  return result;
}

// \frac{1}{4\pi^2} \int_{0}{\pi} (- yS{+--} + yS{++-} - yS{+-+} + yS{+++}) dy = 
double ComputeIntegralRCSC(const int i1, const int g1, const int h1) {
  double result = 0;
  // - yS{+--}
  result -= IntegralRS(i1 - g1 - h1);
  // + yS{++-}
  result += IntegralRS(i1 + g1 - h1);
  // - yS{+-+}
  result -= IntegralRS(i1 - g1 + h1);
  // + yS{+++}
  result += IntegralRS(i1 + g1 + h1);
  // \frac{1}{4\pi^2}
  result *= (0.25/PI_SQUARE);

  return result;
}

// \frac{1}{4\pi^2} \int_{0}{\pi} ( yC{+--} + yC{++-} - yC{+-+} - yC{+++}) dy = 
double ComputeIntegralRSCS_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  // + yC{+--}
  result += IntegralRC_D2(ix2 - gx2 - hx2);
  // + yC{++-}
  result += IntegralRC_D2(ix2 + gx2 - hx2);
  // - yC{+-+}
  result -= IntegralRC_D2(ix2 - gx2 + hx2);
  // - yC{+++}
  result -= IntegralRC_D2(ix2 + gx2 + hx2);
  // \frac{1}{4\pi^2}
  result *= (0.25/PI_SQUARE);

  return result;
}

double ComputeIntegralRCSC_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  result += IntegralRS_D2(gx2 - hx2 - ix2);
  result += IntegralRS_D2(gx2 + hx2 - ix2);
  result += IntegralRS_D2(gx2 - hx2 + ix2);
  result += IntegralRS_D2(gx2 + hx2 + ix2);
  result *= (0.25/PI_SQUARE);
  return result;
}

/*
// \int_{0}{1} 1/r sin(i1\pi r)*sin(g1 \pi r)*sin(h1 \pi r) dr =
// \int_{0}{\pi} 1/y sin(i1 y)*sin(g1 y)*sin(h1 y) dy =
// 0.25*\int_{0}{\pi} 1/y (-S{+--} + S{++-} + S{+-+} - S{+++}) dy =
double ComputeIntegralRInvSSS(const int i1, const int g1, const int h1) {
  double result = 0;
  // - 1/y S{+--}
  result -= IntegralRInvS(i1 - g1 - h1);
  // 1/y S{++-}
  result += IntegralRInvS(i1 + g1 - h1);
  // 1/y S{+-+}
  result += IntegralRInvS(i1 - g1 + h1);
  // - 1/y S{+++}
  result -= IntegralRInvS(i1 + g1 + h1);
  result *= 0.25;

  return result;
}

double ComputeIntegralRInvSSS_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  result -= IntegralRInvS_D2(gx2 - hx2 - ix2);
  result += IntegralRInvS_D2(gx2 + hx2 - ix2);
  result += IntegralRInvS_D2(gx2 - hx2 + ix2);
  result -= IntegralRInvS_D2(gx2 + hx2 + ix2);
  result *= 0.25;
  return result;
}

// 0.25*\int_{0}{\pi} 1/y (C{+--} + C{++-} + C{+-+} + C{+++}) dy =
double ComputeIntegralRInvCCC_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  result += IntegralRInvC_D2(ix2 - gx2 - hx2);
  result += IntegralRInvC_D2(ix2 + gx2 - hx2);
  result += IntegralRInvC_D2(ix2 - gx2 + hx2);
  result += IntegralRInvC_D2(ix2 + gx2 + hx2);
  result *= 0.25;

  return result;
}*/

// \int_{0}{1}r^2 sin(i1\pi r)*sin(g1\pi r)*cos(h1\pi r) dr =
// \frac{1}{\pi^3} \int_{0}{\pi} y^2 sin(i1 y)*sin(g1 y)*cos(h1 y) dy =
// \frac{1}{4\pi^3} \int_{0}{\pi} (y^2C{+--} - y^2C{++-} + y^2C{+-+} - y^2C{+++}) dy
double ComputeIntegralR2SSC(const int i1, const int g1, const int h1) {
  double result = 0;
  // y^2C{+--}
  result += IntegralR2C(i1 - g1 - h1);
  // - y^2C{++-}
  result -= IntegralR2C(i1 + g1 - h1);
  // + y^2C{+-+}
  result += IntegralR2C(i1 - g1 + h1);
  // - y^2C{+++}
  result -= IntegralR2C(i1 + g1 + h1);
  result *= 0.25/PI_CUBE;
  return result;
}

// \frac{1}{4\pi^3} \int_{0}{\pi} (- y^2 S{+--} - y^2 S{++-} + y^2 S{+-+} + y^2 S{+++}) dy
double ComputeIntegralR2CCS_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  // - y^2 S{+--}
  result -= IntegralR2S_D2(ix2 - gx2 - hx2);
  // - y^2 S{++-} 
  result -= IntegralR2S_D2(ix2 + gx2 - hx2);
  // + y^2 S{+-+}
  result += IntegralR2S_D2(ix2 - gx2 + hx2);
  // + y^2 S{+++}
  result += IntegralR2S_D2(ix2 + gx2 + hx2);
  result *= 0.25/PI_CUBE;
  return result;
}

double ComputeIntegralR2SSC_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  result += IntegralR2C_D2(gx2 - hx2 - ix2);
  result += IntegralR2C_D2(gx2 + hx2 - ix2);
  result -= IntegralR2C_D2(gx2 - hx2 + ix2);
  result -= IntegralR2C_D2(gx2 + hx2 + ix2);
  result *= 0.25/PI_CUBE;
  return result;
}

double IngtegralSin2Pi(int a, bool of) {
  if(! of ) // integer
    return 0;
  else {
    return 2.0 / ((double)(a) + 0.5);
  }
}

// \int_{0}^{2pi} cos(i2 t)sin(g2 t)cos(h2 t) dt
// 0.25 \int_{0}^{2pi}(-S{+--} + S{++-} - S{+-+} + S{+++}) dt
// i2, g2, h2 \in [0, N]. If ofi, ofg, ofh is set to true, i2,g2,h2 are summed by 0.5
double IntegralCSC2Pi(int i2, int g2, int h2, bool ofi, bool ofg, bool ofh) {
  if ((i2 == 0 && !ofi) || (g2 == 0 && !ofg) || (h2 == 0 && !ofh)) {
    return 0;
  }
  double result = 0;
  // -S{+--}
  int carry = (int)(ofi) - (int)(ofg) - (int)(ofh);
  // a = i2 - g2 - h2 is integer plus half, IngtegralSin2Pi(a, false) returns non-zero
  if (carry % 2 != 0) { 
    result -= IngtegralSin2Pi(i2 - g2 - h2 + floor((double)(carry)*0.5), true);
  }
  // + S{++-}
  carry = (int)(ofi) + (int)(ofg) - (int)(ofh);
  if (carry % 2 != 0) {
    result += IngtegralSin2Pi(i2 + g2 - h2 + floor((double)(carry)*0.5), true);
  }
  // - S{+-+}
  carry = (int)(ofi) - (int)(ofg) + (int)(ofh);
  if (carry % 2 != 0) {
    result -= IngtegralSin2Pi(i2 - g2 + h2 + floor((double)(carry)*0.5), true);
  }
  // + S{+++}
  carry = (int)(ofi) + (int)(ofg) + (int)(ofh);
  if (carry % 2 != 0) {
    result += IngtegralSin2Pi(i2 + g2 + h2 + floor((double)(carry)*0.5), true);
  }
  return 0.25*result;
}

// input is twice of the wavenumber.
// \int_{0}{1} sin(i1\pi r)*cos(g1\pi r)*cos(h1\pi r) dr = 
// \frac{1}{\pi} \int_{0}{pi} sin(i1 y)*cos(g1 y)*cos(h1 y) dy =
// \frac{1}{4 \pi} \int_{0}{pi} S{+--} + S{++-} + S{+-+} + S_{+++} dy 
double ComputeIntegralSCC_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  // S+--
  if ((ix2 - gx2 - hx2) != 0)
    result += (1.0 - CheapCos_D2(ix2 - gx2 - hx2))/(ix2 - gx2 - hx2);
  // S++-
  if ((ix2 + gx2 - hx2) != 0)
    result += (1.0 - CheapCos_D2(ix2 + gx2 - hx2))/(ix2 + gx2 - hx2);
  // S+-+
  if ((ix2 - gx2 + hx2) != 0)
    result += (1.0 - CheapCos_D2(ix2 - gx2 + hx2))/(ix2 - gx2 + hx2);
  // S+++
  if ((ix2 + gx2 + hx2) != 0)
    result += (1.0 - CheapCos_D2(ix2 + gx2 + hx2))/(ix2 + gx2 + hx2);
  // \frac{1}{4 \pi}*2
  result *= (0.5/M_PI);
  return result;
}

double ComputeIntegralCSS_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  if ((gx2 - hx2 - ix2) == 0)
    result += M_PI;
  else
    result += 2.0*CheapSin_D2(gx2 - hx2 - ix2)/(gx2 - hx2 - ix2);
  
  if ((gx2 + hx2 - ix2) == 0)
    result -= M_PI;
  else
    result -= 2.0*CheapSin_D2(gx2 + hx2 - ix2)/(gx2 + hx2 - ix2);
  
  if ((gx2 - hx2 + ix2) == 0)
    result += M_PI;
  else
    result += 2.0*CheapSin_D2(gx2 - hx2 + ix2)/(gx2 - hx2 + ix2);

  if ((gx2 + hx2 + ix2) == 0)
    result -= M_PI;
  else
    result -= 2.0*CheapSin_D2(gx2 + hx2 + ix2)/(gx2 + hx2 + ix2);
  result *= (0.25/M_PI);
  return result;
}

// \int_{0}{1} cos(i1\pi r)*cos(g1\pi r)*sin(h1\pi r) dr =
// \frac{1}{\pi} \int_{0}{\pi} cos(i1 y)*cos(g1 y)*sin(h1 y) dy =
// \frac{1}{4 \pi} \int_{0}{\pi} -S{+--} -S{++-} +S{+-+} +S{+++} dy
double ComputeIntegralCCS_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  // S+--
  if ((ix2 - gx2 - hx2) != 0)
    result -= (1.0 - CheapCos_D2(ix2 - gx2 - hx2))/(ix2 - gx2 - hx2);
  // S++-
  if ((ix2 + gx2 - hx2) != 0)
    result -= (1.0 - CheapCos_D2(ix2 + gx2 - hx2))/(ix2 + gx2 - hx2);
  // S+-+
  if ((ix2 - gx2 + hx2) != 0)
    result += (1.0 - CheapCos_D2(ix2 - gx2 + hx2))/(ix2 - gx2 + hx2);
  // S+++
  if ((ix2 + gx2 + hx2) != 0)
    result += (1.0 - CheapCos_D2(ix2 + gx2 + hx2))/(ix2 + gx2 + hx2);
  // \frac{1}{4 \pi}*2
  result *= (0.5/M_PI);
  return result;
}

// \int_{0}^{2pi} sin(i2 t)sin(g2 t)cos(h2 t) dt
// 0.25*\int_{0}^{2pi} C_{+--} - C_{++-} + C_{+-+} - C_{+++} dt
// when sum of wavenumber is not zero, the result is always zero.
double IntegralSSC2Pi_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  if (ix2 == 0 || gx2 == 0)
    return 0.0;

  if ((ix2 - gx2 - hx2) == 0)
    result += M_PI;

  if ((ix2 + gx2 - hx2) == 0)
    result -= M_PI;

  if ((ix2 - gx2 + hx2) == 0)
    result += M_PI;

  if ((ix2 + gx2 + hx2) == 0)
    result -= M_PI;

  return result*0.5;
}

// \int_{0}^{2pi} cos(i2 t)cos(g2 t)cos(h2 t) dt
// 0.25*\int_{0}^{2pi} C_{+--} + C_{++-} + C_{+-+} + C_{+++} dt
double IntegralCCC2Pi_D2(const int ix2, const int gx2, const int hx2) {
  double result = 0;
  
  if ((ix2 - gx2 - hx2) == 0)
    result += M_PI;

  if ((ix2 + gx2 - hx2) == 0)
    result += M_PI;

  if ((ix2 - gx2 + hx2) == 0)
    result += M_PI;

  if ((ix2 + gx2 + hx2) == 0)
    result += M_PI;

  return result*0.5;
}

double IntegralCosDivSin(int k, double* HS) {
  if (k >= 2000)
    LOG(FATAL) << "out of bound";
  k = abs(k);

  return k%2 == 0 ? lnSinEPS - HS[k>>1] : 0;
}

double IntegralSinDivSin(int k) {
  return (k%2 == 0 ? 0 : (k > 0 ? M_PI : -M_PI));
}
double IntegralCosInt2Pi(int k) {
  return (k == 0 ? 2.0*M_PI : 0);
}
double IntegralSinInt(int k) {
  return (k%2 == 0 ? 0 : 2.0/k);
}
double IntegralCosInt(int k) {
  return (k == 0 ? M_PI : 0);
}

// \int_{0}{\pi} cos(a2/2 y) dy = 
double IntegralC_D2(const int a2) {
  // return (a2 == 0 ? M_PI : 0);
  return a2 == 0 ? M_PI : 2.0*CheapSin_D2(a2)/a2;
}

double IntegralS_D2(const int a2) {
  return a2 == 0 ? 0 : (1.0 - CheapCos_D2(a2))*2.0/a2;
  // return ((a2/2)%2 == 0 ? 0 : 2.0/(a2/2));
}

#define ISPI IntegralSinInt
#define ICPI IntegralCosInt

// int_{\theta = 0}^{Pi} sin(i1*t)*sin(i2*t)*sin(\theta) d\theta 
//1/4 (-Sin[1 - i1 - i2] + Sin[1 + i1 - i2] + Sin[1 - i1 + i2] - Sin[1 + i1 + i2])
double IntegSinSinWSin(const int i1, const int i2) {
  return 0.25*(-ISPI(1 - i1 - i2) + ISPI(1 + i1 - i2) +
                ISPI(1 - i1 + i2) - ISPI(1 + i1 + i2));
}

// int_{\theta = 0}^{Pi} cos(i1*t)*sin(i2*t)*sin(\theta) d\theta 
double IntegCosSinWSin(const int i1, const int i2) {
  return 0.25*(ICPI(1 - i1 - i2) + ICPI(1 + i1 - i2) - ICPI(1 - i1 + i2) - 
   ICPI(1 + i1 + i2));
}

// int_{\theta = 0}^{Pi} cos(i1*t)*cos(i2*t)*sin(\theta) d\theta 
double IntegCosCosWSin(const int i1, const int i2) {
  return 0.25*(ISPI(1 - i1 - i2) + ISPI(1 + i1 - i2) + ISPI(1 - i1 + i2) + 
   ISPI(1 + i1 + i2));
}

#undef ICPI
#undef ISPI

// \int_{0}{\pi}y^3 sin(a2/2 y)dy
// this takes in the twice of the wavenumber.
double IntegralR3S_D2(const int a2) {
  if (a2 == 0)
    return 0;
  double result = 0;
  double a = a2/2.0;

  result += 6.0*M_PI*CheapCos_D2(a2)/(a*a*a);
  result -= PI_CUBE*CheapCos_D2(a2)/a;
  result -= 6.0*CheapSin_D2(a2)/(a*a*a*a);
  result += 3.0*PI_SQUARE*CheapSin_D2(a2)/(a*a);

  return result;
}

double IntegralR3C_D2(const int a2) {
  if (a2 == 0)
    return PI_SQUARE*PI_SQUARE*0.25;
  else {
    double result = 0;
    double a = a2/2.0;

    result += 6.0*(1.0 - CheapCos_D2(a2))/(a*a*a*a);
    result += 3.0*PI_SQUARE*CheapCos_D2(a2)/(a*a);
    result -= 6.0*M_PI*CheapSin_D2(a2)/(a*a*a);
    result += PI_CUBE*CheapSin_D2(a2)/a;
    return result;
  }
}

// \int_{0}{\pi}y^4 sin(a2/2 y)dy
// this takes in the twice of the wavenumber.
double IntegralR4S_D2(const int a2) {
  if (a2 == 0)
    return 0;
  double result = 0;
  double a = a2/2.0;

  result += 24.0*(1.0 - CheapCos_D2(a2))/(a*a*a*a*a);
  result += 12.0*PI_SQUARE*CheapCos_D2(a2)/(a*a*a);
  result -= PI_SQUARE*PI_SQUARE*CheapCos_D2(a2)/a; 
  result -= 24.0*M_PI*CheapSin_D2(a2)/(a*a*a*a);
  result += 4.0*PI_CUBE*CheapSin_D2(a2)/(a*a);

  return result;
}

double IntegralR4C_D2(const int a2) {

  if (a2 == 0)
    return PI_CUBE*PI_SQUARE*0.2;

  double result = 0;
  double a = a2/2.0;

  result -= 24.*M_PI*CheapCos_D2(a2)/(a*a*a*a);
  result += 4.*PI_CUBE*CheapCos_D2(a2)/(a*a); 
  result += 24.*CheapSin_D2(a2)/(a*a*a*a*a);
  result -= 12.*PI_SQUARE*CheapSin_D2(a2)/(a*a*a);
  result += PI_SQUARE*PI_SQUARE*CheapSin_D2(a2)/a;

  return result;
}

double IntegralR5S_D2(const int a2) {
  if (a2 == 0)
    return 0;
  double result = 0;
  const double a = a2/2.0;

  result -= (120.0*M_PI*CheapCos_D2(a2))/(a*a*a*a*a);
  result += (20.0*PI_CUBE*CheapCos_D2(a2))/(a*a*a);
  result -= (PI_CUBE*PI_SQUARE* CheapCos_D2(a2))/a;
  result += 120.0*CheapSin_D2(a2)/(a*a*a*a*a*a);
  result -= 60.0*PI_SQUARE*CheapSin_D2(a2)/(a*a*a*a);
  result += (5.0*PI_SQUARE*PI_SQUARE*CheapSin_D2(a2))/(a*a);

  return result;
}

double IntegralR5C_D2(const int a2) {
  if (a2 == 0)
    return PI_CUBE*PI_CUBE/6.0;
  
  double result = 0;
  const double a = a2/2.0;

  result -= 120.0/(a*a*a*a*a*a);
  result += 120.0*CheapCos_D2(a2)/(a*a*a*a*a*a);
  result -= 60.0*PI_SQUARE*CheapCos_D2(a2)/(a*a*a*a);
  result += 5.0*PI_SQUARE*PI_SQUARE*CheapCos_D2(a2)/(a*a);
  result += 120.0*M_PI*CheapSin_D2(a2)/(a*a*a*a*a);
  result -= 20.0*PI_CUBE*CheapSin_D2(a2)/(a*a*a);
  result += PI_SQUARE*PI_CUBE*CheapSin_D2(a2)/a;

  return result;
}

double IntegralR6S_D2(const int a2) {
  if (a2 == 0)
    return 0;
  
  double result = 0;
  const double a = a2/2.0;

  result -= 720.0/(a*a*a*a*a*a*a);
  result += 720.0*CheapCos_D2(a2)/(a*a*a*a*a*a*a);
  result -= 360.0*PI2*CheapCos_D2(a2)/(a*a*a*a*a);
  result += 30.0*PI4*CheapCos_D2(a2)/(a*a*a);
  result -= (PI6*CheapCos_D2(a2))/a;
  result += (720.0*PI*CheapSin_D2(a2))/(a*a*a*a*a*a);
  result -= (120.0*PI3*CheapSin_D2(a2))/(a*a*a*a);
  result += (6.0*PI5*CheapSin_D2(a2))/(a*a);

  return result;
}

double IntegralR6C_D2(const int a2) {
  if (a2 == 0)
    return PI7/7.0;
  double result = 0;
  const double a = a2/2.0;

  result += (720.0*PI*CheapCos_D2(a2))/(a*a*a*a*a*a);
  result -= (120.0*PI3*CheapCos_D2(a2))/(a*a*a*a);
  result += (6.0*PI5*CheapCos_D2(a2))/(a*a);
  result -= (720.0*CheapSin_D2(a2))/(a*a*a*a*a*a*a);
  result += (360.0*PI2*CheapSin_D2(a2))/(a*a*a*a*a);
  result -= (30.0*PI4*CheapSin_D2(a2))/(a*a*a);
  result += (PI6*CheapSin_D2(a2))/a;

  return result;
}

double IntegralR7S_D2(const int a2) {
  if (a2 == 0)
    return 0;
  
  double result = 0;
  const double a = a2/2.0;

  result += (5040.0*PI*CheapCos_D2(a2))/(a*a*a*a*a*a*a);
  result -= (840.0*PI3*CheapCos_D2(a2))/(a*a*a*a*a);
  result += (42.0*PI5*CheapCos_D2(a2))/(a*a*a);
  result -= (PI7*CheapCos_D2(a2))/a;
  result -= (5040.0*CheapSin_D2(a2))/(a*a*a*a*a*a*a*a);
  result += (2520.0*PI2*CheapSin_D2(a2))/(a*a*a*a*a*a);
  result -= (210.0*PI4*CheapSin_D2(a2))/(a*a*a*a);
  result += (7.0*PI6*CheapSin_D2(a2))/(a*a);

  return result;
}

double IntegralR7C_D2(const int a2) {
  if (a2 == 0)
    return 1186.066377008821;
  
  double result = 0;
  const double a = a2/2.0;

 result += 5040.0/(a*a*a*a*a*a*a*a);
 result -= (5040.0*CheapCos_D2(a2))/(a*a*a*a*a*a*a*a);
 result += (2520.0*PI2*CheapCos_D2(a2))/(a*a*a*a*a*a);
 result -= (210.0*PI4*CheapCos_D2(a2))/(a*a*a*a);
 result += (7.0*PI6*CheapCos_D2(a2))/(a*a);
 result -= (5040.0*PI*CheapSin_D2(a2))/(a*a*a*a*a*a*a);
 result += (840.0*PI3*CheapSin_D2(a2))/(a*a*a*a*a);
 result -= (42.0*PI5*CheapSin_D2(a2))/(a*a*a);
 result += (PI7*CheapSin_D2(a2))/a;

  return result;
}

#define Power(val, p) std::pow(val, p)
#define CheapCosD2 CheapCos_D2
#define CheapSinD2 CheapSin_D2

double IntegralS_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;

return 0.3183098861837907/a - (0.3183098861837907*CheapCosD2(a2))/a;
}

double IntegralC_D2_ONE(const int a2) {
  if (a2 == 0)
    return 1.0;

  const double a = a2*0.5;

return (0.3183098861837907*CheapSinD2(a2))/a;
}

double IntegralRS_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;

  return (-0.3183098861837907*CheapCosD2(a2))/a + (0.10132118364233778*CheapSinD2(a2))/(a*a);
}

double IntegralRC_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0.5;

  const double a = a2*0.5;

return -0.10132118364233778/(a*a) + (0.10132118364233778*CheapCosD2(a2))/(a*a) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}

double IntegralR2S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;

  return -0.06450306886639899/(a*a*a) + (0.06450306886639899*CheapCosD2(a2))/(a*a*a) - 
   (0.3183098861837907*CheapCosD2(a2))/a + (0.20264236728467555*CheapSinD2(a2))/(a*a);
}

double IntegralR2C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 1.0/3.0;

  const double a = a2*0.5;

return (0.20264236728467555*CheapCosD2(a2))/(a*a) - (0.06450306886639899*CheapSinD2(a2))/(a*a*a) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}

double IntegralR3S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;
  return (0.19350920659919696*CheapCosD2(a2))/(a*a*a) - (0.3183098861837907*CheapCosD2(a2))/a - 
   (0.061595893528106016*CheapSinD2(a2))/(a*a*a*a) + (0.3039635509270133*CheapSinD2(a2))/(a*a);
}

double IntegralR3C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0.25;

  const double a = a2*0.5;

  return 0.061595893528106016/(a*a*a*a) - (0.061595893528106016*CheapCosD2(a2))/(a*a*a*a) + 
   (0.3039635509270133*CheapCosD2(a2))/(a*a) - (0.19350920659919696*CheapSinD2(a2))/(a*a*a) + 
   (0.3183098861837907*CheapSinD2(a2))/a;

}

double IntegralR4S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

return 0.07842632743328126/Power(a,5) - (0.07842632743328126*CheapCosD2(a2))/Power(a,5) + (0.3870184131983939*CheapCosD2(a2))/Power(a,3) - 
   (0.3183098861837907*CheapCosD2(a2))/a - (0.24638357411242406*CheapSinD2(a2))/Power(a,4) + 
   (0.4052847345693511*CheapSinD2(a2))/Power(a,2);
}

double IntegralR4C_D2_ONE(const int a2) {
if (a2 == 0)
  return 0.2;

const double a = a2*0.5;

return (-0.24638357411242406*CheapCosD2(a2))/Power(a,4) + (0.4052847345693511*CheapCosD2(a2))/Power(a,2) + 
   (0.07842632743328126*CheapSinD2(a2))/Power(a,5) - (0.3870184131983939*CheapSinD2(a2))/Power(a,3) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}


double IntegralR5S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

  return (-0.3921316371664063*CheapCosD2(a2))/Power(a,5) + (0.6450306886639899*CheapCosD2(a2))/Power(a,3) - 
   (0.3183098861837907*CheapCosD2(a2))/a + (0.12481937679550231*CheapSinD2(a2))/Power(a,6) - 
   (0.6159589352810602*CheapSinD2(a2))/Power(a,4) + (0.5066059182116889*CheapSinD2(a2))/Power(a,2);
}

double IntegralR5C_D2_ONE(const int a2) {
if (a2 == 0)
  return 1.0/6.0;

const double a = a2*0.5;

  return -0.12481937679550231/Power(a,6) + (0.12481937679550231*CheapCosD2(a2))/Power(a,6) - (0.6159589352810602*CheapCosD2(a2))/Power(a,4) + 
   (0.5066059182116889*CheapCosD2(a2))/Power(a,2) + (0.3921316371664063*CheapSinD2(a2))/Power(a,5) - 
   (0.6450306886639899*CheapSinD2(a2))/Power(a,3) + (0.3183098861837907*CheapSinD2(a2))/a;
}

double IntegralR6S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

  return -0.23838744972784817/Power(a,7) + (0.23838744972784817*CheapCosD2(a2))/Power(a,7) - (1.176394911499219*CheapCosD2(a2))/Power(a,5) + 
   (0.9675460329959849*CheapCosD2(a2))/Power(a,3) - (0.3183098861837907*CheapCosD2(a2))/a + 
   (0.7489162607730139*CheapSinD2(a2))/Power(a,6) - (1.2319178705621203*CheapSinD2(a2))/Power(a,4) + 
   (0.6079271018540267*CheapSinD2(a2))/Power(a,2);

}

double IntegralR6C_D2_ONE(const int a2) {

if (a2 == 0)
  return 1.0/7.0;

const double a = a2*0.5;

return (0.7489162607730139*CheapCosD2(a2))/Power(a,6) - (1.2319178705621203*CheapCosD2(a2))/Power(a,4) + 
   (0.6079271018540267*CheapCosD2(a2))/Power(a,2) - (0.23838744972784817*CheapSinD2(a2))/Power(a,7) + 
   (1.176394911499219*CheapSinD2(a2))/Power(a,5) - (0.9675460329959849*CheapSinD2(a2))/Power(a,3) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}

double IntegralR7S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

  return (1.6687121480949372*CheapCosD2(a2))/Power(a,7) - (2.744921460164844*CheapCosD2(a2))/Power(a,5) + 
   (1.3545644461943789*CheapCosD2(a2))/Power(a,3) - (0.3183098861837907*CheapCosD2(a2))/a - 
   (0.5311675739336081*CheapSinD2(a2))/Power(a,8) + (2.6212069127055484*CheapSinD2(a2))/Power(a,6) - 
   (2.1558562734837103*CheapSinD2(a2))/Power(a,4) + (0.7092482854963644*CheapSinD2(a2))/Power(a,2);
}

double IntegralR7C_D2_ONE(const int a2) {

if (a2 == 0)
  return 0.125;

const double a = a2*0.5;

return 
  0.5311675739336081/Power(a,8) - (0.5311675739336081*CheapCosD2(a2))/Power(a,8) + (2.6212069127055484*CheapCosD2(a2))/Power(a,6) - 
   (2.1558562734837103*CheapCosD2(a2))/Power(a,4) + (0.7092482854963644*CheapCosD2(a2))/Power(a,2) - 
   (1.6687121480949372*CheapSinD2(a2))/Power(a,7) + (2.744921460164844*CheapSinD2(a2))/Power(a,5) - 
   (1.3545644461943789*CheapSinD2(a2))/Power(a,3) + (0.3183098861837907*CheapSinD2(a2))/a;
}

// int_{r = 0}^{1} r^8*cos(a*pi*r) dr
double IntegralR8S_D2_ONE(const int a2) {

  if (a2 == 0)
    return 0;
  
  const double a = a2*0.5;
  return 1.3526071200266163/Power(a,9) - (1.3526071200266163*CheapCos_D2(a2))/Power(a,9) + 
   (6.674848592379749*CheapCos_D2(a2))/Power(a,7) - (5.489842920329688*CheapCos_D2(a2))/Power(a,5) + 
   (1.8060859282591717*CheapCos_D2(a2))/Power(a,3) - (0.3183098861837907*CheapCos_D2(a2))/a - 
   (4.249340591468865*CheapSin_D2(a2))/Power(a,8) + (6.989885100548129*CheapSin_D2(a2))/Power(a,6) - 
   (3.449370037573937*CheapSin_D2(a2))/Power(a,4) + (0.8105694691387022*CheapSin_D2(a2))/Power(a,2);  
}

// int_{r = 0}^{1} r^8*cos(a*pi*r) dr
double IntegralR8C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 1.0/9.0;
  
  const double a = a2*0.5;
  
  return (-4.249340591468865*CheapCos_D2(a2))/Power(a,8) + (6.989885100548129*CheapCos_D2(a2))/Power(a,6) - 
   (3.449370037573937*CheapCos_D2(a2))/Power(a,4) + (0.8105694691387022*CheapCos_D2(a2))/Power(a,2) + 
   (1.3526071200266163*CheapSin_D2(a2))/Power(a,9) - (6.674848592379749*CheapSin_D2(a2))/Power(a,7) + 
   (5.489842920329688*CheapSin_D2(a2))/Power(a,5) - (1.8060859282591717*CheapSin_D2(a2))/Power(a,3) + 
   (0.3183098861837907*CheapSin_D2(a2))/a;
}

// int_{r = 0}^{1} r^9*cos(a*pi*r) dr
double IntegralR9S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  
  const double a = a2*0.5;

  return (-12.173464080239548*CheapCosD2(a2))/Power(a,9) + (20.024545777139245*CheapCosD2(a2))/Power(a,7) - 
   (9.88171725659344*CheapCosD2(a2))/Power(a,5) + (2.3221104791903637*CheapCosD2(a2))/Power(a,3) - 
   (0.3183098861837907*CheapCosD2(a2))/a + (3.8749339658435145*CheapSinD2(a2))/Power(a,10) - 
   (19.122032661609893*CheapSinD2(a2))/Power(a,8) + (15.72724147623329*CheapSinD2(a2))/Power(a,6) - 
   (5.174055056360905*CheapSinD2(a2))/Power(a,4) + (0.91189065278104*CheapSinD2(a2))/Power(a,2);
}

double IntegralR9C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0.1;
  
  const double a = a2*0.5;

  return -3.8749339658435145/Power(a,10) + (3.8749339658435145*CheapCosD2(a2))/Power(a,10) - (19.122032661609893*CheapCosD2(a2))/Power(a,8) + 
   (15.72724147623329*CheapCosD2(a2))/Power(a,6) - (5.174055056360905*CheapCosD2(a2))/Power(a,4) + 
   (0.91189065278104*CheapCosD2(a2))/Power(a,2) + (12.173464080239548*CheapSinD2(a2))/Power(a,9) - 
   (20.024545777139245*CheapSinD2(a2))/Power(a,7) + (9.88171725659344*CheapSinD2(a2))/Power(a,5) - 
   (2.3221104791903637*CheapSinD2(a2))/Power(a,3) + (0.3183098861837907*CheapSinD2(a2))/a;
}

double IntegralRInvS_D2(const int a2) {
  if (a2 == 0)
    return 0;
  else
    return gsl_sf_Si((double)(a2)*0.5*M_PI);
}

// \int_{eps}{1} 1/r cos(a \pi r) dr = 
// Ci(a \pi) - Ci(eps)
double IntegralRInvC_D2(const int a2) {
  const double eps = 1e-6;
  // even func
  int a2A = std::abs(a2);

  if (a2A == 0)
    return -log(eps);
  else
    return gsl_sf_Ci((double)(a2A)*M_PI*0.5) - gsl_sf_Ci(eps*(double)(a2A)*M_PI*0.5);
}

double IntegralSinInvSinT(const int a2) {
  double v = ((a2/2)%2 == 0 ? 0 : M_PI);
  if (a2 < 0)
    return -v;
  else
    return v;
}

// Computed form t = 10^-6, t = pi-10^-6.
double SinvCos[301] = {29.01731547704827,0.,25.01731547705027,0.,23.683982143722936,0.,22.883982143732936,0.,
   22.312553572318365,0.,21.86810912789192,0.,21.50447276427756,0.,21.19678045661125,0.,
   20.930113789974584,0.,20.694819672361525,0.,20.484293356610053,0.,20.293817166175863,0.,
   20.119904122743602,0.,19.9599041227936,0.,19.81175597469945,0.,19.67382494027469,0.,
   19.544792682272174,0.,19.423580561126055,0.,19.309294846910344,0.,19.201186738876235,0.,
   19.098622636390132,0.,19.001061660862376,0.,18.90803840513442,0.,18.819149516335536,0.,
   18.734043133450808,0.,18.652410480487585,0.,18.573979108040568,0.,18.498507410033355,0.,
   18.425780137416083,0.,18.355604698933597,0.,18.287808088882105,0.,18.222234318512303,0.,
   18.158742255146237,0.,18.097203793737776,0.,18.037502301334456,0.,17.979531286979707,0.,
   17.923193258952697,0.,17.86839873855075,0.,17.815065405367417,0.,17.76311735357336,0.,
   17.712484442338955,0.,17.663101726451572,0.,17.614908955533238,0.,17.567850132173824,0.,
   17.52187312085357,0.,17.476929300806855,0.,17.432973257032806,0.,17.389962504530637,0.,
   17.347857241562743,0.,17.30662012835468,0.,17.26621608814864,0.,17.226612127954596,0.,
   17.187777176704287,0.,17.14968193881905,0.,17.112298761462956,0.,17.075601513974533,0.,
   17.039565478160497,0.,17.004167248298007,0.,16.96938463983235,0.,16.935196605878318,0.,
   16.901583160738166,0.,16.868525309740498,0.,16.836004984783244,0.,16.804004985033245,0.,
   16.772508922295117,0.,16.741501170615138,0.,16.7109668197321,0.,16.68089163202817,0.,
   16.651262002668542,0.,16.622064922650576,0.,16.593287944511303,0.,16.564919150467066,0.,
   16.536947122781037,0.,16.509360916174487,0.,16.482150032114745,0.,16.45530439482885,0.,
   16.428814328905688,0.,16.402670538362013,0.,16.37686408705911,0.,16.351386380366737,0.,
   16.326229147980335,0.,16.301384427805445,0.,16.276844550830823,0.,16.252602126918404,0.,
   16.22865003144402,0.,16.20498139272877,0.,16.18158958020527,0.,16.15846819326803,0.,
   16.135611050760893,0.,16.113012181058394,0.,16.09066581270131,0.,16.068566365549497,0.,
   16.04670844241823,0.,16.025086821166603,0.,16.00369644720906,0.,15.982532426423038,0.,
   15.961590018428065,0.,15.940864630213035,0.,15.920351810090217,0.,15.900047241956297,0.,
   15.879946739841731,0.,15.860046242731293,0.,15.840341809639755,0.,15.820829614927812,0.,
   15.80150594384422,0.,15.78236718828136,0.,15.763409842731795,0.,15.744630500434793,0.,
   15.726025849702003,0.,15.707592670412497,0.,15.689327830667851,0.,15.67122828359854,0.,
   15.653291064313597,0.,15.635513286985825,0.,15.617892142065369,0.,15.600424893615074,0.,
   15.583108876761056,0.,15.565941495252805,0.,15.548920219127062,0.,15.532042582470257,0.,
   15.515306181274621,0.,15.498708671383177,0.,15.482247766519384,0.,15.465921236397135,0.,
   15.449726904907333,0.,15.433662648377219,0.,15.41772639389914,0.,15.401916117725298,0.,
   15.386229843725493,0.,15.370665641904866,0.,15.355221626978848,0.,15.339895957002765,0.,
   15.324686832053475,0.,15.30959249296084,0.,15.294611220086596,0.,15.279741332148758,0.,
   15.26498118508929,0.,15.250329170983271,0.,15.235783716987815,0.,15.221343284328821,0.,
   15.207006367324098,0.,15.19277149244126,0.,15.178637217388879,0.,15.16460213023958,0.,
   15.150664848583617,0.,15.136824018711792,0.,15.12307831482644,0.,15.109426438279336,0.,
   15.095867116835432,0.,15.082399103961418,0.,15.069021178138014};

double IntegralSinInvCosT(const int a2) {
  int idx = std::abs(a2)/2;

  CHECK(idx <= 300);
  return SinvCos[idx];
}

#undef INTEGRAL_SS
#undef INTEGRAL_CC
#undef INTEGRAL_SC
#undef INTEGRAL_CS

// Int_{x = v1}^{v2} sin(A/B*x + c) dx, B != 0.
double IntegralSinAny(const double A, const double B, const double c, const double v1, const double v2) {
  if (A == 0)  // Int_{x = v1}^{v2} sin(c) dx
    return (v2 - v1)*sin(c);
  else {
    const double a = double(A)/double(B);
    return (cos(c + a*v1) - cos(c + a*v2))/a;
  }
}

// Int_{x = v1}^{v2} cos(A/B*x + c), B != 0.
double IntegralCosAny(const double A, const double B, const double c, const double v1, const double v2) {
  if (A == 0)
    return (v2 - v1)*cos(c);
  else {
    const double a = double(A)/double(B);
    return (-sin(c + a*v1) + sin(c + a*v2))/a;
  }
}