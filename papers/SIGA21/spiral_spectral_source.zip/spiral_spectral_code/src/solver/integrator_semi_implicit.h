#ifndef INTEGRATOR_SEMI_IMPLICIT_H
#define INTEGRATOR_SEMI_IMPLICIT_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>

#include "integrator_2d.h"
#include "setting.h"

// We call this integrator 'semi' implicit. The complete implicit formulation
// contains quadratic terms of unknows in the right hand side of the equation
// and linear terms on left hand side of the equation. By replace part of the
// unknow with the known coefficients, we reduced the quadratic terms to linear.

class IntegratorSemiImplicit : public Integrator2D {
public:
  IntegratorSemiImplicit() : Integrator2D() {};
  ~IntegratorSemiImplicit(){};
  void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd& coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) override;
private:
};

#endif  // INTEGRATOR_SEMI_IMPLICIT_H
