#ifndef SPHERE_BASIS_SET_2D_H
#define SPHERE_BASIS_SET_2D_H

#include <cstring>
#include <Eigen/Eigen>
#include <fstream>
#include <fftw3.h>
#include <learnopengl/shader_m.h>
#include <vector>

#include "2D/VFIELD2D.h"
#include "common/particle_sph_3d.h"
#include "common/pairedCoef.h"
#include "common/surface_basis_set_2D.h"
#include "elliptic/prolate_oblate_2D.h"
#include "polar_2D/sphere_basis_2D_all.h"
#include "util/gl4_drawer.h"

#define FAST_TENSOR

typedef std::shared_ptr<SphereBasis2DAll> spherePtrAll;

class SphereBasisSet2D : public SurfaceBasisSet2D {

public:
  SphereBasisSet2D(const int N, const int thetaK, const int phiK):thetaK_(thetaK), phiK_(phiK), is_prolate_(false), is_oblate_(false) {
    nTheta_ = N;
    nPhi_ = 2*N;
    b_ = 1.0;
    c_ = 1.0;
    a_ = 0;
    // nTheta_ must be even to ensure dst works.
    if (nPhi_ % 2 != 0)
      nPhi_ ++;

    allocateBasisMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  SphereBasisSet2D(const int N, const int thetaK, const int phiK, const bool is_prolate, const double& b):thetaK_(thetaK), phiK_(phiK),
    a_(sqrt(1.0 - b*b)), b_(b), c_(b/sqrt(1.0 - b*b)), is_prolate_(is_prolate), is_oblate_(false) {
    nTheta_ = N;
    nPhi_ = 2*N;
    CHECK(isfinite(a_) && isfinite(b_) && isfinite(c_));
    // nTheta_ must be even to ensure dst works.
    if (nPhi_ % 2 != 0)
      nPhi_ ++;

    setUpTable();
    allocateBasisMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  SphereBasisSet2D(const int N, const int thetaK, const int phiK, const bool is_prolate, const bool is_oblate,
                   const double& b):thetaK_(thetaK), phiK_(phiK),
    a_(sqrt(1.0 - b*b)), b_(b), c_(b/sqrt(1.0 - b*b)), is_prolate_(is_prolate), is_oblate_(is_oblate) {
    nTheta_ = N;
    nPhi_ = 2*N;
    CHECK(! (is_prolate_ && is_oblate));
    CHECK(isfinite(a_) && isfinite(b_) && isfinite(c_));
    // nTheta_ must be even to ensure dst works.
    if (nPhi_ % 2 != 0)
      nPhi_ ++;

    setUpTable();
    allocateBasisMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  SphereBasisSet2D(int N, std::ifstream& in):thetaK_(0), phiK_(0) {
    nTheta_ = N;
    nPhi_ = 2*N;
    // nTheta_ must be even to ensure dst works.
    if (nPhi_ % 2 != 0)
      nPhi_ ++;

    // set up table in read from file.
    readFromFile(in);
    allocateTemp();
    setUpFFTWPlan();
  };
  
  ~SphereBasisSet2D(){
  };

  void InverseTramsformToVelocity(
       Eigen::VectorXd& fieldCoef, VFIELD2D* field) override;

  // Input a std::vector field, transform and output the basis coefficients.
  void ForwardTransformtoFrequency(
      const VFIELD2D& field, Eigen::VectorXd* coefficients) override;
  
  void debugInfo(const PolarBasis2D& basis_i, const PolarBasis2D& basis_j,
                          const PolarBasis2D& basis_k);

  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  void outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor);

  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const override;
  void readFromFile(std::ifstream& in) override;

  static int getIndex(const PolarBasis2D& basis_i, const PolarBasis2D& basis_g,
                       const PolarBasis2D& basis_h);

  void computeVelocityPole(const Eigen::VectorXd& fieldCoef, VEC2& north, VEC2& south);

  const Eigen::VectorXd& waveNum2() const {
    return waveNum2_;
  }
 // compute the ur, ut on a uniform r, t grid, test only.
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut);

  // project the force field fr, ft on a uniform r, t grid, test only.  
  void projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef);
  double a() {return a_;}
  double b() {return b_;}
  double c() {return c_;}

  void ReSeedParticles(std::vector<ParticleSph3D>& particles) override;

  Eigen::Vector3d getVelocityCartesian(const Eigen::Vector3d& pos, const VFIELD2D& velocity) override;
  void ProjectParticle(ParticleSph3D& p) override;
  void DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& model, const FIELD2D& density,
                   const std::vector<ParticleSph3D>& particles, const double& ptl_length, drawerCollection& drawers) override;
  void splatParticle(const float ptlWeight, ParaParticle3Df& p, FIELD2D& density) override;

  // Add density particles
  void addParticles(const int x, const int y, const int width, const int height,
                    const int maxParticlePerCell, std::vector<ParaParticle3Df>& densityParticles) override;
  void DrawParticles(const std::vector<ParticleSph3D>& particles, const double ptl_length, drawerCollection& drawers) override;
  VEC2 getVelocityParam(VEC2& pos, const VFIELD2D& velocity) override;
  int inverseLookup(const int k12, const int k22, const int idx) {
    uint64_t hash = Basis2D::toHash(k12, k22, idx);
    std::unordered_map<uint64_t, int>::const_iterator it = basisLookup_.find(hash);
    if (it != basisLookup_.end())
      return it->second;
    else
      return -1;
  }
  void projPosBack(ParaParticle3Df& p) override;

  template<typename DT, typename VT, typename MT>
  void getVelocityPosT(const VT& pos, VT& uCat);
  Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) override;
  Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) override;

  Eigen::Vector3f textureLookUp(const Eigen::Vector3f& pos, const int width, const int height, const int nChannel, const unsigned char *img);

protected:
  Eigen::Vector3d getVelocityProlateOblate(const Eigen::Vector3d& pos, const VFIELD2D& velocity);

  void allocateTemp();
  void setUpTable();

  // clear chunk of mem following ptr, it's up to user
  void clearPointer(double* ptr) {
    std::memset(ptr, 0x00, sizeof(double)*totalSize_);
  }
  void clearPointerSize(double* ptr, int ssize) {
    std::memset(ptr, 0x00, sizeof(double)*ssize);
  }

  void allocateBasisMGS();

  void allocateNumerical();


  void weightCosSin(double* field, double* mult);
  void runMGS(const double thresh, const std::vector<spherePtrAll>& in, std::vector<spherePtrAll>& out,
            Eigen::MatrixXd& Coef, int& m);

  double dotProdCast(const spherePtrAll a, const spherePtrAll b);
  double tensorEntryCast(const spherePtrAll basis_i, const spherePtrAll basis_g, const spherePtrAll basis_h);

  void weightJacobian();
  // transform of phi0
  // 
  void InvTransPhi0();
  void InvTransPhi1();
  void InvTransPhi2();
  void InvTransPsi0();
  void InvTransPsi1();
  void FwdTransPhi0();
  void FwdTransPhi1();
  void FwdTransPhi2();
  void FwdTransPsi0();
  void FwdTransPsi1();
  
  void transformFirstPartPhi(const std::vector<pairedCoef2d2>& coef, bool kind);
  void transformFirstPartPsi(const std::vector<pairedCoef2d2>& coef, bool kind);
  
  void forwardFirstPartPhi(bool kind, std::vector<pairedCoef2d2>& coef);
  void forwardFirstPartPsi(bool kind, std::vector<pairedCoef2d2>& coef);

  void setUpFFTWPlan();
  
  // collect the coef need to be transformed into a std::vector.
  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);
  void initPairCoef();
  void clearPairCoef();
  void assignPairCoef(Eigen::VectorXd& fieldCoef);

  std::vector<VFIELD2D> cached_basis_;

  std::vector<spherePtrAll> all_basis_;

  //bool boundaryCnd_;
  double* weightFunc_;
  double* weightDeriv_;
  // first mode of cosine/sine function.
  double* cosFunc_;
  double* sinFunc_;
  //int nEnrichBasis_;

  int nTheta_;
  int nPhi_;
  double dTheta_;
  double dPhi_;

  // need to write this out.....
  // number of basis along theta
  int thetaK_;
  // number of basis along phi
  int phiK_;

  int totalSize_;
  double invTotalSize_;
  // pointers of size totalSize_
  double* vtTemp_;
  double* vpTemp_;
  double* tTemp0_;
  double* tTemp1_;
  double* pTemp0_;
  double* pTemp1_;
  double* inTemp_;

  // 1D buff of size ntheta.
  double* t1DTemp0_;
  double* t1DTemp1_;

  // pointers of size ntheta
  double* cosTVal_;
  double* sinTVal_;

  // inverse plans
  fftw_plan IsinTheta_;
  fftw_plan IcosTheta_;
  // only need even less for truncated along enrichment basis.
  fftw_plan IsinThetaE_;
  fftw_plan IcosThetaE_;
  fftw_plan IcosPhi_;
  fftw_plan IsinPhi_;
  
  // forward plans
  fftw_plan FsinTheta_;
  fftw_plan FcosTheta_;
  fftw_plan FsinThetaE_;
  fftw_plan FcosThetaE_;
  fftw_plan FcosPhi_;
  fftw_plan FsinPhi_;

  fftw_plan IsinT1D_;
  fftw_plan FsinT1D_;

  std::vector<std::vector<pairedCoef2d2>> phiCoef_;

  //TensorEval eval_;

// elliptic
  
  // focus
  double a_;
  // short axis
  double b_;
  // sinh(w) = b/a
  double c_;

  bool is_prolate_;
  bool is_oblate_;
  std::shared_ptr<IntegrationTable1DPtn> queryTable_;
  std::shared_ptr<IntTable1DData> tabData_;

  // tensor table
  std::shared_ptr<IntegrationTable1DPtn> tensorTable_;
  std::shared_ptr<IntTable1DData> tensorData_;

  double* h_;

  std::default_random_engine m_gen_;
  std::unordered_map<uint64_t, int> basisLookup_;
};

#endif  // SPHERE_BASIS_SET_2D_H