#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "common/basis_set.h"
#include "polar_2D/sphere_basis_set_2D.h"

#include "util/util.h"
#include "util/timer.h"

namespace {
  
  void testTensor() {

    SphereBasisSet2D basis(512, 10, 20);
    std::vector<Adv_Tensor_Type> Adv_tensor_;
    basis.FillVariationalTensor(&Adv_tensor_);
    BasisSet::VerifyAntisymmetric(Adv_tensor_);
  }

  void testProlateTensor() {
    const double b = 0.9;
    SphereBasisSet2D basis(512, 10, 10, false, true, b);
    std::vector<Adv_Tensor_Type> Adv_tensor_;
    basis.outputTestTensorEntries(100, "./oblate2D_tensorTest.txt", &Adv_tensor_);
  }
  
  void testEntry() {
    const double b_ = 0.9;

    // tensor table
    std::shared_ptr<IntegrationTable1DPtn> tensorTable_;
    std::shared_ptr<IntTable1DData> tensorData_;
    std::shared_ptr<IntegrationTable1DPtn> queryTable_;
    std::shared_ptr<IntTable1DData> tabData_;

    queryTable_.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                            "./Tensor/tables/prolate2D/prolateDotTable.bin",
                                            "./Tensor/tables/prolate2D/prolate2DDot.txt"));
    tabData_.reset(new IntTable1DData(b_));
    tabData_->setIntTable(queryTable_);

    tensorTable_.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                            "./Tensor/tables/prolate2D/prolateTensorTable.bin",
                                            "./Tensor/tables/prolate2D/prolateTensor2D.txt"));
    tensorData_.reset(new IntTable1DData(b_));
    tensorData_->setIntTable(tensorTable_);



    ProlateOblate2D basis_i(12, 10, 0, *tabData_, true);
    ProlateOblate2D basis_g(12, 6, 0, *tabData_, true);
    ProlateOblate2D basis_h(16, 4, 0, *tabData_, true);
    LOG(INFO) << basis_i.computeTensorEntry(basis_g, basis_h, *tensorData_);

  }
}

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);
  //testTensor();
  testProlateTensor();
  //testEntry();
}