#ifndef SURFACE_BASIS_SET_2D_H
#define SURFACE_BASIS_SET_2D_H

#include <Eigen/Eigen>
#include <fstream>
#include <learnopengl/shader_m.h>

#include "2D/FIELD2D.h"
#include "2D/VFIELD2D.h"
#include "polar_2D/polar_basis_2D.h"
#include "common/basic_function.h"
#include "common/particle_sph_3d.h"
#include "util/gl4_drawer.h"
#include "util/util.h"

struct drawerCollection {
  std::unique_ptr<particle3DGL4> ptlGL4_;
  std::shared_ptr<Shader> textureShader_;
  std::shared_ptr<Shader> fixColorShader_;
  std::unique_ptr<denstityDrawerSurface> densDrawer_;
};

class SurfaceBasisSet2D {

public:
  SurfaceBasisSet2D(){
    
  };

  ~SurfaceBasisSet2D(){};

  virtual void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) = 0;
  virtual void InverseTramsformToVelocity(
      Eigen::VectorXd& fieldCoef, VFIELD2D* field) = 0;

  // Input a std::vector field, transform and output the basis coefficients.
  virtual void ForwardTransformtoFrequency(
      const VFIELD2D& field, Eigen::VectorXd* coefficients) = 0;

  const Eigen::MatrixXd& transferMat() const  {
    return A_;
  }
  
  int numBasisAll() const {
    return numBasisAll_;
  }

  int GetnumBasisOrtho() const  {
    return numBasisOrtho_;
  }
  virtual void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const = 0;
  virtual void readFromFile(std::ifstream& in) = 0;

  const Eigen::VectorXd& waveNum2() const {
    return waveNum2_;
  }
  virtual Eigen::Vector3d getVelocityCartesian(const Eigen::Vector3d& pos, const VFIELD2D& velocity) = 0;
  virtual void ReSeedParticles(std::vector<ParticleSph3D>& particles) = 0;
  virtual void DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& model, const FIELD2D& density,
                           const std::vector<ParticleSph3D>& particles, const double& ptl_length, drawerCollection& drawers) = 0;
  virtual void splatParticle(const float ptlWeight, ParaParticle3Df& p, FIELD2D& density) = 0;
  
  virtual void addParticles(const int x, const int y, const int width, const int height,
                    const int maxParticlePerCell, std::vector<ParaParticle3Df>& densityParticles) = 0;

  virtual void ProjectParticle(ParticleSph3D& p) = 0;
  virtual void DrawParticles(const std::vector<ParticleSph3D>& particles, const double ptl_length, drawerCollection& drawers) = 0;
  virtual VEC2 getVelocityParam(VEC2& pos, const VFIELD2D& velocity) = 0;

  virtual void projPosBack(ParaParticle3Df& p) = 0;

  virtual Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) = 0;
  virtual Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) = 0;

  void advectRK4(ParticleSph3D& p, const double& dt_);
  void advectRK4(ParaParticle3Df& p, const double& dt_);

protected:
  
  int numBasisAll_;
  // number of orthogonal basis.
  int numBasisOrtho_;

  // inner product of all basis.
  Eigen::MatrixXd H_;
  // transfer matrix
  Eigen::MatrixXd A_;

  // square of wavenumbers.
  Eigen::VectorXd waveNum2_;
};

#endif  // SURFACE_BASIS_SET_2D_H