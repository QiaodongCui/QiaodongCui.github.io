#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "tensorCompute/polar2DTensor.h"
#include "polar_2D/polar_basis_all.h"
#include "polar_2D/scomp_basis_set_2D.h"
#include "util/timer.h"

namespace {

void test() {
  
  const bool boundaryCnd_ = true;
  std::vector<basisPtrAll> all_basis_;
  const int radK_ = 15;
  const int angK_ = 20;

  int offsetOdd = !boundaryCnd_ ? 1 : 0;\
  int offset = boundaryCnd_ ? 1 : 0;\
  const double thresh = 0.2;\
\
  /*Phi^2, Phi^0*/\
  for (int i2 = 1; i2 < angK_; i2++) {\
    if (i2 == 1) {\
      /*phi^2*/\
      for (int i1 = 0; i1 < radK_; i1++) {\
        all_basis_.push_back(basisPtrAll(new PolarBasisAll(i1*2 + offset, 2, 2 )));\
      }\
    }\
    /* phi^0*/\
    for (int i1 = 1; i1 < radK_; i1++) {\
      all_basis_.push_back(basisPtrAll(new PolarBasisAll(i1*2 - offsetOdd, i2*2, 0 )));\
    }\
  }\

  /*Phi^3, Phi^1*/\
  for (int i2 = 1; i2 < angK_; i2++) {\
    if (i2 == 1) {\
      /* phi^3*/\
      for (int i1 = 0; i1 < radK_; i1++) {\
        all_basis_.push_back(basisPtrAll(new PolarBasisAll(i1*2 + offset, 2, 3 )));\
      }\
    }\
\
    /*phi^1*/\
    for (int i1 = 1; i1 < radK_; i1++) {\
      all_basis_.push_back(basisPtrAll(new PolarBasisAll(i1*2 - offsetOdd, i2*2, 1 )));\
    }\
  }\
  /* Phi^4*/\
  for (int i1 = 1; i1 < radK_; i1++) {\
    all_basis_.push_back(basisPtrAll(new PolarBasisAll(i1*2, 0, 4 )));\
  }

  const int numBasisAll_ = all_basis_.size();

Timer timer;
timer.Reset();
  LOG(INFO) << numBasisAll_;

  polar2DTensor tensorEval;

  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
  	for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const PolarBasisAll& basis_i = *all_basis_[i];
        const PolarBasisAll& basis_g = *all_basis_[g];
        const PolarBasisAll& basis_h = *all_basis_[h];
        volatile double Cigh = PolarBasisAll::computeTensorEntry(basis_i, basis_g, basis_h);
				const int idx = basis_i.index()*25 + basis_g.index()*5 + basis_h.index();
        double invWn = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
        volatile double Cnew = tensorEval.pointers_[idx](basis_i, basis_g, basis_h)*invWn;
        CHECK(fabs(Cigh -  Cnew) < 1e-6) << Cigh << " " << Cnew << " " << i << " " << g << " " << h;
      }
    }
  }
  LOG(INFO) << timer.ElapsedTimeInSeconds();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
	
	test();

  return 0;
}