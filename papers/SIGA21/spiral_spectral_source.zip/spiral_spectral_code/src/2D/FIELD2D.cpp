#include <glog/logging.h>
#include "2D/FIELD2D.h"
#include <stdio.h>

void FIELD2D::clear() {
  for(int i = 0; i < xRes*yRes; i++)
    data[i] = 0;
}

void FIELD2D::swapPointer(FIELD2D& field) {
  assert(xRes == field.getxRes());
  assert(yRes == field.getyRes());
  Real* tmp = NULL;
  tmp = data;
  data = field.data;
  field.data = tmp;
}

void FIELD2D::setZeroBorder() {
  int totals = xRes*yRes;

  for(int i = 0; i < xRes; i++) {
    data[i] = 0;
    data[i+ totals  - xRes ] = 0;
  }
  for(int j = 0; j < yRes; j++) {
    data[j*xRes] = 0;
    data[xRes - 1 + j*xRes] = 0.;
  }
}

void FIELD2D::setZeroBorder2Layers() {
  int totals = xRes*yRes;
  
  for(int i = 0; i < xRes; i++) {
    // Bottom.
    data[i] = 0;
    data[i + xRes] = 0;
    // Top.
    data[i + totals - xRes] = 0;
    data[i + totals - 2*xRes] = 0.;
  }
  for(int j = 0; j < yRes; j++) {
    // Left.
    data[j*xRes] = 0;
    data[j*xRes + 1] = 0;
    // Right.
    data[xRes - 1 + j*xRes - 1] = 0;
    data[xRes - 1 + j*xRes] = 0;
  }
}

void FIELD2D::copyBorderAll() {

  for(int i = 0; i < xRes; i++) {
    data[i] = data[i + xRes];
    data[i + totalsize -xRes] = data[i+totalsize -2*xRes];
  }
  
  for(int j = 0; j < yRes; j++) {
    data[j*xRes] = data[j*xRes + 1];
    data[j*xRes + xRes - 1] = data[j*xRes + xRes -2];
  }
}

Real FIELD2D::dot(const FIELD2D& in) {
  assert(xRes == in.getxRes());
  assert(yRes == in.getyRes());
  Real result = 0.;
  for(int i = 0; i < totalsize; i++)
  {
  	result += data[i]*in[i];
  }

  return result;
}
void FIELD2D::axpy(const Real& alpha, const FIELD2D& input) {
  assert(xRes == input.getxRes());
  assert(yRes == input.getyRes());
  for(int i = 0; i < totalsize; i++) {
    data[i] += alpha*input[i];
  }
}
// FIELD2D& FIELD2D::operator=(const Real& alpha)
// {
// 	for(int i=0;i<totalsize;i++)
// 		data[i] = alpha;
// 	return *this;
// }
// FIELD2D& FIELD2D::operator=(const FIELD2D& A)
// {
// 	for(int i=0;i<totalsize;i++)
// 		data[i] = A[i];
// 	return *this;
//}
FIELD2D& FIELD2D::operator *=(const Real alpha) {
  for (int x = 0; x < totalsize; x++)
    data[x] *= alpha;
  return *this;
}

FIELD2D& FIELD2D::operator +=(const Real alpha) {
  for(int x = 0; x < totalsize; x++)
    data[x] += alpha;

  return *this;
}

void FIELD2D::CheckNegative() {
  for (int i = 0; i < totalsize; i++) {
    if (data[i] < 0) {
      printf("Negative");
    }
  }
}

FIELD2D& FIELD2D::operator +=(const FIELD2D& input) {
  assert(xRes == input.getxRes());
  assert(yRes == input.getyRes());

  for(int x = 0; x < totalsize; x++)
    data[x] += input[x];

  return *this;
}

FIELD2D& FIELD2D::operator *=(const FIELD2D& input) {
  assert(xRes == input.getxRes());
  assert(yRes == input.getyRes());

  for(int x = 0; x < totalsize; x++)
    data[x] *= input[x];

  return *this;
}

void FIELD2D::Field2D_Save(FILE* out) {
  fwrite(data, sizeof(Real), totalsize, out);
}

void FIELD2D::checkValue() {
  for (int i = 0; i < totalsize; i++)
    CHECK(std::isfinite(data[i])) << "x: " << i%xRes << " y: " << i/xRes;
}

///////////////////////////////////////////////////////////////////////
// maximum entry
///////////////////////////////////////////////////////////////////////
Real FIELD2D::max()
{
  Real final = data[0];

  for (int i = 0; i < totalsize; i++)
    if (data[i] > final)
      final = data[i];

  return final;
}

// Get the value at a specific position.
Real FIELD2D::GetValue(const float pos_x, const float pos_y) const {
  int x0 = (int)pos_x;
  int x1 = x0 + 1;
  int y0 = (int)pos_y;
  int y1 = y0 + 1;
  
  // clamp everything
  x0 = (x0 < 0) ? 0 : x0;
  y0 = (y0 < 0) ? 0 : y0;
  x1 = (x1 < 0) ? 0 : x1;
  y1 = (y1 < 0) ? 0 : y1;
  
  x0 = (x0 > xRes - 1) ? xRes - 1 : x0;
  y0 = (y0 > yRes - 1) ? yRes - 1 : y0;
  x1 = (x1 > xRes - 1) ? xRes - 1 : x1;
  y1 = (y1 > yRes - 1) ? yRes - 1 : y1;
  
  //interpolate
  const Real s1 = pos_x - x0;
  const Real s0 = 1.0f - s1;
  const Real t1 = pos_y - y0;
  const Real t0 = 1.0f - t1;

  const int i00 = x0 + y0 * xRes;
  const int i01 = x0 + y1 * xRes;
  const int i10 = x1 + y0 * xRes;
  const int i11 = x1 + y1 * xRes;
  
  return s0 * (t0 * data[i00] +
    t1 * data[i01]) +
    s1 * (t0 * data[i10] +
    t1 * data[i11]);
}

void FIELD2D::writeToFile(std::ofstream& out) const {
  out.write(reinterpret_cast<const char *>(&xRes), sizeof(int));
  out.write(reinterpret_cast<const char *>(&yRes), sizeof(int));
  out.write(reinterpret_cast<const char *>(data), sizeof(Real)*xRes*yRes);
}