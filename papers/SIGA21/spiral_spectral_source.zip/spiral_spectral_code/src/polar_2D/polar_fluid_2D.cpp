#include <cstdlib>
#include <ctime>
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <fstream>
#include <glog/logging.h>
#include <math.h>

#include "2D/drawer_2d.h"
#include "2D/FIELD2D.h"
#include "2D/particle_2d.h"
#include "2D/VFIELD2D.h"

#include "Alg/VEC2.h"
#include "common/query_table.h"

#include "solver/bi_cg_s_solver.h"
#include "solver/bi_cg_stab_preconditioned.h"
#include "solver/integrator_2d.h"
#include "solver/integrator_RK4.h"
#include "solver/integrator_semi_implicit.h"
#include "solver/symmetric_cg.h"
#include "solver/trapezoidal.h"
#include "3D/laplacian_basis_set_3d.h"

#include "polar_2D/polar_fluid_2D.h"
#include "polar_2D/scomp_basis_set_2D.h"

#include "elliptic/elliptic_basis_2D.h"
#include "elliptic/elliptic_basis_set_2D.h"
#include "util/timer.h"
#include "util/util.h"
#include "util/read_write_tensor.h"

#include "setting.h"
using namespace std;

void PolarFluid2D::Initialize() {
  // Initialize the density and velocity field.
  velocity_ = VFIELD2D(xRes_, yRes_);
  force_    = VFIELD2D(xRes_, yRes_);

  density_  = FIELD2D(xRes_, yRes_);
  density_old_ = FIELD2D(xRes_, yRes_);
  
  temp1 = FIELD2D(xRes_, yRes_);
  temp2 = FIELD2D(xRes_, yRes_);

  timer_ = Timer();

  int radK = floor(sqrtf((double)(numBasisAll)*0.5));
  int angK = radK + 1;

  ifstream in;
  if (tensor_fname_.size() != 0) {
    in.open(tensor_fname_);
    if (! in.is_open())
      LOG(FATAL) << "cannot open " << tensor_fname_;
  }

  // Initialize the basis.
  int basis_type_int;
  
  if (basis_type_ == "scomp_dirichlet") {
    basis_type_int = 3;
    if (tensor_fname_.size() == 0) {
      basis_.reset(new SCompBasisSet2D(xRes_, radK, angK, true));
      //basis_->init();
    } else {
      basis_.reset(new SCompBasisSet2D(xRes_, in));
    }
  } else if (basis_type_ == "scomp_neumann") {
    basis_type_int = 4;
    if (tensor_fname_.size() == 0) {
      basis_.reset(new SCompBasisSet2D(xRes_, radK, angK, false));
    //basis_->init();
    } else {
      basis_.reset(new SCompBasisSet2D(xRes_, in));
    }
  } else if (basis_type_ == "elliptic_dirichlet") {
    basis_type_int = 6;
    is_elliptic_ = true;
    if (tensor_fname_.size() == 0) {
      LOG(INFO) << "allocate elliptic: " << a_ << " " << c_;
      basis_.reset(new EllipticBasisSet2D(xRes_, radK, angK, true, b_));
    } else {
      basis_.reset(new EllipticBasisSet2D(xRes_, in));
    }
  } else {
    LOG_ASSERT(false) << "Unknow basis tpye: " << basis_type_;
  }

  numBasisAll = basis_.get()->numBasisAll();
  numBasisOrtho = basis_.get()->GetnumBasisOrtho();

  LOG(INFO) << "orthogonal basis allocated: " << numBasisOrtho;
  A_ = basis_.get()->transferMat();
  // Initialize the coefficients.
  basis_coefficients_.resize(numBasisOrtho);
  basis_coefficients_.setZero();

  basis_coefficients_old_.resize(numBasisOrtho);
  basis_coefficients_old_.setZero();

  tempVector_.resize(numBasisOrtho);
  tempVector_.setZero();

  // Initialize drawer.
  drawer_.reset(new Drawer2D());

  basisWeights_.resize(numBasisAll);
  basisWeights_.setOnes();

  // Fill the tensor.
  if (tensor_fname_.size() == 0) {
    LOG(INFO) << "Fill the advection tensor...";
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
  } else {
    LOG(INFO) << "Read tensor from file.";
    //ReadTensor(tensor_fname_, numBasisAll, basis_type_int, &Adv_tensor_);
    //basis_.get()->ComputeBasisWeights(&basisWeights_);
    //basis_.get()->MultiplyweightTensor(Adv_tensor_, basisWeights_);
    ReadTensor(in, numBasisAll, basis_type_int, &Adv_tensor_);
  }
  
  reWeightTensor();
  
  Eigen::VectorXd weights = Eigen::VectorXd::Ones(Adv_tensor_.size());
  if (basis_type_ == "scomp_dirichlet") {
    //std::static_pointer_cast<SCompBasisSet2D>(basis_)->computeBasisWeight(weights);
    //LaplacianBasisSet3D::MultiplyweightTensor(Adv_tensor_, weights);
  }
  
  for (int i = 0; i < num_particles_; i++) {
    int px = 0;
    int py = 0;
    Particle2D particle(px + 0.5, py + 0.5);
    particles_.push_back(particle);
  }
  ReSeedParticles();
  rest_frame_ = total_frame_;
  integrator_time_ = 0.;
  transformation_time_ = 0.;
  density_advection_time_ = 0.;
  maximum_condition_number_ = 0.;
  frame_simulated_ = 0;
  Eigen::VectorXd allCoef = Eigen::VectorXd::Zero(numBasisAll);

  basis_coefficients_ = basis_.get()->transferMat()*allCoef;
  const Eigen::VectorXd& waveN2 = basis_->waveNum2();
  computeSortedIdx(waveN2);
  InitSmoke();
}

void PolarFluid2D::InitSmoke() {
  AddSmokeTestCase(xRes_/2, yRes_/2+100, 180, 180);
  //AddSmokeTestCase(xRes_/2 + 60, yRes_/2+15, 120, 120);
}

void PolarFluid2D::AddBuoyancy() {
  const int ddy = 40;
  const int ddx = 40;
  //if (current_energy_ > 0.6)
  //  return;

  //LOG(INFO) << xRes_;
  for (int i = 0; i < xRes_; i++) {
    for (int j = 0; j < yRes_; j++) {
      //force_(i,j)[0] = -40.0*density_(i,j);
      force_(i,j)[1] = -6.0*density_(i,j);
    }
  }
}

void PolarFluid2D::Step() {
  float DCT_time = 0;
  float integrator_time = 0;
  float advection_time = 0;
  float contraction_time = 0;
  float solver_time = 0;
  // plume
  //InitSmoke();
  //AddSmokeTestCase(xRes_/2-180, yRes_/2, 40, 12);
  current_energy_ = CalculateEnergy();
  
  // Swap the coefficients.
  for (int i = 0; i < basis_coefficients_.size(); i++) {
    basis_coefficients_old_[i] = basis_coefficients_[i];
  }

  double condition_number = 1.0;

  integrator_.get()->IntegrateForward(Adv_tensor_, A_, basis_coefficients_old_,
                                       dt_,
                                       basis_coefficients_, condition_number,
                                       contraction_time, solver_time);

  if (condition_number > maximum_condition_number_) {
    maximum_condition_number_ = condition_number;
  }

  integrator_time = contraction_time + solver_time;

  // Disspate energy from viscosity.
  DissipateEnergy();
  // Add buoyancy by using DCT to transform to freq domain.
  AddBuoyancy();

  timer_.Reset();
  DCT_time += timer_.ElapsedTimeInSeconds();
  // Add external forces.
  AddExternalForce();
  timer_.Reset();

  // Reconstruct the velocity field.
  timer_.Reset();
  basis_.get()->InverseTransformToVelocity(basis_coefficients_, &velocity_);

  DCT_time += timer_.ElapsedTimeInSeconds();

  timer_.Reset();
  // Advect density.
  AdvectDensity();

  // Advect particles.
  AdvectParticles();
  advection_time = timer_.ElapsedTimeInSeconds();
  rest_frame_ --;
  if (rest_frame_ <=0) {
    Quit();
  }

  LOG(INFO) << "Frame: " << frame_simulated_;
  LOG(INFO) << "Total energy: " << current_energy_;

  LOG(INFO) << "DCT time: " << DCT_time;
  LOG(INFO) << "Advection time: " << advection_time;
  LOG(INFO) << "Contraction time: " << contraction_time;
  LOG(INFO) << "Solver time: " << solver_time;

  integrator_time_ += integrator_time;
  density_advection_time_ += advection_time;  
  transformation_time_ += DCT_time;
  
  frame_simulated_ ++;
}

void PolarFluid2D::AdvectDensity() {
  const double dt0 = dt_ / dx_;
  density_.swapPointer(density_old_);
  // VFIELD2D::advect(dt0, velocity_, density_old_, density_);
  VFIELD2D::advectMacCormack(dt0, velocity_, density_old_, density_, temp1, temp2);
  temp1.clear();
  temp2.clear();
  density_.setZeroBorder();
}

void PolarFluid2D::AddSmokeTestCase(
    const int xpos, const int ypos, const int width, const int height) {
  AddDensity(xpos, ypos, width, height, &density_);  
}

void PolarFluid2D::AddDensity(const int x, const int y, const int width,
                                const int height, FIELD2D* field) {
  int startx = x - width / 2;
  int starty = y - height / 2;
  int endx = x + width / 2;
  int endy = y + height / 2;
  
  if (startx < 0) startx = 0;
  if (startx >= xRes_) startx = xRes_ - 1;
  if (starty < 0) starty = 0;
  if (starty >= yRes_) starty = yRes_ - 1;
  if (endx < 0) endx = 0;
  if (endx >= xRes_) endx = xRes_ - 1;
  if (endy < 0) endy = 0;
  if (endy >= yRes_) endy = yRes_ - 1;
  
  for(int j = starty; j <= endy; j++) {
    for (int i = startx; i <= endx; i ++) {
      int index = i + j*xRes_;
      (*field)[index] = 1.f;
    }
  }
}

// Convert the external force field into the coefficients, and then
// add the external forces.
void PolarFluid2D::AddExternalForce() {
  Eigen::VectorXd force_coef(numBasisOrtho); force_coef.setZero();
  basis_.get()->ForwardTransformtoFrequency(force_, &force_coef);

  for (int i = 0; i < numBasisOrtho; i++) {
    basis_coefficients_[i] += force_coef[i] * dt_;
  }
  force_.clear();
}

void PolarFluid2D::DrawDensity() {
  drawer_.get()->DrawDensity(density_, xRes_, yRes_, dx_);
}

void PolarFluid2D::DrawVelocity() {
  drawer_.get()->DrawVelocity(velocity_, xRes_, yRes_, dx_);
}

void PolarFluid2D::DrawCoefficients(const double multi_factor) {

  Eigen::VectorXd energy_w = basis_coefficients_.cwiseProduct(basis_coefficients_);
  // sort according to the charastic wave numbers.
  Eigen::VectorXd energySorted = Eigen::VectorXd::Zero(numBasisOrtho);
  for (int i = 0; i < sortedIndex_.size(); i++)
    energySorted[i] = energy_w[sortedIndex_[i]];
  drawer_.get()->DrawCoefficients(energySorted,  dx_, multi_factor*20.0, 0);
}

void PolarFluid2D::DrawParticles(const double ptl_length) {
  drawer_.get()->DrawParticles(particles_, dx_, dt_, ptl_length);
}

void PolarFluid2D::AddForce(const int xpos, const int ypos,
                              const float fx, const float fy) {
  const int index = xpos + ypos * xRes_;
  force_[index][0] += fx;
  force_[index][1] += fy;
}

void PolarFluid2D::AddSmoke(const int xpos, const int ypos, 
                              const float amount){
  const int index = xpos + ypos * xRes_;
  density_[index] += amount;
}

// Using the velocity field directed interpolated from the polar grid,
// RK4 advection.
void PolarFluid2D::AdvectParticles() {
  const double h = dt_;

  #pragma omp parallel for
  for (int i = 0; i < num_particles_; i++) {
    // substepping each with RK4.

    // Get the velocity at the particles.
    const VEC2& position = particles_[i].position;
    VEC2 p_v = velocity_.GetVelocity(position[0]*xRes_, position[1]*yRes_);
    //VEC2 p_v = basis_->fromPolar(position[0], position[1]);
    VEC2 K1 = p_v*h;
    VEC2 pos1 = position + K1*0.5;
    p_v = velocity_.GetVelocity(pos1[0]*xRes_, pos1[1]*yRes_);
    //p_v = basis_->fromPolar(pos1[0], pos1[1]);

    VEC2 K2 = p_v*h;
    VEC2 pos2 = position + K2*0.5;
    p_v = velocity_.GetVelocity(pos2[0]*xRes_, pos2[1]*yRes_);
    //p_v = basis_->fromPolar(pos2[0], pos2[1]);

    VEC2 K3 = p_v*h;
    VEC2 pos3 = position + K3;
    p_v = velocity_.GetVelocity(pos3[0]*xRes_, pos3[1]*yRes_);
    //p_v = basis_->fromPolar(pos3[0], pos3[1]);
    VEC2 K4 = p_v*h;

    // Forward Eular.
    particles_[i].position += (K1 + 2.0*K2 + 2.0*K3 + K4)/6.0;
    particles_[i].velocity = p_v;
  }

  projBackParticles();
}

#define RESEED_POLAR(arg)\
arg.position[0] = (r*cos(t)*0.5 + 0.5);\
arg.position[1] = (r*sin(t)*0.5 + 0.5);\

#define RESEED_ELLIPTIC(arg)\
arg.position[0] = 0.5*a_*sqrt(1.0 + c_*c_*r*r)*cos(t) + 0.5;\
arg.position[1] = 0.5*b_*r*sin(t) + 0.5;\

void PolarFluid2D::ReSeedParticles() {
  // Reseed the particles at random position.
  for (int i = 0; i < num_particles_; i++) {
    double px = (double)(std::rand())/RAND_MAX;
    double py = (double)(std::rand())/RAND_MAX;

    double r = sqrtf(px);
    double t = 2.0*M_PI*py;

  if (is_elliptic_) {
    // [0, 1]
    // [0.5, 0.5] +- b/2
    RESEED_ELLIPTIC(particles_[i]);
  } else {
    // [0-1]
    RESEED_POLAR(particles_[i]);
  }
    particles_[i].velocity = 0.;
  }
}

void PolarFluid2D::projBackParticles() {
  for (int i = 0; i < num_particles_; i++) {
    double xx = particles_[i].position[0]*2.0 - 1.0;
    double yy = particles_[i].position[1]*2.0 - 1.0;
    double curR = 0;
    
   if (is_elliptic_)
      curR = basis_->getR().GetValue(particles_[i].position[0]*xRes_, particles_[i].position[1]*yRes_);
    else
      curR = xx*xx + yy*yy;

    if (curR >= 0.97) {
      double px = (double)(std::rand())/RAND_MAX;
      double py = (double)(std::rand())/RAND_MAX;
      double r = sqrtf(px);
      double t = 2.0*M_PI*py;

      if (is_elliptic_) {
        RESEED_ELLIPTIC(particles_[i]);
      }
      else{
        RESEED_POLAR(particles_[i]);
      }

      particles_[i].velocity = 0.;
    }
  }
}

void PolarFluid2D::reWeightTensor() {
  for (int i = 0; i < Adv_tensor_.size(); i++) {
    Adv_tensor_[i] *= tensorWeight_;
  }
}

#undef RESEED_POLAR
#undef RESEED_ELLIPTIC