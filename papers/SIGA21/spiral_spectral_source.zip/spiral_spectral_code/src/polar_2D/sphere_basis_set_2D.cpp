#include <algorithm>
#include <cmath>
#include <Eigen/Eigen>
#include <float.h>
#include <fstream>
#include <fftw3.h>
#include <glog/logging.h>
#include <iomanip>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "3D/trig_integral_3d.h"
#include "3D/particle_3d.h"
#include "common/particle_sph_3d.h"
#include "common/basis_set.h"
#include "elliptic/prolate_oblate_2D.h"
#include "polar_2D/sphere_basis_set_2D.h"
#include "polar_2D/sphere_basis_2D_all.h"
#include "setting.h"
#include "util/gl4_drawer.h"
#include "util/transform.h"
#include "util/util.h"
#include "util/read_write_tensor.h"

void SphereBasisSet2D::allocateBasisMGS() {
  // diagonal blocks of the coefficient matrix.
  std::vector<Eigen::MatrixXd> Coefs;
  const double thresh = 0.2;

  // Phi^0, Psi^0
  for (int j = 1; j < phiK_; j++) {
    std::vector<spherePtrAll> tempBuffer;
    // Psi^0
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        if (! is_prolate_ && ! is_oblate_)
          tempBuffer.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2, 3)));
        else if (! is_oblate_)
          tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2, 3, *tabData_)));
        else {
          tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2, 3, *tabData_, false)));
        }
      }
    }
    for (int i = 1; i <= thetaK_; i++) { 
      // init, 2*wavenumber.
      if (! is_prolate_ && ! is_oblate_)
        tempBuffer.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2*j, 0)));
      else if (! is_oblate_)
        tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2*j, 0, *tabData_)));
      else
        tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2*j, 0, *tabData_, false)));
    }
    // Run MGS, reject basis, and collect coefficients.
    Eigen::MatrixXd Coef;
    int m = 1;
    std::vector<spherePtrAll> allocated;
    runMGS(thresh, tempBuffer, allocated, Coef, m);
    all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());
    Coefs.push_back(Coef.topLeftCorner(m,m));
  }

  // Phi^1, Psi^1
  for (int j = 1; j < phiK_; j++) {
    std::vector<spherePtrAll> tempBuffer;    
    // Psi^1
    if (j == 1) {
      for (int i = 0; i < thetaK_; i++) {
        if (! is_prolate_ && ! is_oblate_)
          tempBuffer.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2, 4)));
        else if (! is_oblate_)
          tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2, 4, *tabData_)));
        else
          tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2, 4, *tabData_, false)));
      }
    }

    for (int i = 1; i <= thetaK_; i++) {
      // Phi^1
      if (! is_prolate_ && ! is_oblate_)
        tempBuffer.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 2*j, 1)));
      else if (! is_oblate_)
        tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2*j, 1, *tabData_)));
      else
        tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 2*j, 1, *tabData_, false)));
    }
    // Run MGS, reject basis, and collect coefficients.
    Eigen::MatrixXd Coef;
    int m = 1;
    std::vector<spherePtrAll> allocated;
    runMGS(thresh, tempBuffer, allocated, Coef, m);
    all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());
    Coefs.push_back(Coef.topLeftCorner(m,m));
  }

  // Phi^2 last one.
  std::vector<spherePtrAll> tempBuffer;

  for (int i = 1; i <= thetaK_; i++) {
    if (! is_prolate_ && ! is_oblate_)
      tempBuffer.push_back(spherePtrAll(new SphereBasis2DAll(2*i, 0, 2)));
    else if (! is_oblate_)
      tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 0, 2, *tabData_)));
    else
      tempBuffer.push_back(spherePtrAll(new ProlateOblate2D(2*i, 0, 2, *tabData_, false)));
  }

  // Run MGS, reject basis, and collect coefficients.
  Eigen::MatrixXd Coef;
  int m = 1;
  std::vector<spherePtrAll> allocated;
  runMGS(thresh, tempBuffer, allocated, Coef, m);
  all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());
  Coefs.push_back(Coef.topLeftCorner(m,m));

  // Assemble global coefficient matrix.
  A_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
  int colIdx = 0;
  // Square matrices.
  for (int i = 0; i < Coefs.size(); i++) {
    int curSize = Coefs[i].rows();
    A_.block(colIdx, colIdx, curSize, curSize) = Coefs[i];
    colIdx += curSize;
  }

  numBasisOrtho_ = all_basis_.size();
  numBasisAll_ = all_basis_.size();
  LOG(INFO) << "number allocated: " << numBasisAll_;
}

void SphereBasisSet2D::allocateNumerical(){
  // precompute basis numerically.
  for (int i = 0; i < all_basis_.size(); i++) {
    cached_basis_.push_back(VFIELD2D(nPhi_, nTheta_));
  }
  #pragma omp parallel for
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->DiscretizeAdd(1.0, &cached_basis_[i]);
  }
}

void SphereBasisSet2D::allocateTemp() {
  totalSize_ = nTheta_*nPhi_;

  vtTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(vtTemp_, 0x00, sizeof(double)*totalSize_);
  vpTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(vpTemp_, 0x00, sizeof(double)*totalSize_);

  inTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(inTemp_, 0x00, sizeof(double)*totalSize_);

  tTemp0_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(tTemp0_, 0x00, sizeof(double)*totalSize_);
  tTemp1_ = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(tTemp1_, 0x00, sizeof(double)*totalSize_);
  pTemp0_= (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(pTemp0_, 0x00, sizeof(double)*totalSize_);
  pTemp1_= (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(pTemp1_, 0x00, sizeof(double)*totalSize_);
  
  t1DTemp0_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  std::memset(t1DTemp0_, 0x00, sizeof(double)*nTheta_);
  t1DTemp1_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  std::memset(t1DTemp1_, 0x00, sizeof(double)*nTheta_);
  
  invTotalSize_ = 1.0 / totalSize_;
  dTheta_ = M_PI / nTheta_;
  dPhi_ = 2.0*M_PI / nPhi_;

  cosTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  std::memset(cosTVal_, 0x00, sizeof(double)*nTheta_);
  sinTVal_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
  std::memset(sinTVal_, 0x00, sizeof(double)*nTheta_);
  for (int j = 0; j < nTheta_; j++) {
    double theta = ((double)(j) + 0.5)*dTheta_;
    cosTVal_[j] = cos(theta);
    sinTVal_[j] = sin(theta);
  }
  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    waveNum2_[i] = k1*k1 + k2*k2;
  }
  initPairCoef();

  if (is_prolate_ || is_oblate_) {
    h_ = (double*) fftw_malloc(sizeof(double)*nTheta_);
    std::memset(h_, 0x00, sizeof(double)*nTheta_);
    // fill scale factor
    for (int i = 0; i < nTheta_; i++) {
      double theta = ((double)i + 0.5)*dTheta_;
      if (is_prolate_)
        h_[i] = sqrt(c_*c_ + sin(theta)*sin(theta));
      else
        h_[i] = sqrt(c_*c_ + cos(theta)*cos(theta));
    }
  }
}

void SphereBasisSet2D::computeVelocityPole(const Eigen::VectorXd& fieldCoef, VEC2& north, VEC2& south) {
  north = VEC2(0,0);
  south = VEC2(0,0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    int k1 = all_basis_[i]->WN1x2()/2;
    double invN = all_basis_[i]->GetInvNorm();
    if (index == 2) {
      north[0] += fieldCoef[i]*invN;
      south[0] += fieldCoef[i]*invN;
      if (k1 % 2 == 0)
        south[0] = -south[0];
    } else if (index == 3) {
      north[1] += fieldCoef[i]*invN;
      south[1] += fieldCoef[i]*invN;
      if (k1 % 2 == 0)
        south[1] = - south[1];
    }
  }
}

void SphereBasisSet2D::initPairCoef() {
  phiCoef_.resize(5);
  for (int i = 0; i < all_basis_.size(); i++) {
    // Get wavenumber.
    int k1x2 = all_basis_[i]->WN1x2();
    int k2x2 = all_basis_[i]->WN2x2();
    int idx = all_basis_[i]->index();
    int k1 = k1x2/2;
    int k2 = k2x2/2;
    phiCoef_[idx].push_back(pairedCoef2d2(k1, k2, 0));
    // init inverselookup
    uint64_t hash = Basis2D::toHash(k1x2, k2x2, idx);
    basisLookup_[hash] = i;
  }

}

void SphereBasisSet2D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
  int bidx[5] = {0,0,0,0,0};
  for (int i = 0; i < all_basis_.size(); i++) {
    int idx = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[idx][bidx[idx]].coef_ = fieldCoef[i]*C_x;
    bidx[idx]++;
  }
}

void SphereBasisSet2D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
  int bidx[5] = {0,0,0,0,0};
  for (int i = 0; i < all_basis_.size(); i++) {
    double C_x = all_basis_[i]->GetInvNorm();
    int idx = all_basis_[i]->index();
    fieldCoef[i] += phiCoef_[idx][bidx[idx]].coef_*C_x*dPhi_*dTheta_*0.25;
    bidx[idx]++;
  }
}

void SphereBasisSet2D::clearPairCoef() {
  for (int j = 0; j < 5; j++) {
    for (auto& pc : phiCoef_[j])
      pc.coef_ = 0.0;
  }
}

//* Memory layout,  *//
// Row major order, where phi is along the row direction.
// --------------------------> phi
// |1    2   3   4   5   6, .....,
// |nphi nphi+1, nphi+2, .....
// |2*nphi, 2*npi+1, ....
// theta
void SphereBasisSet2D::setUpFFTWPlan() {

  int howmanyTheta = 2*phiK_;
  int nt_[1] = {nTheta_};
  int *inembedt_ = nt_;
  int *onembedt_ = nt_;
  int np_[1] = {nPhi_};
  int* inembedp_ = np_;
  int* onembedp_ = np_;
  fftw_r2r_kind invS_ = FFTW_RODFT01;
  fftw_r2r_kind invC_ = FFTW_REDFT01;
  fftw_r2r_kind fwdS_ = FFTW_RODFT10;
  fftw_r2r_kind fwdC_ = FFTW_REDFT10;
  // inverse plans
  IsinTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &invS_, FFTW_MEASURE);
  IcosTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &invC_, FFTW_MEASURE);
  IsinThetaE_ = fftw_plan_many_r2r(1, nt_, 4, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &invS_, FFTW_MEASURE);
  IcosThetaE_ = fftw_plan_many_r2r(1, nt_, 4, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &invC_, FFTW_MEASURE);
  IcosPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, inembedp_, 1, nPhi_, tTemp0_, onembedp_, 1, nPhi_, &invC_, FFTW_MEASURE);
  IsinPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, inembedp_, 1, nPhi_, tTemp0_, onembedp_, 1, nPhi_, &invS_, FFTW_MEASURE);

  IsinT1D_ = fftw_plan_r2r_1d(nTheta_, t1DTemp0_, t1DTemp1_, invS_, FFTW_MEASURE);
  FsinT1D_ = fftw_plan_r2r_1d(nTheta_, t1DTemp0_, t1DTemp1_, fwdS_, FFTW_MEASURE);

  //forward plans
  FsinTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &fwdS_, FFTW_MEASURE);
  FcosTheta_ = fftw_plan_many_r2r(1, nt_, howmanyTheta, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &fwdC_, FFTW_MEASURE);
  FsinThetaE_ = fftw_plan_many_r2r(1, nt_, 4, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &fwdS_, FFTW_MEASURE);
  FcosThetaE_ = fftw_plan_many_r2r(1, nt_, 4, inTemp_, inembedt_, nPhi_, 1, tTemp0_, onembedt_, nPhi_, 1, &fwdC_, FFTW_MEASURE);
  FcosPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, inembedp_, 1, nPhi_, tTemp0_, onembedp_, 1, nPhi_, &fwdC_, FFTW_MEASURE);
  FsinPhi_ = fftw_plan_many_r2r(1, np_, nTheta_, inTemp_, inembedp_, 1, nPhi_, tTemp0_, onembedp_, 1, nPhi_, &fwdS_, FFTW_MEASURE);

  // INIT FFTW PLAN.
  LOG(INFO) << "init fftw plan";
  InvTransPhi0();
  InvTransPhi1();
  InvTransPsi0();
  InvTransPsi1();
}

//#define TEST

// 1) Do int wavenumber first, with two different kinds.
// 2) USE [0, 2Pi] in theta range to avoid additional dcts.
void SphereBasisSet2D::InverseTramsformToVelocity(
   Eigen::VectorXd& fieldCoef, VFIELD2D* field) {

  CHECK(fieldCoef.size() == numBasisAll_);

  Eigen::Map<Eigen::VectorXd> vtV(vtTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vpV(vpTemp_, totalSize_);

  collectPairedCoef(fieldCoef);

  clearPointer(vtTemp_);
  clearPointer(vpTemp_);
  InvTransPhi0();
  InvTransPhi1();
  InvTransPhi2();
  InvTransPsi0();
  InvTransPsi1();

  // handle the elliptic weight
  if (is_prolate_) {
    for (int i = 0; i < totalSize_; i++)
      vtTemp_[i] *= 1.0/b_;
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++)
        vpTemp_[i + j*nPhi_] *= 1.0/h_[j]/a_;
  } else if (is_oblate_) {
    for (int i = 0; i < totalSize_; i++)
      vtTemp_[i] *= 1.0/a_/sqrt(1.0 + c_*c_);
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++)
        vpTemp_[i + j*nPhi_] *= 1.0/h_[j]/a_;
  }

#ifdef TEST
  double *rtest, *ttest;
  rtest = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(rtest, 0x00, sizeof(double)*totalSize_);
  ttest = (double*) fftw_malloc(sizeof(double)*totalSize_);
  std::memset(ttest, 0x00, sizeof(double)*totalSize_);
  computeUniformRTNumerical(fieldCoef, nTheta_, nPhi_, rtest, ttest);
  Eigen::Map<Eigen::VectorXd> rtestV(rtest, totalSize_);
  Eigen::Map<Eigen::VectorXd> ttestV(ttest, totalSize_);
  LOG(INFO) << (rtestV).norm() << " " << (vtV).norm() << " tdiff " << (rtestV - vtV).norm();
  LOG(INFO) << (ttestV).norm() << " " << (vpV).norm() << " pdiff " << (ttestV - vpV).norm();
  exit(0);
#endif

  for (int j = 0; j < nTheta_; j++) {
    for (int i = 0; i < nPhi_; i++) {
      (*field)(i,j)[0] = vtTemp_[i + j*nPhi_];
      (*field)(i,j)[1] = vpTemp_[i + j*nPhi_];
    }
  }

  return;
}

void SphereBasisSet2D::weightCosSin(double* field, double* mult) {
  // TODO: apply truncation here.
  for (int j = 0; j < nTheta_; j++) {
    for (int i = 0; i < nPhi_; i++) {
      field[i + j*nPhi_] *= mult[j];
    }
  }
}
// Transformation of cos(t)*sin(i1 t) + i1*sin(t)*cos(i1 t)
// This might look unintuitive but refer to Trick 2 of basisAnalysis_sphere.
void SphereBasisSet2D::transformFirstPartPhi(const std::vector<pairedCoef2d2>& coef, bool kind) {
  int sgn = kind ? -1 : 1;
  int offset = kind ? -1 : 0;
  // phi component
  // first theta part
  clearPointer(inTemp_);
  for (const auto& pc : coef) {
    double divd = (double)(pc.i2_);
    double mult = (double)(pc.i1_);
    if (pc.i2_ == 0) {
      inTemp_[pc.i2_*2 + offset + (pc.i1_ - 1)*nPhi_] += sgn*pc.coef_;
      continue;
    }
    // invS_, invS_
    inTemp_[pc.i2_*2 + offset + (pc.i1_)*nPhi_] += sgn*pc.coef_/divd*0.5;
    if (pc.i1_ > 1)
      inTemp_[pc.i2_*2 + offset + (pc.i1_ - 2)*nPhi_] += sgn*pc.coef_/divd*0.5;

    inTemp_[pc.i2_*2 + offset + (pc.i1_)*nPhi_] += sgn*pc.coef_*mult/divd*0.5;
    if (pc.i1_ > 1)
      inTemp_[pc.i2_*2 + offset + (pc.i1_ - 2)*nPhi_] -= sgn*pc.coef_*mult/divd*0.5;  
  }
  clearPointer(tTemp1_);
  fftw_execute_r2r(IsinTheta_, inTemp_, tTemp1_);
}

/// !!! The first wavenumber should be multipled by 2 because the phi angle is in [0, 2*PI] !!!
/// Wasted an hour debugging this...

void SphereBasisSet2D::InvTransPhi0() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  clearPointer(pTemp0_);

  for (const auto& pc : phiCoef_[0]) {
    // t, i1: invS_, p, i2: invC
    inTemp_[pc.i2_*2 + (pc.i1_ - 1)*nPhi_] = pc.coef_;
  }
  // theta component
  fftw_execute_r2r(IsinTheta_, inTemp_, tTemp0_);
  fftw_execute_r2r(IcosPhi_, tTemp0_, pTemp0_);

  Eigen::Map<Eigen::VectorXd> pTemp0V(pTemp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  vtTempV += pTemp0V;
  transformFirstPartPhi(phiCoef_[0], true);

  clearPointer(pTemp0_);
  fftw_execute_r2r(IsinPhi_, tTemp1_, pTemp0_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  vpTempV += pTemp0V;
}

void SphereBasisSet2D::InvTransPhi1() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  clearPointer(pTemp0_);
  for (const auto& pc : phiCoef_[1]) {
    // t, i1: invS_, p, i2: invS_
    inTemp_[pc.i2_*2 - 1 + (pc.i1_ - 1)*nPhi_] = pc.coef_;
  }
  // theta component
  fftw_execute_r2r(IsinTheta_, inTemp_, tTemp0_);
  fftw_execute_r2r(IsinPhi_, tTemp0_, pTemp0_);

  Eigen::Map<Eigen::VectorXd> pTemp0V(pTemp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  vtTempV += pTemp0V;
  transformFirstPartPhi(phiCoef_[1], false);

  clearPointer(pTemp0_);
  fftw_execute_r2r(IcosPhi_, tTemp1_, pTemp0_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  vpTempV += pTemp0V;
}

void SphereBasisSet2D::InvTransPhi2() {
  clearPointerSize(t1DTemp0_, nTheta_);
  clearPointerSize(t1DTemp1_, nTheta_);
  for (const auto& pc : phiCoef_[2]) {
    // DST
    t1DTemp0_[pc.i1_ - 1] = pc.coef_;
  }
  fftw_execute_r2r(IsinT1D_, t1DTemp0_, t1DTemp0_);

  clearPointer(pTemp0_);
  Eigen::Map<Eigen::VectorXd> pTemp0V(pTemp0_, totalSize_);
  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < nPhi_; i++) {
      pTemp0_[i + j*nPhi_] = t1DTemp0_[j];
    }
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  vpTempV += pTemp0V;
}

void SphereBasisSet2D::transformFirstPartPsi(const std::vector<pairedCoef2d2>& coef, bool kind) {
  int sgn = kind ? 1 : -1;
  int offset = kind ? -1 : 0;

  // phi component
  clearPointer(inTemp_);
  for (const auto& pc : coef) {
    // This part is tricky because the first wavenumber can go to zero.
    if (pc.i1_ == 0)
      inTemp_[pc.i2_*2 + offset + nPhi_] += -sgn*pc.coef_*0.5;
    else {
      inTemp_[pc.i2_*2 + offset + (pc.i1_+1)*nPhi_] += -sgn*pc.coef_*0.5;
      if (pc.i1_ == 1)
        inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_] += -sgn*pc.coef_;
      else
        inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_] += -sgn*pc.coef_*0.5;
    }

    if (pc.i1_ == 0)
      ; // zero
    else {
      inTemp_[pc.i2_*2 + offset + (pc.i1_+1)*nPhi_] -= sgn*pc.coef_*(double)(pc.i1_)*0.5;
      if (pc.i1_ == 1)
        inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_] += sgn*pc.coef_*(double)(pc.i1_);
      else
        inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_] += sgn*pc.coef_*(double)(pc.i1_)*0.5;
    }
  }
  clearPointer(tTemp1_);
  fftw_execute_r2r(IcosThetaE_, inTemp_, tTemp1_);
}

void SphereBasisSet2D::InvTransPsi0() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  clearPointer(pTemp0_);
  for (const auto& pc : phiCoef_[3]) {
    // t, i1: invC_, p, i2: invC_
    inTemp_[pc.i2_*2 + pc.i1_*nPhi_] = pc.coef_;
  }
  // theta component
  fftw_execute_r2r(IcosThetaE_, inTemp_, tTemp0_);
  fftw_execute_r2r(IcosPhi_, tTemp0_, pTemp0_);
  Eigen::Map<Eigen::VectorXd> pTemp0V(pTemp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  vtTempV += pTemp0V;

  transformFirstPartPsi(phiCoef_[3], true);

  clearPointer(pTemp0_);
  fftw_execute_r2r(IsinPhi_, tTemp1_, pTemp0_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  vpTempV += pTemp0V;
}

void SphereBasisSet2D::InvTransPsi1() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  clearPointer(pTemp0_);
  for (const auto& pc : phiCoef_[4]) {
    // t, i1: invC_, p, i2: invS_
    inTemp_[pc.i2_*2 - 1 + pc.i1_*nPhi_] = pc.coef_;
  }
  // theta component
  fftw_execute_r2r(IcosThetaE_, inTemp_, tTemp0_);
  fftw_execute_r2r(IsinPhi_, tTemp0_, pTemp0_);
  Eigen::Map<Eigen::VectorXd> pTemp0V(pTemp0_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  vtTempV += pTemp0V; 

  transformFirstPartPsi(phiCoef_[4], false);

  clearPointer(pTemp0_);
  fftw_execute_r2r(IcosPhi_, tTemp1_, pTemp0_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  vpTempV += pTemp0V;
}

void SphereBasisSet2D::forwardFirstPartPhi(bool kind, std::vector<pairedCoef2d2>& coef) {
  int sgn = kind ? -1 : 1;
  int offset = kind ? -1 : 0;
  clearPointer(inTemp_);
  fftw_execute_r2r(FsinTheta_, pTemp0_, inTemp_);
  for (auto& pc : coef) {
    double divd = (double)(pc.i2_);
    double mult = (double)(pc.i1_);
    if (pc.i2_ == 0) {
      pc.coef_ += sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_ - 1)*nPhi_];
      continue;
    }
    // invS_, invS_
    pc.coef_+= sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_)*nPhi_]/divd*0.5;
    if (pc.i1_ > 1)
      pc.coef_+= sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_ - 2)*nPhi_]/divd*0.5;

    pc.coef_ += sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_)*nPhi_]*mult/divd*0.5;
    if (pc.i1_ > 1)
      pc.coef_ -= sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_ - 2)*nPhi_]*mult/divd*0.5; 
  }
}

void SphereBasisSet2D::FwdTransPhi0() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  // theta component
  fftw_execute_r2r(FcosPhi_, vtTemp_, tTemp0_);
  fftw_execute_r2r(FsinTheta_, tTemp0_, inTemp_);

  for (auto& pc : phiCoef_[0]) {
    // t, i1: invC_, p, i2: invC_
    pc.coef_ += inTemp_[pc.i2_*2 + (pc.i1_ - 1)*nPhi_];
  }

  clearPointer(pTemp0_);
  fftw_execute_r2r(FsinPhi_, vpTemp_, pTemp0_);

  // tran along theta
  forwardFirstPartPhi(true,  phiCoef_[0]);
}

void SphereBasisSet2D::FwdTransPhi1() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  // theta component
  fftw_execute_r2r(FsinPhi_, vtTemp_, tTemp0_);
  fftw_execute_r2r(FsinTheta_, tTemp0_, inTemp_);
  for (auto& pc : phiCoef_[1]) {
    // t, i1: invC_, p, i2: invC_
    pc.coef_ += inTemp_[pc.i2_*2 - 1 + (pc.i1_ - 1)*nPhi_];
  }
  clearPointer(pTemp0_);
  fftw_execute_r2r(FcosPhi_, vpTemp_, pTemp0_);

  // tran along theta
  forwardFirstPartPhi(false,  phiCoef_[1]);
}

void SphereBasisSet2D::forwardFirstPartPsi(bool kind, std::vector<pairedCoef2d2>& coef) {
  int sgn = kind ? 1 : -1;
  int offset = kind ? -1 : 0;
  clearPointer(inTemp_);
  fftw_execute_r2r(FcosThetaE_, pTemp0_, inTemp_);
  for (auto& pc : coef) {
    if (pc.i1_ == 0)
      pc.coef_ += -sgn*inTemp_[pc.i2_*2 + offset + nPhi_];
    else {
      pc.coef_ += -sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_+1)*nPhi_]*0.5 ;
      if (pc.i1_ == 1)
        pc.coef_ += -sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_];
      else
        pc.coef_ += -sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_]*0.5;
    }
    if (pc.i1_ == 0)
      ; // zero
    else {
      pc.coef_ -= sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_+1)*nPhi_]*(double)(pc.i1_)*0.5;
      if (pc.i1_ == 1)
        pc.coef_ += sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_]*(double)(pc.i1_);
      else
        pc.coef_ += sgn*inTemp_[pc.i2_*2 + offset + (pc.i1_-1)*nPhi_]*(double)(pc.i1_)*0.5;
    }
  }
}

void SphereBasisSet2D::FwdTransPhi2() {
  clearPointerSize(t1DTemp0_, nTheta_);
  for (int j = 0; j < nTheta_; j++) {
    double sum = 0.0;
    for (int i = 0; i < nPhi_; i++) {
      sum += vpTemp_[i + j*nPhi_];
    }
    t1DTemp0_[j] = sum;
  }
  fftw_execute_r2r(FsinT1D_, t1DTemp0_, t1DTemp0_);
  for (auto& pc : phiCoef_[2]) {
    // t, i1: invC_, p, i2: invC_
    // offset the 2 factor in DST
    pc.coef_ += 2.0*t1DTemp0_[pc.i1_ - 1];
  }
}

void SphereBasisSet2D::FwdTransPsi0() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  // theta component
  fftw_execute_r2r(FcosPhi_, vtTemp_, tTemp0_);
  fftw_execute_r2r(FcosTheta_, tTemp0_, inTemp_);
  for (auto& pc : phiCoef_[3]) {
    // t, i1: invC_, p, i2: invC_
    pc.coef_ += inTemp_[pc.i2_*2 + (pc.i1_ )*nPhi_];
  }
  clearPointer(pTemp0_);
  fftw_execute_r2r(FsinPhi_, vpTemp_, pTemp0_);
  forwardFirstPartPsi(true, phiCoef_[3]);
}

void SphereBasisSet2D::FwdTransPsi1() {
  clearPointer(inTemp_);
  clearPointer(tTemp0_);
  // theta component
  fftw_execute_r2r(FsinPhi_, vtTemp_, tTemp0_);
  fftw_execute_r2r(FcosTheta_, tTemp0_, inTemp_);
  for (auto& pc : phiCoef_[4]) {
    // t, i1: invC_, p, i2: invC_
    pc.coef_ += inTemp_[pc.i2_*2 - 1 + (pc.i1_ )*nPhi_];
  }
  clearPointer(pTemp0_);
  fftw_execute_r2r(FcosPhi_, vpTemp_, pTemp0_);
  forwardFirstPartPsi(false, phiCoef_[4]);
}

void SphereBasisSet2D::weightJacobian() {
  if (! is_prolate_ && ! is_oblate_) {
    for (int j = 0; j < nTheta_; j++) {
      for (int i = 0; i < nPhi_; i++) {
        vtTemp_[i + j*nPhi_] *= sinTVal_[j];
        vpTemp_[i + j*nPhi_] *= sinTVal_[j];
      }
    }
  } else if (is_prolate_) {
    for (int j = 0; j < nTheta_; j++) {
      for (int i = 0; i < nPhi_; i++) {
        vtTemp_[i + j*nPhi_] *= a_*h_[j]*sinTVal_[j];
        vpTemp_[i + j*nPhi_] *= b_*sinTVal_[j];
      }
    }
  } else {
    for (int j = 0; j < nTheta_; j++) {
      for (int i = 0; i < nPhi_; i++) {
        vtTemp_[i + j*nPhi_] *= a_*h_[j]*sinTVal_[j];
        vpTemp_[i + j*nPhi_] *= a_*sqrt(1.0 + c_*c_)*sinTVal_[j];
      }
    }
  }
}

// Input a std::vector field, transform and output the basis coefficients.
void SphereBasisSet2D::ForwardTransformtoFrequency(
  const VFIELD2D& field, Eigen::VectorXd* coefficients) {
  
  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());

  clearPairCoef();
  clearPointer(vtTemp_);
  clearPointer(vpTemp_);
  // put field into trans.
  for (int j = 0; j < nTheta_; j++) {
    for (int i = 0; i < nPhi_; i++) {
      vtTemp_[i + j*nPhi_] = (field)(i,j)[0];
      vpTemp_[i + j*nPhi_] = (field)(i,j)[1];
    }
  }

  // test
#ifdef TEST
  srand((unsigned int) (time(0)));
  Eigen::VectorXd basisCoef1 = Eigen::VectorXd::Random(all_basis_.size());
  computeUniformRTNumerical(basisCoef1, nTheta_, nPhi_, vtTemp_, vpTemp_);
  double* vt1;
  double* vp1;
  vt1 = (double*) malloc(sizeof(double)*totalSize_);
  memcpy(vt1, vtTemp_, sizeof(double)*totalSize_);
  vp1 = (double*) malloc(sizeof(double)*totalSize_);
  memcpy(vp1, vpTemp_, sizeof(double)*totalSize_);
#endif

  weightJacobian();
  FwdTransPhi0();
  FwdTransPhi1();
  FwdTransPhi2();
  FwdTransPsi0();
  FwdTransPsi1();

  assignPairCoef(fieldCoef);
  *coefficients = A_*fieldCoef;

#ifdef TEST
  Eigen::VectorXd projectCoef = Eigen::VectorXd::Zero(all_basis_.size());
  if (is_prolate_) {
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        vt1[i + j*nPhi_] *= a_*b_*h_[j]*sinTVal_[j];
        vp1[i + j*nPhi_] *= a_*b_*h_[j]*sinTVal_[j];
      }
  } else if (is_oblate_) {
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        vt1[i + j*nPhi_] *= a_*a_*sqrt(1.0 + c_*c_)*h_[j]*sinTVal_[j];
        vp1[i + j*nPhi_] *= a_*a_*sqrt(1.0 + c_*c_)*h_[j]*sinTVal_[j];
      }
  } else {
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nPhi_; i++) {
        vt1[i + j*nPhi_] *= sinTVal_[j];
        vp1[i + j*nPhi_] *= sinTVal_[j];
      }
  }
  projectUniformRTNumerical(nTheta_, nPhi_, vt1, vp1, projectCoef);
  LOG(INFO) << (projectCoef - fieldCoef).norm() << " " << projectCoef.norm() << " " << fieldCoef.norm();
  exit(0);
 #endif
}

void SphereBasisSet2D::debugInfo(const PolarBasis2D& basis_i, const PolarBasis2D& basis_g,
                        const PolarBasis2D& basis_h) {
  bool iKind = basis_i.kind();
  bool gKind = basis_g.kind();
  bool hKind = basis_h.kind();
  
  // second wavenumber,i,g,h
  int i2x2 = basis_i.WN2x2();
  int g2x2 = basis_g.WN2x2();
  int h2x2 = basis_h.WN2x2();

  //first wavenumber,i,g,h
  int i1x2 = basis_i.WN1x2();
  int g1x2 = basis_g.WN1x2();
  int h1x2 = basis_h.WN1x2();

  LOG(INFO) << "i " << iKind << " " << i1x2 << " " << i2x2 << " g " << gKind << " " << g1x2 << " "
    << g2x2 << " h " << hKind << " " << h1x2 << " " << h2x2;
}

int SphereBasisSet2D::getIndex(const PolarBasis2D& basis_i, const PolarBasis2D& basis_g,
                               const PolarBasis2D& basis_h) {
  int id1 = basis_i.index();
  if (id1 == 1 && basis_i.WN2x2() == 0)
    id1 = 4;
  int id2 = basis_g.index();
  if (id2 == 1 && basis_g.WN2x2() == 0)
    id2 = 4;
  int id3 = basis_h.index();
  if (id3 == 1 && basis_h.WN2x2() == 0)
    id3 = 4;
  return id1*25 + id2*5 + id3;
}

double SphereBasisSet2D::tensorEntryCast(const spherePtrAll basis_i, const spherePtrAll basis_g, const spherePtrAll basis_h) {
  if (! is_prolate_ && ! is_oblate_)
    return SphereBasis2DAll::computeTensorEntry(*basis_i, *basis_g, *basis_h);
  else
    return std::static_pointer_cast<ProlateOblate2D>(basis_i)->
           computeTensorEntry(*std::static_pointer_cast<ProlateOblate2D>(basis_g), 
                              *std::static_pointer_cast<ProlateOblate2D>(basis_h), *tensorData_);
}

#ifdef FAST_TENSOR
#include "tensorCompute/sphere2DTensor.h"
#endif

void SphereBasisSet2D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {

#ifdef FAST_TENSOR
  sphere2DTensor tensorEval;
#endif

  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  const double pow_w = - 0.00;
  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;

#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {

        double Cigh = 0;

#ifdef FAST_TENSOR
        const SphereBasis2DAll& basis_i = *all_basis_[i];
        const SphereBasis2DAll& basis_g = *all_basis_[g];
        const SphereBasis2DAll& basis_h = *all_basis_[h];
        const int idx = basis_i.index()*25 + basis_g.index()*5 + basis_h.index();
        double invWn = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
        Cigh = tensorEval.pointers_[idx](basis_i, basis_g, basis_h)*invWn;
#else        
        Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);
#endif

        CHECK(std::isfinite(Cigh));
        if (Cigh == 0) {
          continue;
        }
        
        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  //BasisSet::VerifyAntisymmetric(*Adv_tensor);
  //exit(0);
}

void SphereBasisSet2D::outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor) {
   CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  std::vector<Eigen::Vector3i> indices;
  
  for (int i = 0; i < numBasisAll_; i++) {
    LOG(INFO) << i;
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const SphereBasis2DAll& basis_i = *all_basis_[i];
        const SphereBasis2DAll& basis_g = *all_basis_[g];
        const SphereBasis2DAll& basis_h = *all_basis_[h];

        double Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);

        if (abs(Cigh) <1e-12) {
          continue;
        }
        
        // IncrementMatrixEntry(&(*Adv_tensor)[k],i, j, Cijk*InvNormijk);
        tripletList.push_back(T(g,h, Cigh));
        indices.push_back(Eigen::Vector3i(i,g,h));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  BasisSet::VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  std::ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    spherePtrAll basis_i = all_basis_[indices[i][0]];
    spherePtrAll basis_g = all_basis_[indices[i][1]];
    spherePtrAll basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " <<
           std::setprecision(12) << basis_i->GetInvNorm() << " " << basis_g->GetInvNorm()
           << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}

void SphereBasisSet2D::readFromFile(std::ifstream& in) {

  in.read(reinterpret_cast<char*>(&numBasisAll_), sizeof(int));
  in.read(reinterpret_cast<char *>(&thetaK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&phiK_), sizeof(int));
  in.read(reinterpret_cast<char*>(&numBasisOrtho_), sizeof(int));
  in.read(reinterpret_cast<char *>(&is_prolate_), sizeof(bool));
  in.read(reinterpret_cast<char *>(&is_oblate_), sizeof(bool));
  in.read(reinterpret_cast<char *>(&a_), sizeof(double));
  in.read(reinterpret_cast<char *>(&b_), sizeof(double));
  in.read(reinterpret_cast<char *>(&c_), sizeof(double));
  CHECK(!(is_oblate_ && is_prolate_));
  // to do...
  LOG(INFO) << numBasisAll_;
  if (! is_prolate_ && ! is_oblate_) {
    for (int i = 0; i < numBasisAll_; i++) {
      all_basis_.push_back(spherePtrAll(SphereBasis2DAll::fromFile(in)));
    }
  } else {
    setUpTable();
    for (int i = 0; i < numBasisAll_; i++) {
      all_basis_.push_back(spherePtrAll(ProlateOblate2D::fromFile(in, *tabData_, is_prolate_)));
    }
  }

  readEigenDense_binary(in, A_);
}

// int N, int radiusK, int angK, bool bndCnd
void SphereBasisSet2D::writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const {
  // grid sizes
  out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&thetaK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&phiK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&is_prolate_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&is_oblate_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&a_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&b_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&c_), sizeof(double));

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }
  writeEigenDense_binary(out, A_);
  WriteTensor(Adv_tensor_, 0, out);
}

double SphereBasisSet2D::dotProdCast(const spherePtrAll a, const spherePtrAll b) {
  if (! is_prolate_ && ! is_oblate_)
    return a->dotProd(*b)*a->GetInvNorm()*b->GetInvNorm();
  else
    return std::static_pointer_cast<ProlateOblate2D>(a)->dotProd(*std::static_pointer_cast<ProlateOblate2D>(b), *tabData_)*
            a->GetInvNorm()*b->GetInvNorm();
}

#define dotProdMarco(arg, i,j) dotProdCast(arg[i], arg[j])
// Run MGS on a set of basis functions stored in in, and orthogonalize them. The kept basis
// is stored in out. The basis functions with distinct part smalelr than thresh of existing basis
// are thrown away. Coef are a matrix which kepts the coefficients of MGS. m is the number of
// basis functions that are kept.
void SphereBasisSet2D::runMGS(const double thresh, const std::vector<spherePtrAll>& in, std::vector<spherePtrAll>& out,
            Eigen::MatrixXd& Coef, int& m) {
  out.clear();
  // inner product matrix of all basis.
  Eigen::MatrixXd H = Eigen::MatrixXd::Zero(in.size(), in.size());
  // temp buffer.
  Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(in.size(), in.size());
  // Coefficients matrix.
  Coef = Eigen::MatrixXd::Zero(in.size(), in.size());
  // map from row/col index of H matrix to basis index
  Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(in.size());
  Coef(0,0) = 1.0; 
  H(0,0) = dotProdMarco(in, 0,0);
  HC.col(0) = H*Coef.row(0).transpose();
  idxMap[0] = 0;
  // The first one.
  out.push_back(in[0]);
  // size of the final allocated basis.
  m = 1;

  for(int i = 1; i < in.size(); i++) {
    Coef(m,m) = 1.0;
    H(m,m) = dotProdMarco(in, i,i);
    for (int j = 0; j < m; j++)
      H(j,m) = H(m,j) = dotProdMarco(in, i,idxMap[j]);
    for (int j = 0; j < m; j++) {
      HC(m,j) = H.row(m)*Coef.row(j).transpose();
    }

    for (int j = 0; j < m; j++) {
      double dotProd = Coef.row(m)*HC.col(j);
      Coef.row(m) -= dotProd*Coef.row(j);
    }

    // compute norm.
    HC.col(m) = H*Coef.row(m).transpose();
    double norm2 = Coef.row(m)*HC.col(m);

    if (norm2 > thresh) {
      idxMap[m] = i;
      Coef.row(m) /= sqrt(norm2);
      HC.col(m) /= sqrt(norm2);
      m++;
      out.push_back(in[i]);
    }
    else {
      LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";
      // H should be positive definite.
      //LOG(INFO) << Coef.row(m)*Coef.row(m).transpose();
      //exit(0);
    }
  }
  CHECK(m <= in.size());
  CHECK(m == out.size());
  // test
  // Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  // for (int i = 0; i < reduced.rows(); i++) {
  //   reduced(i,i) -= 1.0;
  // }
  // LOG(INFO) << reduced.norm();
}

// compute the ur, ut on a uniform r, t grid, test only.
void SphereBasisSet2D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut) {
  memset(ur, 0x00, sizeof(double)*nTheta*nR);
  memset(ut, 0x00, sizeof(double)*nTheta*nR);
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    if (! is_prolate_ && ! is_oblate_) {
      all_basis_[i]->AddUniformU(fullCoef[i], nR, nTheta, ur, ut);
    } else {
      std::static_pointer_cast<ProlateOblate2D>(all_basis_[i])->AddUniformU(fullCoef[i], nR, nTheta, ur, ut);
    }
  }
}

void SphereBasisSet2D::projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    if (! is_prolate_ && ! is_oblate_)
      fullCoef[i] = all_basis_[i]->ProjectUniformU(nR, nTheta, fr, ft);
    else
      fullCoef[i] = std::static_pointer_cast<ProlateOblate2D>(all_basis_[i])->ProjectUniformU(nR, nTheta, fr, ft);
  }
}

void SphereBasisSet2D::ReSeedParticles(std::vector<ParticleSph3D>& particles) {
  if (! is_prolate_ && ! is_oblate_) {
    // Reseed the particles at random position.
    for (int i = 0; i < particles.size(); i++) {
      Eigen::Vector3d pos = sampleOnSphere(m_gen_);
      // [0-1]
      particles[i].position[0] = pos[0];
      particles[i].position[1] = pos[1];
      particles[i].position[2] = pos[2];
      particles[i].velocity.setZero();
    }
  } else if (is_oblate_) {
    for (int i = 0; i < particles.size(); i++) {
      Eigen::Vector3d pos = sampleOnSphere(m_gen_);
      // [0-1]
      particles[i].position[0] = pos[0];
      particles[i].position[1] = pos[1];
      particles[i].position[2] = pos[2]*b_;
      particles[i].velocity.setZero();
    }
  } else {
    for (int i = 0; i < particles.size(); i++) {
      Eigen::Vector3d pos = sampleOnSphere(m_gen_);
      // [0-1]
      particles[i].position[0] = pos[0]*b_;
      particles[i].position[1] = pos[1]*b_;
      particles[i].position[2] = pos[2];
      particles[i].velocity.setZero();
    }
  }
}

#define CLAMPT(tv) \
tv = (tv < 0) ? 0 : tv;\
tv = (tv > nTheta_ - 1) ? nTheta_ - 1 : tv;

#define CLAMPP(pv) \
pv = (pv < 0) ? nPhi_ + pv : pv;\
pv = (pv > nPhi_ - 1) ? pv - nPhi_ : pv;

#define interPol(arg_)\
(wp0 * (wt0 * arg_[i000] + wt1 * arg_[i010]) +\
 wp1 * (wt0 * arg_[i100] + wt1 * arg_[i110]))\

// When past pole, the pi shift in phi will results in a shift in sign of the velocity.
// This will cancel out the velocity in the interpolation if the shift of the sign is not
// porperity accounted.
#define CLAMP_POINTS(ARG, sgn)\
if (ARG[0] < 0) {\
  ARG[0] = -ARG[0];\
  ARG[1] += nPhi_/2;\
  sgn = -1;\
} else if (ARG[0] >= nTheta_) {\
  ARG[0] = 2*nTheta_ - ARG[0] - 1;\
  ARG[1] += nPhi_/2;\
  sgn = -1;\
}\
ARG[1] = (ARG[1] < 0) ? nPhi_ + ARG[1] : ARG[1];\
ARG[1] = (ARG[1] >= nPhi_) ? ARG[1] - nPhi_ : ARG[1];

#define interPol1(arg_, sgns)\
(wp0 * (wt0 * arg_[i000]*sgns[0] + wt1 * arg_[i010]*sgns[1]) +\
 wp1 * (wt0 * arg_[i100]*sgns[2] + wt1 * arg_[i110]*sgns[3]))\

VEC2 SphereBasisSet2D::getVelocityParam(VEC2& pos, const VFIELD2D& velocity) {
  // clamp theta
  if (pos[0] < 0) {
    pos[0] = -pos[0];
    pos[1] += M_PI;
  } else if (pos[0] > M_PI) {
    pos[0] = 2*M_PI - pos[0];
    pos[1] += M_PI;
  }

  // clamp phi.
  pos[1] = (pos[1] < 0) ? 2*M_PI + pos[1] : pos[1];
  pos[1] = (pos[1] > 2*M_PI) ? pos[1] - 2*M_PI : pos[1];

  int tl = floor(pos[0]/dTheta_);
  int tu = tl+1;
  int pl = floor(pos[1]/dPhi_);
  int pu = pl+1;
  
  const double wp1 = pos[1]/dPhi_ - pl;
  const double wp0 = 1.0 - wp1;

  const double wt1 = pos[0]/dTheta_ - tl;
  const double wt0 = 1.0 - wt1;

  int p00[2] = {tl, pl};
  int p01[2] = {tl, pu};
  int p10[2] = {tu, pl};
  int p11[2] = {tu, pu};
  int sgn[4] = {1,1,1,1};

  CLAMP_POINTS(p00, sgn[0]);
  CLAMP_POINTS(p01, sgn[2]);
  CLAMP_POINTS(p10, sgn[1]);
  CLAMP_POINTS(p11, sgn[3]);

  //CHECK(p00[0] >= 0 && p01[0] >= 0 && p10[0] >= 0 && p11[0] >= 0);
  //CHECK(p00[0] < nTheta_ && p01[0] < nTheta_ && p10[0] < nTheta_ && p11[0] < nTheta_);
  //CHECK(p00[1] >= 0 && p01[1] >= 0 && p10[1] >= 0 && p11[1] >= 0);
  //CHECK(p00[1] < nPhi_ && p01[1] < nPhi_ && p10[1] < nPhi_ && p11[1] < nPhi_);

  const int i000 = p00[1] + p00[0] * nPhi_;
  const int i010 = p10[1] + p10[0] * nPhi_;
  const int i100 = p01[1] + p01[0] * nPhi_;
  const int i110 = p11[1] + p11[0] * nPhi_;

  VEC2 uSph = interPol1(velocity, sgn);
  //uSph = velocity[i000];

  return uSph;
}

#undef CLAMP_POINTS
#undef interPol1

Eigen::Vector3d SphereBasisSet2D::getVelocityCartesian(const Eigen::Vector3d& pos, const VFIELD2D& velocity) {
  Eigen::Vector3d result;
  getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(pos, result);
  return result;
}

void SphereBasisSet2D::ProjectParticle(ParticleSph3D& p) {
  if (! is_prolate_ && ! is_oblate_) {
    p.position.normalize();
    p.computeSphCoord();
    return;
  }

  Eigen::Vector3d& pos = p.position;
  // this should be 1
  double dist = 0;
  if (is_prolate_)
    dist = (pos[0]*pos[0] + pos[1]*pos[1])/b_/b_ + pos[2]*pos[2];
  else
    dist = pos[0]*pos[0] + pos[1]*pos[1] + pos[2]*pos[2]/b_/b_;
  double ratio = 1.0 / sqrt(dist);
  pos *= ratio;
  
  double r;
  if (is_prolate_)
    Transform::Spheroid::CatersianToProlate(a_, c_, pos, r, p.theta, p.phi);
  else
    Transform::Spheroid::CatersianToOblate(a_, c_, pos, r, p.theta, p.phi);
}

// should be [-1, 1]^3
template<typename DT, typename VT, typename MT>
void SphereBasisSet2D::getVelocityPosT(const VT& pos, VT& uCat) {
  VT uSph(0,0,0);
  uCat.setZero();

  // parameter space.
  VT sphCord;// = Transform::Spherical::toSpherical(pos);
  if (! is_prolate_ && ! is_oblate_)
    sphCord = Transform::Spherical::toSpherical(pos);
  else if (is_prolate_)
    Transform::Spheroid::CatersianToProlate(a_, c_, pos, sphCord[0], sphCord[1], sphCord[2]);
  else if (is_oblate_)
    Transform::Spheroid::CatersianToOblate(a_, c_, pos, sphCord[0], sphCord[1], sphCord[2]);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, pi]
  const DT& p = sphCord[2]; // [0, 2*pi]
  //CHECK(isfinite(r) && isfinite(t) && isfinite(p)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.

  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int p0 = (int)(p/dPhi_);
  int p1 = p0 + 1;

  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPP(p0);
  CLAMPP(p1);

  // get interpolation weights
  const DT wp1 = p/dPhi_ - p0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;

  const int i000 = p0 + t0 * nPhi_;
  const int i010 = p0 + t1 * nPhi_;
  const int i100 = p1 + t0 * nPhi_;
  const int i110 = p1 + t1 * nPhi_;

  uSph << 0, interPol(vtTemp_), interPol(vpTemp_);
  MT transMat;
  if (is_prolate_)
    Transform::Spheroid::toCartesianMatProlate(r, t, p, c_, transMat);
  else if (is_oblate_)
    Transform::Spheroid::toCartesianMatOblate(r, t, p, c_, transMat);
  else
    Transform::Spherical::toCartesianMat(t, p, transMat);
  // toCartesian
  uCat = transMat*uSph;
}

template void SphereBasisSet2D::getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(const Eigen::Vector3d&, Eigen::Vector3d&);
template void SphereBasisSet2D::getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(const Eigen::Vector3f&, Eigen::Vector3f&);

Eigen::Vector3d SphereBasisSet2D::getVelocityPos(const Eigen::Vector3d& pos) {
  Eigen::Vector3d result(0,0,0);
  getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(pos, result);
  return result;
}

Eigen::Vector3f SphereBasisSet2D::getVelocityPos(const Eigen::Vector3f& pos) {
  Eigen::Vector3f result(0,0,0);
  getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(pos, result);
  return result;
}

void SphereBasisSet2D::splatParticle(const float ptlWeight, ParaParticle3Df& p, FIELD2D& density) {
  
  Eigen::Vector3f sph;
  sph = Transform::Spherical::toSpherical(p.position_);
  float theta = sph[1];
  float phi   = sph[2];

  int tl = floor(theta/dTheta_);
  int tu = tl+1;
  int pl = floor(phi/dPhi_);
  int pu = pl+1;

  CLAMPT(tu);
  CLAMPT(tl);
  CLAMPP(pu);
  CLAMPP(pl);
  
  float wt = theta/dTheta_ - tl;
  float wp = phi/dPhi_ - pl;
  float ww = ptlWeight*p.weight_;
  // interpolate along theta
  density(pl, tl) += ww*(1.0 - wt)*(1.0 - wp);
  density(pl, tu) += ww*wt*(1.0 - wp);
  density(pu, tl) += ww*wp*(1.0 - wt);
  density(pu, tu) += ww*wt*wp;
}

Eigen::Vector3f SphereBasisSet2D::textureLookUp(const Eigen::Vector3f& pos, const int width,
         const int height, const int nChannel, const unsigned char *img) {

  const float dTheta = M_PI/height;
  const float dPhi   = 2.0*M_PI/width;
  
  Eigen::Vector3f sph;
  sph = Transform::Spherical::toSpherical(pos);
  float theta = sph[1];
  float phi   = sph[2];

  int tl = floor(theta/dTheta);
  int tu = tl+1;
  int pl = floor(phi/dPhi);
  int pu = pl+1;

  tl = (tl < 0) ? 0 : tl;
  tu = (tu > height - 1) ? height - 1 : tu;
  pl = (pl < 0) ? width + pl : pl;\
  pu = (pu > width - 1) ? pu - width : pu;
  
  float wt = theta/dTheta - tl;
  float wp = phi/dPhi - pl;

  Eigen::Vector3f result(0,0,0);
  for (int i = 0 ; i < 3; i++) {
    result[i] += (float)(img[nChannel*(pl + tl*width) + i])/255.f*(1.0 - wt)*(1.0 - wp);
    result[i] += (float)(img[nChannel*(pl + tu*width) + i])/255.f*wt*(1.0 - wp);
    result[i] += (float)(img[nChannel*(pu + tl*width) + i])/255.f*wp*(1.0 - wt);
    result[i] += (float)(img[nChannel*(pu + tu*width) + i])/255.f*wt*wp;
  }
  return result;
}

void SphereBasisSet2D::projPosBack(ParaParticle3Df& p) {
   Eigen::Vector3f sphCord;
  if (! is_prolate_ && ! is_oblate_)
    sphCord = Transform::Spherical::toSpherical(p.position_);
  else if (is_prolate_)
    Transform::Spheroid::CatersianToProlate(a_, c_, p.position_, sphCord[0], sphCord[1], sphCord[2]);
  else if (is_oblate_)
    Transform::Spheroid::CatersianToOblate(a_, c_, p.position_, sphCord[0], sphCord[1], sphCord[2]);
  
  if (sphCord[0] <= 1.0)
    return;

  sphCord[0] = 1.0;
  if (! is_prolate_ && ! is_oblate_)
    p.position_ = Transform::Spherical::toCartesian(sphCord);
  else if (is_prolate_)
    Transform::Spheroid::ProlateToCatersian(a_, c_, sphCord[0], sphCord[1], sphCord[2], p.position_);
  else if (is_oblate_)
    Transform::Spheroid::OblateToCatersian (a_, c_, sphCord[0], sphCord[1], sphCord[2], p.position_);
  //p.weight_ = 0.0;
  //p.life_ = 0;
}

// Add density particles
void SphereBasisSet2D::addParticles(const int x, const int y, const int width, const int height, 
                                    const int maxParticlePerCell, 
                                   std::vector<ParaParticle3Df>& densityParticles) {
  LOG(FATAL) << "depredated";
}

void SphereBasisSet2D::DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& rot, const FIELD2D& density,
                                   const std::vector<ParticleSph3D>& particles, const double& ptl_length, drawerCollection& drawers) {
  glm::mat4 model = glm::translate(glm::mat4(1.f), glm::vec3(-1.5,0.0,0.0));//glm::mat4(1.0f);
  model = glm::translate(model, glm::vec3(0.0f, 0.0, -3.f)); // translate it down so it's at the center of the scene
  model = model*rot;

  glm::vec3 scVec(0.76, 0.76, 0.76);
  if (is_prolate_)
    scVec = glm::vec3(0.76*b_, 0.76*b_, 0.76);
  if (is_oblate_)
    scVec = glm::vec3(0.76, 0.76, 0.76*b_);
  drawers.textureShader_->use();
  drawers.textureShader_->setMat4("projection", projection);
  drawers.textureShader_->setMat4("view", view);
  drawers.textureShader_->setMat4("model", glm::translate(glm::scale(model, scVec), glm::vec3(0,-1.049168, 0)));
  drawers.textureShader_->setVec4("color",glm::vec4(1.0,1.0,1.0,1.0));

  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < nPhi_; i++) {
      int i1 = (i + nPhi_/4) % nPhi_;
      drawers.densDrawer_->textureData[i1 + j*nPhi_] = 1.0 - density[i + j*nPhi_];//forceMag_[i + j*nPhi_]/maxMag;
  }
  drawers.densDrawer_->Draw(*drawers.textureShader_);

  model = glm::scale(model, glm::vec3(2.0, 2.0, 2.0));
  drawers.fixColorShader_->use();
  drawers.fixColorShader_->setMat4("projection", projection);
  drawers.fixColorShader_->setMat4("view", view);
  drawers.fixColorShader_->setMat4("model", model);
  drawers.fixColorShader_->setVec4("color",glm::vec4(0.0,0.0,0.0,1.0));
  drawers.ptlGL4_->updatePos(particles, ptl_length);
  drawers.ptlGL4_->Draw();
}

void SphereBasisSet2D::DrawParticles(const std::vector<ParticleSph3D>& particles, const double ptl_length,  drawerCollection& drawers) {
  drawers.ptlGL4_->updatePos(particles, ptl_length);
  drawers.ptlGL4_->Draw();
}

void SphereBasisSet2D::setUpTable() {

  if (is_prolate_) {
    queryTable_.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                            "./Tensor/tables/prolate2D/prolateDotTable.bin",
                                            "./Tensor/tables/prolate2D/prolate2DDot.txt"));
    tabData_.reset(new IntTable1DData(b_));
    tabData_->setIntTable(queryTable_);

    tensorTable_.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                            "./Tensor/tables/prolate2D/prolateTensorTable.bin",
                                            "./Tensor/tables/prolate2D/prolateTensor2D.txt"));
    tensorData_.reset(new IntTable1DData(b_));
    tensorData_->setIntTable(tensorTable_);

  } else if (is_oblate_) {
    queryTable_.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                            "./Tensor/tables/prolate2D/OblateDotTable.bin",
                                            "./Tensor/tables/prolate2D/prolate2DDot.txt"));
    tabData_.reset(new IntTable1DData(b_));
    tabData_->setIntTable(queryTable_);
    
    tensorTable_.reset(new IntegrationTable1DPtn("./Tensor/tables/prolate2D/bList.csv", "./Tensor/tables/prolate2D/k1x2Range.csv",
                                            "./Tensor/tables/prolate2D/oblateTensorTable.bin",
                                            "./Tensor/tables/prolate2D/oblateTensor2D.txt"));
    tensorData_.reset(new IntTable1DData(b_));
    tensorData_->setIntTable(tensorTable_);
  }
}
