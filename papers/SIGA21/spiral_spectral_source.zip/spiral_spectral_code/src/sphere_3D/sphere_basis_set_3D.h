#ifndef SPHERE_BASIS_SET_3D_H
#define SPHERE_BASIS_SET_3D_H

#include <cstring>
#include <Eigen/Eigen>
#include <fstream>
#include <fftw3.h>
#include <vector>

#include "common/pairedCoef.h"
#include "common/particle_sph_3d.h"
#include "elliptic/prolate_oblate_3D.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"

#define FAST_TENSOR

#ifdef FAST_TENSOR
#include "tensorCompute/sphere3DTensor.h"
#endif

enum TRANSTYPE {ICOS, ISIN, FCOS, FSIN};

typedef std::shared_ptr<SphereBasis3D> basisPtr3D;

class SphereBasisSet3D : public BasisSet3D {

public:
  SphereBasisSet3D(const int nR, const int nTheta, const int nPhi, const int rK, const int thetaK, const int phiK,
                  bool bndCnd):nR_(nR), nTheta_(nTheta),nPhi_(nPhi), nThetaPhi_(nTheta*nPhi), rK_(rK), thetaK_(thetaK),
                  phiK_(phiK), boundaryCnd_(bndCnd),xRes_(2*nR), yRes_(2*nR), zRes_(2*nR),
                  cartesianSize_(2*nR*2*nR*2*nR), dx_(1.0/std::max(std::max(2*nR,2*nR),2*nR)),nPhiTheta_(nTheta*nPhi),
                  is_prolate_(false), is_oblate_(false) {
    
    // nPhi_ must be even to ensure dst works.
    CHECK(nPhi_ % 2 == 0);
    b_ = 1.0;
    c_ = 1.0;
    a_ = 0;
    //allocateBasis();
    allocateMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  SphereBasisSet3D(const int nR, const int nTheta, const int nPhi, const int rK, const int thetaK, const int phiK,
                  bool bndCnd, const bool is_prolate, const bool is_oblate,
                  const double& b):nR_(nR), nTheta_(nTheta),nPhi_(nPhi), nThetaPhi_(nTheta*nPhi), rK_(rK), thetaK_(thetaK),
                  phiK_(phiK), boundaryCnd_(bndCnd),xRes_(2*nR), yRes_(2*nR), zRes_(2*nR),
                  cartesianSize_(2*nR*2*nR*2*nR), dx_(1.0/std::max(std::max(2*nR,2*nR),2*nR)),nPhiTheta_(nTheta*nPhi),
                  a_(sqrt(1.0 - b*b)), b_(b), c_(b/sqrt(1.0 - b*b)), is_prolate_(is_prolate), is_oblate_(is_oblate) {
    
    // nPhi_ must be even to ensure dst works.
    CHECK(nPhi_ % 2 == 0);
    CHECK(isfinite(a_) && isfinite(b_) && isfinite(c_));
    CHECK(!(is_prolate_ && is_oblate_));
    setUpTable();
    allocateMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  SphereBasisSet3D(const int nR, const int nTheta, const int nPhi, std::ifstream& in):nR_(nR), nTheta_(nTheta),nPhi_(nPhi),
                nThetaPhi_(nTheta*nPhi), rK_(0), thetaK_(0), phiK_(0),xRes_(2*nR), yRes_(2*nR), zRes_(2*nR),
                cartesianSize_(2*nR*2*nR*2*nR), dx_(1.0/std::max(std::max(2*nR,2*nR),2*nR)),nPhiTheta_(nTheta*nPhi) {
    // nPhi_ must be even to ensure dst works.
    CHECK(nPhi_ % 2 == 0);
    readFromFile(in);
    allocateTemp();
    setUpFFTWPlan();
  }

  // void allocateNumerical();
  ~SphereBasisSet3D(){
  };

  void InverseTransformToVelocity(Eigen::VectorXd& coefficients) override;

  // Input a std::vector field, transform and output the basis coefficients.
  void ForwardTransformtoFrequency(
      const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) override;
  void ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) override;

  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  void FillTensorProOblate(std::vector<Adv_Tensor_Type> *Adv_tensor, const int iStart, const int iEnd);
  void outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor);
  
  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const override;
  void readFromFile(std::ifstream& in) override;
  
  bool isProlate() {return is_prolate_;}
  bool isOblate() {return is_oblate_;}
  double getb() {return b_;}
  double geta() {return a_;}
  double getc() {return c_;}
  void ReSeedParticles(std::vector<ParticleSph3D>& particles, std::vector<Eigen::Vector3d>& initPos) override;
  void projBackParticles(const std::vector<Eigen::Vector3d>& initPos, std::vector<ParticleSph3D>& particles) override;
  VEC3 getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) override;
  Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) override;
  Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) override;
  void projPosBack(ParaParticle3Dd& p) override;
  void projPosBack(ParaParticle3Df& p) override;

  void interpolateToCartesian(VECTOR3_FIELD_3D* field) override;
  int nR() {return nR_;}
  int nPhi() {return nPhi_;}
  int nTheta() {return nTheta_;}
  // Add force to the grid where the particle is.
  template<typename DT, typename VT>
  void addParticleForce(const double& ptlWeight, const VT& pos, const VT& f, const bool isCartesian, VECTOR3_FIELD_3D& buf);
  
  int inverseLookup(const int k12, const int k22, const int k32, const int idx) {
    uint64_t hash = Basis3D::toHash(k12, k22, k32, idx);
    std::unordered_map<uint64_t, int>::const_iterator it = basisLookup_.find(hash);
    if (it != basisLookup_.end())
      return it->second;
    else
      return -1;
  }
  double DCflowMag = 0.0;
  void computeLaplacianMatrix(Adv_Tensor_Type& sparseD_);
  void computeBasisWeight(Eigen::VectorXd& weights);
protected:
  int getBasisSize(const int idx) {
    return phiCoef_[idx].size();
  }
  double computeTensorEntry(const SphereBasis3D& basis_i, const SphereBasis3D& basis_j,
                          const SphereBasis3D& basis_k);
  // collect the coef need to be transformed into a std::vector.
  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);
  void assignPairCoef(Eigen::VectorXd& fieldCoef);

  void allocateTemp() ;
  void allocateNumerical();
  // clear chunk of mem following ptr, it's up to user
  void clearPointer(double* ptr) {
    int multipier = ! boundaryCnd_ ? 2 : 1;
    std::memset(ptr, 0x00, sizeof(double)*totalSize_*multipier);
  }

  void clearPointerSize(double* ptr, const int sizeBuf) {
    std::memset(ptr, 0x00, sizeof(double)*sizeBuf);
  }

  void allocateMGS();
  void setUpFFTWPlan();

  void sphereToCartesian(VECTOR3_FIELD_3D* field);
  void proOblateToCartesian(VECTOR3_FIELD_3D* field);
  void interpolateToSphere(const VECTOR3_FIELD_3D& field);
  void CartesianToProOblate(const VECTOR3_FIELD_3D& field);
  void CartesianToProlate(const VECTOR3_FIELD_3D& field);
  void CartesianToOblate(const VECTOR3_FIELD_3D& field);

  void initCartesian();
  void initPhiCoef();
  void weightByR(double* buf);
  void weightR(const double* rVal, double* buf);
  // weight with r^2sin(t), before projecting to coefficients.
  void weightR2SinT(double* buf);
  void weightVRFactor(double* ptr);
  void weightVTFactor(double* ptr);
  void weightVPFactor(double* ptr);
  // add a slab of size nR*nTheta to the entire 3d cube.
  // a(i,j,k) += slab(j,k)
  void addSlabRT(const double* slab, double* a);
  // slab(j,k) += \sum_i a(i,j,k)
  void projectSlabRT(const double* field, double* slab);
  // outer product of two vec of size nR and nTheta, results in a RT slab.
  void outerSlabRT(const double* rV, const double* tV, double* slab);
  // add outer product of rV, tv to full 3D field a.
  void addOuterRT(const double* rV, const double* tV, double* a);

  void addOuterRTCRDivH(const double* rV, const double* tV, double* a);
  void addOuterDivH(const double* rV, const double* tV, double* a);
  void addOuterRTSqrtCRDivH(const double* rV, const double* tV, double* a);

  void addOuterRTP(const double* rV, const double* tV, const double* pV, double* a);
  void addOuterRTPSqrtCRDivH(const double* rV, const double* tV, const double* pV, double* a);
  void addOuterRTPCRDivH(const double* rV, const double* tV, const double* pV, double* a);

  void addOuterSlabP(const double* slab, const double* pV, double* a);
  void projectSlabP(const double* field, const double* pV, double* slab);
  
  // project to R with t.
  void projectRT(const double* field, const double* tV, double* rV);
  void projectRTCRDivH(const double* field, const double* tV, double* rV);
  void projectRTSqrtCRDivH(const double* field, const double* tV, double* rV);
  void projectRTDivH(const double* field, const double* tV, double* rV);
  void projectTPtoR(const double* field, const double* tV, const double* pV, double* rV );
  //void addOuterRT(const double* rV, const double* tV, double* a);
  void projectTPtoRSqrtCRDivH(const double* field, const double* tV, const double* pV, double* rV);
  void projectTPtoRCRDivH(const double* field, const double* tV, const double* pV, double* rV );

  void InverseTransformVR();
  void ForwardTransformVR();
  void InverseTransformVT();
  void ForwardTransformVT();
  void InverseTransformVP();
  void ForwardTransformVP();
  void InverseTransformEnrich();
  void ForwardTransformEnrich();
  void TransR(fftw_plan plan, double* in, double* out);
  void TransT(fftw_plan plan, double* in, double* out);
  //void ITranssinT(double* in, double* out);
  void TransP(fftw_plan plan, double* in, double* out);
  // transform either 5 or 6
  void InverseTransformPhi5();
  void InverseTransformPhi6();

  void ForwardTransformPhi5();
  void ForwardTransformPhi6();
  void clearPairCoef();
  void weightJacobian(double* ur, double* ut, double* up);
  double dotProdCast(const basisPtr3D a, const basisPtr3D b) const;
  void runMGS(const double thresh, const std::vector<basisPtr3D>& in, std::vector<basisPtr3D>& out,
            Eigen::MatrixXd& Coef, int& m);

  // set up query table for inner products etc.
  void setUpTable();
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta,
       const int nPhi, double* ur, double* ut, double* up);
  
  void projectUniformRTNumerical(const int nR, const int nTheta, const int nPhi, double* fr,
                                           double* ft, double* fp, Eigen::VectorXd& fullCoef);

  double tensorEntryCast(const basisPtr3D basis_i, const basisPtr3D basis_g, const basisPtr3D basis_h);
  // should be [-1, 1]^3
  template<typename DT, typename VT, typename MT>
  void getVelocityPosT(const VT& pos, VT& uCat);

  const int nR_;
  const int nTheta_;
  const int nPhi_;
  const int nThetaPhi_;
  // need to write this out.....
  int rK_;
  // number of basis along theta
  int thetaK_;
  // number of basis along phi
  int phiK_;
  bool boundaryCnd_;

  const int xRes_;
  const int yRes_;
  const int zRes_;

  // dims of the cartesian grid
  const int cartesianSize_;
  // grid scale of cartesian grid
  const double dx_;
  const int nPhiTheta_;
  
  double dR_;
  double dTheta_;
  double dPhi_;

  // r, theta, p at the cartesian grid locations.
  double* rCat_ = NULL;
  double* tCat_ = NULL;
  double* pCat_ = NULL;

  int totalSize_;
  double invTotalSize_;

  // pointers of size totalSize_
  double* inTemp_ = NULL;
  double* vpTemp_ = NULL;
  double* vtTemp_ = NULL;
  double* vrTemp_ = NULL;
  double* temp0_ = NULL;
  double* temp1_ = NULL;
  double* temp2_ = NULL;

  // pointers of size nR_;
  double* rtemp0_ = NULL;
  double* rtemp1_ = NULL;
  double* rtemp2_ = NULL;

  // pointers of size nR_*nTheta_;
  double* rtTemp_ = NULL;

  // pointers of size nTheta_
  double* cosTVal_ = NULL;
  double* sinTVal_ = NULL;
  
  // pointers of size nPhi_
  double* cosPVal_ = NULL;
  double* sinPVal_ = NULL;

  const bool useTrimmedPlan = true;
  // inverse full plans
  fftw_plan IsinR_;
  fftw_plan IcosR_;
  fftw_plan IsinT_;
  fftw_plan IcosT_;
  fftw_plan IcosP_;
  fftw_plan IsinP_;
  // inverse trimmed plans, this plans are 2D for the same reason IsinT_ and IcosT_ are 2D.
  // due to jump in idsit.
  fftw_plan IsinRE_;
  fftw_plan IcosRE_;
  fftw_plan IsinTE_;
  fftw_plan IcosTE_;
  fftw_plan IcosPE_;
  fftw_plan IsinPE_;

  // 1D plan, needed for computing the enrichment basis.
  fftw_plan IcosR1D_;
  fftw_plan IsinR1D_;
  // 2D plan, only Phi^7 needed.
  fftw_plan IsinRsinT_;

  // forward full plans
  fftw_plan FsinR_;
  fftw_plan FcosR_;
  fftw_plan FsinT_;
  fftw_plan FcosT_;
  fftw_plan FcosP_;
  fftw_plan FsinP_;
  // forward trimmed plans.
  fftw_plan FsinRE_;
  fftw_plan FcosRE_;
  fftw_plan FsinTE_;
  fftw_plan FcosTE_;
  fftw_plan FcosPE_;
  fftw_plan FsinPE_;
  
  // 1D plan, needed for computing the enrichment basis.
  fftw_plan FcosR1D_;
  fftw_plan FsinR1D_;
  // 2D plan, only Phi^7 needed.
  fftw_plan FsinRsinT_;

  std::vector<std::vector<pairedCoef>> phiCoef_;

  std::vector<basisPtr3D> all_basis_;
  std::unordered_map<uint64_t, int> basisLookup_;

  // focus
  double a_;
  // short axis
  double b_;
  // sinh(w) = b/a
  double c_;

  bool is_prolate_;
  bool is_oblate_;
  std::shared_ptr<IntegrationTable1DPtn> dotTable1D_;
  std::shared_ptr<TensorTable2D> dotTable2D_;
  std::shared_ptr<IntTable1DData> dotData_;

  std::shared_ptr<IntegrationTable1DPtn> tensorTable1D_;
  std::shared_ptr<TensorTable2D> tensorTable2D_;
  std::shared_ptr<IntTable1DData> tensorData_;

  double* h_ = NULL;
  double* sqrtCR_ = NULL;
  std::default_random_engine m_gen_;
  
  double* sinPi2r_ = NULL;
  double* pirSinPi2r_ = NULL;
  double* pir2Cos2Sin_ = NULL;

#ifdef FAST_TENSOR
  sphere3DTensor tensorEval_;
#endif

};

#endif  // SPHERE_BASIS_SET_3D_H