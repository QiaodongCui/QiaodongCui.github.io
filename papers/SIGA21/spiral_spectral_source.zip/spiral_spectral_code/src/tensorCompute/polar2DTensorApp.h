static double evalpol2D_0(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_0(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)))
+((pol2DtEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_1(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_1(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_2(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)))
+((pol2DtEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_3(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_2(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_4(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_5(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_3(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_6(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_7(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_4(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_8(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_8(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_5(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_2(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_2(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)))
+((pol2DtEval::evalT_3(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_3(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_6(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_0(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_0(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)))
+((pol2DtEval::evalT_1(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_1(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_7(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_6(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_6(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
+((pol2DtEval::evalT_7(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_7(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_8(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_4(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_4(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
+((pol2DtEval::evalT_5(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_5(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_9(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_9(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_9(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_10(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_10(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)))
+((pol2DtEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_11(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_11(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_12(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
+((pol2DtEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_13(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_12(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_14(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_13(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_15(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_16(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_14(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_17(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_15(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_12(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_12(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)))
+((pol2DtEval::evalT_13(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_13(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_16(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_10(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_10(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
+((pol2DtEval::evalT_11(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_11(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_17(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_15(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_15(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)))
+((pol2DtEval::evalT_16(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_16(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_18(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_14(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_14(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_19(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_18(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_20(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_19(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_19(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_21(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_20(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_20(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_22(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_17(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_17(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_23(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_18(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_18(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_24(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_21(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_24(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_25(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_22(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)))
+((pol2DtEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_23(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_26(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_24(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)))
+((pol2DtEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_25(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_27(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_26(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_27(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_28(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_28(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_29(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_29(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_30(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_30(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_30(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_24(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_24(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)))
+((pol2DtEval::evalT_25(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_25(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_31(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_22(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_22(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)))
+((pol2DtEval::evalT_23(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_23(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_32(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_28(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_28(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
+((pol2DtEval::evalT_29(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_29(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g2*h1*Pi+-g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_33(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_26(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_26(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
+((pol2DtEval::evalT_27(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_27(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g2*h1*Pi+g2*h1*i2*Pi*i2)+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+g2+-g2*i2*i2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_34(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_31(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_31(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2+g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_35(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_32(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)))
+((pol2DtEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_33(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_36(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_34(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
+((pol2DtEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_35(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g1*h2*Pi+g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_37(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_36(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_38(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_37(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_38(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g1*Pi+g1*i2*Pi*i2)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_39(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_39(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_40(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_34(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_34(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)))
+((pol2DtEval::evalT_35(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_35(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_41(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_32(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_32(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_15(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1+-i2*i2)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+3*i1*Pi)))
+((pol2DtEval::evalT_33(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_33(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_9(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g1*h2*Pi+-g1*h2*i2*Pi*i2)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-h2+h2*i2*i2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_42(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_37(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_37(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)))
+((pol2DtEval::evalT_38(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_38(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+h1*Pi+-h1*i2*Pi*i2)+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+-1+i2*i2)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_43(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_36(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_36(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_4(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-h1*Pi+h1*i2*Pi*i2)+pol2DrEval::evalR_6(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g1*Pi+-g1*i2*Pi*i2)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_44(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_40(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1+i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_45(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_41(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_41(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_46(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_42(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_42(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2+-h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_47(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_39(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_39(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_48(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_40(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_40(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1+-i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_49(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_21(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_24(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_50(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_43(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_44(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_51(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_45(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_46(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_52(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_47(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_48(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_53(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_49(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_50(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_54(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_51(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_55(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_45(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_45(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_46(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_46(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_56(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_43(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_43(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_44(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_44(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_57(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_49(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_50(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_50(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_58(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_47(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_47(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_48(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_59(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_52(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_60(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_53(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_54(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_61(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_55(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_56(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_62(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_57(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_63(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_58(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_59(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_64(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_60(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_65(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_55(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_56(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_56(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_66(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_53(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_53(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_54(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_67(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_58(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_59(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_59(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_68(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_57(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_69(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_61(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_70(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_62(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_71(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_63(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_72(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_60(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_73(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_61(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_74(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_21(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_24(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_75(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_64(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_65(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_76(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_66(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_67(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_77(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_49(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_68(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_78(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_69(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_48(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_79(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_70(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_80(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_66(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_66(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_67(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_67(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_81(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_64(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_64(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_65(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_65(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_82(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_69(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_69(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_48(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_48(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_83(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_49(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_49(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_68(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_68(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*g2*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_84(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_71(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+3*g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_85(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_55(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_72(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_86(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_73(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_54(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_87(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_58(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_88(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_74(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_57(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+3*g1*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+g1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_89(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_75(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_90(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_73(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_73(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_54(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_54(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_91(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_55(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_55(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_21(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_28(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
+((pol2DtEval::evalT_72(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_72(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_3(i1x2, g1x2, h1x2)*(+-3*g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*h2*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+h2*i1*Pi*i1*Pi)+pol2DrEval::evalR_27(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_92(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_74(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_74(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)))
+((pol2DtEval::evalT_57(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_57(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+-3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_93(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_58(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_58(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_11(i1x2, g1x2, h1x2)*(+-3*g1*i1*Pi*Pi)+pol2DrEval::evalR_26(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*i1*Pi*Pi)+pol2DrEval::evalR_18(i1x2, g1x2, h1x2)*(+3*h1*i1*Pi*Pi)+pol2DrEval::evalR_25(i1x2, g1x2, h1x2)*(+h1*i1*Pi*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_94(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_60(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+3*i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_95(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_76(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_96(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_77(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-3*h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-h2*i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_97(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_75(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_98(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_60(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-3*i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-i1*Pi*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_99(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_21(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_24(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_100(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_78(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-g1*h2*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-h2*i1*Pi)))
+((pol2DtEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_79(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g2*h1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_101(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_80(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g2*h1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-g2*i1*Pi)))
+((pol2DtEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_81(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-g1*h2*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_102(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_51(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g2*h1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+g2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_71(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-g1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_103(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_70(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g2*h1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-g2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_52(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-g1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_104(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_82(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_82(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_105(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_80(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_80(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+g1*h2*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+h2*i1*Pi)))
+((pol2DtEval::evalT_81(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_81(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g2*h1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_106(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_78(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_78(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-g2)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g2*h1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-g2*i1*Pi)))
+((pol2DtEval::evalT_79(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_79(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+h2)+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+g1*h2*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*Pi)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_107(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_70(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_70(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+g1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+i1*Pi)))
+((pol2DtEval::evalT_52(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_52(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g2*h1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+g2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g2*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_108(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_51(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_51(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+g1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+g1*i1*Pi*Pi)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+i1*Pi)))
+((pol2DtEval::evalT_71(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_71(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g2*h1*Pi)+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-g2)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-g2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g2*h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_109(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_83(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_83(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+g2)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+g2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_110(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_62(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g1*h2*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-h2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*Pi)))
+((pol2DtEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_77(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+h1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_111(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_76(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-h1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-i1*Pi)))
+((pol2DtEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_63(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+g1*h2*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-h2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+g1*h2*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_112(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_60(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-h1*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g1*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_113(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_75(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+h1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+-i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+h1*i1*Pi*Pi)))
+((pol2DtEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_61(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+g1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+-i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+g1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_114(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_84(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_115(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_76(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_76(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g1*h2*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+h2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*Pi)))
+((pol2DtEval::evalT_63(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_63(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+h1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_116(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_62(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_62(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_16(i1x2, g1x2, h1x2)*(+-h1*Pi)+pol2DrEval::evalR_17(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*Pi)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+-i1*Pi)))
+((pol2DtEval::evalT_77(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_77(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_10(i1x2, g1x2, h1x2)*(+-g1*h2*Pi)+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+h2)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+h2*i1*Pi)+pol2DrEval::evalR_14(i1x2, g1x2, h1x2)*(+-g1*h2*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_117(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_75(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_75(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+i1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*Pi)))
+((pol2DtEval::evalT_61(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_61(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+-h1*Pi)+pol2DrEval::evalR_22(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_23(i1x2, g1x2, h1x2)*(+i1*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+-h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_118(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_60(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_60(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_1(i1x2, g1x2, h1x2)*(+h1*Pi)+pol2DrEval::evalR_7(i1x2, g1x2, h1x2)*(+-g1*Pi)+pol2DrEval::evalR_8(i1x2, g1x2, h1x2)*(+-g1*i1*Pi*Pi)+pol2DrEval::evalR_2(i1x2, g1x2, h1x2)*(+h1*i1*Pi*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_119(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_85(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_19(i1x2, g1x2, h1x2)*(+1)+pol2DrEval::evalR_20(i1x2, g1x2, h1x2)*(+i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_120(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_86(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_86(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_121(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_87(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_87(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_0(i1x2, g1x2, h1x2)*(+-h2)+pol2DrEval::evalR_5(i1x2, g1x2, h1x2)*(+-h2*i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_122(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_84(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_84(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_123(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_85(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_85(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_12(i1x2, g1x2, h1x2)*(+-1)+pol2DrEval::evalR_13(i1x2, g1x2, h1x2)*(+-i1*Pi)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evalpol2D_124(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH) {
getWaveN;
double val = +(1*(+((pol2DtEval::evalT_21(i2x2, g2x2, h2x2) == 0) ? 0 :pol2DtEval::evalT_21(i2x2, g2x2, h2x2)*(+pol2DrEval::evalR_24(i1x2, g1x2, h1x2)*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
