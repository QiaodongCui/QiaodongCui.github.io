#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "elliptic/elliptic_basis_set_2D.h"


#include "util/util.h"
#include "util/timer.h"

namespace {
  
void testTensor() {
  const double b = 0.9;
  EllipticBasisSet2D basis(512, 5, 10, true, b);

  std::vector<Adv_Tensor_Type> Adv_tensor_;
  //basis.FillVariationalTensor(&Adv_tensor_);
  basis.outputTestTensorEntries(100, "./elliptic_tensorTest.txt", &Adv_tensor_);
  //BasisSet::VerifyAntisymmetric(Adv_tensor_);
}


}

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);
  
  testTensor();
  //testEntry();

  return 0;
}