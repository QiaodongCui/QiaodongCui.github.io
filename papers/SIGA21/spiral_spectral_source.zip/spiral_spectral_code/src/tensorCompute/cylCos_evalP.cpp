#include <vector>
#include "tensorCompute/cylCos_evalP.h"
cylCospEval::cylCospEval() {
pointers_.resize(9);
pointers_[0] = &evalP_0;
pointers_[1] = &evalP_1;
pointers_[2] = &evalP_2;
pointers_[3] = &evalP_3;
pointers_[4] = &evalP_4;
pointers_[5] = &evalP_5;
pointers_[6] = &evalP_6;
pointers_[7] = &evalP_7;
pointers_[8] = &evalP_8;
}


