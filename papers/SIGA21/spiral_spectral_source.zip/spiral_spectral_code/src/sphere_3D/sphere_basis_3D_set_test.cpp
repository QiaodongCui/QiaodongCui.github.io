#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "sphere_3D/sphere_basis_set_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "common/basis_set.h"

#include "util/util.h"
#include "util/timer.h"

using namespace std;

namespace {
  void testFwd() {
    const double b = 1.0;

    SphereBasisSet3D basis(64, 128, 256, 4,4,8, true);
    int numBasisAll = basis.numBasisAll();
    Eigen::VectorXd coef = Eigen::VectorXd::Zero(numBasisAll);
    VECTOR3_FIELD_3D field(128, 128, 128);
   
    basis.InverseTransformToVelocity(coef);
    //basis.InverseTransformToVelocity(coef);
    //basis.InverseTransformToVelocity(coef);
    //basis.ForwardTransformtoFrequency(field, &coef);
  }

  void testTensor() {
    SphereBasisSet3D basis(64, 64, 64, 2,4,8, false);
    vector<Adv_Tensor_Type> Adv_tensor_;
    basis.outputTestTensorEntries(100, "./sphere_tensorTest1.txt", &Adv_tensor_);
    //BasisSet::VerifyAntisymmetric(Adv_tensor_);
  }

  void testProlateOblate() {
    const double b = 0.9;
    SphereBasisSet3D basis(64, 128, 256, 4,8,16, true, false, true, b);
  }

  void testEntry() {
    SphereBasis3D basis_i(2, 0, 2, 3);
    SphereBasis3D basis_g(2, 2, 4, 1);
    SphereBasis3D basis_h(2, 4, 6, 1);
    LOG(INFO) << SphereBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
  }

  void testProlateTensor() {
    const double b = 0.9;
    SphereBasisSet3D basis(64, 64, 64, 4,4,4, true, true, false, b);
    vector<Adv_Tensor_Type> Adv_tensor_;
    Timer timer;
    timer.Reset();
    basis.outputTestTensorEntries(100, "./pro3D_tensorTest.txt", &Adv_tensor_);
    LOG(INFO) << timer.ElapsedTimeInSeconds();
  }
  
  void testEntryProlate() {
    const double b_ = 0.9;
    const string folder = "./Tensor/tables/prolate3D/";
    shared_ptr<IntegrationTable1DPtn> dotTable1D_;
    shared_ptr<TensorTable2D> dotTable2D_;
    shared_ptr<IntTable1DData> dotData_;

    shared_ptr<IntegrationTable1DPtn> tensorTable1D_;
    shared_ptr<TensorTable2D> tensorTable2D_;
    shared_ptr<IntTable1DData> tensorData_;;

    dotTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                          folder + "prolate3D_dot_1D_val.bin",
                                          folder + "prolate3D_dot_1D.txt"));
    dotTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "blistTableName.txt", 
                                                folder + "prolate3D_dot_2D.txt", false));
    dotData_.reset(new IntTable1DData(b_));
    dotData_->setIntTable(dotTable1D_);
    dotData_->set2DTable(dotTable2D_);

    tensorTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                          folder + "prolate3D_tensor_1D_val.bin",
                                          folder + "prolate3D_tensor_1D.txt"));
    tensorTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "pro3DTensorName.txt", 
                                                folder + "prolate_tensor_2D.txt", false));
    tensorData_.reset(new IntTable1DData(b_));
    tensorData_->setIntTable(tensorTable1D_);
    tensorData_->set2DTable(tensorTable2D_);

    ProlateOblate3D basis_i(1, 2, 2, 5, *dotData_, true);
    ProlateOblate3D basis_g(2, 4, 4, 1, *dotData_, true);
    ProlateOblate3D basis_h(1, 2, 2, 2, *dotData_, true);
    //ProlateOblate3D basis_f(2, 4, 6, 1 , *dotData_, false);

    //basis_i.printFullForm();
    //basis_f.printJCurl();
    //ProlateOblate3D::printCrossProd(basis_g, basis_h);
    LOG(INFO) << basis_i.computeTensorEntry(basis_g, basis_h, *tensorData_);
  }
  
  void testEntryOblate() {
    const double b_ = 0.9;
    const string folder = "./Tensor/tables/prolate3D/";
    shared_ptr<IntegrationTable1DPtn> dotTable1D_;
    shared_ptr<TensorTable2D> dotTable2D_;
    shared_ptr<IntTable1DData> dotData_;

    shared_ptr<IntegrationTable1DPtn> tensorTable1D_;
    shared_ptr<TensorTable2D> tensorTable2D_;
    shared_ptr<IntTable1DData> tensorData_;;

    dotTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                          folder + "oblate3D_dot_1D_val.bin",
                                          folder + "oblate3D_dot_1D.txt"));
    dotTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "blistTableName.txt", 
                                                folder + "oblate3D_dot_2D.txt", false));
    dotData_.reset(new IntTable1DData(b_));
    dotData_->setIntTable(dotTable1D_);
    dotData_->set2DTable(dotTable2D_);

    ProlateOblate3D basis_f(6, 2, 0, 7, *dotData_, false);
    //basis_i.printFullForm();
    basis_f.printJCurl();
    //LOG(INFO) << basis_i.computeTensorEntry(basis_g, basis_h, *tensorData_);
  }

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);

  //testProlateOblate();
  testFwd();
  //testTensor();
 //testEntry();
  //testProlateTensor();
  //testEntryProlate();
  //testEntryOblate();
}