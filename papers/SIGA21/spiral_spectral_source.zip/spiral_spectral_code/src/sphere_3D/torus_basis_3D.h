#ifndef TORUS_BASIS_3D_H
#define TORUS_BASIS_3D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>

#include "common/basic_function.h"
#include "3D/FIELD_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "sphere_3D/basis_3D.h"

class TorusBasis3D : public Basis3D {

public:
  // init, 2*wavenumber
  TorusBasis3D(const int k12, const int k22, const int k32, const int idx, const double& a):
    Basis3D(k12, k22, k32, idx),
    scale_(1.0/(a+1.0)), scale3_(scale_*scale_*scale_)
  {
    invNorm_ = 0; // Default zero.
    // Initialize DCT norm.
    int num_zeros = 0;
    if (k1x2 == 0) num_zeros ++;
    if (k2x2 == 0) num_zeros ++;
    if (k3x2 == 0) num_zeros ++;

    // need dct both directions
    if (num_zeros == 0) {
      DCTNorm_ = 0.125;
    } else if (num_zeros == 1) { // only dct one direction
      DCTNorm_ = 0.25;
    } else if (num_zeros == 2) {
      DCTNorm_ = 0.5;
    } else {  // dc component
      DCTNorm_ = 1.;
    }
    initBasicCoef();
    Normalize(a);
    curlSph(a);
    // scale so that the max physical length is [-1, 1]
  };

  void initBasicCoef();

  // 2*A[i1 r] + rA'[i1 r]
  static inline double rCos2Sin(const double& arg) {
    return 2.0*sin(arg) + arg*cos(arg);
  }

  static inline double rSinCos(const double& arg) {
    return -arg*sin(arg) + cos(arg);
  }

  ~TorusBasis3D(){};

  // compute on a catersian grid.
  void DiscretizeAdd(const double coef, FIELD_3D& r, FIELD_3D& theta, FIELD_3D& phi,
              VECTOR3_FIELD_3D* vfield);

  // compute on a spherical grid.
  void AddUniformU(const double coef, const int nR, const int nTheta, const int nPhi, double* ur, double* ut, double* up) const;

  double dotProd(const TorusBasis3D& other, const double& a) const;
  double dotProdScale(const TorusBasis3D& other, const double& a) const;

  void writeToFile(std::ofstream& out) const;
  
  static TorusBasis3D* fromFile(std::ifstream& in, const double& a);

  double ProjectUniformU(const int nR, const int nTheta, const int nPhi,
                         const double* ur, const double* ut, const double* up) const;

  double GetDCTNorm() const {
    return DCTNorm_;
  }

  // this is simply the transpose of toCartesianMat
  //void toSphericalMat(const double& t, const double& p, Matrix3d& mat);
  static void FillFields(FIELD_3D& r, FIELD_3D& theta, FIELD_3D& phi, const double& a);
  const BasicFunc& getPhiFunc(int idx) const {
    return phiFunc_[idx];
  }

  const BasicFunc& getCurPhi(int i, int j) const {
    return curlPhi_[i][j];
  }

  const std::vector<RTMultiply>& getRT(int idx) const {
    return RT_[idx];
  }

  const std::vector<RTMultiply>& getCurRT(int i, int j) const {
    return curlRT_[i][j];
  }
  
  // {SIN, COS, ZERO, ONE};
  // int_{phi = 0}^{2 \Pi} type1(i1*\phi)*type2(i2*\phi) d\phi 
  static double computePhiInt(const BasicFunc& fun1, const BasicFunc& fun2);
  
  // int_{\theta = 0}^{Pi} fun1*fun2*sin(\theta) d\theta
  static double computeThetaInt(const BasicFunc& fun1);

  //static double computeRInt(const BasicFunc& fun1, const int rPow);

  static double computeRTMultInt(const RTMultiply& rt1, const double a);

  void curlSph(const double& a);
  // cross product
  // a2 b3 - a3 b2
  // a3 b1 - a1 b3
  // a1 b2 - a2 b1
  static void crossProdPhi(const TorusBasis3D& phiG, const TorusBasis3D& phiH, std::vector<BasicFunc> (&crossPhi)[3][2]);
  static void crossProdRT( const TorusBasis3D& phiG, const TorusBasis3D& phiH, std::vector<RTMultiply> (&crossRT)[3][2]);
  
  static double integrateCurlCross(const BasicFunc& curP, const std::vector<BasicFunc>& crossP,
                                   const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT);
  
  static double computeTensorEntry(const TorusBasis3D& phiI, const TorusBasis3D& phiG, const TorusBasis3D& phiH);
  static double computeTensorEntryScale(const TorusBasis3D& phiI, const TorusBasis3D& phiG, const TorusBasis3D& phiH, const double& scale3);

  void printRT(const int idx) const {
    for (const auto& RT: RT_[idx]) {
      RT.print();
      printf("\n");
    }
  }

protected:

  Eigen::Vector3d computeRTP(const TorusBasis3D& other, const double& a) const;
  void Normalize(const double& a);

  double DCTNorm_;
  double poleNorm_;
  double norm2_;
  
  // basic form of the basis function
  //T R component along (r, \theta, \phi) direction.
  std::vector<RTMultiply> RT_[3];
  // type of phi along (r, \theta, \phi) direction.
  // global coefficients are into each phi components.
  BasicFunc phiFunc_[3];

  /* [3][3]
     rsin(t)D[A_p, t], rcos(t)A_p, -r D[A_t, p]
     rD[A_r, p] - rsin(t)A_p, -r^2sin(t)D[A_p, r]
     rsin(t)A_t + r^2sin(t)D[A_t, r] - rsin(t)D[A_r, t]
  */

  // curl data
  BasicFunc curlPhi_[3][3];
  std::vector<RTMultiply> curlRT_[3][3];

  // A constant scale to the basis so it lines up with the coordinates.
  const double scale_;
  const double scale3_;
};

//typedef std::unique_ptr<TorusBasis3D> basisPtr;

#endif // TORUS_BASIS_3D_H