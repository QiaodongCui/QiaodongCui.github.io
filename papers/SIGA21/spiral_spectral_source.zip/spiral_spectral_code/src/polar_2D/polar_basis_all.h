#ifndef POLAR_BASIS_ALL_H
#define POLAR_BASIS_ALL_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>
#include "2D/FIELD2D.h"
#include "2D/VFIELD2D.h"
#include "common/basic_function.h"
#include "2D/basis_2D.h"

class PolarBasisAll : public Basis2D {

public:
  // init, 2*wavenumber
  PolarBasisAll(const int k12, const int k22, const int idx):
  Basis2D(k12, k22), index_(idx)
  {
    init(true);
  };
  
  PolarBasisAll(const int k12, const int k22, const int idx, const bool norm):
  Basis2D(k12, k22), index_(idx) {
    init(norm);
  };
  
  ~PolarBasisAll(){};
  
  void init(bool norm) {
     invNorm_ = 0; // Default zero.
    // Initialize DCT norm.
    int num_zeros = 0;
    if (k1x2 == 0) num_zeros ++;
    if (k2x2 == 0) num_zeros ++;

    // need dct both directions
    if (num_zeros == 0) {
      DCTNorm_ = 0.25;
    } else if (num_zeros == 1) { // only dct one direction
      DCTNorm_ = 0.5;
    } else {  // dc component
      DCTNorm_ = 1.;
    }
    initBasicCoef();
    if (norm) {
      Normalize();
    }
    curlSph();
  }

  static void toCartesianMat(const double& t, Eigen::Matrix2d& mat);
  void DiscretizeAdd(const double coef, const FIELD2D& r, const FIELD2D& theta,
                    VFIELD2D* vfield) const;
  // compute ur along a uniform theta r grid
  void AddUniformU(const double coef, const int nR, const int nTheta, double* ur, double* ut) const;
  double ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const;
  double dotProd(const PolarBasisAll& other) const;

  double GetDCTNorm() const {
    return DCTNorm_;
  }

  void print() const {
    LOG(INFO) << "k1 " << k1 << " k2 " << k2 << " index " << index_ << " norm " << invNorm_;
  }
  
  int index() const {
    return  index_;
  }
  void initBasicCoef();
  void Normalize() {
    norm2_ = dotProd(*this);
    invNorm_ = 1.0/sqrt(norm2_);
  }

  // r*\nabla x f = r*D[f_t, r] + f_t - D[f_r, t]
  void curlSph();

  const BasicFunc& getPhiFunc(int idx) const {
    return phiFunc_[idx];
  }
  const std::vector<RTMultiply>& getRT(int idx) const {
    return RT_[idx];
  }

  const BasicFunc& getCurPhi(int i) const {
    return curlPhi_[i];
  }
  
  const std::vector<RTMultiply>& getCurRT(int i) const {
    return curlRT_[i];
  }

  static void crossProdPhi(const PolarBasisAll& phiG, const PolarBasisAll& phiH,
                                 std::vector<BasicFunc> (&crossPhi)[2]);
  static void crossProdRT(const PolarBasisAll& phiG, const PolarBasisAll& phiH,
                                std::vector<RTMultiply> (&crossRT)[2]);
  // int_{\theta = 0}^{Pi} fun1*fun2 d\theta 
  static double computeThetaInt(const BasicFunc& fun1, const BasicFunc& fun2);

  // int_{r = 0}^{1} fun1*fun2*r dr 
  static double computeRInt(const BasicFunc& fun1, const BasicFunc& fun2);
  static double computeVThetaInt(const std::vector<BasicFunc>& t1, const std::vector<BasicFunc>& t2);
  static double computeVRInt(const std::vector<BasicFunc>& r1, const std::vector<BasicFunc>& r2);
  static double computeRTMultInt(const RTMultiply& rt1, const RTMultiply& rt2);
  
  static double integrateCurlCross(const BasicFunc& curlP, const std::vector<BasicFunc>& crossP,
                            const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT);
  static double computeTensorEntry(const PolarBasisAll& phiI, const PolarBasisAll& phiG, const PolarBasisAll& phiH);

  void writeToFile(std::ofstream& out) const;
  
  static PolarBasisAll* fromFile(std::ifstream& in);
  
  const double getInvWaveN() const {
    if (index_ == 0 || index_ == 1) {
      return 1.0/k2;
    }
    return 1.0;
  }
protected:

  double DCTNorm_;
  double norm2_;
  // index for different kind of basis functions
  int index_;
  
  // basic form of the basis function
  //T R component along (r, \theta, \phi) direction.
  // RT[0]->R
  // RT[1]->T
  std::vector<RTMultiply> RT_[2];
  // Copied from sphere3D basis functions, in this case the function along 
  // phi are all constant numbers with coefficients.
  BasicFunc phiFunc_[2];
  /* [3][3]
     rsin(t)D[A_p, t], rcos(t)A_p, -r D[A_t, p]
     rD[A_r, p] - rsin(t)A_p, -r^2sin(t)D[A_p, r]
     rsin(t)A_t + r^2sin(t)D[A_t, r] - rsin(t)D[A_r, t]
  */

  // curl data
  BasicFunc curlPhi_[3];
  std::vector<RTMultiply> curlRT_[3];

};

#endif // POLAR_BASIS_ALL_H