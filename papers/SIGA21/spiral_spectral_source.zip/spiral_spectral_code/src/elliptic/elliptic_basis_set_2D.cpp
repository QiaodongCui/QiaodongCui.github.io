#include <algorithm>
#include <iomanip>

#include "elliptic/elliptic_basis_set_2D.h"
#include "elliptic/elliptic_polar_share.h"
#include "util/read_write_tensor.h"

#define ELLIPTICADDARG ,*tabData_
void EllipticBasisSet2D::allocateBasisMGS() {
  ALLOCATE_MGS_SHARE(ellipticPtr, EllipticBasis2D, ELLIPTICADDARG);
  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    waveNum2_[i] = k1*k1 + k2*k2;
  }
}
#undef ELLIPTICADDARG

#define dotProdMarco(arg, i,j) arg[i]->dotProd(*arg[j], *tabData_)*arg[i]->GetInvNorm()*arg[j]->GetInvNorm();
// Run MGS on a set of basis functions stored in in, and orthogonalize them. The kept basis
// is stored in out. The basis functions with distinct part smalelr than thresh of existing basis
// are thrown away. Coef are a matrix which kepts the coefficients of MGS. m is the number of
// basis functions that are kept.
void EllipticBasisSet2D::runMGS(const double thresh, const std::vector<ellipticPtr>& in, std::vector<ellipticPtr>& out,
            Eigen::MatrixXd& Coef, int& m) {
  
  RUNMGS_SHARE(dotProdMarco);
  /* test
  Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  for (int i = 0; i < reduced.rows(); i++) {
    reduced(i,i) -= 1.0;
  }
  LOG(INFO) << reduced.norm();*/
}

void EllipticBasisSet2D::computeWeightF() {
  h_ = (double*) malloc(sizeof(double)*nTheta_*nR_);
  memset(h_, 0x00, sizeof(double)*nTheta_*nR_);
  sqrtCR_ = (double*) malloc(sizeof(double)*nR_);
  memset(sqrtCR_, 0x00, sizeof(double)*nR_);
  
  r_ = FIELD2D(N_, N_);
  t_ = FIELD2D(N_, N_);
  x_ = FIELD2D(nTheta_, nR_);
  y_ = FIELD2D(nTheta_, nR_);
  
  erC_ = (Eigen::Vector2d*) malloc(sizeof(Eigen::Vector2d)*N_*N_);
  memset(erC_, 0x00, sizeof(Eigen::Vector2d)*N_*N_);
  etC_ = (Eigen::Vector2d*) malloc(sizeof(Eigen::Vector2d)*N_*N_);
  memset(etC_, 0x00, sizeof(Eigen::Vector2d)*N_*N_);

  erP_ = (Eigen::Vector2d*) malloc(sizeof(Eigen::Vector2d)*nTheta_*nR_);
  memset(erP_, 0x00, sizeof(Eigen::Vector2d)*nTheta_*nR_);
  etP_ = (Eigen::Vector2d*) malloc(sizeof(Eigen::Vector2d)*nTheta_*nR_);
  memset(etP_, 0x00, sizeof(Eigen::Vector2d)*nTheta_*nR_);

  for (int j = 0; j < nR_; j++) {
    double r = ((double)(j) + 0.5)*dr_;   // [0-1]
    sqrtCR_[j] = sqrt(1.0 + c_*c_*r*r);
  }

  for (int j = 0; j < nR_; j++) {
    const double r = ((double)(j) + 0.5)*dr_;   // [0-1]
    const double sqrtCR = sqrtCR_[j];
    for (int i = 0; i < nTheta_; i++) {
      const double t = ((double)(i) + 0.5)*dTheta_;// - M_PI;  // [0, 2*pi]
      const double h = sqrt(c_*c_*r*r + sin(t)*sin(t));
      h_[i + j*nTheta_] = h;
      x_[i + j*nTheta_] = a_*sqrtCR*cos(t);
      y_[i + j*nTheta_] = b_*r*sin(t);
      erP_[i + j*nTheta_] << c_*r*cos(t)/h, sqrtCR*sin(t)/h;
      etP_[i + j*nTheta_] << -sqrtCR*sin(t)/h, c_*r*cos(t)/h;
    }
  }

  // iterate over catersian grid.
  // [-1, 1]x[-1, 1]
  const double dx = 2.0 / N_;
  const double dy = 2.0 / N_;

  for (int j = 0; j < N_; j++) {
    for (int i = 0; i < N_; i++) {
      const double x = -1.0 + ((double)(i) + 0.5)*dx;
      const double y = -1.0 + ((double)(j) + 0.5)*dx;
      double r = 0, t = 0;
      EllipticBasis2D::CatersianToElliptic(a_, c_, x, y, r, t);
      r_[i + j*N_] = r;
      t_[i + j*N_] = t;
      const double h = sqrt(c_*c_*r*r + sin(t)*sin(t));
      const double sqrtCR = sqrt(1.0 + c_*c_*r*r);
      erC_[i + j*N_] << c_*r*cos(t)/h, sqrtCR*sin(t)/h;
      etC_[i + j*N_] << -sqrtCR*sin(t)/h, c_*r*cos(t)/h;
    }
  }
}

#undef dotProdMarco


void EllipticBasisSet2D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  std::vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[index][Coefidx[index]].coef = fieldCoef[i]*C_x;
    Coefidx[index]++;
  }
}

// NOT OPTIMIZED WITH TRIMMED PLAN

//#define TEST

// 1) Do int wavenumber first, with two different kinds.
// 2) USE [0, 2Pi] in theta range to avoid additional dcts.
void EllipticBasisSet2D::InverseTransformToVelocity(
  const Eigen::VectorXd& coefficients, VFIELD2D* field) {

  Eigen::VectorXd fieldCoef = A_.transpose()*coefficients;
  //fieldCoef[phiCoef_[2].size() + phiCoef_[0].size() + phiCoef_[3].size() + phiCoef_[1].size()] = 1.0;
  //fieldCoef.setZero();
  // cached mem
  //CHECK_EQ(fieldCoef.size(), all_basis_.size());
  //CHECK_EQ(cached_basis_.size(), fieldCoef.size());

  //field->clear();
  //for (int i = 0; i < fieldCoef.size(); i++) {
  //  field->addField(fieldCoef[i], cached_basis_[i]);
  //}
  //return;

  // test
#ifdef TEST
    srand((unsigned int) (time(0)));
    fieldCoef = Eigen::VectorXd::Random(fieldCoef.size());
#endif

  INVERSE_R1_SHARE(ELLIPSE_R1_WEIGHT);

  INVERSE_T1_SHARE(ELLIPSE_T1_WEIGHT);

  INVERSE_T2_SHARE(ELLIPSE_T2_WEIGHT);

  // last part, phi^4
  int rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;
  clearPointerSize(rtemp0_,  rsize);
  // NEED 1D PLANS
  for (const auto& p : phiCoef_[4]) {
    // RODFT
    rtemp0_[p.i1x2/divd - 1] += p.coef;
  }
  fftw_execute_r2r(IsinR1D_, rtemp0_, rtemp1_);

  for (int j = 0; j < nR_; j++ ) {
    double r = ((double)(j) + 0.5)*dr_;
    for (int i = 0; i < nTheta_; i++) {
      utV[i + j*nTheta_] += rtemp1_[j]*c_*r;
    }
  }

  InversetTransformEnrich(fieldCoef, urV, utV);
  
  for (int j = 0; j < nR_; j++ )
    for (int i = 0; i < nTheta_; i++) {
      urV[i + j*nTheta_] /= h_[i + j*nTheta_];
      utV[i + j*nTheta_] /= h_[i + j*nTheta_];
    }

#ifdef TEST
    double *rtest, *ttest;
    rtest = (double*) malloc(sizeof(double)*nTheta_*nR_);
    std::memset(rtest, 0x00, sizeof(double)*nTheta_*nR_);
    ttest = (double*) malloc(sizeof(double)*nTheta_*nR_);
    std::memset(ttest, 0x00, sizeof(double)*nTheta_*nR_);
    computeUniformRTNumerical(fieldCoef, nR_, nTheta_, rtest, ttest);
    Eigen::Map<Eigen::VectorXd> rtestV(rtest, nTheta_*nR_);
    Eigen::Map<Eigen::VectorXd> ttestV(ttest, nTheta_*nR_);
    LOG(INFO) << "rdiff " << (rtestV - urV).norm() << " tdiff " << (ttestV - utV).norm();
    //exit(0);
#endif

  // for (int j = 0; j < nR_; j++) {
  //   for (int i = 0; i < nTheta_; i++) {
  //     polarV_(i,j)[0] = urV[i + j*nTheta_];
  //     polarV_(i,j)[1] = utV[i + j*nTheta_];
  //   }
  // }

  interpolateToCartesian(field);
  //all_basis_[phiCoef_[2].size() + phiCoef_[0].size() + phiCoef_[3].size() + phiCoef_[1].size()]->DiscretizeAdd(1.0, r_, t_, field);
}


void EllipticBasisSet2D::InversetTransformEnrich(const Eigen::VectorXd& fieldCoef, Eigen::Map<Eigen::VectorXd>& vr, Eigen::Map<Eigen::VectorXd>& vt) {
  
  INVERSE_R2_SHARE(ELLIPSE_R2_WEIGHT);

  INVERSE_T3_SHARE(ELLIPSE_T3_WEIGHT);

  INVERSE_T4_SHARE(ELLIPSE_T4_WEIGHT);
}

//#define TEST

// weight with jacobian divided by h (a b h/sqrtCR) 
void EllipticBasisSet2D::weightJacobian(double* ptr) {
  for (int j = 0; j < nR_; j++ ) {
    for (int i = 0; i < nTheta_; i++) {
      ptr[i + j*nTheta_] *= a_*b_*h_[i + j*nTheta_]/sqrtCR_[j];
    }
  }
}

// Input a std::vector field, transform and output the basis coefficients.
void EllipticBasisSet2D::ForwardTransformtoFrequency(
  const VFIELD2D& field, Eigen::VectorXd* coefficients) {

  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();
  
  interpolateToPolar(field);

  weightJacobian(urTemp_);
  weightJacobian(utTemp_);
  int divd = !boundaryCnd_ ? 1 : 2;
  int divd1 = boundaryCnd_ ? 1 : 2;

  //----------------------------FFTW ur----------------------------------
  // Iterate over all the coefficients and put it into the field.
  ClearOdd();
  ClearExt();
  /*for (int j = 0; j < nR_; j++) {
    for (int i = 0; i < nTheta_; i++) {
      urTemp_[i + j*nTheta_] = polarF_(i,j)[0];
      utTemp_[i + j*nTheta_] = polarF_(i,j)[1];
    }
  }
  polarF_.clear();*/

  // now the field is interpolated to ur, ut field.
  // test
#ifdef TEST
    srand((unsigned int) (time(0)));
    double *ur, *ut;
    ur = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
    ut = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
    Eigen::Map<Eigen::VectorXd> urV(ur, nR_*nTheta_);
    Eigen::Map<Eigen::VectorXd> utV(ut, nR_*nTheta_);
    urV.setZero();
    utV.setZero();
    urV = Eigen::VectorXd::Random(nR_*nTheta_);
    utV = Eigen::VectorXd::Random(nR_*nTheta_);
    weightJacobian(urTemp_);
    weightJacobian(utTemp_);
    ClearuT();
    ClearuR();
    memcpy(urTemp_, ur, sizeof(double)*nR_*nTheta_);
    memcpy(utTemp_, ut, sizeof(double)*nR_*nTheta_);
#endif
  
  FORWARD_R1_SHARE(ELLIPSE_R1F_WEIGHT);

  ForwardTransformEnrichUR(fieldCoef);

  //----------------------------FFTW ut----------------------------------s
  FORWARD_T1_SHARE(ELLIPSE_T1F_WEIGHT);

  FORWARD_T2_SHARE(ELLIPSE_T2F_WEIGHT);
  
  // last part, phi^4
  rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;
  clearPointerSize(rtemp0_,  rsize);
  
  for (int j = 0; j < nR_; j++ ) {
    double sum = 0;
    const double r = ((double)(j) + 0.5)*dr_;
    for (int i = 0; i < nTheta_; i++) {
      sum += utTemp_[i + j*nTheta_]*c_*r;
    }
    rtemp0_[j] = sum;
  }

  fftw_execute_r2r(FsinR1D_, rtemp0_, rtemp1_);

  // NEED 1D PLANS
  for (auto& p : phiCoef_[4]) {
    // we are doing one dct, need to offset 0.25 factor in assignPairCoef
    // RODFT
    p.coef += rtemp1_[p.i1x2/divd - 1]*2.0;
  }
  
  ForwardTransformEnrichUT1(fieldCoef);
  ForwardTransformEnrichUT2(fieldCoef);

  assignPairCoef(fieldCoef);

  *coefficients = A_*fieldCoef;
#ifdef TEST
    Eigen::VectorXd projCoef = Eigen::VectorXd::Zero(all_basis_.size());
    for (int i = 0; i < all_basis_.size(); i++) {
      projCoef[i] = all_basis_[i]->ProjectUniformU(nR_, nTheta_, ur, ut);
    }
    LOG(INFO) << "diff: " << (projCoef - fieldCoef).norm() << " " << projCoef.norm() << " " << fieldCoef.norm();
    //exit(0);
#endif

}

#undef TEST

void EllipticBasisSet2D::ForwardTransformEnrichUR(Eigen::VectorXd& fieldCoef) {
  FORWARD_R2_SHARE(ELLIPSE_R2F_WEIGHT);
}

void EllipticBasisSet2D::ForwardTransformEnrichUT1(Eigen::VectorXd& fieldCoef) {
  FORWARD_T3_SHARE(ELLIPSE_T3F_WEIGHT);
}

void EllipticBasisSet2D::ForwardTransformEnrichUT2(Eigen::VectorXd& fieldCoef) {
  FORWARD_T4_SHARE(ELLIPSE_T4F_WEIGHT);
}

// compute the ur, ut on a uniform r, t grid, test only.
void EllipticBasisSet2D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut) {
  memset(ur, 0x00, sizeof(double)*nTheta*nR);
  memset(ut, 0x00, sizeof(double)*nTheta*nR);
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    all_basis_[i]->AddUniformU(fullCoef[i], nR, nTheta, ur, ut);
  }
}


void EllipticBasisSet2D::projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    fullCoef[i] = all_basis_[i]->ProjectUniformU(nR, nTheta, fr, ft);
  }
}

void EllipticBasisSet2D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size()) << fieldCoef.size() << " vs " << all_basis_.size();
  fieldCoef.setZero();
  std::vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    // 0.125 comes from 2 factor from foward dcts. This funcion assumes doing dcts along three
    // directions.
    double C_x = all_basis_[i]->GetInvNorm()*0.25;
    fieldCoef[i] += phiCoef_[index][Coefidx[index]].coef*C_x*dr_*dTheta_;
    Coefidx[index]++;
  }
}

#define interPol(arg_)\
(wt0 * (wr0 * arg_[i000] + wr1 * arg_[i010]) +\
 wt1 * (wr0 * arg_[i100] + wr1 * arg_[i110]))\

void EllipticBasisSet2D::interpolateToCartesian(VFIELD2D* field) {
  CHECK(field->getxRes() == N_ && field->getyRes() == N_);
  field->clear();
  // iterate over catersian grid.
  // [-1, 1]x[-1, 1]

  #pragma omp parallel for
  for (int j = 0; j < N_; j++) {
    for (int i = 0; i < N_; i++) {
      const int cidx = i + j*N_;
      const double r = r_[cidx];
      const double t = t_[cidx];

      // outside of the ellipse
      if (r > 1.0)
        continue;
      
      int r0 = (int)(r/dr_);
      int r1 = r0 + 1;
      int t0 = (int)(t/dTheta_);
      int t1 = t0 + 1;
      
      // clamp
      r0 = (r0 < 0) ? 0 : r0;
      r1 = (r1 > nR_ - 1) ? nR_ - 1 : r1;
      // periodic bc
      t0 = (t0 < 0) ? nTheta_ + t0 : t0;
      t1 = (t1 > nTheta_ - 1) ? t1 - nTheta_ : t1;

      // get interpolation weights
      const double wt1 = t/dTheta_ - t0;
      const double wt0 = 1.0 - wt1;
      const double wr1 = r/dr_ - r0;
      const double wr0 = 1.0 - wr1;

      const int i000 = t0 + r0 * nTheta_;
      const int i010 = t0 + r1 * nTheta_;
      const int i100 = t1 + r0 * nTheta_;
      const int i110 = t1 + r1 * nTheta_;
      Eigen::Vector2d uEllip(0,0);
      uEllip << interPol(urTemp_), interPol(utTemp_);
      
      // ux = ur*erC_x + ut*etC_x
      // uy = ur*erC_y + ut*etC_y
      (*field)[cidx][0] = uEllip[0]*erC_[cidx][0] + uEllip[1]*etC_[cidx][0];
      (*field)[cidx][1] = uEllip[0]*erC_[cidx][1] + uEllip[1]*etC_[cidx][1];
    }
  }
}

#undef interPol

void EllipticBasisSet2D::interpolateToPolar(const VFIELD2D& field) {
  ClearuR();
  ClearuT();
  
  CHECK(field.getxRes() == N_ && field.getyRes() == N_);

  #pragma omp parallel for
  for (int j = 0; j < nR_; j++) {
    const double r = ((double)(j) + 0.5)*dr_; // [0-1]
    for (int i = 0; i < nTheta_; i++) {
      const double t = ((double)(i) + 0.5)*dTheta_; // [0, 2*pi]
      // need to get the nearest catersian grid
      const double x = (x_[i + j*nTheta_] + 1.0)*0.5;
      const double y = (y_[i + j*nTheta_] + 1.0)*0.5;
      VEC2 vCat = field.GetVelocity(x*N_, y*N_);
      Eigen::Vector2d vf(vCat[0], vCat[1]);
      urTemp_[i + j*nTheta_] = erP_[i + j*nTheta_].dot(vf);
      utTemp_[i + j*nTheta_] = etP_[i + j*nTheta_].dot(vf);
    }
  }

}

void EllipticBasisSet2D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {
  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  const double pow_w = - 0.00;
  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;
  
#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const EllipticBasis2D& basis_i = *all_basis_[i];
        const EllipticBasis2D& basis_g = *all_basis_[g];
        const EllipticBasis2D& basis_h = *all_basis_[h];

        // double Cigh = PolarBasisAll::computeTensorEntry(basis_i, basis_g, basis_h);
        double Cigh = basis_i.computeTensorEntry(basis_g, basis_h, *tabData_);
        CHECK(std::isfinite(Cigh)) << i << " " << g << " " << h;

        if (Cigh == 0) {
          continue;
        }
        
        // IncrementMatrixEntry(&(*Adv_tensor)[k],i, j, Cijk*InvNormijk);
        tripletList.push_back(T(g,h, Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  //VerifyAntisymmetric(*Adv_tensor);
  //exit(0);
}

void EllipticBasisSet2D::outputTestTensorEntries(const int numWant, const std::string& fname, 
            std::vector<Adv_Tensor_Type> *Adv_tensor) {

  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  
  std::vector<Eigen::Vector3i> indices;
  
  for (int i = 0; i < numBasisAll_; i++) {
    LOG(INFO) << i;
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const EllipticBasis2D& basis_i = *all_basis_[i];
        const EllipticBasis2D& basis_g = *all_basis_[g];
        const EllipticBasis2D& basis_h = *all_basis_[h];

        double Cigh = basis_i.computeTensorEntry(basis_g, basis_h, *tabData_);
        CHECK(std::isfinite(Cigh)) << i << " " << g << " " << h;

        if (abs(Cigh) <1e-12) {
          continue;
        }

        indices.push_back(Eigen::Vector3i(i,g,h));
        tripletList.push_back(T(g,h, Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  VerifyAntisymmetric(*Adv_tensor);
  BasisSet::VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  std::ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    ellipticPtr basis_i = all_basis_[indices[i][0]];
    ellipticPtr basis_g = all_basis_[indices[i][1]];
    ellipticPtr basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " <<
           std::setprecision(12) << basis_i->GetInvNorm() << " " << basis_g->GetInvNorm()
           << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}

void EllipticBasisSet2D::writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const {
  // boundaryCnd_
  out.write(reinterpret_cast<const char *>(&boundaryCnd_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&a_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&b_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&c_), sizeof(double));

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }

  //writeEigenDense_binary(out, H_);
  writeEigenDense_binary(out, A_);
  int tensorType = 6;

  WriteTensor(Adv_tensor_, tensorType, out);
}

void EllipticBasisSet2D::readFromFile(std::ifstream& in) {

  in.read(reinterpret_cast<char*>(&boundaryCnd_), sizeof(bool));
  in.read(reinterpret_cast<char*>(&numBasisAll_), sizeof(int));
  in.read(reinterpret_cast<char*>(&numBasisOrtho_), sizeof(int));
  in.read(reinterpret_cast<char*>(&a_), sizeof(double));
  in.read(reinterpret_cast<char*>(&b_), sizeof(double));
  in.read(reinterpret_cast<char*>(&c_), sizeof(double));
  b_ = 0.9;
  a_ = sqrt(1.0 - b_*b_);
  c_ = b_/a_;
  const std::string tableFolder = "./Tensor/tables/elliptic/";
  queryTable_.reset(new IntegrationTable1DPtn(tableFolder + "bList.csv", tableFolder + "k1x2Range.csv", tableFolder + "fun1DVal.bin",
                        tableFolder + "pattern1D.txt"));
  tabData_.reset(new IntTable1DData(b_));
  tabData_->setIntTable(queryTable_);

   // neumann
  for (int i = 0; i < numBasisAll_; i++) {
    all_basis_.push_back(ellipticPtr(EllipticBasis2D::fromFile(in, *tabData_)));
  }

  readEigenDense_binary(in, A_);

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    waveNum2_[i] = k1*k1 + k2*k2;
  }
  
  phiCoef_.resize(5);
  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    phiCoef_[index].push_back(pairedCoefPolar(all_basis_[i]->WN1x2(), all_basis_[i]->WN2x2(), 0));
  }
  LOG(INFO) << "all_basis_: " << all_basis_.size();
  // Tensor is read in fluid cpp
}