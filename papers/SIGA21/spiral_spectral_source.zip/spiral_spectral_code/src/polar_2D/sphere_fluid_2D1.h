#ifndef SPHERE_FLUID_2D1_H
#define SPHERE_FLUID_2D1_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>
#include <memory>
#include <learnopengl/shader_m.h>

#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "3D/drawer_3d.h"

#include "common/eigen_fluid.h"
#include "common/particle_sph_3d.h"
#include "common/surface_basis_set_2D.h"
#include "polar_2D/polar_basis_set_2D.h"
#include "polar_2D/sphere_basis_set_2D.h"
#include "solver/integrator_2d.h"
#include "elliptic/prolate_oblate_2D.h"

#include "setting.h"
#include "util/colorMap.h"
#include "util/gl4_drawer.h"
#include "util/timer.h"

class SphereFluid2D1: public EigenFluid {
public:
  SphereFluid2D1(
    const int xRes, const int yRes, const int basis_dim,
    const double dt,
    const std::string& basis_type,
    const std::string& integrator_type,
    double buoyancy, double visc, 
    const int num_particles, const int total_frame, const double added_smoke_density,
    const std::string tensor_fname, const double tensorWeight, const double b,
    const float densityPtlWeight,  const int maxDensityParticles, const int scenario,
    const bool output_texture, const std::string& texture_folder, const bool headless,
    const bool writeRGB, const bool writeVelocity, const double blendW, const double omega):
    EigenFluid(basis_dim, dt, buoyancy, visc, num_particles, total_frame, basis_type, tensor_fname,
                 tensorWeight, integrator_type),
    nTheta_(xRes), nPhi_(xRes*2), dTheta_(M_PI/nTheta_), dPhi_(2.0*M_PI/nPhi_),
    added_smoke_density_(added_smoke_density), b_(b), a_(sqrt(1.0 - b*b)), c_(b/sqrt(1.0 - b*b)),
    densityPtlWeight_(densityPtlWeight), maxDensityParticles_(maxDensityParticles*1000000), scenario_(scenario),
    output_texture_(output_texture), texture_folder_(texture_folder), headless_(headless),
    writeRGB_(writeRGB),writeVelocity_(writeVelocity), blendW_(blendW), omega_(omega) {
      if (! isfinite(a_) || !isfinite(b_) || ! isfinite(c_)) {
        a_ = 0;
        b_ = 1.0;
        c_ = 1.0;
      }
      // TODO: modify the LaplacianBasisSet2D to support differemt xRes and yRes.
      CHECK(xRes % 2 == 0) << "xres even";
      CHECK_EQ(xRes, yRes) << "Only support square domain for now.";
      dx_ = 1.0 /nPhi_;
      Initialize();
    }
  
  ~SphereFluid2D1(){
  }

  // Perform the forward step.
  void Step();
  void DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& rot,
                   const double& ptl_length);
  
  void DrawCoefficients(const double multi_factor);
  void DrawObstacles() {};
  void AddBuoyancy();

  void AddSmokeTestCase(const int xpos, const int ypos, const int width,
                        const int height, const double amount);
  void addForcePatch(const int xpos, const int ypos, const int width,
                     const int height, const VEC2& f);
  void ReSeedParticles() {
    basis_->ReSeedParticles(particles_);
  }

  bool isFinished(){return quit_;}
  
  bool addBounyancyOnce = false;
  const std::vector<ParticleSph3D>& particles() {
    return particles_;
  }
  double dt() {
    return dt_;
  }
  double dx() {
    return dx_;
  }

  int nPhi(){return nPhi_;}
  int nTheta(){return nTheta_;}
  
  void writeTextureImage(const std::string& path);

  double b() {return b_;}
  void setParticleColor();
  
protected:

  void Initialize();
  void averageImg(const int width, const int height, const int channels, unsigned char *img);
  void resetDensity();

  // The resolution of the velocity field.
  const int nTheta_;
  const int nPhi_;
  double dTheta_;
  const double dPhi_;
  const double added_smoke_density_;

  double dx_;

  Eigen::VectorXd tempVector_;
  Eigen::VectorXd fieldCoef_;
  
  std::shared_ptr<SurfaceBasisSet2D> basis_;

  // Class to draw stuff.
  std::unique_ptr<Drawer3D> drawer_;
  std::unique_ptr<coeffcientDrawGL4> coefDrawer_;
  
  // These are in [phi, theta] velocity components.
  // Velocity field.
  VFIELD2D velocity_;
  // Force field.
  VFIELD2D force_;
  FIELD2D forceMag_;

  // Density field.
  FIELD2D density_;
  FIELD2D density_old_;

  FIELD2D densityG_;
  FIELD2D densityG_old_;

  FIELD2D densityB_;
  FIELD2D densityB_old_;

  FIELD2D forceMask_;

  FIELD2D initDensityR_;
  FIELD2D initDensityG_;
  FIELD2D initDensityB_;

  double initDensityTotal_;
  
  // Particles.
  std::vector<ParticleSph3D> particles_;
  
  const int nDensityParticle_ = 100000;
  const int maxParticlePerCell_ = 8;
  
  void AddExternalForce();
  void AddDensity(const int x, const int y, const int width,
                  const int height, const double amount, FIELD2D* field);

  void setInitColor(const int x, const int y, const int width,
                  const int height, const Eigen::Vector3f& col);
  
  void AdvectDensity();

  void initDensityParticles();
  
  std::default_random_engine m_gen_;

  //----------------- Elliptic params.
  double b_;
  double a_;
  double c_;
  bool is_prolate_ = false;
  bool is_oblate_ = false;

  drawerCollection drawers_;
  std::unique_ptr<ParticleSystem> particleSys_;
  std::vector<Eigen::Vector3f> particleColor_;
  // save out the initial position of particles.
  std::vector<Eigen::Vector3f> initPos_;

  const float densityPtlWeight_;
  const int maxDensityParticles_;
  const int scenario_;

  const bool output_texture_;
  const std::string texture_folder_;

  const bool headless_;
  const bool writeRGB_;
  const bool writeVelocity_;
  std::shared_ptr<ColorMap> colorMap_;
  const double blendW_;
  // coriolis force param
  const double omega_;
  Adv_Tensor_Type sparseA_;
};

#endif  // SPHERE_FLUID_2D1_H
