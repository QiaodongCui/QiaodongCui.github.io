#ifndef INTEGRATOR_RK4_H
#define INTEGRATOR_RK4_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>

#include "integrator_2d.h"
// Runge Kutta 4 explicit integrator.
class IntegratorRK4 : public Integrator2D {
public:
  IntegratorRK4() : Integrator2D() {};
  ~IntegratorRK4(){};
  void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) override;
protected:
  
};

#endif  //INTEGRATOR_RK4_H
