#include <Eigen/Eigen>
#include <math.h>

#include "3D/trig_integral_3d.h"
#include "common/basic_function.h"
#include "polar_2D/torus_basis_2D.h"
#include "sphere_3D/torus_basis_3D.h"
#include "util/transform.h"
#include "util/util.h"

using namespace std;

namespace {
// {SIN, COS, ZERO, ONE};
// int_{phi = 0}^{2 \Pi} type1(i1*\phi) d\phi 
double computePhiOneInt(const FUNTYPE type1, const int i1) {
  if (type1 == SIN || type1 == ZERO)
    return 0;
  else if (type1 == COS)
    return i1 == 0 ? 2.0*M_PI : 0;
  else if (type1 == ONE)
    return 2.0*M_PI;

  LOG(FATAL) << "unsupported type";
  return 0.0;
};

// {SIN, COS, ZERO, ONE};
// int_{\theta = 0}^{Pi} fun1*sin(\theta) d\theta 
double computeThetaOneInt(const BasicFunc& fun1) {
  if (fun1.type == ZERO)
    return 0;
  else if (fun1.type == ONE)  // int_{t = 0}^{Pi} sin(t) dt = 2.0
    return fun1.coef*2.0;
  else if (fun1.type == COS)  // cos(i1 t)sin(t) -> sin
    return fun1.coef*0.5*(-IntegralSinInt(fun1.wnx2/2 - 1) + IntegralSinInt(fun1.wnx2/2 + 1));
  else if (fun1.type == SIN)  // sin(i1 t)sin(t) -> cos
    return fun1.coef*0.5*(IntegralCosInt(fun1.wnx2/2 + 1) - IntegralCosInt(fun1.wnx2/2 + 1));

  LOG(FATAL) << "unsupported type";
  return 0.0;  
};

// {SIN, COS, ZERO, ONE};
// int_{r = 0}^{1} fun1*r^2 dr 
double computeROneInt(const BasicFunc& fun1) {
  CHECK(fun1.dir == R);

  BasicFunc fr2(fun1);
  fr2.rPower += 2;
  return fr2.integrate();
};

};

void TorusBasis3D::initBasicCoef() {
  double invk2 = 1.0;
  if (k2x2 != 0)
    invk2 = 1.0/k2;
  double invk3 = 1.0;
  if (k3x2 != 0)
    invk3 = 1.0/k3;

  // seee from basisAnalysis_3D.pdf in the doc
  switch (index_) {
    // two regular basis
    case 0:
            phiFunc_[0] = BasicFunc(SIN, P, k3x2, k2*k3);
            phiFunc_[1] = BasicFunc(SIN, P, k3x2, -k3);
            phiFunc_[2] = BasicFunc(COS, P, k3x2, -1.0);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0);
    break;
  
    case 1:
            phiFunc_[0] = BasicFunc(COS, P, k3x2, k2*k3);
            phiFunc_[1] = BasicFunc(COS, P, k3x2, -k3);
            phiFunc_[2] = BasicFunc(SIN, P, k3x2, 1.0);
            CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0);
    break;
    // enrich along pole line
    case 2:
            phiFunc_[0] = BasicFunc(SIN, P, k3x2, k2*k3);
            phiFunc_[1] = BasicFunc(SIN, P, k3x2, k3);
            phiFunc_[2] = BasicFunc(COS, P, k3x2, 1.0);
            CHECK(k1x2 > 0 && k2x2 >= 0 && k3x2 > 0);
    break;
    
    case 3:
            phiFunc_[0] = BasicFunc(COS, P, k3x2, k2*k3);
            phiFunc_[1] = BasicFunc(COS, P, k3x2, k3);
            phiFunc_[2] = BasicFunc(SIN, P, k3x2, -1.0);
            CHECK(k1x2 > 0 && k2x2 >= 0 && k3x2 > 0);
    break;

    // enrich at the center
    case 4:
            phiFunc_[0] = BasicFunc(SIN, P, k3x2, k3);
            phiFunc_[1] = BasicFunc(SIN, P, k3x2, k3);
            phiFunc_[2] = BasicFunc(COS, P, k3x2, 1.0);
            CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 > 0);
    break;

    case 5:
            phiFunc_[0] = BasicFunc(COS, P, k3x2, k3);
            phiFunc_[1] = BasicFunc(COS, P, k3x2, k3);
            phiFunc_[2] = BasicFunc(SIN, P, k3x2, -1.0);
            CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 > 0);
    break;

    case 6:
            phiFunc_[0] = BasicFunc(SIN, P, k3x2, k3);
            phiFunc_[1] = BasicFunc(SIN, P, k3x2, k3);
            phiFunc_[2] = BasicFunc(COS, P, k3x2, M_PI*k1);
            CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 > 0);
    break;

    // a special one
    case 7:
            phiFunc_[0] = BasicFunc(COS, P, k3x2, k3);
            phiFunc_[1] = BasicFunc(COS, P, k3x2, k3);
            phiFunc_[2] = BasicFunc(SIN, P, k3x2, -M_PI*k1);
            CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 > 0);
    break;

    case 8:
            phiFunc_[0] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[1] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[2] = BasicFunc(ONE,  P, 0, 1);
            CHECK(k1x2 >= 0 && k2x2 > 0 && k3x2 == 0);
    break;

    case 9:
            phiFunc_[0] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[1] = BasicFunc(ZERO, P, 0, 0);
            phiFunc_[2] = BasicFunc(ONE,  P, 0, 1);
            CHECK(k1x2 >= 0 && k2x2 >= 0 && k3x2 == 0);
    break;

    default:
    LOG(FATAL) << "idx " << index_ << "not supported";
  };

  if (index_ == 0 || index_ == 1) {  // shares expression
    RTMultiply r0;
    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
  
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 1.0)};
    t0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RTMultiply p0;
    p0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, k2+1.0)};
    p0.tComp = {BasicFunc(SIN, T, k2x2-2,0.5)};
    RTMultiply p1;
    p1.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, -k2+1.0)};
    p1.tComp = {BasicFunc(SIN, T, k2x2+2,0.5)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0, p1};
  } else if (index_ == 2 || index_ == 3) { // shares expression
    RTMultiply r0;
    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
    
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 1.0)};
    t0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
    
    RTMultiply p0;
    p0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, k2+1.0)};
    p0.tComp = {BasicFunc(COS, T, k2x2-2, 0.5)};
    RTMultiply p1;
    p1.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, -k2+1.0)};
    p1.tComp = {BasicFunc(COS, T, k2x2+2, 0.5)};
  
    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0, p1};
  } else if (index_ == 4 || index_ == 5) {
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, 2, 1.0)};
  
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(SIN, R, k1x2, -k1*M_PI, 1)};
    t0.tComp = {BasicFunc(COS, T, 2, 1.0)};

    RTMultiply p0;
    p0.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(SIN, R, k1x2, -0.5*M_PI*k1, 1)};
    p0.tComp = {BasicFunc(ONE, T, 0, 1.0)};

    RTMultiply p1;
    p1.rComp = {BasicFunc(SIN, R, k1x2, -0.5*M_PI*k1, 1)};
    p1.tComp = {BasicFunc(COS, T, 4, 1.0)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0, p1};
  } else if (index_ == 6 || index_ == 7) {
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(COS, T, 2, 1.0)};
    
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, -1.0), BasicFunc(SIN, R, k1x2, k1*M_PI, 1)};
    t0.tComp = {BasicFunc(SIN, T, 2, 1.0)};
    
    RTMultiply p0, p1;
    p0.rComp = {BasicFunc(SIN, R, k1x2, 1.0, 1)};
    p0.tComp = {BasicFunc(SIN, T, 4, 0.5)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 8) {
    
    RTMultiply p0;
    p0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    p0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RT_[0] = {}; RT_[1] = {}; RT_[2] = {p0};
  } else if (index_ == 9) {
    RTMultiply p0;
    p0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    p0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
  
    RT_[0] = {}; RT_[1] = {}; RT_[2] = {p0};
  } else {
    //LOG(FATAL) << "idx " << index_ << "not supported";
  }
}

// Directly copied from mathematica ....
#define Cos cos
#define Sin sin
#define Pi M_PI

#define PHI0 k2*k3*Cos(k2*t)*Sin(k3*p)*Sin(k1*Pi*r),\
             -(k3*Sin(k3*p)*(k1*Pi*r*Cos(k1*Pi*r) + Sin(k1*Pi*r))*Sin(k2*t)),\
   Cos(k3*p)*(k2*Cos(k2*t)*Sin(k1*Pi*r)*Sin(t) - Cos(t)*(k1*Pi*r*Cos(k1*Pi*r) + Sin(k1*Pi*r))*Sin(k2*t))

#define PHI1 k2*k3*Cos(k3*p)*Cos(k2*t)*Sin(k1*Pi*r),\
              -(k3*Cos(k3*p)*(k1*Pi*r*Cos(k1*Pi*r) + Sin(k1*Pi*r))*Sin(k2*t)),\
   Sin(k3*p)*(-(k2*Cos(k2*t)*Sin(k1*Pi*r)*Sin(t)) + Cos(t)*(k1*Pi*r*Cos(k1*Pi*r) + Sin(k1*Pi*r))*Sin(k2*t))

#define PHI2 k2*k3*Sin(k3*p)*Sin(k1*Pi*r)*Sin(k2*t),\
             k3*Cos(k2*t)*Sin(k3*p)*(k1*Pi*r*Cos(k1*Pi*r) + Sin(k1*Pi*r)),\
   Cos(k3*p)*(k1*Pi*r*Cos(k1*Pi*r)*Cos(t)*Cos(k2*t) + Sin(k1*Pi*r)*(Cos(t)*Cos(k2*t) + k2*Sin(t)*Sin(k2*t)))

#define PHI3 k2*k3*Cos(k3*p)*Sin(k1*Pi*r)*Sin(k2*t),\
             k3*Cos(k3*p)*Cos(k2*t)*(k1*Pi*r*Cos(k1*Pi*r) + Sin(k1*Pi*r)),\
   -(Sin(k3*p)*(k1*Pi*r*Cos(k1*Pi*r)*Cos(t)*Cos(k2*t) + Sin(k1*Pi*r)*(Cos(t)*Cos(k2*t) + k2*Sin(t)*Sin(k2*t))))

#define PHI4 k3*Cos(k1*Pi*r)*Sin(k3*p)*Sin(t),\
             k3*Cos(t)*Sin(k3*p)*(Cos(k1*Pi*r) - k1*Pi*r*Sin(k1*Pi*r)),\
   Cos(k3*p)*(Cos(k1*Pi*r) - k1*Pi*r*Cos(t)*Cos(t)*Sin(k1*Pi*r))

#define PHI5 k3*Cos(k3*p)*Cos(k1*Pi*r)*Sin(t),\
             k3*Cos(k3*p)*Cos(t)*(Cos(k1*Pi*r) - k1*Pi*r*Sin(k1*Pi*r)),\
   -(Sin(k3*p)*(Cos(k1*Pi*r) - k1*Pi*r*Cos(t)*Cos(t)*Sin(k1*Pi*r)))

#define PHI6 k3*Cos(k1*Pi*r)*Cos(t)*Sin(k3*p),\
   k3*Sin(k3*p)*(-Cos(k1*Pi*r) + k1*Pi*r*Sin(k1*Pi*r))*Sin(t),\
   k1*Pi*r*Cos(k3*p)*Cos(t)*Sin(k1*Pi*r)*Sin(t)

#define PHI7 k3*Cos(k3*p)*Cos(k1*Pi*r)*Cos(t),\
   k3*Cos(k3*p)*(-Cos(k1*Pi*r) + k1*Pi*r*Sin(k1*Pi*r))*Sin(t),\
   -(k1*Pi*r*Cos(t)*Sin(k3*p)*Sin(k1*Pi*r)*Sin(t))

#define PHI8 0,\
             0,\
             Cos(k1*Pi*r)*Sin(k2*t)

#define PHI9 0,\
             0,\
             Cos(k1*Pi*r)*Cos(k2*t)

#define computeBasis switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4;\
          break;\
\
          case 5:\
            v << PHI5;\
          break;\
\
          case 6:\
            v << PHI6;\
          break;\
\
          case 7:\
            v << PHI7;\
          break;\
\
          case 8:\
            v << PHI8;\
          break;\
\
          case 9:\
            v << PHI9;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }


#undef i1
#undef i2
#undef i3
        
void TorusBasis3D::DiscretizeAdd(const double coef, FIELD_3D& radius, FIELD_3D& theta, FIELD_3D& phi,
            VECTOR3_FIELD_3D* vfield) {
  
  Eigen::Matrix3d trans;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < vfield->zRes(); k++)
    for (int j = 0; j < vfield->yRes(); j++)
      for (int i = 0; i < vfield->xRes(); i++) {

        double r = radius(i,j,k);
        double t = theta(i,j,k);
        double p = phi(i,j,k);

        if (r > 1.0)
          continue;

        Eigen::Vector3d v;
        v.setZero();
        computeBasis;

        Transform::Torodial::toCartesianMat(t,p, trans);
        Eigen::Vector3d uCartesian = invNorm_*coef*trans*v;
        (*vfield)(i,j,k)[0] = uCartesian[0];
        (*vfield)(i,j,k)[1] = uCartesian[1];
        (*vfield)(i,j,k)[2] = uCartesian[2];
      }
}

// compute on a spherical grid.
void TorusBasis3D::AddUniformU(const double coef, const int nR, const int nTheta,
                                const int nPhi, double* ur, double* ut, double* up) const {
  double dR = 1.0 / nR;
  double dT = 2.0*M_PI/nTheta;
  double dP = 2.0*M_PI/nPhi;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nPhi; i++) {
        
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-2pi]
        double p = ((double)(i) + 0.5)*dP; // [0-2pi]

        Eigen::Vector3d v;
        v.setZero();
        computeBasis;
        v *= coef*invNorm_;
        int idx = i + j*nPhi + k*nPhi*nTheta;
        ur[idx] += v[0];
        ut[idx] += v[1];
        up[idx] += v[2];
      }
    }
  }
}

double TorusBasis3D::ProjectUniformU(const int nR, const int nTheta, const int nPhi,
                                      const double* fr, const double* ft, const double* fp) const {
  double dR = 1.0 / nR;
  double dT = 2.0*M_PI/nTheta;
  double dP = 2.0*M_PI/nPhi;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;
  double result = 0;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nPhi; i++) {
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-pi]
        double p = ((double)(i) + 0.5)*dP; // [0, 2*pi]

        Eigen::Vector3d v;
        v.setZero();
        computeBasis;
        // v *= coef*invNorm_;
        int idx = i + j*nPhi + k*nPhi*nTheta;
        result += v[0]*fr[idx] + v[1]*ft[idx] + v[2]*fp[idx];
      }
    }
  }
  result *= invNorm_;
  result *= dR*dT*dP;

  return result;
}

// {SIN, COS, ZERO, ONE};
// int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
double TorusBasis3D::computePhiInt(const BasicFunc& fun1, const BasicFunc& fun2) {
 
  vector<BasicFunc> mult = BasicFunc::multiply(fun1, fun2);
  double result = 0;
  for (auto& f : mult) {
    result += f.integrateP2Pi();
  }
  return result;
}

// enum FUNTYPE {SIN, COS, ZERO, ONE};
// int_{\theta = 0}^{Pi} fun1*fun2*sin(\theta) d\theta 

double TorusBasis3D::computeThetaInt(const BasicFunc& fun1) {
  BasicFunc sinT(SIN, T, 2, 1.0); // jacobian
  vector<BasicFunc> addVec = BasicFunc::multiply(fun1, sinT);
  double result = 0;

  for (const auto& f : addVec) {
    result += f.integrate();
  }

  return result;
}

/*double TorusBasis3D::computeRInt(const BasicFunc& fun1, const int rPow) {
  return fun1.integrateRPow(rPow);
}*/

// (a*r + r^2 sin(t))
double TorusBasis3D::computeRTMultInt(const RTMultiply& rt1, const double a) {
  double thetaInt = 0, thetaInt1 = 0;
  BasicFunc sinT(SIN, T, 2, 1.0); // jacobian
  for (const auto& fun1 : rt1.tComp) {
    thetaInt += fun1.integrateP2Pi();
    vector<BasicFunc> mult = BasicFunc::multiply(sinT, fun1);
    for (const auto& fun2 : mult)
      thetaInt1 += fun2.integrateP2Pi();
  }

  double rInt = 0, rInt1 = 0;
  for (const auto& fun1 : rt1.rComp) {
    rInt += fun1.integrateRPow(1);
    rInt1 += fun1.integrateRPow(2);
  }

  return thetaInt*rInt*a + thetaInt1*rInt1;
}

Eigen::Vector3d TorusBasis3D::computeRTP(const TorusBasis3D& other, const double& a) const {
  Eigen::Vector3d result(0,0,0);

  for (int i = 0; i < 3; i++) {
    // <phi_i, phi_i>    
    double pINT = computePhiInt(phiFunc_[i], other.getPhiFunc(i));
    //LOG(INFO) << k3x2/2;

    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and phi.
      double rtINT = 0;
      vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
      for (const auto& rt1 : RTProd)
        rtINT += computeRTMultInt(rt1, a);

      result[i] = pINT*rtINT;
    }
  }

  return result;
}

double TorusBasis3D::dotProd(const TorusBasis3D& other, const double& a) const {
  return computeRTP(other, a).sum();
}

double TorusBasis3D::dotProdScale(const TorusBasis3D& other, const double& a) const {
  return computeRTP(other, a).sum()*scale3_;
}

void TorusBasis3D::Normalize(const double& a) {
  norm2_ = dotProdScale(*this, a);
  invNorm_ = 1.0/sqrt(norm2_);
}
// This includes r^2 sin(t) term in integral, please refer to basisAnalysis_3DTensor.pdf
// this does not include the norm
void TorusBasis3D::curlSph(const double& a) {
  
  // sign is grouped into phi func
  curlPhi_[0][0] = phiFunc_[2];
  curlPhi_[0][1] = phiFunc_[2];
  curlPhi_[0][2] = -phiFunc_[1].deriv()[0];

  curlPhi_[1][0] = phiFunc_[0].deriv()[0];
  curlPhi_[1][1] = -phiFunc_[2];
  curlPhi_[1][2] = -phiFunc_[2];
  
  curlPhi_[2][0] = phiFunc_[1];
  curlPhi_[2][1] = phiFunc_[1];
  curlPhi_[2][2] = -phiFunc_[0];

  // cos(theta), sin(theta)
  BasicFunc cosT(COS, T, 2, 1.0, 0);
  BasicFunc sinT(SIN, T, 2, 1.0, 0);
  BasicFunc aFun(ONE, T, 0, a);

  // r D[sin(T) A_p, t]
  curlRT_[0][0] = RT_[2];
  RTMultiply::multThetaVec(sinT, curlRT_[0][0]);
  RTMultiply::derivTVec(curlRT_[0][0]);
  RTMultiply::multRVec(1, curlRT_[0][0]);

  // a D[f_p, t]
  curlRT_[0][1] = RT_[2];
  RTMultiply::derivTVec(curlRT_[0][1]);
  RTMultiply::multThetaVec(aFun, curlRT_[0][1]);

  // -rD[A_t, p]
  curlRT_[0][2] = RT_[1];
  RTMultiply::multRVec(1, curlRT_[0][2]);

  // rD[A_r, p]
  curlRT_[1][0] = RT_[0];
  RTMultiply::multRVec(1, curlRT_[1][0]);

  // -raD[A_p, r]
  curlRT_[1][1] = RT_[2];
  RTMultiply::derivRVec(curlRT_[1][1]);
  RTMultiply::multRVec(1, curlRT_[1][1]);
  RTMultiply::multThetaVec(aFun, curlRT_[1][1]);

  // -rsin(T)D[r A_p, r]
  curlRT_[1][2] = RT_[2];
  RTMultiply::multRVec(1, curlRT_[1][2]); // r A_p
  RTMultiply::derivRVec(curlRT_[1][2]);
  RTMultiply::multRVec(1, curlRT_[1][2]);
  RTMultiply::multThetaVec(sinT, curlRT_[1][2]);

  // (a+rsin(T))A_t
  curlRT_[2][0] = RT_[1];
  RTMultiply::multRVec(1, curlRT_[2][0]);
  RTMultiply::multThetaVec(sinT, curlRT_[2][0]);
  vector<RTMultiply> At = RT_[1];
  RTMultiply::multThetaVec(aFun, At);
  curlRT_[2][0].insert(curlRT_[2][0].end(), At.begin(), At.end());

  // r^2sin(T)D[A_t, r]
  curlRT_[2][1] = RT_[1];
  RTMultiply::derivRVec(curlRT_[2][1]);
  RTMultiply::multRVec(2, curlRT_[2][1]);
  RTMultiply::multThetaVec(sinT, curlRT_[2][1]);
  At = RT_[1]; // arD[A_t, r]
  RTMultiply::derivRVec(At);
  RTMultiply::multRVec(1, At);
  RTMultiply::multThetaVec(aFun, At);
  curlRT_[2][1].insert(curlRT_[2][1].end(), At.begin(), At.end());

  // -rsin(T)D[A_r, t]
  curlRT_[2][2] = RT_[0];
  RTMultiply::derivTVec(curlRT_[2][2]);
  RTMultiply::multRVec(1, curlRT_[2][2]);
  RTMultiply::multThetaVec(sinT, curlRT_[2][2]);
  At = RT_[0]; // aD[A_r, t]
  RTMultiply::derivTVec(At);
  RTMultiply::multThetaVec(aFun, At);
  curlRT_[2][2].insert(curlRT_[2][2].end(), At.begin(), At.end());

  for (int j = 0; j < 3; j++)
    for (int i = 0; i < 3; i++)
      for (auto& rtm : curlRT_[i][j])
        rtm.hashSimplify();
}

// This also doesnt include norm
// a2 b3 - a3 b2
// a3 b1 - a1 b3
// a1 b2 - a2 b1
void TorusBasis3D::crossProdPhi(const TorusBasis3D& phiG, const TorusBasis3D& phiH,
                                 vector<BasicFunc> (&crossPhi)[3][2]) {
  crossPhi[0][0] = BasicFunc::multiply(phiG.getPhiFunc(1), phiH.getPhiFunc(2));
  crossPhi[0][1] = BasicFunc::multiply(phiG.getPhiFunc(2), -phiH.getPhiFunc(1));
  crossPhi[1][0] = BasicFunc::multiply(phiG.getPhiFunc(2), phiH.getPhiFunc(0));
  crossPhi[1][1] = BasicFunc::multiply(phiG.getPhiFunc(0), -phiH.getPhiFunc(2));
  crossPhi[2][0] = BasicFunc::multiply(phiG.getPhiFunc(0), phiH.getPhiFunc(1));
  crossPhi[2][1] = BasicFunc::multiply(phiG.getPhiFunc(1), -phiH.getPhiFunc(0));
}

// This also doesnt include norm
// These doesnt include the sin(t) weight included in integral, the term is baked into curl.
// sign is in phi component.
// (crossPhi[0][0])*(crossRT[0][0]);
// 
void TorusBasis3D::crossProdRT(const TorusBasis3D& phiG, const TorusBasis3D& phiH,
                                vector<RTMultiply> (&crossRT)[3][2]) {
  crossRT[0][0] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(2));
  crossRT[0][1] = RTMultiply::multV(phiG.getRT(2), phiH.getRT(1));
  crossRT[1][0] = RTMultiply::multV(phiG.getRT(2), phiH.getRT(0));
  crossRT[1][1] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(2));
  crossRT[2][0] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(1));
  crossRT[2][1] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(0));
}

double TorusBasis3D::integrateCurlCross(const BasicFunc& curlP, const vector<BasicFunc>& crossP,
                                         const vector<RTMultiply>& curlRT, const vector<RTMultiply>& crossRT) {
  // first integrate along phi.
  // int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += computePhiInt(curlP, cp);
  if (fabs(phiInt) < 1e-14)
    return 0.0;
  // integrate along theta, without sin(t) term, because its already in curl.
  double rtInt = 0;
  vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  for (auto& rt : RTProd) {
    rt.hashSimplify();
    double tInt = rt.integrateT2Pi();
    if (fabs(tInt) < 1e-14)  // prod is zero.
      continue;
    double rInt = rt.integrateR();
    rtInt += tInt*rInt;
  }

  return phiInt*rtInt;
}

double TorusBasis3D::computeTensorEntry(const TorusBasis3D& phiI, const TorusBasis3D& phiG,
                                         const TorusBasis3D& phiH) {
  // compute cross product.
  vector<BasicFunc> crossPhi[3][2];
  vector<RTMultiply> crossRT[3][2];
  TorusBasis3D::crossProdPhi(phiG, phiH, crossPhi);
  TorusBasis3D::crossProdRT(phiG, phiH, crossRT);

  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 3; ind++) {
    rVal += integrateCurlCross(phiI.getCurPhi(0,ind), crossPhi[0][0], phiI.getCurRT(0,ind), crossRT[0][0]);
    rVal += integrateCurlCross(phiI.getCurPhi(0,ind), crossPhi[0][1], phiI.getCurRT(0,ind), crossRT[0][1]);
  }

  // t component.
  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_t * {phi_g \times phi_h}_t d omega
  double tVal = 0;
  for (int ind = 0; ind < 3; ind++) {
    tVal += integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][0], phiI.getCurRT(1,ind), crossRT[1][0]);
    tVal += integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][1], phiI.getCurRT(1,ind), crossRT[1][1]);
  }

  // p component.
  double pVal = 0;
  for (int ind = 0; ind < 3; ind++) {
    pVal += integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][0], phiI.getCurRT(2,ind), crossRT[2][0]);
    pVal += integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][1], phiI.getCurRT(2,ind), crossRT[2][1]);
  }

  return (rVal + tVal + pVal)*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
}

double TorusBasis3D::computeTensorEntryScale(const TorusBasis3D& phiI, const TorusBasis3D& phiG, const TorusBasis3D& phiH, const double& scale3) {
  return computeTensorEntry(phiI, phiG, phiH)*scale3;
}

void TorusBasis3D::writeToFile(std::ofstream& out) const {
  out.write(reinterpret_cast<const char *>(&k1x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k2x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k3x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&index_), sizeof(int));
}

TorusBasis3D* TorusBasis3D::fromFile(std::ifstream& in, const double& a) {
  int k1x2, k2x2, k3x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k3x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));

  return new TorusBasis3D(k1x2, k2x2, k3x2, index_, a);
}

void TorusBasis3D::FillFields(FIELD_3D& rad, FIELD_3D& theta, FIELD_3D& phi, const double& a) {
  CHECK(a > 1);
  // The physical dimension is xyz: [-(a+1), (a+1)]x[-(a+1), (a+1)]x[-1, 1]
  // physical dx
  double dx = 2.0*(a+1.0) / rad.xRes();
  double lz = rad.zRes()*dx;

  for (int k = 0; k < rad.zRes(); k++)
    for (int j = 0; j < rad.yRes(); j++)
      for (int i = 0; i < rad.xRes(); i++) {
        Eigen::Vector3d pos(((double)(i) + 0.5)*dx - a - 1.0 , ((double)(j) + 0.5)*dx - a - 1.0,
                 ((double)(k) + 0.5)*dx - lz*0.5);  // [-(a+1), (a+1)]^2x[-lz/2, lz/2]
        Eigen::Vector3d sphCord = Transform::Torodial::toTorodial(pos, a);

        rad(i,j,k) = sphCord[0];
        theta(i,j,k) = sphCord[1];
        phi(i,j,k) = sphCord[2];
      }
}