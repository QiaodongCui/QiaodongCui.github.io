#include <vector>
#include "tensorCompute/sph3DR_evalR.h"
sph3DRrEval::sph3DRrEval() {
pointers_.resize(20);
pointers_[0] = &evalR_0;
pointers_[1] = &evalR_1;
pointers_[2] = &evalR_2;
pointers_[3] = &evalR_3;
pointers_[4] = &evalR_4;
pointers_[5] = &evalR_5;
pointers_[6] = &evalR_6;
pointers_[7] = &evalR_7;
pointers_[8] = &evalR_8;
pointers_[9] = &evalR_9;
pointers_[10] = &evalR_10;
pointers_[11] = &evalR_11;
pointers_[12] = &evalR_12;
pointers_[13] = &evalR_13;
pointers_[14] = &evalR_14;
pointers_[15] = &evalR_15;
pointers_[16] = &evalR_16;
pointers_[17] = &evalR_17;
pointers_[18] = &evalR_18;
pointers_[19] = &evalR_19;
}


