#ifndef CYLSIN_EVAL_P_H
#define CYLSIN_EVAL_P_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define SinPZ TrigInt::IntegralS_D2_ONE
#define CosPZ TrigInt::IntegralC_D2_ONE
#define Pi M_PI


class cylSinpEval{
public:
cylSinpEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~cylSinpEval(){};
/* Cos[g3*p*Pi]Cos[h3*p*Pi]Cos[i3*p*Pi]*/
static double evalP_0(const int i3x2, const int g3x2, const int h3x2){
return (CosPZ(g3x2-h3x2-i3x2)+CosPZ(g3x2+h3x2-i3x2)+CosPZ(g3x2-h3x2+i3x2)+CosPZ(g3x2+h3x2+i3x2))/4.;
};

/* Sin[h3*p*Pi]Sin[i3*p*Pi]Cos[g3*p*Pi]*/
static double evalP_1(const int i3x2, const int g3x2, const int h3x2){
return (-CosPZ(g3x2-h3x2-i3x2)+CosPZ(g3x2+h3x2-i3x2)+CosPZ(g3x2-h3x2+i3x2)-CosPZ(g3x2+h3x2+i3x2))/4.;
};

/* Sin[g3*p*Pi]Sin[i3*p*Pi]Cos[h3*p*Pi]*/
static double evalP_2(const int i3x2, const int g3x2, const int h3x2){
return (CosPZ(g3x2-h3x2-i3x2)+CosPZ(g3x2+h3x2-i3x2)-CosPZ(g3x2-h3x2+i3x2)-CosPZ(g3x2+h3x2+i3x2))/4.;
};

/* 1*/
static double evalP_3(const int i3x2, const int g3x2, const int h3x2){
return 1.0;
};

};

#endif // CYLSIN_EVAL_P_H