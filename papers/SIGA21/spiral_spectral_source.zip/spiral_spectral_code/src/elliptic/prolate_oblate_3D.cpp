#include "elliptic/elliptic_basis_2D.h"
#include "elliptic/prolate_oblate_2D.h"
#include "elliptic/prolate_oblate_3D.h"

#include "sphere_3D/sphere_basis_3D.h"
#include "util/transform.h"

#define USE_R_WEIGHT

#define Cos cos
#define Sin sin
#define Pi M_PI
#define i3 k3
#define i2 k2
#define i1 k1

#ifdef USE_R_WEIGHT

  #define PHI0 c_*r/h*r*Cos(i2*t)*Sin(i3*p)*Sin(i1*Pi*r)*Sin(t),\
               sqrtCR/h*-invk2*r*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t),\
               c_*r*sqrtCR/h/h*-invk2*invk3*(r*Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t))

  #define PHI1 c_*r/h*r*Cos(i3*p)*Cos(i2*t)*Sin(i1*Pi*r)*Sin(t),\
               sqrtCR/h*-invk2*r*Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t),\
               c_*r*sqrtCR/h/h*invk2*invk3*r*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t)

  #define PHI2 c_*r/h*r*Sin(p)*Sin(i1*Pi*r)*Sin(i2*t),\
               sqrtCR/h*invk2*r*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)),\
               c_*r*sqrtCR/h/h*invk2*r*Cos(p)*Cos(t)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))

  #define PHI3 c_*r/h*r*Cos(p)*Sin(i1*Pi*r)*Sin(i2*t),\
               sqrtCR/h*invk2*r*Cos(p)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)),\
               c_*r*sqrtCR/h/h*-invk2*(r*Cos(t)*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)))

  #define PHI7 0,\
               0,\
               r*Sin(i1*Pi*r)*Sin(i2*t)

#else

  #define PHI0 c_*r/h*sin(k1*M_PI*r)*sin(t)*cos(k2*t)*sin(k3*p),\
               sqrtCR/h*-invk2*rCos2Sin(k1*M_PI*r)*sin(t)*sin(k2*t)*sin(k3*p),\
               c_*r*sqrtCR/h/h*-invk2*invk3*rCos2Sin(k1*M_PI*r)*sin(2*t)*sin(k2*t)*cos(k3*p)

  #define PHI1 c_*r/h*sin(k1*M_PI*r)*sin(t)*cos(k2*t)*cos(k3*p),\
               sqrtCR/h*-invk2*rCos2Sin(k1*M_PI*r)*sin(t)*sin(k2*t)*cos(k3*p),\
               c_*r*sqrtCR/h/h*invk2*invk3*rCos2Sin(k1*M_PI*r)*sin(2*t)*sin(k2*t)*sin(k3*p)

  #define PHI2 c_*r/h*sin(k1*M_PI*r)*sin(k2*t)*sin(p),\
               sqrtCR/h*invk2*rCos2Sin(k1*M_PI*r)*cos(k2*t)*sin(p),\
               c_*r*sqrtCR/h/h*invk2*rCos2Sin(k1*M_PI*r)*cos(t)*cos(k2*t)*cos(p)

  #define PHI3 c_*r/h*sin(k1*M_PI*r)*sin(k2*t)*cos(p),\
               sqrtCR/h*invk2*rCos2Sin(k1*M_PI*r)*cos(k2*t)*cos(p),\
               c_*r*sqrtCR/h/h*-invk2*rCos2Sin(k1*M_PI*r)*cos(t)*cos(k2*t)*sin(p)

  #define PHI7 0,\
               0,\
               sin(k1*M_PI*r)*sin(k2*t)

#endif

#define PHI4 c_*r/h*cos(k1*M_PI*r)*cos(t),\
             sqrtCR/h*(-cos(k1*M_PI*r) + 0.5*k1*M_PI*r*sin(k1*M_PI*r))*sin(t),\
             0

#define PHI5 sqrtCR/h*cos(k1*M_PI*r)*sin(t)*sin(p),\
             c_*r/h*rSinCos(k1*M_PI*r)*cos(t)*sin(p),\
             1.0/h/h*(cos(k1*M_PI*r)*(1.0 + c_*c_*r*r - cos(t)*cos(t)) - k1*M_PI*r*sin(k1*M_PI*r)*(c_*c_*r*r*cos(t)*cos(t) + sin(t)*sin(t)))*cos(p)

#define PHI6 sqrtCR/h*cos(k1*M_PI*r)*sin(t)*cos(p),\
             c_*r/h*rSinCos(k1*M_PI*r)*cos(t)*cos(p),\
             1.0/h/h*(-cos(k1*M_PI*r)*(1.0 + c_*c_*r*r - cos(t)*cos(t)) + k1*M_PI*r*sin(k1*M_PI*r)*(c_*c_*r*r*cos(t)*cos(t) + sin(t)*sin(t)))*sin(p)

#define computeBasisProLate switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4;\
          break;\
\
          case 5:\
            v << PHI5;\
          break;\
\
          case 6:\
            v << PHI6;\
          break;\
\
          case 7:\
            v << PHI7;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }

#ifdef USE_R_WEIGHT

  #define PHI0B c_*c_*r*r/h/sqrtCR*r*Cos(i2*t)*Sin(i3*p)*Sin(i1*Pi*r)*Sin(t),\
                c_*r/h*-invk2*r*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t),\
                c_*r*sqrtCR/h/h*-invk2*invk3*(r*Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t))

  #define PHI1B c_*c_*r*r/h/sqrtCR*r*Cos(i3*p)*Cos(i2*t)*Sin(i1*Pi*r)*Sin(t),\
                c_*r/h*-invk2*r*Cos(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(t)*Sin(i2*t),\
                c_*r*sqrtCR/h/h*invk2*invk3*r*Sin(i3*p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))*Sin(2*t)*Sin(i2*t)

  #define PHI2B c_*c_*r*r/h/sqrtCR*r*Sin(p)*Sin(i1*Pi*r)*Sin(i2*t),\
                c_*r/h*invk2*r*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)),\
                c_*r*sqrtCR/h/h*invk2*r*Cos(p)*Cos(t)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r))

  #define PHI3B c_*c_*r*r/h/sqrtCR*r*Cos(p)*Sin(i1*Pi*r)*Sin(i2*t),\
                c_*r/h*invk2*r*Cos(p)*Cos(i2*t)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)),\
                c_*r*sqrtCR/h/h*-invk2*(r*Cos(t)*Cos(i2*t)*Sin(p)*(i1*Pi*r*Cos(i1*Pi*r) + 3*Sin(i1*Pi*r)))

  #define PHI7B 0,\
                0,\
                r*Sin(i1*Pi*r)*Sin(i2*t)

#else

  #define PHI0B c_*c_*r*r/h/sqrtCR*sin(k1*M_PI*r)*sin(t)*cos(k2*t)*sin(k3*p),\
                c_*r/h*-invk2*rCos2Sin(k1*M_PI*r)*sin(t)*sin(k2*t)*sin(k3*p),\
                c_*r*sqrtCR/h/h*-invk2*invk3*rCos2Sin(k1*M_PI*r)*sin(2*t)*sin(k2*t)*cos(k3*p)

  #define PHI1B c_*c_*r*r/h/sqrtCR*sin(k1*M_PI*r)*sin(t)*cos(k2*t)*cos(k3*p),\
               c_*r/h*-invk2*rCos2Sin(k1*M_PI*r)*sin(t)*sin(k2*t)*cos(k3*p),\
               c_*r*sqrtCR/h/h*invk2*invk3*rCos2Sin(k1*M_PI*r)*sin(2*t)*sin(k2*t)*sin(k3*p)

  #define PHI2B c_*c_*r*r/h/sqrtCR*sin(k1*M_PI*r)*sin(k2*t)*sin(p),\
               c_*r/h*invk2*rCos2Sin(k1*M_PI*r)*cos(k2*t)*sin(p),\
               c_*r*sqrtCR/h/h*invk2*rCos2Sin(k1*M_PI*r)*cos(t)*cos(k2*t)*cos(p)

  #define PHI3B c_*c_*r*r/h/sqrtCR*sin(k1*M_PI*r)*sin(k2*t)*cos(p),\
               c_*r/h*invk2*rCos2Sin(k1*M_PI*r)*cos(k2*t)*cos(p),\
               c_*r*sqrtCR/h/h*-invk2*rCos2Sin(k1*M_PI*r)*cos(t)*cos(k2*t)*sin(p)

  #define PHI7B 0,\
               0,\
               sin(k1*M_PI*r)*sin(k2*t)

#endif


#define PHI4B sqrtCR/h*cos(k1*M_PI*r)*cos(t),\
             1.0/h*(-c_*r*cos(k1*M_PI*r) + 0.5*k1*M_PI/c_*(1.0 + c_*c_*r*r)*sin(k1*M_PI*r))*sin(t),\
             0

#define PHI5B c_*r/h*cos(k1*M_PI*r)*sin(t)*sin(p),\
             sqrtCR/h*rSinCos(k1*M_PI*r)*cos(t)*sin(p),\
             1/h/h*(cos(k1*M_PI*r)*(c_*c_*r*r + cos(t)*cos(t)) - k1*M_PI*r*(1.0 + c_*c_*r*r)*cos(t)*cos(t)*sin(k1*M_PI*r))*cos(p)

#define PHI6B c_*r/h*cos(k1*M_PI*r)*sin(t)*cos(p),\
             sqrtCR/h*rSinCos(k1*M_PI*r)*cos(t)*cos(p),\
             1/h/h*(-cos(k1*M_PI*r)*(c_*c_*r*r + cos(t)*cos(t)) + k1*M_PI*r*(1.0 + c_*c_*r*r)*cos(t)*cos(t)*sin(k1*M_PI*r))*sin(p)

#define computeBasisObLate switch (index_) {\
          case 0:\
            v << PHI0B;\
          break;\
\
          case 1:\
            v << PHI1B;\
          break;\
\
          case 2:\
            v << PHI2B;\
          break;\
\
          case 3:\
            v << PHI3B;\
          break;\
\
          case 4:\
            v << PHI4B;\
          break;\
\
          case 5:\
            v << PHI5B;\
          break;\
\
          case 6:\
            v << PHI6B;\
          break;\
\
          case 7:\
            v << PHI7B;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }

 // compute on a catersian grid.
void ProlateOblate3D::DiscretizeAdd(const double coef, FIELD_3D& radius, FIELD_3D& theta, FIELD_3D& phi,
            VECTOR3_FIELD_3D* vfield) {
  Eigen::Matrix3d trans;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < vfield->zRes(); k++)
    for (int j = 0; j < vfield->yRes(); j++)
      for (int i = 0; i < vfield->xRes(); i++) {

        double r = radius(i,j,k);
        double t = theta(i,j,k);
        double p = phi(i,j,k);

        if (r > 1.0)
          continue;
        
        Eigen::Vector3d v;
        v.setZero();
        
        const double sqrtCR = sqrt(1.0 + c_*c_*r*r);
        if (is_prolate_) {
          const double h = Transform::Spheroid::computeh(r,t,c_);
          computeBasisProLate;
        } else {
          const double h = Transform::Spheroid::computehc(r,t,c_);
          computeBasisObLate;
        }
        toCartesianMat(r,t,p, trans);
        Eigen::Vector3d uCartesian = invNorm_*coef*trans*v;
        (*vfield)(i,j,k)[0] = uCartesian[0];
        (*vfield)(i,j,k)[1] = uCartesian[1];
        (*vfield)(i,j,k)[2] = uCartesian[2];
      }
}

void ProlateOblate3D::AddUniformU(const double coef, const int nR, const int nTheta, const int nPhi, double* ur, double* ut, double* up) const {
  double dR = 1.0 / nR;
  double dT = M_PI / nTheta;
  double dP = 2.0*M_PI/nPhi;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nPhi; i++) {
        
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-pi]
        double p = ((double)(i) + 0.5)*dP; // [0, 2*pi]

        Eigen::Vector3d v;
        v.setZero();

        const double sqrtCR = sqrt(1.0 + c_*c_*r*r);
        if (is_prolate_) {
          const double h = Transform::Spheroid::computeh(r,t,c_);
          computeBasisProLate;
        } else {
          const double h = Transform::Spheroid::computehc(r,t,c_);
          computeBasisObLate;
        }

        v *= coef*invNorm_;
        int idx = i + j*nPhi + k*nPhi*nTheta;
        ur[idx] += v[0];
        ut[idx] += v[1];
        up[idx] += v[2];
      }
    }
  }
}

double ProlateOblate3D::ProjectUniformU(const int nR, const int nTheta, const int nPhi,
                      const double* fr, const double* ft, const double* fp) const {

  double dR = 1.0 / nR;
  double dT = M_PI / nTheta;
  double dP = 2.0*M_PI/nPhi;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;
  double result = 0;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nPhi; i++) {
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-pi]
        double p = ((double)(i) + 0.5)*dP; // [0, 2*pi]

        Eigen::Vector3d v;
        v.setZero();

        const double sqrtCR = sqrt(1.0 + c_*c_*r*r);
        if (is_prolate_) {
          const double h = Transform::Spheroid::computeh(r,t,c_);
          computeBasisProLate;
        } else {
          const double h = Transform::Spheroid::computehc(r,t,c_);
          computeBasisObLate;
        }

        // v *= coef*invNorm_;
        int idx = i + j*nPhi + k*nPhi*nTheta;
        result += v[0]*fr[idx] + v[1]*ft[idx] + v[2]*fp[idx];
      }
    }
  }
  result *= invNorm_;
  result *= dR*dT*dP;

  return result;
}

void ProlateOblate3D::FillFields(FIELD_3D& rad, FIELD_3D& theta, FIELD_3D& phi) {
  double dx = 2.0 / rad.xRes();
  double dy = 2.0 / rad.yRes();
  double dz = 2.0 / rad.zRes();

  for (int k = 0; k < rad.zRes(); k++)
    for (int j = 0; j < rad.yRes(); j++)
      for (int i = 0; i < rad.xRes(); i++) {
        double r, t, p;
        VEC3 pos(((double)(i) + 0.5)*dx - 1.0 , ((double)(j) + 0.5)*dx - 1.0,
                 ((double)(k) + 0.5)*dx - 1.0 );  // [-1, 1]^3
        if (is_prolate_)
          Transform::Spheroid::CatersianToProlate(a_,c_, pos, r, t, p);
        else
          Transform::Spheroid::CatersianToOblate(a_,c_, pos, r, t, p);
        rad(i,j,k) = r;
        theta(i,j,k) = t;
        phi(i,j,k) = p;
      }
}

void ProlateOblate3D::toCartesianMat(const double& r, const double& t, const double& p, Eigen::Matrix3d& mat) {
  if (is_prolate_) {
    Transform::Spheroid::toCartesianMatProlate(r, t, p, c_, mat);
  } else {
    Transform::Spheroid::toCartesianMatOblate(r, t, p, c_, mat);
  }
}

void ProlateOblate3D::initBasicCoef() {
  if (is_prolate_ ) {
    if (index_ <= 3) {
      eFact_[0] = EllipticFactor(-1, 0, 1, c_);
      eFact_[1] = EllipticFactor(-1, 1, 0, 1.0);
      eFact_[2] = EllipticFactor(-2, 1, 1, c_);
    } else if (index_ == 4) {
      eFact_[0] = EllipticFactor(-1, 0, 1, c_);
      eFact_[1] = EllipticFactor(-1, 1, 0, 1.0);
      eFact_[2] = EllipticFactor(0, 0, 0, 0);

    } else if (index_ == 5 || index_ == 6) {
      eFact_[0] = EllipticFactor(-1, 1, 0, 1.0);
      eFact_[1] = EllipticFactor(-1, 0, 1, c_);
      eFact_[2] = EllipticFactor(-2, 0, 0, 1.0);
      // overload RT component.
      RT_[2].clear();
      RTMultiply p0, p1, p2;
      // -Cos[t]^2 (Cos[i1 \[Pi] r] + c^2 i1 \[Pi] r^3 Sin[i1 \[Pi] r])
      p0.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(SIN, R, k1x2, c_*c_*k1*M_PI, 3)};
      p0.tComp = {BasicFunc(COS, T, 4, -0.5), BasicFunc(ONE, T, 2, -0.5)};  // -cos(t)^2
      // Cos[i1 \[Pi] r] + c^2 r^2 Cos[i1 \[Pi] r]
      p1.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(COS, R, k1x2, c_*c_, 2)};
      p1.tComp = {BasicFunc(ONE, T, 2, 1.0)};
      // -i1 \[Pi] r Sin[i1 \[Pi] r] Sin[t]^2
      p2.rComp = {BasicFunc(SIN, R, k1x2, -k1*M_PI, 1)};
      p2.tComp = {BasicFunc(COS, T, 4, -0.5), BasicFunc(ONE, T, 2, 0.5)}; // Sin[t]^2
      RT_[2] = {p0, p1, p2};
    } else if (index_ == 7) {
      eFact_[0] = EllipticFactor(0,0,0,0.0);
      eFact_[1] = EllipticFactor(0,0,0,0.0);
      eFact_[2] = EllipticFactor(0,0,0,1.0);
    } else {
      LOG(FATAL) << "idx not found";
    }
  } else {
    if (index_ <= 3) {
      eFact_[0] = EllipticFactor(-1, -1, 2, c_*c_);
      eFact_[1] = EllipticFactor(-1, 0, 1, c_);
      eFact_[2] = EllipticFactor(-2, 1, 1, c_);
    } else if (index_ == 4) {
      eFact_[0] = EllipticFactor(-1, 1, 0, 1.0);
      eFact_[1] = EllipticFactor(-1, 0, 0, 1.0);
      eFact_[2] = EllipticFactor(0, 0, 0, 0.0);
      RT_[1].clear(); // overload RT[1]
      RTMultiply t0;
      // -c r Cos[i1 r] + (i1*Pi*Sin[i1 r])/(2 c) + 1/2 c i1*Pi*r^2 Sin[i1 r]
      t0.rComp = {BasicFunc(COS, R, k1x2, -c_, 1),  BasicFunc(SIN, R, k1x2, k1*M_PI*0.5/c_), BasicFunc(SIN, R, k1x2, 0.5*c_*k1*M_PI, 2)};
      t0.tComp = {BasicFunc(SIN, T, 2, 1.0)};
      RT_[1] = {t0};

    } else if (index_ == 5 || index_ == 6) {
      eFact_[0] = EllipticFactor(-1, 0, 1, c_);
      eFact_[1] = EllipticFactor(-1, 1, 0, 1.0);
      eFact_[2] = EllipticFactor(-2, 0, 0, 1.0);
      RT_[2].clear(); // overload
      RTMultiply p0, p1;
      // c^2 r^2 Cos[i1 r]
      p0.rComp = {BasicFunc(COS, R, k1x2, c_*c_, 2)};
      p0.tComp = {BasicFunc(ONE, T, 2, 1.0)};
      // Cos[t]^2 (Cos[i1 r] - i1 *Pi*r (1 + c^2 r^2) Sin[i1 r])
      // Cos[i1 r] - i1*Pi*r Sin[i1 r] - c^2 i1*Pi*r^3 Sin[i1 r]
      p1.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(SIN, R, k1x2, -k1*M_PI, 1), BasicFunc(SIN, R, k1x2, -c_*c_*k1*M_PI, 3)};
      p1.tComp = {BasicFunc(COS, T, 4, 0.5), BasicFunc(ONE, T, 2, 0.5)}; // Cos[t]^2
      RT_[2] = {p0, p1};
    } else if (index_ == 7) {
      eFact_[0] = EllipticFactor(0,0,0,0.0);
      eFact_[1] = EllipticFactor(0,0,0,0.0);
      eFact_[2] = EllipticFactor(0,0,0,1.0);
    } else {
      LOG(FATAL) << "idx not found";
    }
  }
}

// if need to multipy with jacobian, multiply before hand.
// int_{r,t} ef*rfun*tfun drdt.
double ProlateOblate3D::integrateRT(const EllipticFactor& ef, const BasicFunc& rfun, const BasicFunc& tfun,
                                    const IntTable1DData& tabData) const {
  if (tfun.type == ZERO || rfun.type == ZERO || ef.coef_ == 0) {
    return 0;
  }
  // hpow = 2,-2,0
  if (ef.hPow_ == 0 && ef.sqrtCRPow_ == 0) { // can be computed analytically.
    double thetaInt = tfun.integrate();
    if (thetaInt == 0)
      return 0;
    double rInt = rfun.integrateRPow(ef.rPow_);
    return thetaInt*rInt*ef.coef_;
  }

  // (c^2 r^2 + sin(t)^2)*ef*rfun*tfun = c^2 r^2*ef*rfun*tfun + sin(t)^2*ef*rfun*tfun
  if (ef.hPow_ == 2) {  // reduce ef.hopw
    double result = 0;
    EllipticFactor efNew = ef;
    efNew.hPow_ = 0;
    //c^2 r^2*ef*rfun*tfun
    efNew.rPow_ += 2;
    result += integrateRT(efNew, rfun, tfun, tabData)*c_*c_;
    // 1/2 (1 - Cos[2 t])*ef*rfun*tfun; // oblate: 1/2 (1 + Cos[2 t])
    // 1/2*1*ef*rfun*tfun 
    efNew.rPow_ -= 2;
    result += integrateRT(efNew, rfun, tfun, tabData)*0.5;

    // -1/2 Cos[2 t])*ef*rfun*tfun;
    BasicFunc cos2T(COS, T, 4, 1.0);
    std::vector<BasicFunc> mult = BasicFunc::multiply(cos2T, tfun);
    int sgn = is_prolate_ ? -1 : 1;
    for (int i = 0; i < mult.size(); i++) {
      result += integrateRT(efNew, rfun, mult[i], tabData)*0.5*sgn;
    }
    return result;
  }
  
  if (ef.hPow_ == 0 && ef.sqrtCRPow_ != 0) {
    double thetaInt = tfun.integrate();

    if (thetaInt == 0)
      return 0;

    double rInt = 0;
    if (ef.sqrtCRPow_%2 != 0 || ef.sqrtCRPow_ < 0) // query 1D table
      rInt = tabData.queryTable(ef, rfun);
    else
      rInt = EllipticBasis2D::intCRPow(ef, rfun, c_);

    return thetaInt*rInt;
  }

  if (ef.hPow_ == -2 || ef.hPow_ == -4 || ef.hPow_ == -6) { // query 2D table
    return tabData.query2D(ef, rfun, tfun);
  }

  LOG(FATAL) << "unhandled case." << ef.hPow_ << " " << ef.sqrtCRPow_;
  return 0;
}

// count the patterns in RT integral. if hpow == 0, then seperable, otherwise not.
void ProlateOblate3D::countRTPattern(const EllipticFactor& ef, const BasicFunc& rfun, const BasicFunc& tfun, const bool is1DTable,
                                     const bool collectAll, std::unordered_set<uint64_t>& set) {
  if (tfun.type == ZERO || rfun.type == ZERO) {
    return;
  }
  FUNTYPE rType = rfun.type;
  FUNTYPE tType = tfun.type;
  if (rType == ONE)
    rType = COS;
  if (tType == ONE)
    tType = COS;

  if (! collectAll) {
    // collect 1D table.
    if (is1DTable && ef.hPow_ == -2)
      return;
    // collect 2D table.
    if (!is1DTable && ef.hPow_ != -2)
      return;
  }

  if (ef.hPow_ == 0 && ef.sqrtCRPow_ == 0) // can be computed analytically.
    return;

  // oblate: 1/2 (1 + Cos[2 t])
  if (ef.hPow_ == 2) { // (c^2 r^2 + sin(t)^2)*ef*rfun*tfun = r^2*ef*rfun*tfun + sin(t)^2*ef*rfun*tfun
    //r^2*ef*rfun*tfun
    set.insert(EllipticBasis2D::tripleInfoToHash(0, ef.sqrtCRPow_, ef.rPow_ + rfun.rPower + 2, rType, tType));
    //1/2 (1 - Cos[2 t])*ef*rfun*tfun = 1/2*1*ef*rfun*tfun 
    set.insert(EllipticBasis2D::tripleInfoToHash(0, ef.sqrtCRPow_, ef.rPow_ + rfun.rPower, rType, tType));
    //1/2 (- Cos[2 t])*ef*rfun*tfun;
    BasicFunc cos2T(COS, T, 4, 1.0);
    std::vector<BasicFunc> mult = BasicFunc::multiply(cos2T, tfun);
    for (int i = 0; i < mult.size(); i++)
      set.insert(EllipticBasis2D::tripleInfoToHash(0, ef.sqrtCRPow_, ef.rPow_ + rfun.rPower, rType, mult[i].type));

    return;
  }

  uint64_t hash = EllipticBasis2D::tripleInfoToHash(ef.hPow_, ef.sqrtCRPow_, ef.rPow_ + rfun.rPower, rType, tType);
  set.insert(hash);
}

double ProlateOblate3D::inetgrateRTMult(const EllipticFactor& ef, const RTMultiply& rt1, 
                                        const bool withJacobian, const IntTable1DData& tabData) const {
  EllipticFactor efcp = ef;
  double result = 0;

  if (withJacobian) {
    if (is_prolate_) { // prolate jacobian: ab^2 h^2/sqrt(1+c^2r^2)r*sin(t)
      efcp.hPow_ += 2;
      efcp.sqrtCRPow_ -= 1;
      efcp.rPow_ += 1; // this left with sin(t) in jacobian.
      efcp.coef_ *= a_*b_*b_;
    } else {  // oblate jacobian a^2b hc^2 sin(t)
      efcp.hPow_ += 2; // this left with sin(t) in jacobian.
      efcp.coef_ *= a_*a_*b_;
    }
  }

  if (withJacobian) {
    BasicFunc sinT(SIN, T, 2, 1.0);
    for (const auto& tf : rt1.tComp) {
       std::vector<BasicFunc> tmult = BasicFunc::multiply(sinT, tf);
      for (const auto& rf : rt1.rComp) {
        for (int i = 0; i < tmult.size(); i++)
          result += integrateRT(efcp, rf, tmult[i], tabData);
      }
    }
  } else {
    for (const auto& tf : rt1.tComp)
      for (const auto& rf : rt1.rComp) {
        result += integrateRT(efcp, rf, tf, tabData);
      }
  }

  return result;
}

void ProlateOblate3D::computeRTPattern(const EllipticFactor& ef, const RTMultiply& rt1, const bool withJacobian, const bool is1DTable,
                                       const bool collectAll, std::unordered_set<uint64_t>& set) const {
  EllipticFactor efcp = ef;
  if (withJacobian) {
    if (is_prolate_) { // prolate jacobian: ab^2 h^2/sqrt(1+c^2r^2)r*sin(t)
      efcp.hPow_ += 2;
      efcp.sqrtCRPow_ -= 1;
      efcp.rPow_ += 1; // this left with sin(t) in jacobian.
    } else {  // oblate jacobian a^2b hc^2 sin(t)
      efcp.hPow_ += 2; // this left with sin(t) in jacobian.
    }
  }
  BasicFunc sinT(SIN, T, 2, 1.0);
  for (const auto& tf : rt1.tComp) {
    std::vector<BasicFunc> tmult = {tf};
    if (withJacobian)
     tmult = BasicFunc::multiply(sinT, tf);
    for (const auto& rf : rt1.rComp) {
      for (int i = 0; i < tmult.size(); i++)
        countRTPattern(efcp, rf, tmult[i], is1DTable, collectAll, set);
    }
  }
}

void ProlateOblate3D::dotProdPattern(const ProlateOblate3D& other, const bool is1DTable, std::unordered_set<uint64_t>& set) const {
  for (int i = 0; i < 3; i++) {
    EllipticFactor efM = eFact_[i];
    efM *= other.getEFactor(i);
    std::vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
    for (const auto& rt1 : RTProd)
      computeRTPattern(efM, rt1, true, is1DTable, false, set);
  }
}

Eigen::Vector3d ProlateOblate3D::computeRTP(const ProlateOblate3D& other, const IntTable1DData& tabData) const {
  Eigen::Vector3d result(0,0,0);

  for (int i = 0; i < 3; i++) {
    double pINT = computePhiInt(phiFunc_[i], other.getPhiFunc(i));
    // phi part is seperable.
    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and r.
      EllipticFactor efM = eFact_[i];
      efM *= other.getEFactor(i);
      double rtINT = 0;

      std::vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
      for (const auto& rt1 : RTProd)
        rtINT += inetgrateRTMult(efM, rt1, true, tabData);

      result[i] = pINT*rtINT;
    }
  }

  return result;
}

double ProlateOblate3D::dotProd(const ProlateOblate3D& other, const IntTable1DData& tabData) const {
  return computeRTP(other, tabData).sum();
}

void ProlateOblate3D::patternCurlCross(const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT,
        const EllipticFactor& curlEF, const EllipticFactor& crossEF, std::unordered_set<uint64_t>& set) const {

  std::vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  EllipticFactor efM  = curlEF;
  efM *= crossEF;

  // no jacobian, as jacobian is already in curl
  // efM*std::vector<basicFunc>
  for (const auto& rt : RTProd) {
    // computeVThetaPattern(rt.tComp, efM, false, set);
    computeRTPattern(efM, rt, false, false, true, set);
  }
}

double ProlateOblate3D::computeCurlCross(const BasicFunc& curlP, const std::vector<BasicFunc>& crossP,
                const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT,
                const EllipticFactor& curlEF, const EllipticFactor& crossEF, const IntTable1DData& tabData) const {
  // first integrate along phi.
  // int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += computePhiInt(curlP, cp);
  if (fabs(phiInt) < 1e-14)
    return 0.0;

  std::vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  EllipticFactor efM  = curlEF;
  efM *= crossEF;
  double rtInt = 0;
  // no jacobian, as jacobian is already in curl
  // efM*std::vector<basicFunc>
  for (auto& rt : RTProd) {
    rt.hashSimplify();
    // computeVThetaPattern(rt.tComp, efM, false, set);
    rtInt += inetgrateRTMult(efM, rt, false, tabData);
  }

  return phiInt*rtInt;
}

// (r^2*c^2*Cos[t] - Sin[t]^2*Cos[t])*RT_[2];
void ProlateOblate3D::setRT01() {
    BasicFunc cosT(COS, T, 2, 1.0, 0);
    curlRT_[0][1] = RT_[2];
    RTMultiply::multRVec(2, curlRT_[0][1]); // r^2
    BasicFunc c2CosT = cosT; // c^2*Cos[t]
    c2CosT *= c_*c_;
    // multiply into r and t components individually to save space.
    RTMultiply::multThetaVec(c2CosT, curlRT_[0][1]); // r^2*c^2*Cos[t]*RT_[2]
    // - Sin[t]^2*Cos[t]*RT_[2] = 1/4 (-Cos[t] + Cos[3 t])*RT_[2]
    std::vector<RTMultiply> R1 = RT_[2];
    std::vector<BasicFunc> S2CosT = {BasicFunc(COS, T, 2, -0.25), BasicFunc(COS, T, 6, 0.25)};
    for (auto& RT : R1) {
      RT.tComp = BasicFunc::vecVecMult(RT.tComp, S2CosT);
    }
    curlRT_[0][1].insert(curlRT_[0][1].end(), R1.begin(), R1.end());
}

void ProlateOblate3D::curlSph() {
  // sign is grouped into phi func
  curlPhi_[0][0] = phiFunc_[2];
  curlPhi_[0][1] = phiFunc_[2];
  curlPhi_[0][2] = -phiFunc_[1].deriv()[0];
  curlPhi_[1][0] = -phiFunc_[2];
  curlPhi_[1][1] = -phiFunc_[2];
  curlPhi_[1][2] = phiFunc_[0].deriv()[0];
  curlPhi_[2][0] = phiFunc_[1];
  curlPhi_[2][1] = phiFunc_[1];
  curlPhi_[2][2] = -phiFunc_[0];
  if (is_prolate_)
    curlSphProlate();
  else
    curlSphOblate();

  for (int j = 0; j < 3; j++)
    for (int i = 0; i < 3; i++) {
      for (auto& RT : curlRT_[j][i])
        RT.hashSimplify();
    }
}

#define DUP_T_SINT \
/* D[u_p, t]*Sin[t]*/\
curlRT_[0][0] = RT_[2];\
RTMultiply::derivTVec(curlRT_[0][0]); /* D[u_p, t]*/\
RTMultiply::multThetaVec(sinT, curlRT_[0][0]); /* D[u_p, t]*Sin[t]*/

#define DUP_R_SINT \
/*( Sin[t]) D[u_p, r]*/\
curlRT_[1][0] = RT_[2];\
RTMultiply::derivRVec(curlRT_[1][0]); /*D[u_p, r]*/\
RTMultiply::multThetaVec(sinT, curlRT_[1][0]); /*Sin[t]*D[u_p, r]*/

#define DUT_R_SINT \
curlRT_[2][0] = RT_[1];\
RTMultiply::derivRVec(curlRT_[2][0]); /*D[u_t, r]*/\
RTMultiply::multThetaVec(sinT, curlRT_[2][0]); /*Sin[t] D[u_t, r]*/

#define DUR_T_SINT \
curlRT_[2][2] = RT_[0];\
RTMultiply::derivTVec(curlRT_[2][2]); /* D[u_r, t]*/\
RTMultiply::multThetaVec(sinT, curlRT_[2][2]);  /* Sin[t] D[u_r, t]*/

void ProlateOblate3D::curlSphProlate() {
  // cos(theta), sin(theta)
  BasicFunc cosT(COS, T, 2, 1.0, 0);
  BasicFunc sinT(SIN, T, 2, 1.0, 0);

  if (index_ <= 4) {
    // hr hp tau_p D[u_p, t] = (a^2 c^3 r^2)/Sqrt[c^2 r^2 + Sin[t]^2]*D[u_p, t]*Sin[t]
    // (a^2 c^3 r^2)/Sqrt[c^2 r^2 + Sin[t]^2], a^2 c^3 = b^2 c
    curlEF_[0][0] = EllipticFactor(-1, 0, 2, b_*b_*c_);
    // D[u_p, t]*Sin[t]
    DUP_T_SINT;

    // (a^2 c^3 r^2 Cos[t] (c^2 r^2 - Sin[t]^2))/(c^2 r^2 + Sin[t]^2)^(3/2)
    // (r^2*c^2*Cos[t] - Sin[t]^2*Cos[t])*RT_[2];
    curlEF_[0][1] = EllipticFactor(-3, 0, 2, b_*b_*c_);
    setRT01();

    // a^2 c Sqrt[c^2 r^2 + Sin[t]^2], a*b
    curlEF_[0][2] = EllipticFactor(1, 0, 0, a_*b_);
    // D[u_t, p] = RT[1], phi
    curlRT_[0][2] = RT_[1];

    // (a^2 c^2 r^2 Sqrt[1 + c^2 r^2] Sin[t])/Sqrt[c^2 r^2 + Sin[t]^2]
    // ( Sin[t]) D[u_p, r]
    curlEF_[1][0] = EllipticFactor(-1, 1, 2, b_*b_);
    DUP_R_SINT;

    // r*a^2*c^2 = r*b^2
    curlEF_[1][1] = EllipticFactor(-3, -1, 1, b_*b_);
    // (c^4 r^4 Sin[t] + (2 + 3 c^2 r^2) Sin[t]^3)*u_p
    curlRT_[1][1] = RT_[2];
    BasicFunc c4SinT = sinT;
    c4SinT *= c_*c_*c_*c_;
    RTMultiply::multRVec(4, curlRT_[1][1]); // r^4
    RTMultiply::multThetaVec(c4SinT, curlRT_[1][1]); // c^4 r^4 Sin[t]*u_p 
    // (2 + 3 c^2 r^2) 1/4 (3 Sin[t] - Sin[3 t])
    std::vector<RTMultiply> R1 = RT_[2];
    std::vector<BasicFunc> S3T = {BasicFunc(SIN, T, 2, 0.75), BasicFunc(SIN, T, 6, -0.25)};
    std::vector<BasicFunc> c2r2Plus2 = {BasicFunc(ONE, R, 0, 2.0), BasicFunc(ONE, R, 0, 3*c_*c_, 2)};
    for (auto& RT : R1) { // (2 + 3 c^2 r^2) Sin[t]^3 u_p
      RT.tComp = BasicFunc::vecVecMult(RT.tComp, S3T);
      RT.rComp = BasicFunc::vecVecMult(RT.rComp, c2r2Plus2);
    }
    curlRT_[1][1].insert(curlRT_[1][1].end(), R1.begin(), R1.end());

    // (a^2 c^2 r Sqrt[c^2 r^2 + Sin[t]^2])/Sqrt[1 + c^2 r^2] D[u_r, p]
    // D[u_r, p]
    curlEF_[1][2] = EllipticFactor(1,-1, 1, b_*b_);
    curlRT_[1][2] = RT_[0];

    // a^2 c r Sqrt[1 + c^2 r^2] Sin[t] D[u_t, r]
    // Sin[t] D[u_t, r],
    curlEF_[2][0] = EllipticFactor(0, 1, 1, b_*a_);
    DUT_R_SINT;

    // (a^2 c^3 r^2 Sin[t])/Sqrt[1 + c^2 r^2] u_t
    // (Sin[t]) u_t
    curlEF_[2][1] = EllipticFactor(0, -1, 2, b_*b_*c_);
    curlRT_[2][1] = RT_[1];
    RTMultiply::multThetaVec(sinT, curlRT_[2][1]); // (Sin[t]) u_t

    // (a^2 c^3 r^2 Sin[t])/Sqrt[1 + c^2 r^2] D[u_r, t]
    // Sin[t] D[u_r, t]
    curlEF_[2][2] = EllipticFactor(0, -1, 2, b_*b_*c_);
    DUR_T_SINT;

  } if (index_ == 5 || index_ == 6) {
    //  Sin[t]/D[U_p, t]
    curlEF_[0][0] = EllipticFactor(-1, -1, 1, b_*b_);
    DUP_T_SINT;

    // (r^2*c^2*Cos[t] - Sin[t]^2*Cos[t])*RT_[2];
    curlEF_[0][1] = EllipticFactor(-3, -1, 1, b_*b_);
    setRT01();

    curlEF_[0][2] = EllipticFactor(1, -1, 1, b_*b_);
    // D[u_t, p] = RT[1], phi
    curlRT_[0][2] = RT_[1];

    //(a^2 c r Sin[t])/Sqrt[c^2 r^2 + Sin[t]^2]
    //(Sin[t])
    curlEF_[1][0] = EllipticFactor(-1, 0, 1, a_*b_);
    DUP_R_SINT;

    // (Sin[t] (-c^3 r^2 + c Sin[t]^2))
    curlEF_[1][1] = EllipticFactor(-3, 0, 0, a_*a_);
    // (Sin[t] (-c^3 r^2 + c Sin[t]^2))*u_p
    curlRT_[1][1] = RT_[2];
    for (auto& RT : curlRT_[1][1])
      RT.rComp = BasicFunc::vecMultOne(RT.rComp, BasicFunc(ONE, R, 0, -c_*c_*c_, 2));
    std::vector<RTMultiply> R1 = RT_[2];
    // c/2 (1 - Cos[2 t])
    std::vector<BasicFunc> cSinT2 = {BasicFunc(ONE, T, 0, c_*0.5), BasicFunc(COS, T, 4, -0.5*c_)};
    for (auto& RT : R1)
      RT.tComp = BasicFunc::vecVecMult(RT.tComp, cSinT2);
    // R1 = c Sin[t]^2*u_p
    curlRT_[1][1].insert(curlRT_[1][1].end(), R1.begin(), R1.end()); // (-c^3 r^2 + c Sin[t]^2))*u_p
    RTMultiply::multThetaVec(sinT, curlRT_[1][1]); // Sin[t](-c^3 r^2 + c Sin[t]^2))*u_p

    curlEF_[1][2] = EllipticFactor(1, 0,0, a_*b_);
    // D[u_r, p]
    curlRT_[1][2] = RT_[0];

    // Sin[t]
    curlEF_[2][0] = EllipticFactor(0,0,2, b_*b_);
    DUT_R_SINT;

   //  a^2 c^2 r Sin[t]
    curlEF_[2][1] = EllipticFactor(0,0,1,b_*b_);
    curlRT_[2][1] = RT_[1];
    RTMultiply::multThetaVec(sinT, curlRT_[2][1]); // (Sin[t]) u_t

    //  a^2 c^2 r Sin[t]
    curlEF_[2][2] = EllipticFactor(0,0,1,b_*b_);
    DUR_T_SINT;

  } else if (index_ == 7) {
    // (a^2 c^2 r Sin[t] Sqrt[c^2 r^2 + Sin[t]^2])/Sqrt[1 + c^2 r^2]
    // Sin[t]
    curlEF_[0][0] = EllipticFactor(1, -1, 1, b_*b_);
    DUP_T_SINT;

    // Cos[t]*u_p
    curlEF_[0][1] = EllipticFactor(1, -1, 1, b_*b_);
    curlRT_[0][1] = RT_[2];
    RTMultiply::multThetaVec(cosT, curlRT_[0][1]); // Cos[t]*RT_[2]

    curlEF_[0][2] = EllipticFactor(0,0,0,0);
    curlRT_[0][2] = {};

    // Sin[t]*D[u_p, r]
    curlEF_[1][0] = EllipticFactor(1, 0, 1, a_*b_);
    DUP_R_SINT;

    // Sin[t]*u_p
    curlEF_[1][1] = EllipticFactor(1, 0, 0, a_*b_);
    curlRT_[1][1] = RT_[2];
    RTMultiply::multThetaVec(sinT, curlRT_[1][1]); // Sin[t]*u_p

    curlEF_[1][2] = EllipticFactor(0,0,0,0);
    curlRT_[1][2] = {};

    curlEF_[2][0] = EllipticFactor(0,0,0,0);
    curlRT_[2][0] = {};

    curlEF_[2][1] = EllipticFactor(0,0,0,0);
    curlRT_[2][1] = {};

    curlEF_[2][2] = EllipticFactor(0,0,0,0);
    curlRT_[2][2] = {};
  }
}

#define setUpRT01 \
/* Cos[t] (c^2 r^2 + 1 + Sin[t]^2)*u_p */\
curlRT_[0][1] = RT_[2];\
for (auto& RT : curlRT_[0][1]) /* c^2 r^2 u_p*/\
  RT.rComp = BasicFunc::vecMultOne(RT.rComp, BasicFunc(ONE, R, 0, c_*c_, 2));\
std::vector<RTMultiply> R1 = RT_[2];\
/* 1 + Sin[t]^2 = 1/2 (3 - Cos[2 t])*/\
std::vector<BasicFunc> s2T1 = {BasicFunc(ONE, T, 0, 1.5), BasicFunc(COS, T, 4, -0.5)};\
for (auto& RT : R1)  /* (1 + Sin[t]^2)*u_p*/\
  RT.tComp = BasicFunc::vecVecMult(RT.tComp, s2T1);\
curlRT_[0][1].insert(curlRT_[0][1].end(), R1.begin(), R1.end());  /* (c^2 r^2 + 1 + Sin[t]^2)*u_p*/\
RTMultiply::multThetaVec(cosT, curlRT_[0][1]); /* Cos[t] (c^2 r^2 + 1 + Sin[t]^2)*u_p*/


void ProlateOblate3D::curlSphOblate() {
  BasicFunc cosT(COS, T, 2, 1.0, 0);
  BasicFunc sinT(SIN, T, 2, 1.0, 0);
  if (index_ <= 3) {  // 0,1,2,3
    //(Sin[t])
    curlEF_[0][0] = EllipticFactor(-1, 1, 1, b_*b_);
    // D[u_p, t]*Sin[t]
    DUP_T_SINT;

    // Cos[t] (c^2 r^2 + 1 + Sin[t]^2)*u_p
    curlEF_[0][1] = EllipticFactor(-3, 1, 1, b_*b_);
    setUpRT01

    //(a^2 c^2 )
    curlEF_[0][2] = EllipticFactor(1, -1, 1, b_*b_);
    // D[u_t, p] = RT[1], phi
    curlRT_[0][2] = RT_[1];

    // (Sin[t]) D[u_p, r]
    curlEF_[1][0] = EllipticFactor(-1, 2, 1, a_*b_);
    DUP_R_SINT;

    // (1 + c^2 r^2 + 2 c^4 r^4 + (1 + 3 c^2 r^2) Cos[2 t]) Sin[t]) u_p
    curlEF_[1][1] = EllipticFactor(-3, 0, 0, a_*b_*0.5);
    curlRT_[1][1] = RT_[2];
    std::vector<BasicFunc> c2r2c4r4One = {BasicFunc(ONE, R, 0, 1.0), BasicFunc(ONE, R, 0, c_*c_, 2), 
                                     BasicFunc(ONE, R, 0, c_*c_*c_*c_*2.0, 4)};
    for (auto& RT : curlRT_[1][1])  // (1 + c^2 r^2 + 2 c^4 r^4)u_p
      RT.rComp = BasicFunc::vecVecMult(RT.rComp, c2r2c4r4One);
    R1.clear();
    R1 = RT_[2]; // u_p
    std::vector<BasicFunc> c2r2One = {BasicFunc(ONE, R, 0, 1.0), BasicFunc(ONE, R, 0, 3.0*c_*c_, 2)};
    for (auto& RT : R1) { // (1 + 3 c^2 r^2) Cos[2 t] u_p
      RT.rComp = BasicFunc::vecVecMult(RT.rComp, c2r2One);
      RT.tComp = BasicFunc::vecMultOne(RT.tComp, BasicFunc(COS, T, 4, 1.0));
    }
    // (1 + c^2 r^2 + 2 c^4 r^4)u_p + (1 + 3 c^2 r^2) Cos[2 t] u_p
    curlRT_[1][1].insert(curlRT_[1][1].end(), R1.begin(), R1.end());
    RTMultiply::multThetaVec(sinT, curlRT_[1][1]); // Sin[t]

    curlEF_[1][2] = EllipticFactor(1, -2, 2, c_*b_*b_);
    curlRT_[1][2] = RT_[0]; // D[u_r, p]

    // Sin[t]
    curlEF_[2][0] = EllipticFactor(0, 1, 1, a_*b_);
    DUT_R_SINT;

    // Sin[t]
    curlEF_[2][1] = EllipticFactor(0, 1, 0, a_*b_);
    curlRT_[2][1] = RT_[1];
    RTMultiply::multThetaVec(sinT, curlRT_[2][1]); // (Sin[t]) u_t

    // (Sin[t])
    curlEF_[2][2] = EllipticFactor(0, -1, 2, c_*b_*b_);
    DUR_T_SINT;
  } else if (index_ == 4) {

    curlEF_[0][0] = EllipticFactor(0,0,0,0);
    curlRT_[0][0] = {};
    curlEF_[0][1] = EllipticFactor(0,0,0,0);
    curlRT_[0][1] = {};

    curlEF_[0][2] = EllipticFactor(0, -1, 1, b_*b_);
    curlRT_[0][2] = RT_[1]; // D[u_t, p]

    curlEF_[1][0] = EllipticFactor(0,0,0,0);
    curlRT_[1][0] = {};
    curlEF_[1][1] = EllipticFactor(0,0,0,0);
    curlRT_[1][1] = {};

    curlEF_[1][2] = EllipticFactor(1, 0, 0, a_*b_);
    // D[u_r, p]
    curlRT_[1][2] = RT_[0];

    // Sin[t]
    curlEF_[2][0] = EllipticFactor(0, 1, 0, a_*a_);
    // D[u_t, r]Sin[t]
    DUT_R_SINT;

    curlEF_[2][1] = EllipticFactor(0,0,0,0);
    curlRT_[2][1] = {};

    // Sin[t]
    curlEF_[2][2] = EllipticFactor(0, 1, 0, a_*b_);
    DUR_T_SINT;
  } else if (index_ == 5 || index_ == 6) {

    // ( Sin[t])
    curlEF_[0][0] = EllipticFactor(-1, 0, 0, a_*b_);
    DUP_T_SINT;

    //(Cos[t] (c^2 r^2 + 1 + Sin[t]^2))
    curlEF_[0][1] = EllipticFactor(-3, 0,0, a_*b_);
    setUpRT01;

    curlEF_[0][2] = EllipticFactor(1, 0,0, a_*b_);
    // D[u_t, p] = RT[1], phi
    curlRT_[0][2] = RT_[1];

    // (Sin[t])
    curlEF_[1][0] = EllipticFactor(-1, 1, 0, a_*a_);
    DUP_R_SINT;

    // -((a^2 c^2 r (2 + c^2 r^2 - Cos[t]^2) Sin[t])
    // (2 + c^2 r^2 - Cos[t]^2) -Sin[t]
    curlEF_[1][1] = EllipticFactor(-3, -1, 1, b_*b_);
    curlRT_[1][1] = RT_[2]; // u_p
    std::vector<BasicFunc> c2r2Plus2 = {BasicFunc(ONE, R, 0, 2.0), BasicFunc(ONE, R, 0, c_*c_, 2)};
    for (auto& RT : curlRT_[1][1]) // (2 + c^2 r^2)*u_p
      RT.rComp = BasicFunc::vecVecMult(RT.rComp, c2r2Plus2);
    // -cos[t]^2 = -1/2 (1 + Cos[2 t])
    R1.clear();
    R1 = RT_[2];
    for (auto& RT : R1)
      RT.tComp = BasicFunc::vecVecMult(RT.tComp, {BasicFunc(ONE, T, 0, -0.5), BasicFunc(COS, T, 4, -0.5)});
    curlRT_[1][1].insert(curlRT_[1][1].end(), R1.begin(), R1.end()); // (2 + c^2 r^2 - Cos[t]^2)*u_p
    RTMultiply::multThetaVec(BasicFunc(SIN, T, 2, -1.0), curlRT_[1][1]);

    curlEF_[1][2] = EllipticFactor(1, -1, 1, b_*b_);
    curlRT_[1][2] = RT_[0]; // D[u_r, p]

    // Sin[t]*D[u_t,r ]
    curlEF_[2][0] = EllipticFactor(0, 2, 0, a_*a_);
    DUT_R_SINT;

    // Sin[t]
    curlEF_[2][1] = EllipticFactor(0, 0, 1, b_*b_);
    curlRT_[2][1] = RT_[1];
    RTMultiply::multThetaVec(sinT, curlRT_[2][1]); // (Sin[t]) u_t

    // Sin[t]
    curlEF_[2][2] = EllipticFactor(0, 0, 1, b_*b_);
    DUR_T_SINT;
  } else if (index_ == 7) {
    // Sin[t]
    curlEF_[0][0] = EllipticFactor(1, 0, 0, a_*b_);
    DUP_T_SINT;

    // Cos[t]
    curlEF_[0][1] = EllipticFactor(1, 0, 0, a_*b_);
    curlRT_[0][1] = RT_[2];
    RTMultiply::multThetaVec(cosT, curlRT_[0][1]); // Cos[t]*RT_[2]

    curlEF_[0][2] = EllipticFactor(0,0,0,0);
    curlRT_[0][2] = {};

    // Sin[t]
    curlEF_[1][0] = EllipticFactor(1, 1, 0, a_*a_);
    DUP_R_SINT;

    // Sin[t]
    curlEF_[1][1] = EllipticFactor(1, -1, 1, b_*b_);
    curlRT_[1][1] = RT_[2];
    RTMultiply::multThetaVec(sinT, curlRT_[1][1]); // Sin[t]*u_p

    curlEF_[1][2] = EllipticFactor(0,0,0,0);
    curlRT_[1][2] = {};

    curlEF_[2][0] = EllipticFactor(0,0,0,0);
    curlRT_[2][0] = {};

    curlEF_[2][1] = EllipticFactor(0,0,0,0);
    curlRT_[2][1] = {};

    curlEF_[2][2] = EllipticFactor(0,0,0,0);
    curlRT_[2][2] = {};
  }
}
// This also doesnt include norm
// a2 b3 - a3 b2
// a3 b1 - a1 b3
// a1 b2 - a2 b1
void ProlateOblate3D::getCrossEF(const ProlateOblate3D& phiG, const ProlateOblate3D& phiH, EllipticFactor (&crossEF)[3][2]) {
  crossEF[0][0] = EllipticFactor::mult(phiG.getEFactor(1), phiH.getEFactor(2));
  crossEF[0][1] = EllipticFactor::mult(phiG.getEFactor(2), phiH.getEFactor(1));
  crossEF[1][0] = EllipticFactor::mult(phiG.getEFactor(2), phiH.getEFactor(0));
  crossEF[1][1] = EllipticFactor::mult(phiG.getEFactor(0), phiH.getEFactor(2));
  crossEF[2][0] = EllipticFactor::mult(phiG.getEFactor(0), phiH.getEFactor(1));
  crossEF[2][1] = EllipticFactor::mult(phiG.getEFactor(1), phiH.getEFactor(0));
}

void ProlateOblate3D::computeTensorPattern(const ProlateOblate3D& phiG,
       const ProlateOblate3D& phiH, std::unordered_set<uint64_t>& set) const {
  
  std::vector<BasicFunc> crossPhi[3][2];
  std::vector<RTMultiply> crossRT[3][2];
  EllipticFactor crossEF[3][2];

  SphereBasis3D::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis3D::crossProdRT(phiG, phiH, crossRT);
  getCrossEF(phiG, phiH, crossEF);

  // r component
  for (int ind = 0; ind < 3; ind++) {
    //rVal += integrateCurlCross( phiI.getCurRT(0,ind), crossRT[0][0]);
    //rVal += integrateCurlCross( phiI.getCurRT(0,ind), crossRT[0][1]);
    patternCurlCross(this->getCurRT(0,ind), crossRT[0][0], this->getcurlEF(0,ind), crossEF[0][0], set);
    patternCurlCross(this->getCurRT(0,ind), crossRT[0][1], this->getcurlEF(0,ind), crossEF[0][1], set);
  }

  for (int ind = 0; ind < 3; ind++) {
    //integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][0], phiI.getCurRT(1,ind), crossRT[1][0]);
    //integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][1], phiI.getCurRT(1,ind), crossRT[1][1]);
    patternCurlCross(this->getCurRT(1,ind), crossRT[1][0], this->getcurlEF(1,ind), crossEF[1][0], set);
    patternCurlCross(this->getCurRT(1,ind), crossRT[1][1], this->getcurlEF(1,ind), crossEF[1][1], set);
  }

  for (int ind = 0; ind < 3; ind++) {
    // integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][0], phiI.getCurRT(2,ind), crossRT[2][0]);
    // integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][1], phiI.getCurRT(2,ind), crossRT[2][1]);
    patternCurlCross(this->getCurRT(2,ind), crossRT[2][0], this->getcurlEF(2,ind), crossEF[2][0], set);
    patternCurlCross(this->getCurRT(2,ind), crossRT[2][1], this->getcurlEF(2,ind), crossEF[2][1], set);
  }
}

double ProlateOblate3D::computeTensorEntry(const ProlateOblate3D& phiG,
     const ProlateOblate3D& phiH, const IntTable1DData& tabData) const {

  std::vector<BasicFunc> crossPhi[3][2];
  std::vector<RTMultiply> crossRT[3][2];
  EllipticFactor crossEF[3][2];

  SphereBasis3D::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis3D::crossProdRT(phiG, phiH, crossRT);

  getCrossEF(phiG, phiH, crossEF);

   // r component
  double result = 0;
  for (int ind = 0; ind < 3; ind++) {
    result += computeCurlCross(this->getCurPhi(0,ind), crossPhi[0][0], this->getCurRT(0,ind),
                               crossRT[0][0], this->getcurlEF(0,ind), crossEF[0][0], tabData);
    result += computeCurlCross(this->getCurPhi(0,ind), crossPhi[0][1], this->getCurRT(0,ind),
                               crossRT[0][1], this->getcurlEF(0,ind), crossEF[0][1], tabData);
  }

  for (int ind = 0; ind < 3; ind++) {
    result += computeCurlCross(this->getCurPhi(1,ind), crossPhi[1][0], this->getCurRT(1,ind),
                               crossRT[1][0], this->getcurlEF(1,ind), crossEF[1][0], tabData);
    result += computeCurlCross(this->getCurPhi(1,ind), crossPhi[1][1], this->getCurRT(1,ind),
                               crossRT[1][1], this->getcurlEF(1,ind), crossEF[1][1], tabData);
  }

  for (int ind = 0; ind < 3; ind++) {
    result += computeCurlCross(this->getCurPhi(2,ind), crossPhi[2][0], this->getCurRT(2,ind),
                               crossRT[2][0], this->getcurlEF(2,ind), crossEF[2][0], tabData);
    result += computeCurlCross(this->getCurPhi(2,ind), crossPhi[2][1], this->getCurRT(2,ind),
                               crossRT[2][1], this->getcurlEF(2,ind), crossEF[2][1], tabData);
  }

  return result*this->GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();;
}

// debug functions

void ProlateOblate3D::printFullForm() const {
  printf("{ ");
  eFact_[0].print();
  printf("*( ");
  for (const auto& RT: RT_[0]) {
    printf("+");
    RT.print();
  }
  printf(")*"); phiFunc_[0].print(); printf(",");

  eFact_[1].print();
  printf("*( ");
  for (const auto& RT: RT_[1]) {
    printf("+");
    RT.print();
  }
  printf(")*"); phiFunc_[1].print(); printf(",");
  
  eFact_[2].print();
  printf("*( ");
  for (const auto& RT: RT_[2]) {
    printf("+");
    RT.print();
  }
  printf(")*"); phiFunc_[2].print(); printf("}");
}

void ProlateOblate3D::printJCurl() const {
  printf("{ ");
  for (int j = 0; j < 3; j++) {
    for (int i = 0; i < 3; i++) {
      printf("+");
      curlEF_[j][i].print();
      printf("*( ");
      if (curlRT_[j][i].size() == 0)
        printf("0");
      else {
        for (const auto& RT: curlRT_[j][i]) {
          printf("+");
          RT.print();
        }
      }
      printf(")*"); curlPhi_[j][i].print(); 
    }
    if (j != 2) 
      printf(",");
  }
  printf("}");
}

void ProlateOblate3D::printCrossProd(const ProlateOblate3D& phiG, const ProlateOblate3D& phiH) {
  std::vector<BasicFunc> crossPhi[3][2];
  std::vector<RTMultiply> crossRT[3][2];
  EllipticFactor crossEF[3][2];

  SphereBasis3D::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis3D::crossProdRT(phiG, phiH, crossRT);
  getCrossEF(phiG, phiH, crossEF);
  printf("{ ");

  for (int j = 0; j < 3; j++) {
    for (int i = 0; i < 2; i++) {
      printf("+");
      crossEF[j][i].print();
      printf("*( ");
      if (crossRT[j][i].size() == 0)
        printf("0");
      else {
        for (const auto& RT: crossRT[j][i]) {
          printf("+");
          RT.print();
        }
      }
      printf(")*("); BasicFunc::printVec(crossPhi[j][i]); printf(")");
    }
    if (j != 2) 
      printf(",");
  }
  printf("}");
}

ProlateOblate3D* ProlateOblate3D::fromFile(std::ifstream& in, const bool is_prolate, const IntTable1DData& tabData) {
  int k1x2, k2x2, k3x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k3x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));

  return new ProlateOblate3D(k1x2, k2x2, k3x2, index_, tabData, is_prolate);
}