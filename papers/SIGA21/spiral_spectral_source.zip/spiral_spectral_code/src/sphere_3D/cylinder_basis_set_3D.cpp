#include <Eigen/Eigen>
#include <fstream>
#include <iomanip>
#include <glog/logging.h>
#include <memory>

#include "common/basic_function.h"
#include "common/basis_set.h"
#include "sphere_3D/cylinder_basis_set_3D.h"
#include "3D/FIELD_3D.h"
#include "3D/particle_3d.h"
#include "3D/VECTOR3_FIELD_3D.h"

#include "util/read_write_tensor.h"
#include "util/transform.h"

using namespace std;

#define MGSORTHORUN Eigen::MatrixXd Coef;\
int m = 1;\
vector<basisPtr3DCyl> allocated;\
runMGS(thresh, tempBuffer, allocated, Coef, m);\
all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
Coefs.push_back(Coef.topLeftCorner(m,m));

void CylinderBasisSet3D::allocateMGS() {
  // we have 6 different modes.
  phiCoef_.resize(6);
  vector<Eigen::MatrixXd> Coefs;
  const double thresh = 0.2;
  
  // half integer for dirichlet bc
  int offsetR = isDirichletR_ ? 0 : 1;
  int offsetZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 0;
  int offsetEn = isDirichletR_ ? 1 : 0;
  //int offsetOdd = !boundaryCnd_ ? 1 : 0;

  // allocate Phi^0, Psi^2, Psi^5
  for (int i3 = 1; i3 < zK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {

      vector<basisPtr3DCyl> tempBuffer;
      // put enrichment basis functions first
      // interestingly, when i2==1, the linear space of Phi^0 almost coverlaps with Phi^2
      // Phi^2
      if (i2 == 1) {
        for (int i1 = 1; i1 < rK_; i1++) {
          int k1x2 = i1*2 - offsetEn;
          int k3x2 = i3*2 - offsetZ;
          if (! isDirichletR_)
            k1x2 = (i1-1)*2;   // starts with 0.
          if (zBndCndIdx_ == 2)   // neumann both ends
            k3x2 = (i3-1)*2;
          if (k1x2 != 0 || k3x2 != 0)
            tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(k1x2, 2, k3x2, 2, b_, isDirichletR_, zBndCndIdx_)));
        }
      }

      // Phi^0
      for (int i1 = 1; i1 < rK_; i1++) {
        int k3x2 = i3*2 - offsetZ;
        if (zBndCndIdx_ == 2) // neumann both ends.
          k3x2 = (i3-1)*2;
        tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(i1*2 - offsetR, i2*2, k3x2, 0, b_, isDirichletR_, zBndCndIdx_)));
      }
      // Run MGS, reject basis, and collect coefficients.
      MGSORTHORUN;
    }

  for (int i3 = 1; i3 < zK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {

      vector<basisPtr3DCyl> tempBuffer;

      // Phi^3
      if (i2 == 1) {
        for (int i1 = 1; i1 < rK_; i1++) {
          int k1x2 = i1*2 - offsetEn;
          int k3x2 = i3*2 - offsetZ;
          if (! isDirichletR_)
            k1x2 = (i1-1)*2;   // starts with 0.
          if (zBndCndIdx_ == 2)   // neumann both ends
            k3x2 = (i3-1)*2;
          if (k1x2 != 0 || k3x2 != 0)
            tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(k1x2, 2, k3x2, 3, b_, isDirichletR_, zBndCndIdx_)));
        }
      }

      // Phi^1
      for (int i1 = 1; i1 < rK_; i1++) {
        int k3x2 = i3*2 - offsetZ;
        if (zBndCndIdx_ == 2) // neumann both ends.
          k3x2 = (i3-1)*2;
        tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(i1*2 - offsetR, i2*2, k3x2, 1, b_, isDirichletR_, zBndCndIdx_)));
      }
      // Run MGS, reject basis, and collect coefficients.
      MGSORTHORUN;
    }

    // Phi^4
    for (int i3 = 1; i3 < zK_; i3++) {
      vector<basisPtr3DCyl> tempBuffer;
      for (int i1 = 1; i1 < rK_; i1++) {
        int k1x2 = i1*2 - offsetEn;
        int k3x2 = i3*2 - offsetZ;
        if (! isDirichletR_)
          k1x2 = (i1-1)*2;
        if (zBndCndIdx_ == 2) // both neumann, need dc
          k3x2 = (i3-1)*2;
        if (zBndCndIdx_ == 2 && i1 == 1 && i3 == 1)
          tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(0, 0, 0, 4, b_, isDirichletR_, zBndCndIdx_)));
        // this one allows both wavenumber goes to zero when both neumann along z.
        tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(k1x2, 0, k3x2, 4, b_, isDirichletR_, zBndCndIdx_)));
      }
      MGSORTHORUN;
    }
  
  // Phi^5
  for (int i3 = 0; i3 < zK_; i3++) {
    vector<basisPtr3DCyl> tempBuffer;
    for (int i1 = 1; i1 < rK_; i1++)
      tempBuffer.push_back(basisPtr3DCyl(new CylinderBasis3D(i1*2, 0, i3*2, 5, b_, isDirichletR_, zBndCndIdx_)));
    MGSORTHORUN;
  }

  initPhiCoef();
  numBasisAll_ = all_basis_.size();
  numBasisOrtho_ = all_basis_.size();
  LOG(INFO) << "total number of basis " << numBasisAll_;
  LOG(INFO) << "total number of ortho basis: " << numBasisOrtho_;

  // Assemble global coefficient matrix.
  A_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
  int colIdx = 0;
  // Square matrices.
  for (int i = 0; i < Coefs.size(); i++) {
    int curSize = Coefs[i].rows();
    A_.block(colIdx, colIdx, curSize, curSize) = Coefs[i];
    colIdx += curSize;
  }
}

void CylinderBasisSet3D::initPhiCoef() {
  // init phiCoef
  for (int i = 0; i < all_basis_.size(); i++) {
    int idx = all_basis_[i]->index();
    int i1x2 = all_basis_[i]->WN1x2();
    int i2x2 = all_basis_[i]->WN2x2();
    int i3x2 = all_basis_[i]->WN3x2();
    pairedCoef coef(i1x2, i2x2, i3x2, 0);
    phiCoef_[idx].push_back(coef);
    // init inverselookup
    uint64_t hash = Basis3D::toHash(i1x2, i2x2, i3x2, idx);
    basisLookup_[hash] = i;
  }
}

void CylinderBasisSet3D::allocateTemp() {
  totalSize_ = nTheta_*nZ_*nR_;
  invTotalSize_ = 1.0 / totalSize_;
  dR_ = 1.0 / nR_;
  dTheta_ = 2.0*M_PI / nTheta_;
  // parameter space.
  dZ_ = 1.0 / nZ_;

  nThetaE_ = thetaK_*2 + 4;
  nZE_ = zK_*2 + 4;
  // memory layour, r is outmost direction, then theta, then z.
  // for exmple, an index of inTemp_ will be indexed as index = r*nZTheta_ + t*nZ_ + z;
  if (zBndCndIdx_ == 1 || zBndCndIdx_ == 3)
    zStride_ = nZ_*2;

  int multipierR_ = ! isDirichletR_ ? 2 : 1;
  multipier_ = ! isDirichletR_ ? 2 : 1;
  int multipierz = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 2 : 1;
  multipier_ *= multipierz;
  // these are used for principle basis functions. 
  inTemp_ = (double*) fftw_malloc(sizeof(double)*nR_*nThetaE_*nZE_*multipierR_);
  memset(inTemp_, 0x00, sizeof(double)*nR_*nThetaE_*nZE_*multipierR_);
  pointerSize_[inTemp_] = nR_*nThetaE_*nZE_*multipierR_;

  inTemp1_ = (double*) fftw_malloc(sizeof(double)*nR_*nThetaE_*nZE_*multipierR_);
  memset(inTemp1_, 0x00, sizeof(double)*nR_*nThetaE_*nZE_*multipierR_);
  pointerSize_[inTemp1_] = nR_*nThetaE_*nZE_*multipierR_;

  tTemp_ = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_*nZE_);
  memset(tTemp_, 0x00, sizeof(double)*nR_*nTheta_*nZE_);
  pointerSize_[tTemp_] = nR_*nTheta_*nZE_;

  vrTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier_);
  memset(vrTemp_, 0x00, sizeof(double)*totalSize_*multipier_);
  pointerSize_[vrTemp_] = totalSize_*multipier_;

  vtTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier_);
  memset(vtTemp_, 0x00, sizeof(double)*totalSize_*multipier_);
  pointerSize_[vtTemp_] = totalSize_*multipier_;

  vpTemp_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier_);
  memset(vpTemp_, 0x00, sizeof(double)*totalSize_*multipier_);
  pointerSize_[vpTemp_] = totalSize_*multipier_;

  temp0_ = (double*) fftw_malloc(sizeof(double)*totalSize_*multipier_);
  memset(temp0_, 0x00, sizeof(double)*totalSize_*multipier_);
  pointerSize_[temp0_] = totalSize_*multipier_;

  int rzRsize = isDirichletR_ ? 2*nR_ : nR_;
  rZTemp_ = (double*) fftw_malloc(sizeof(double)*rzRsize*nZE_);
  memset(rZTemp_, 0x00, sizeof(double)*rzRsize*nZE_);
  pointerSize_[rZTemp_] = rzRsize*nZE_;

  rZTemp1_ = (double*) fftw_malloc(sizeof(double)*rzRsize*nZE_);
  memset(rZTemp1_, 0x00, sizeof(double)*rzRsize*nZE_);
  pointerSize_[rZTemp1_] = rzRsize*nZE_;
  
  int rsize4A = isDirichletR_ ? nR_ : 2*nR_;
  rZTemp4A_ = (double*) fftw_malloc(sizeof(double)*rsize4A*nZE_);
  memset(rZTemp4A_, 0x00, sizeof(double)*rsize4A*nZE_);
  pointerSize_[rZTemp4A_] = rsize4A*nZE_;
  rZTemp4A1_ = (double*) fftw_malloc(sizeof(double)*rsize4A*nZE_);
  memset(rZTemp4A1_, 0x00, sizeof(double)*rsize4A*nZE_);
  pointerSize_[rZTemp4A1_] = rsize4A*nZE_;

  rZTemp5_ = (double*) fftw_malloc(sizeof(double)*nR_*nZ_);
  memset(rZTemp5_, 0x00, sizeof(double)*nR_*nZ_);
  pointerSize_[rZTemp5_] = nR_*nZ_;

  sinHalfPiR_ = (double*) fftw_malloc(sizeof(double)*nR_);
  memset(sinHalfPiR_, 0x00, sizeof(double)*nR_);
  cosHalfPiR_ = (double*) fftw_malloc(sizeof(double)*nR_);
  memset(cosHalfPiR_, 0x00, sizeof(double)*nR_);
  
  weightF_ = (double*) fftw_malloc(sizeof(double)*nR_);
  memset(weightF_, 0x00, sizeof(double)*nR_);
  weightDerivF_ = (double*) fftw_malloc(sizeof(double)*nR_);
  memset(weightDerivF_, 0x00, sizeof(double)*nR_);

  for (int i = 0; i < nR_; i++) {
    double r = ((double)(i) + 0.5)*dR_;
    sinHalfPiR_[i] = sin(M_PI*0.5*r);
    cosHalfPiR_[i] = cos(M_PI*0.5*r);
    weightF_[i] = CylinderBasis3D::weightF(r);
    weightDerivF_[i] = CylinderBasis3D::weightFDeriv(r);
  }

  LOG(INFO) << "multipier: " << multipier_;

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    double k3 = all_basis_[i]->WN3D();
    waveNum2_[i] = k1*k1 + k2*k2 + k3*k3;
  }
}

void CylinderBasisSet3D::setUpFFTWPlan() {
  fftw_r2r_kind invS_ = FFTW_RODFT01;
  fftw_r2r_kind invC_ = FFTW_REDFT01;
  fftw_r2r_kind fwdS_ = FFTW_RODFT10;
  fftw_r2r_kind fwdC_ = FFTW_REDFT10;

  // full plans are all 2D plans,
  // R plan only covers a nr*nz slice, need to run nT times. 
  // T plan only covers a nz*nt slice, need to run nR times.
  // stride, dist
  int howManyR = nZ_;
  int nr[1] = {nR_};
  if (!isDirichletR_)  // neumann
    nr[0] = 2*nR_;
  // Need to be executed thetaK_*2 times
  IsinRE_ = fftw_plan_many_r2r(1, nr, nZE_, inTemp_, nr, nZE_*nThetaE_, 1, inTemp_, nr, nZE_*nThetaE_, 1, &invS_, FFTW_MEASURE);
  IcosRE_ = fftw_plan_many_r2r(1, nr, nZE_, inTemp_, nr, nZE_*nThetaE_, 1, inTemp_, nr, nZE_*nThetaE_, 1, &invC_, FFTW_MEASURE);
  FsinRE_ = fftw_plan_many_r2r(1, nr, nZE_, inTemp_, nr, nZE_*nThetaE_, 1, inTemp_, nr, nZE_*nThetaE_, 1, &fwdS_, FFTW_MEASURE);
  FcosRE_ = fftw_plan_many_r2r(1, nr, nZE_, inTemp_, nr, nZE_*nThetaE_, 1, inTemp_, nr, nZE_*nThetaE_, 1, &fwdC_, FFTW_MEASURE);
  
  // 2D plans on 3D grid
  int nr1[1] = {nR_};
  if (isDirichletR_)
    nr1[0] = 2*nR_;

  IsinR2D_ = fftw_plan_many_r2r(1, nr1, nZE_, rZTemp_, nr1, nZE_, 1, rZTemp_, nr1, nZE_, 1, &invS_, FFTW_MEASURE);
  IcosR2D_ = fftw_plan_many_r2r(1, nr1, nZE_, rZTemp_, nr1, nZE_, 1, rZTemp_, nr1, nZE_, 1, &invC_, FFTW_MEASURE);
  FsinR2D_ = fftw_plan_many_r2r(1, nr1, nZE_, rZTemp_, nr1, nZE_, 1, rZTemp_, nr1, nZE_, 1, &fwdS_, FFTW_MEASURE);
  FcosR2D_ = fftw_plan_many_r2r(1, nr1, nZE_, rZTemp_, nr1, nZE_, 1, rZTemp_, nr1, nZE_, 1, &fwdC_, FFTW_MEASURE);

  IsinR4A_ = fftw_plan_many_r2r(1, nr, nZE_, rZTemp4A_, nr, nZE_, 1, rZTemp4A_, nr, nZE_, 1, &invS_, FFTW_MEASURE);
  IcosR4A_ = fftw_plan_many_r2r(1, nr, nZE_, rZTemp4A_, nr, nZE_, 1, rZTemp4A_, nr, nZE_, 1, &invC_, FFTW_MEASURE);
  FsinR4A_ = fftw_plan_many_r2r(1, nr, nZE_, rZTemp4A_, nr, nZE_, 1, rZTemp4A_, nr, nZE_, 1, &fwdS_, FFTW_MEASURE);
  FcosR4A_ = fftw_plan_many_r2r(1, nr, nZE_, rZTemp4A_, nr, nZE_, 1, rZTemp4A_, nr, nZE_, 1, &fwdC_, FFTW_MEASURE);

  int howManyT = nZ_;
  int nt_[1] = {nTheta_};
  
  // these are plans for one slice. Because the idist parameter varies when changing from one slice to another.
  // i.e. the idist should be 1, for one slice, but the pointer need to move nTheta_*nPhi_ when moves to next slice.
  // it's unclear how to bake this as one transformations like r and p directions.
  // Same as the guru plan.
  // Need to be executed nr times
  IsinTE_ = fftw_plan_many_r2r(1, nt_, nZE_, tTemp_, nt_, nZE_, 1, tTemp_, nt_, nZE_, 1, &invS_, FFTW_MEASURE);
  IcosTE_ = fftw_plan_many_r2r(1, nt_, nZE_, tTemp_, nt_, nZE_, 1, tTemp_, nt_, nZE_, 1, &invC_, FFTW_MEASURE);
  FsinTE_ = fftw_plan_many_r2r(1, nt_, nZE_, tTemp_, nt_, nZE_, 1, tTemp_, nt_, nZE_, 1, &fwdS_, FFTW_MEASURE);
  FcosTE_ = fftw_plan_many_r2r(1, nt_, nZE_, tTemp_, nt_, nZE_, 1, tTemp_, nt_, nZE_, 1, &fwdC_, FFTW_MEASURE);

  // plans along z direction.
  int howManyZ = nR_*nTheta_;
  int nz_[1] = {nZ_};
  // z bndcnd, need twice more..
  if (zBndCndIdx_ == 1 || zBndCndIdx_ == 3)
    nz_[0] = 2*nZ_;

  // P plan is full 3D.
  IsinP_ = fftw_plan_many_r2r(1, nz_, howManyZ, temp0_, nz_, 1, zStride_, temp0_, nz_, 1, zStride_, &invS_, FFTW_MEASURE);
  IcosP_ = fftw_plan_many_r2r(1, nz_, howManyZ, temp0_, nz_, 1, zStride_, temp0_, nz_, 1, zStride_, &invC_, FFTW_MEASURE);
  FsinP_ = fftw_plan_many_r2r(1, nz_, howManyZ, temp0_, nz_, 1, zStride_, temp0_, nz_, 1, zStride_, &fwdS_, FFTW_MEASURE);
  FcosP_ = fftw_plan_many_r2r(1, nz_, howManyZ, temp0_, nz_, 1, zStride_, temp0_, nz_, 1, zStride_, &fwdC_, FFTW_MEASURE);

  // used for Phi5
  IsinRsinZ_ = fftw_plan_r2r_2d(nR_, nZ_, rZTemp5_, rZTemp5_, invS_, invS_, FFTW_MEASURE);
  FsinRsinZ_ = fftw_plan_r2r_2d(nR_, nZ_, rZTemp5_, rZTemp5_, fwdS_, fwdS_, FFTW_MEASURE);
  IsinRcosZ_ = fftw_plan_r2r_2d(nR_, nZ_, rZTemp5_, rZTemp5_, invS_, invC_, FFTW_MEASURE);
  FsinRcosZ_ = fftw_plan_r2r_2d(nR_, nZ_, rZTemp5_, rZTemp5_, fwdS_, fwdC_, FFTW_MEASURE);
}

void CylinderBasisSet3D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[index][Coefidx[index]].coef = fieldCoef[i]*C_x;
    Coefidx[index]++;
  }
}

void CylinderBasisSet3D::TransR(fftw_plan rPlan, double* in, double* out) {
  for (int i = 0; i < nThetaE_ && i < nTheta_; i++)
    fftw_execute_r2r(rPlan, &in[i*nZE_], &out[i*nZE_]);
}

void CylinderBasisSet3D::TransT(fftw_plan tPlan, double* in, double* out) {
  // need to run nR_ because r is currently filled.
  for (int i = 0; i < nR_; i++)
    fftw_execute_r2r(tPlan, &in[i*nTheta_*nZE_], &out[i*nTheta_*nZE_]);
}

void CylinderBasisSet3D::weightSinCosR(const int zStride, const double* rf, double* field) {
  int tRange = nThetaE_;
  int zRange = nZE_;
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < tRange; j++)
      for (int i = 0; i < zRange; i++) {
        field[i + j*nZE_ + k*nZE_*nThetaE_] *= rf[k];
      }
}

// weight by r along the radial, only used by phi4D and phi4A
void CylinderBasisSet3D::weightR(const int zStride, double* slice2D) {
  for (int k = 0; k < nR_; k++)
    for (int i = 0; i < nZE_; i++) {
      double r = ((double)(k) + 0.5)*dR_;
      slice2D[i + k*nZE_] *= r;
    }
}

// copy a R-Z 2d slice to full 3D grid, used for phi^2-3
void CylinderBasisSet3D::add2DSliceToFull(const int offset, const double* slice2D, double* out) {
  // phi2 shares rest transformations with phi0
  // need to copy to the right slice... 2*zStride because we have cos(t).
  int offsetT = offset*nZE_;
  for (int k = 0; k < nR_; k++)
    for (int i = 0; i < nZE_; i++) {
      out[i + offsetT + k*nTheta_*nZE_] += slice2D[i + k*nZE_];
    }
}

void CylinderBasisSet3D::extract2DSliceToFull(const int offset, const double* in, double* slice2D) {
  // phi2 shares rest transformations with phi0
  // need to copy to the right slice... 2*zStride because we have cos(t).
  int offsetT = offset*nZE_;
  for (int k = 0; k < nR_; k++)
    for (int i = 0; i < nZE_; i++) {
      slice2D[i + k*nZE_] += in[i + offsetT + k*nTheta_*nZE_];
    }
}

void CylinderBasisSet3D::moveInToTgrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nThetaE_; j++)
      memcpy(&out[j*nZE_ + k*nTheta_*nZE_], &in[j*nZE_ + k*nThetaE_*nZE_], sizeof(double)*nZE_);
}

void CylinderBasisSet3D::moveTToIngrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nThetaE_; j++)
      memcpy(&out[j*nZE_ + k*nThetaE_*nZE_], &in[j*nZE_ + k*nTheta_*nZE_], sizeof(double)*nZE_);
}

// move grid in of size nR_*nTheta_*nPhiE_  to grid out of full size
void CylinderBasisSet3D::moveTtoPGrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      memcpy(&out[j*zStride_ + k*nTheta_*zStride_], &in[j*nZE_ + k*nTheta_*nZE_], sizeof(double)*nZE_);
}

void CylinderBasisSet3D::movePtoTGrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      memcpy(&out[j*nZE_ + k*nTheta_*nZE_], &in[j*zStride_ + k*nTheta_*zStride_], sizeof(double)*nZE_);
}

// sum grid in of size nR_*nTheta_*nPhiE_  to grid out of full size
void CylinderBasisSet3D::sumTtoPGrid(const double* in, double* out) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nZE_; i++)
        out[j*zStride_ + k*nTheta_*zStride_ + i] += in[j*nZE_ + k*nTheta_*nZE_ + i];
}

// This deal every vr of Phi^0-Phi^4
void CylinderBasisSet3D::InverseTransformVR() {

  clearPointer(vrTemp_);
  clearPointer(temp0_);
  clearPointer(inTemp_);
  clearPointer(tTemp_);

  int divdR = !isDirichletR_ ? 1 : 2;  // dirichlet, should divide by 2.
  int divdZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 2;
  // 0, 1, F(z) = sin(i3 pi z), F'(z) = i3*pi*cos(i3*pi*z)
  // 2, 3, F(z) = cos(i3 pi z), F'(z) = -i3*pi*sin(i3*pi*z)
  //Phi^0: R, sin, T, cos
  int offsetZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 0 : 1;
  int sgnZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 1 : -1;
  // Phi^0 -----------------------------------------------------------
  for (const auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    inTemp_[p.i3x2/divdZ - offsetZ + p.i2x2*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_] += -i2*p.coef*i3*M_PI*sgnZ;
  }
  TransR(IsinRE_, inTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_ , inTemp_);
  weightSinCosR(zStride_, weightF_ , inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  // Phi^2 -----------------------------------------------------------
  int divR23 = !isDirichletR_ ? 2 : 1;  // dirichlet, should divide by 2.
  clearPointer(rZTemp_);
  for (const auto& p : phiCoef_[2]) {
    double i3 = p.i3x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_] += p.coef*i3*M_PI*sgnZ;
  }
  // nrxnz 2D grid.
  fftw_execute_r2r(IcosR2D_, rZTemp_, rZTemp_);
  add2DSliceToFull(2, rZTemp_, tTemp_);
  
  // Phi^4 -----------------------------------------------------------
  clearPointer(rZTemp_);
  for (const auto& p : phiCoef_[4]) {
    double i3 = p.i3x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_] += p.coef*i3*M_PI*sgnZ;
  }
  fftw_execute_r2r(IcosR2D_, rZTemp_, rZTemp_);

  if (! isDirichletR_) {  // need Phi^4A to get rid of extra derivatives, see cylindrical.pdf
    clearPointer(rZTemp4A_);
    for (const auto& p : phiCoef_[4]) {
      double i3 = p.i3x2*0.5; // i1* = i1 + 0.5 -> i1*x2 = i1x2 + 1
      if (p.i1x2 == 0) i3 *= 0.5;  // need to multiple by 0.5 when i1x2 == 0 to account for the dct norm.
      rZTemp4A_[p.i3x2/divdZ - offsetZ + (p.i1x2/divdR)*nZE_] += -p.coef*i3*M_PI*sgnZ;
    }
    fftw_execute_r2r(IsinR4A_, rZTemp4A_, rZTemp4A_);
    for (int k = 0; k < nR_; k++)
      for (int i = 0; i < nZE_; i++)
        rZTemp_[i + k*nZE_] += rZTemp4A_[i + k*nZE_];
  }

  weightR(zStride_, rZTemp_);
  add2DSliceToFull(0, rZTemp_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, temp0_);

  clearPointer(inTemp_);
  clearPointer(tTemp_);
  // Phi^1 -----------------------------------------------------------
  for (const auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_] += i2*p.coef*i3*M_PI*sgnZ;
  }

  TransR(IsinRE_, inTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_ , inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rZTemp_);
  // Phi^3 -----------------------------------------------------------
  for (const auto& p : phiCoef_[3]) {
    double i3 = p.i3x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_] += p.coef*i3*M_PI*sgnZ;
  }
  // nrxnz 2D grid.
  fftw_execute_r2r(IcosR2D_, rZTemp_, rZTemp_);
  add2DSliceToFull(1, rZTemp_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, temp0_);

  // full plan along the last dimension.
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    fftw_execute_r2r(IcosP_, temp0_, temp0_);
  else
    fftw_execute_r2r(IsinP_, temp0_, temp0_);

  // collect into vr, due to z stride might be different.
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
      memcpy(&vrTemp_[j*nZ_ + k*nZTheta_], &temp0_[j*zStride_ + k*nTheta_*zStride_], sizeof(double)*nZ_);
    }
}

void CylinderBasisSet3D::InverseTransformVT() {
  clearPointer(vtTemp_);
  clearPointer(temp0_);
  clearPointer(inTemp_);
  clearPointer(tTemp_);

  int divdR = !isDirichletR_ ? 1 : 2;  // dirichlet, should divide by 2.
  int divdZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 2;
  // 0, 1, F(z) = sin(i3 pi z), F'(z) = i3*pi*cos(i3*pi*z)
  // 2, 3, F(z) = cos(i3 pi z), F'(z) = -i3*pi*sin(i3*pi*z)
  //Phi^0: R, sin, T, cos
  int offsetZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 0 : 1;
  int sgnZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 1 : -1;

  // Phi^0 -----------------------------------------------------------
  for (const auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_] += p.coef*i3*M_PI*sgnZ;
  }

  TransR(IsinRE_, inTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  // Phi^2 -----------------------------------------------------------
  int divR23 = !isDirichletR_ ? 2 : 1;  // dirichlet, should divide by 2.
  clearPointer(rZTemp_);
  for (const auto& p : phiCoef_[2]) {
    double i3 = p.i3x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_] += -p.coef*i3*M_PI*sgnZ;
  }
  // nrxnz 2D grid.
  fftw_execute_r2r(IcosR2D_, rZTemp_, rZTemp_);
  add2DSliceToFull(1, rZTemp_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, temp0_);

  clearPointer(inTemp_);
  clearPointer(tTemp_);

  // Phi^1 -----------------------------------------------------------
  for (const auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_] += p.coef*i3*M_PI*sgnZ;
  }

  TransR(IsinRE_, inTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rZTemp_);
  // Phi^3 -----------------------------------------------------------
  for (const auto& p : phiCoef_[3]) {
    double i3 = p.i3x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_] += p.coef*i3*M_PI*sgnZ;
  }
  // nrxnz 2D grid.
  fftw_execute_r2r(IcosR2D_, rZTemp_, rZTemp_);
  add2DSliceToFull(2, rZTemp_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, temp0_);
  
  // Phi^5 -----------------------------------------------------------
  clearPointer(rZTemp5_);
  for (const auto& p : phiCoef_[5]) {
    rZTemp5_[p.i3x2/2 + (p.i1x2/2 - 1)*nZ_] += p.coef;
  }
  fftw_execute_r2r(IsinRcosZ_, rZTemp5_, rZTemp5_);

  // full plan along the last dimension.
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    fftw_execute_r2r(IcosP_, temp0_, temp0_);
  else
    fftw_execute_r2r(IsinP_, temp0_, temp0_);

  // collect into vr, due to z stride might be different.
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
      memcpy(&vtTemp_[j*nZ_ + k*nZTheta_], &temp0_[j*zStride_ + k*nTheta_*zStride_], sizeof(double)*nZ_);
    }

  // put int Phi5
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nZ_; i++)
        vtTemp_[i + j*nZ_ + k*nZTheta_] += rZTemp5_[i + k*nZ_];

}

void CylinderBasisSet3D::InverseTransformVZ() {
  clearPointer(vpTemp_);
  clearPointer(temp0_);
  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);

  Eigen::Map<Eigen::VectorXd> inTempV(inTemp_, pointerSize_[inTemp_]);
  Eigen::Map<Eigen::VectorXd> inTemp1V(inTemp1_, pointerSize_[inTemp1_]);

  int divdR = !isDirichletR_ ? 1 : 2;  // dirichlet, should divide by 2.
  int divdZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 2;
  // 0, 1, F(z) = sin(i3 pi z), F'(z) = i3*pi*cos(i3*pi*z)
  // 2, 3, F(z) = cos(i3 pi z), F'(z) = -i3*pi*sin(i3*pi*z)
  //Phi^0: R, sin, T, cos
  int offsetZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 1 : 0;

  // Phi^0 -----------------------------------------------------------
  for (const auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    double i1 = p.i1x2*0.5;
    // sin(i1 pi r)
    inTemp_[p.i3x2/divdZ - offsetZ + p.i2x2*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_] += i2*p.coef*b_;
    // cos(i1 pi r)
    inTemp1_[p.i3x2/divdZ - offsetZ + p.i2x2*nZE_ + (p.i1x2/divdR)*nThetaE_*nZE_] += i2*i1*M_PI*p.coef*b_;
  }

  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);

  //weightSinCosR(zStride_, cosHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightDerivF_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp1_);
  weightSinCosR(zStride_, weightF_, inTemp1_);

  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  // Phi^2 -----------------------------------------------------------
  int divR23 = !isDirichletR_ ? 2 : 1;  // dirichlet, should divide by 2.
  clearPointer(rZTemp_);
  for (const auto& p : phiCoef_[2]) {
    double i1 = p.i1x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23 - 1)*nZE_] += i1*M_PI*p.coef*b_;
  }
  // nrxnz 2D grid.
  fftw_execute_r2r(IsinR2D_, rZTemp_, rZTemp_);
  add2DSliceToFull(2, rZTemp_, tTemp_);

  // Phi^4 -----------------------------------------------------------
  clearPointer(rZTemp_);
  clearPointer(rZTemp1_);
  for (const auto& p : phiCoef_[4]) {
    double i1 = p.i1x2*0.5;
    // sin(i1*pi*r)
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23 - 1)*nZE_] += i1*M_PI*p.coef*b_;
    // cos(i1*pi*r)
    rZTemp1_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_] += -2.0*p.coef*b_;
  }

  fftw_execute_r2r(IsinR2D_, rZTemp_, rZTemp_);
  weightR(zStride_, rZTemp_);
  fftw_execute_r2r(IcosR2D_, rZTemp1_, rZTemp1_);
  for (int i = 0; i < pointerSize_[rZTemp_]; i++) {
    rZTemp_[i] += rZTemp1_[i];
  }

  if (! isDirichletR_) {  // need Phi^4A to get rid of extra derivatives, see cylindrical.pdf
    clearPointer(rZTemp4A_);
    clearPointer(rZTemp4A1_);
    for (const auto& p : phiCoef_[4]) {
      // i1* = i1 + 0.5 -> i1*x2 = i1x2 + 1
      double i1Star = (p.i1x2 + 1)*0.5;
      int divdDCT = (p.i1x2 == 0) ? 2 : 1; // need to multiple by 0.5 when i1x2 == 0 to account for the dct norm.
      // sin(i1*pi*r)
      rZTemp4A_[p.i3x2/divdZ - offsetZ + (p.i1x2/divdR)*nZE_] += -2.0*p.coef*b_/divdDCT;
      // cos(i1*pi*r)
      rZTemp4A1_[p.i3x2/divdZ - offsetZ + (p.i1x2/divdR + 1)*nZE_] += -i1Star*M_PI*p.coef*b_/divdDCT;
    }
    fftw_execute_r2r(IsinR4A_, rZTemp4A_, rZTemp4A_);
    fftw_execute_r2r(IcosR4A_, rZTemp4A1_, rZTemp4A1_);
    weightR(zStride_, rZTemp4A1_);
    for (int k = 0; k < nR_; k++)
      for (int i = 0; i < nZE_; i++)
        rZTemp_[i + k*nZE_] -= (rZTemp4A_[i + k*nZE_] + rZTemp4A1_[i + k*nZE_]);
  }

  // offset 0
  add2DSliceToFull(0, rZTemp_, tTemp_);

  TransT(IcosTE_, tTemp_, tTemp_);
  moveTtoPGrid(tTemp_, temp0_);

  clearPointer(inTemp_);
  clearPointer(inTemp1_);
  clearPointer(tTemp_);
  // Phi^1 -----------------------------------------------------------
  for (const auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    double i1 = p.i1x2*0.5;
    // sin(i1 pi r)
    inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_] += -i2*p.coef*b_;
    // cos(i1 pi r)
    inTemp1_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR)*nThetaE_*nZE_] += -i2*i1*M_PI*p.coef*b_;
  }

  TransR(IsinRE_, inTemp_, inTemp_);
  TransR(IcosRE_, inTemp1_, inTemp1_);

  //weightSinCosR(zStride_, cosHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightDerivF_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp1_);
  weightSinCosR(zStride_, weightF_, inTemp1_);
  inTempV += inTemp1V;
  moveInToTgrid(inTemp_, tTemp_);

  clearPointer(rZTemp_);
  // Phi^3 -----------------------------------------------------------
  for (const auto& p : phiCoef_[3]) {
    double i1 = p.i1x2*0.5;
    rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23-1)*nZE_] += i1*M_PI*p.coef*b_;
  }
  // nrxnz 2D grid.
  fftw_execute_r2r(IsinR2D_, rZTemp_, rZTemp_);
  add2DSliceToFull(1, rZTemp_, tTemp_);

  TransT(IsinTE_, tTemp_, tTemp_);
  sumTtoPGrid(tTemp_, temp0_);

  // full plan along the last dimension.
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    fftw_execute_r2r(IsinP_, temp0_, temp0_);
  else
    fftw_execute_r2r(IcosP_, temp0_, temp0_);

  // collect into vr, due to z stride might be different.
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
      memcpy(&vpTemp_[j*nZ_ + k*nZTheta_], &temp0_[j*zStride_ + k*nTheta_*zStride_], sizeof(double)*nZ_);
    }
}

//#define TEST

void CylinderBasisSet3D::InverseTransformToVelocity(Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());

  // test code
#ifdef TEST 
  //srand(time(NULL));
  fieldCoef = Eigen::VectorXd::Random(fieldCoef.size());
  double *ur, *ut, *up;
  ur = (double*) fftw_malloc(sizeof(double)*totalSize_);
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> urV(ur, totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  urV.setZero();
  utV.setZero();
  upV.setZero();
  computeUniformRTNumerical(fieldCoef, nR_, nTheta_, nZ_, ur, ut, up); 
#endif
  //computeUniformRTNumerical(fieldCoef, nR_, nTheta_, nZ_, vrTemp_, vtTemp_, vpTemp_); 
  collectPairedCoef(fieldCoef);

  InverseTransformVR();
  InverseTransformVT();
  InverseTransformVZ();

#ifdef TEST 
  Eigen::Map<Eigen::VectorXd> vrTempV(vrTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vtTempV(vtTemp_, totalSize_);
  Eigen::Map<Eigen::VectorXd> vpTempV(vpTemp_, totalSize_);
  LOG(INFO) << "diff r " << (urV - vrTempV).norm() << " " << urV.norm() << " " << vrTempV.norm();
  LOG(INFO) << "diff t " << (utV - vtTempV).norm() << " " << utV.norm() << " " << vtTempV.norm();
  LOG(INFO) << "diff p " << (upV - vpTempV).norm() << " " << upV.norm() << " " << vpTempV.norm();
  exit(0);
#endif
}

void CylinderBasisSet3D::clearPairCoef() {
  for (auto& v : phiCoef_)
    for (auto& p : v) {
      p.coef = 0;
    }
}

void CylinderBasisSet3D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  fieldCoef.setZero();
  vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    // 0.125 comes from 2 factor from foward dcts. This funcion assumes doing dcts along three
    // directions.
    double C_x = all_basis_[i]->GetInvNorm()*0.125;
    fieldCoef[i] += phiCoef_[index][Coefidx[index]].coef*C_x*dR_*dTheta_*dZ_;
    Coefidx[index]++;
  }
}

// These work for both Neumann and Dirichlet because the grid is doubled along k dimension
// and we dont need to  weight the field on the extension part of transformation of half
// wavenumber is needed.
// weight with r^2sin(t),
void CylinderBasisSet3D::weightRB(const int zStride, double* buf) {
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nZ_; i++) {
        double r = ((double)(k) + 0.5)*dR_;
        buf[i + j*zStride + k*zStride*nTheta_] *= r*b_*scale3_;
      }
}

void CylinderBasisSet3D::weightJacobian(const int zStride, double* ur, double* ut, double* up) {
  weightRB(zStride, ur);
  weightRB(zStride, ut);
  weightRB(zStride, up);
}

void CylinderBasisSet3D::ForwardTransformVR() {

  clearPointer(temp0_);
  clearPointer(inTemp_);
  clearPointer(tTemp_);

  int divdR = !isDirichletR_ ? 1 : 2;  // dirichlet, should divide by 2.
  int divdZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 2;
  // 0, 1, F(z) = sin(i3 pi z), F'(z) = i3*pi*cos(i3*pi*z)
  // 2, 3, F(z) = cos(i3 pi z), F'(z) = -i3*pi*sin(i3*pi*z)
  //Phi^0: R, sin, T, cos
  int offsetZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 0 : 1;
  int sgnZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 1 : -1;

  memcpy(temp0_, vrTemp_, sizeof(double)*totalSize_*multipier_);
  // full plan along the last dimension.
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    fftw_execute_r2r(FcosP_, temp0_, temp0_);
  else
    fftw_execute_r2r(FsinP_, temp0_, temp0_);
  
  movePtoTGrid(temp0_, tTemp_);
  // temp1 holds F'(z)cos(t)
  TransT(FcosTE_, tTemp_, tTemp_);

  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_ , inTemp_);
  weightSinCosR(zStride_, weightF_ , inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^0 -----------------------------------------------------------
  for (auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    p.coef += -inTemp_[p.i3x2/divdZ - offsetZ + p.i2x2*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_]*i2*i3*M_PI*sgnZ;
  }

  clearPointer(rZTemp_);
  extract2DSliceToFull(2, tTemp_, rZTemp_);
  // nrxnz 2D grid.
  fftw_execute_r2r(FcosR2D_, rZTemp_, rZTemp_);
  // Phi^2 -----------------------------------------------------------
  int divR23 = !isDirichletR_ ? 2 : 1;  // dirichlet, should divide by 2.
  for (auto& p : phiCoef_[2]) {
    double i3 = p.i3x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_]*i3*M_PI*sgnZ;
  }

  // Phi^4 -----------------------------------------------------------
  clearPointer(rZTemp_);
  extract2DSliceToFull(0, tTemp_, rZTemp_);
  weightR(zStride_, rZTemp_);
  fftw_execute_r2r(FcosR2D_, rZTemp_, rZTemp_);
  for (auto& p : phiCoef_[4]) {
    double i3 = p.i3x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_]*i3*M_PI*sgnZ;
  }

  if (! isDirichletR_) {  // need Phi^4A to get rid of extra derivatives, see cylindrical.pdf
    clearPointer(rZTemp4A_);
    extract2DSliceToFull(0, tTemp_, rZTemp4A_);
    weightR(zStride_, rZTemp4A_);
    fftw_execute_r2r(FsinR4A_, rZTemp4A_, rZTemp4A_);
    for (auto& p : phiCoef_[4]) {
      double i3 = p.i3x2*0.5; // i1* = i1 + 0.5 -> i1*x2 = i1x2 + 1
      p.coef += -rZTemp4A_[p.i3x2/divdZ - offsetZ + (p.i1x2/divdR)*nZE_]*i3*M_PI*sgnZ;
    }
  }

  // temp0 holds F'(z)sin(t)
  clearPointer(tTemp_);
  movePtoTGrid(temp0_, tTemp_);
  TransT(FsinTE_, tTemp_, tTemp_);
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^1 -----------------------------------------------------------
  for (auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i3 = p.i3x2*0.5;
    p.coef += inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_]*i2*i3*M_PI*sgnZ;
  }

  clearPointer(rZTemp_);
  extract2DSliceToFull(1, tTemp_, rZTemp_);
  fftw_execute_r2r(FcosR2D_, rZTemp_, rZTemp_);
  // Phi^3 -----------------------------------------------------------
  for (auto& p : phiCoef_[3]) {
    double i3 = p.i3x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_]*i3*M_PI*sgnZ;
  }
}

void CylinderBasisSet3D::ForwardTransformVT() {
  clearPointer(temp0_);
  clearPointer(tTemp_);
  clearPointer(inTemp_);

  int divdR = !isDirichletR_ ? 1 : 2;  // dirichlet, should divide by 2.
  int divdZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 2;
  // 0, 1, F(z) = sin(i3 pi z), F'(z) = i3*pi*cos(i3*pi*z)
  // 2, 3, F(z) = cos(i3 pi z), F'(z) = -i3*pi*sin(i3*pi*z)
  //Phi^0: R, sin, T, cos
  int offsetZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 0 : 1;
  int sgnZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 1 : -1;

  memcpy(temp0_, vtTemp_, sizeof(double)*totalSize_*multipier_);
  // full plan along the last dimension.
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    fftw_execute_r2r(FcosP_, temp0_, temp0_);
  else
    fftw_execute_r2r(FsinP_, temp0_, temp0_);

  // temp1 holds F'(z)sin(t)
  movePtoTGrid(temp0_, tTemp_);

  TransT(FsinTE_, tTemp_, tTemp_);
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);

  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^0 -----------------------------------------------------------
  for (auto& p : phiCoef_[0]) {
    double i3 = p.i3x2*0.5;
    p.coef += inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_]*i3*M_PI*sgnZ;
  }

  clearPointer(rZTemp_);
  extract2DSliceToFull(1, tTemp_, rZTemp_);
  // nrxnz 2D grid.
  fftw_execute_r2r(FcosR2D_, rZTemp_, rZTemp_);
  // Phi^2 -----------------------------------------------------------
  int divR23 = !isDirichletR_ ? 2 : 1;  // dirichlet, should divide by 2.
  for (auto& p : phiCoef_[2]) {
    double i3 = p.i3x2*0.5;
    p.coef += -rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_]*i3*M_PI*sgnZ;
  }

  // temp0 holds F'(z)cos(t)
  clearPointer(tTemp_);
  movePtoTGrid(temp0_, tTemp_);

  TransT(FcosTE_, tTemp_, tTemp_);
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);

  TransR(FsinRE_, inTemp_, inTemp_);
  // Phi^1 -----------------------------------------------------------
  for (auto& p : phiCoef_[1]) {
    double i3 = p.i3x2*0.5;
    p.coef += inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_]*i3*M_PI*sgnZ;
  }

  clearPointer(rZTemp_);
  extract2DSliceToFull(2, tTemp_, rZTemp_);
  fftw_execute_r2r(FcosR2D_, rZTemp_, rZTemp_);
  // Phi^3 -----------------------------------------------------------
  for (auto& p : phiCoef_[3]) {
    double i3 = p.i3x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_]*i3*M_PI*sgnZ;
  }

  // Phi^5 -----------------------------------------------------------
  clearPointer(rZTemp5_);
  // put int Phi5
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nZ_; i++)
        rZTemp5_[i + k*nZ_] += vtTemp_[i + j*zStride_ + k*nTheta_*zStride_];
  fftw_execute_r2r(FsinRcosZ_, rZTemp5_, rZTemp5_);    
  for (auto& p : phiCoef_[5]) {
    // multiply by 2 because we assuem dct is performed along nz.
    p.coef += rZTemp5_[p.i3x2/2 + (p.i1x2/2 - 1)*nZ_]*2.0;
  }
}

void CylinderBasisSet3D::ForwardTransformVZ() {
  clearPointer(temp0_);
  clearPointer(tTemp_);
  clearPointer(inTemp_);

  int divdR = !isDirichletR_ ? 1 : 2;  // dirichlet, should divide by 2.
  int divdZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 2;
  // 0, 1, F(z) = sin(i3 pi z), F'(z) = i3*pi*cos(i3*pi*z)
  // 2, 3, F(z) = cos(i3 pi z), F'(z) = -i3*pi*sin(i3*pi*z)
  //Phi^0: R, sin, T, cos
  int offsetZ = (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) ? 1 : 0;

  memcpy(temp0_, vpTemp_, sizeof(double)*totalSize_*multipier_);
  // full plan along the last dimension.
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    fftw_execute_r2r(FsinP_, temp0_, temp0_);
  else
    fftw_execute_r2r(FcosP_, temp0_, temp0_);

  movePtoTGrid(temp0_, tTemp_);
  // temp1 holds F(z)*cos(t)

  TransT(FcosTE_, tTemp_, tTemp_);

  // Phi^0 -----------------------------------------------------------
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, cosHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightDerivF_, inTemp_);

  TransR(FsinRE_, inTemp_, inTemp_);
  for (auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    p.coef += inTemp_[p.i3x2/divdZ - offsetZ + p.i2x2*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_]*i2*b_;
  }
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);
  TransR(FcosRE_, inTemp_, inTemp_);
  for (auto& p : phiCoef_[0]) {
    double i2 = p.i2x2*0.5;
    double i1 = p.i1x2*0.5;
    p.coef += inTemp_[p.i3x2/divdZ - offsetZ + p.i2x2*nZE_ + (p.i1x2/divdR)*nThetaE_*nZE_]*i2*i1*M_PI*b_;
  }

  clearPointer(rZTemp_);
  extract2DSliceToFull(2, tTemp_, rZTemp_);
  // nrxnz 2D grid.
  fftw_execute_r2r(FsinR2D_, rZTemp_, rZTemp_);
  // Phi^2 -----------------------------------------------------------
  int divR23 = !isDirichletR_ ? 2 : 1;  // dirichlet, should divide by 2.
  for (auto& p : phiCoef_[2]) {
    double i1 = p.i1x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23 - 1)*nZE_]*i1*M_PI*b_;
  }

  // Phi^4 -----------------------------------------------------------
  clearPointer(rZTemp_);
  extract2DSliceToFull(0, tTemp_, rZTemp_);
  memcpy(rZTemp1_, rZTemp_, sizeof(double)*pointerSize_[rZTemp_]);
  weightR(zStride_, rZTemp_);
  fftw_execute_r2r(FsinR2D_, rZTemp_, rZTemp_);
  for (auto& p : phiCoef_[4]) {
    double i1 = p.i1x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23 - 1)*nZE_]*i1*M_PI*b_;
  }
  fftw_execute_r2r(FcosR2D_, rZTemp1_, rZTemp1_);
  for (auto& p : phiCoef_[4]) {
    p.coef += rZTemp1_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23)*nZE_]*-2.0*b_;
  }

  if (! isDirichletR_) {  // need Phi^4A to get rid of extra derivatives, see cylindrical.pdf
    clearPointer(rZTemp4A_);
    extract2DSliceToFull(0, tTemp_, rZTemp4A_);
    memcpy(rZTemp4A1_, rZTemp4A_, sizeof(double)*pointerSize_[rZTemp4A_]);
    weightR(zStride_, rZTemp4A_);
    fftw_execute_r2r(FcosR4A_, rZTemp4A_, rZTemp4A_);
    for (auto& p : phiCoef_[4]) {
      // i1* = i1 + 0.5 -> i1*x2 = i1x2 + 1
      double i1Star = (p.i1x2 + 1)*0.5;
      p.coef -= rZTemp4A_[p.i3x2/divdZ - offsetZ + (p.i1x2/divdR + 1)*nZE_]*-i1Star*M_PI*b_;
    }
    fftw_execute_r2r(FsinR4A_, rZTemp4A1_, rZTemp4A1_);
    for (auto& p : phiCoef_[4]) {
      // i1* = i1 + 0.5 -> i1*x2 = i1x2 + 1
      p.coef -= rZTemp4A1_[p.i3x2/divdZ - offsetZ + (p.i1x2/divdR)*nZE_]*-2.0*b_;
    }
  }

  // temp0 holds F(z)*sin(t)
  clearPointer(tTemp_);
  movePtoTGrid(temp0_, tTemp_);

  TransT(FsinTE_, tTemp_, tTemp_);
  // Phi^1 -----------------------------------------------------------
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, cosHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightDerivF_, inTemp_);
  TransR(FsinRE_, inTemp_, inTemp_);
  for (auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    // sin(i1 pi r)
    p.coef += -inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR - 1)*nThetaE_*nZE_]*i2*b_;
  }
  clearPointer(inTemp_);
  moveTToIngrid(tTemp_, inTemp_);
  //weightSinCosR(zStride_, sinHalfPiR_, inTemp_);
  weightSinCosR(zStride_, weightF_, inTemp_);

  TransR(FcosRE_, inTemp_, inTemp_);
  for (auto& p : phiCoef_[1]) {
    double i2 = p.i2x2*0.5;
    double i1 = p.i1x2*0.5;
    p.coef += -inTemp_[p.i3x2/divdZ - offsetZ + (p.i2x2-1)*nZE_ + (p.i1x2/divdR)*nThetaE_*nZE_]*i2*i1*M_PI*b_;
  }

  clearPointer(rZTemp_);
  extract2DSliceToFull(1, tTemp_, rZTemp_);
  fftw_execute_r2r(FsinR2D_, rZTemp_, rZTemp_);
  // Phi^3 -----------------------------------------------------------
  for (auto& p : phiCoef_[3]) {
    double i1 = p.i1x2*0.5;
    p.coef += rZTemp_[p.i3x2/divdZ - offsetZ + (p.i1x2/divR23 - 1)*nZE_]*i1*M_PI*b_;
  }

}

void CylinderBasisSet3D::ForwardTransformtoFrequency(
      const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) {

  // Be CAREFUL of zStride when interpolate field into vr, vt, vp.
  interpolateToSphere(field);

  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();

  // test code
#ifdef TEST
  srand(time(NULL));
  double *ur, *ut, *up;
  ur = (double*) fftw_malloc(sizeof(double)*totalSize_);
  ut = (double*) fftw_malloc(sizeof(double)*totalSize_);
  up = (double*) fftw_malloc(sizeof(double)*totalSize_);
  Eigen::Map<Eigen::VectorXd> urV(ur, totalSize_);
  Eigen::Map<Eigen::VectorXd> utV(ut, totalSize_);
  Eigen::Map<Eigen::VectorXd> upV(up, totalSize_);
  urV.setZero();
  utV.setZero();
  upV.setZero();

  srand((unsigned int) (time(0)));
  Eigen::VectorXd basisCoef1 = Eigen::VectorXd::Random(all_basis_.size());
  computeUniformRTNumerical(basisCoef1, nR_, nTheta_, nZ_, ur, ut, up); 
  // collect into vr, due to z stride might be different.
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++) {
      memcpy(&vrTemp_[j*zStride_ + k*nTheta_*zStride_], &ur[j*nZ_ + k*nZTheta_], sizeof(double)*nZ_);
      memcpy(&vtTemp_[j*zStride_ + k*nTheta_*zStride_], &ut[j*nZ_ + k*nZTheta_], sizeof(double)*nZ_);
      memcpy(&vpTemp_[j*zStride_ + k*nTheta_*zStride_], &up[j*nZ_ + k*nZTheta_], sizeof(double)*nZ_);
    }

  weightJacobian(nZ_, ur, ut, up);

#endif
  weightJacobian(zStride_, vrTemp_, vtTemp_, vpTemp_);

  ForwardTransformVR();
  ForwardTransformVT();
  ForwardTransformVZ();
  assignPairCoef(fieldCoef);

#ifdef TEST
  Eigen::VectorXd projCoef = Eigen::VectorXd::Zero(all_basis_.size());
  projectUniformRTNumerical(nR_, nTheta_, nZ_, ur, ut, up, projCoef);
  LOG(INFO) << "diff: " << (projCoef - fieldCoef).norm() << " " << projCoef.norm() << " " << fieldCoef.norm();
  exit(0);
#endif

  *coefficients = A_*fieldCoef;
}

// xRes, yRes, zRes lines up with (nphi, ntheta, nr)
void CylinderBasisSet3D::ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) {
  CHECK(df.xRes() == nZ_);
  CHECK(df.yRes() == nTheta_);
  CHECK(df.zRes() == nR_);

  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nZ_; i++) {
        int ind   = i + j*nZ_ + k*nZ_*nTheta_;
        int index = i + j*zStride_ + k*zStride_*nTheta_;
        vrTemp_[index] = df[ind][0];
        vtTemp_[index] = df[ind][1];
        vpTemp_[index] = df[ind][2];
      }

  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();

  weightJacobian(zStride_, vrTemp_, vtTemp_, vpTemp_);

  ForwardTransformVR();
  ForwardTransformVT();
  ForwardTransformVZ();
  assignPairCoef(fieldCoef);

  *coefficients = A_*fieldCoef;
}

void CylinderBasisSet3D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta,
     const int nZ, double* ur, double* ut, double* uz) {

  memset(ur, 0x00, sizeof(double)*nTheta*nR*nZ);
  memset(ut, 0x00, sizeof(double)*nTheta*nR*nZ);
  memset(uz, 0x00, sizeof(double)*nTheta*nR*nZ);

  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    all_basis_[i]->AddUniformU(fullCoef[i], nR, nTheta, nZ, ur, ut, uz);
  }
}

void CylinderBasisSet3D::projectUniformRTNumerical(const int nR, const int nTheta, const int nZ, double* fr,
                                           double* ft, double* fz, Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    fullCoef[i] = all_basis_[i]->ProjectUniformU(nR, nTheta, nZ, fr, ft, fz);
  }
}

void CylinderBasisSet3D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {
  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;

  vector<double (*)(const Basis3D&, const Basis3D&, const Basis3D&, const double& b)>* pointers = NULL;
  if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
    pointers = &sinEval_.pointers_;
  else
    pointers = &cosEval_.pointers_;

#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    // compute half
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {
        //
        const CylinderBasis3D& basis_i = *all_basis_[i];
        const CylinderBasis3D& basis_g = *all_basis_[g];
        const CylinderBasis3D& basis_h = *all_basis_[h];
        double Cigh = 0;

#ifdef FAST_TENSOR
        const int idx = basis_i.index()*36 + basis_g.index()*6 + basis_h.index();
        Cigh = (*pointers)[idx](basis_i, basis_g, basis_h, b_)*scale3_;
#else
        Cigh = tensorEntryCast(all_basis_[i], all_basis_[g], all_basis_[h]);
#endif
        CHECK(std::isfinite(Cigh));

        if (abs(Cigh) <1e-12) {
          continue;
        }
        //Cigh = (Cigh > 2.0) ? 2.0 : Cigh;
        //Cigh = (Cigh < -2.0) ? -2.0 : Cigh;
        
        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  //BasisSet::VerifyAntisymmetric(*Adv_tensor);
  //exit(0);
}

#define interPol(arg_)\
wr0*(wp0 * (wt0 * arg_[i000] + wt1 * arg_[i010]) +\
     wp1 * (wt0 * arg_[i100] + wt1 * arg_[i110]))+\
wr1*(wp0 * (wt0 * arg_[i001] + wt1 * arg_[i011]) +\
     wp1 * (wt0 * arg_[i101] + wt1 * arg_[i111]))
// i000 i100 --> ur0
// i001 i101 --> ur1
#define interPolPole(arg_, v0, v1)\
wr0*(wp0 * (wt0 * v0 + wt1 * arg_[i010]) +\
     wp1 * (wt0 * v0 + wt1 * arg_[i110]))+\
wr1*(wp0 * (wt0 * v1 + wt1 * arg_[i011]) +\
     wp1 * (wt0 * v1 + wt1 * arg_[i111]))

#define CLAMPR(rv) \
rv = (rv < 0) ? 0 : rv;\
rv = (rv > nR_ - 1) ? nR_ - 1 : rv;

#define CLAMPT(tv) \
tv = (tv < 0) ? nTheta_ + tv : tv;\
tv = (tv > nTheta_ - 1) ? tv - nTheta_ : tv;

#define CLAMPZ(zv) \
zv = (zv < 0) ? 0 : zv;\
zv = (zv > nZ_ - 1) ? nZ_ - 1 : zv;


void CylinderBasisSet3D::interpolateToCartesian(VECTOR3_FIELD_3D* field) {
  
  const int xRes = field->xRes();
  const int yRes = field->yRes();
  const int zRes = field->zRes();
  CHECK(xRes == yRes);
  // xRes, yRes lines up with the circle of the cylinder
  // physical dimension: [-1,1]^2x[0, b].
  // align the radius of the cylinder to the field.
  double dx = 2.0 / xRes;
  double lzHalf = dx*zRes*0.5;

  #pragma omp parallel for
  for (int k = 0; k < zRes; k++)
    for (int j = 0; j < yRes; j++)
      for (int i = 0; i < xRes; i++) {
        
        const int cidx = i + j*xRes + k*xRes*yRes;
        Eigen::Vector3d uSph(0,0,0);
        Eigen::Vector3d uCat(0,0,0);

        Eigen::Vector3d pos(((double)(i) + 0.5)*dx - 1.0 , ((double)(j) + 0.5)*dx - 1.0,
                 ((double)(k) + 0.5)*dx - lzHalf);  // x, y, [-1, 1]^2x[-lz/2, lz/2]
        // parameter space.
        Eigen::Vector3d cylCord = Transform::Cylinderical::toCylinderical(pos, b_);

        const double r = cylCord[0]; // [0, 1]
        const double t = cylCord[1]; // [0, 2pi]
        double z = cylCord[2]; // [-lz/(2b), lz/(2b)]
        // center aligned.
        if (r > 1.0 ||z < -0.5 || z > 0.5)  // velocity is zero
          continue;
        z += 0.5;
        int r0 = (int)(r/dR_);
        int r1 = r0 + 1;
        int t0 = (int)(t/dTheta_);
        int t1 = t0 + 1;
        int z0 = (int)(z/dZ_);
        int z1 = z0 + 1;
        
        // clamp
        CLAMPR(r0);
        CLAMPR(r1);
        // periodic bc
        CLAMPT(t0);
        CLAMPT(t1);
        CLAMPZ(z0);
        CLAMPZ(z1);
        
        // get interpolation weights
        const double wp1 = z/dZ_ - z0;
        const double wp0 = 1.0 - wp1;
        const double wt1 = t/dTheta_ - t0;
        const double wt0 = 1.0 - wt1;
        const double wr1 = r/dR_ - r0;
        const double wr0 = 1.0 - wr1;

        const int i000 = z0 + t0 * nZ_ + r0 * nZTheta_;
        const int i010 = z0 + t1 * nZ_ + r0 * nZTheta_;
        const int i100 = z1 + t0 * nZ_ + r0 * nZTheta_;
        const int i110 = z1 + t1 * nZ_ + r0 * nZTheta_;
        const int i001 = z0 + t0 * nZ_ + r1 * nZTheta_;
        const int i011 = z0 + t1 * nZ_ + r1 * nZTheta_;
        const int i101 = z1 + t0 * nZ_ + r1 * nZTheta_;
        const int i111 = z1 + t1 * nZ_ + r1 * nZTheta_;

        uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
        Eigen::Matrix3d transMat;
        Transform::Cylinderical::toCartesianMat(t, transMat);
        // toCartesian
        uCat = transMat*uSph;
        (*field)[cidx][0] = uCat[0];
        (*field)[cidx][1] = uCat[1];
        (*field)[cidx][2] = uCat[2];
      }
}

void CylinderBasisSet3D::interpolateToSphere(const VECTOR3_FIELD_3D& field) {
  const int xRes = field.xRes();
  const int yRes = field.yRes();
  const int zRes = field.zRes();
  CHECK(xRes == yRes);

  clearPointer(vrTemp_);
  clearPointer(vtTemp_);
  clearPointer(vpTemp_);
  const int fZres = field.zRes();
  // dx = 2/xres;
  // cat[2] [0, b] vs [0, lz]
  #pragma omp parallel for
  for (int k = 0; k < nR_; k++)
    for (int j = 0; j < nTheta_; j++)
      for (int i = 0; i < nZ_; i++) {
        int index = i + j*zStride_ + k*zStride_*nTheta_;
        Eigen::Vector3d sph;
        sph << ((double)(k) + 0.5)*dR_, ((double)(j) + 0.5)*dTheta_, ((double)(i) + 0.5)*dZ_;
        Eigen::Vector3d cat = Transform::Cylinderical::toCartesian(sph, b_); // [-1,1]^3x[0,b]
        cat[0] = (cat[0] + 1.0)*0.5;
        cat[1] = (cat[1] + 1.0)*0.5; // [0,1]
        cat[2] -= b_/2;  // [-b/2, b/2]

        Eigen::Matrix3d transMat;
        Transform::Cylinderical::toCartesianMat(sph[1], transMat);
        // in grid coordinates, center aligned.
        double zPos = fZres/2 + cat[2]*0.5*xRes;
        // cylinder too short.
        if (zPos < 0 || zPos >= fZres)
          continue;
        VEC3 vcat = field.GetVelocity(cat[0]*xRes, cat[1]*xRes, zPos);
        Eigen::Vector3d uCat(vcat[0], vcat[1], vcat[2]);
        Eigen::Vector3d uSph = transMat.transpose()*uCat;
        vrTemp_[index] = uSph[0];
        vtTemp_[index] = uSph[1];
        vpTemp_[index] = uSph[2];
      }
}

void CylinderBasisSet3D::outputTestTensorEntries(const int numWant, const string& fname,
        std::vector<Adv_Tensor_Type> *Adv_tensor) {

  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  vector<Eigen::Vector3i> indices;

  for (int i = 0; i < numBasisAll_; i++) {
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const CylinderBasis3D& basis_i = *all_basis_[i];
        const CylinderBasis3D& basis_g = *all_basis_[g];
        const CylinderBasis3D& basis_h = *all_basis_[h];

        double Cigh = CylinderBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
        CHECK(std::isfinite(Cigh));

        if (abs(Cigh) < 1e-12) {
          continue;
        }

        indices.push_back(Eigen::Vector3i(i,g,h));
        tripletList.push_back(T(g,h, Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  BasisSet::VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    basisPtr3DCyl basis_i = all_basis_[indices[i][0]];
    basisPtr3DCyl basis_g = all_basis_[indices[i][1]];
    basisPtr3DCyl basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " << basis_i->WN3x2() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " << basis_g->WN3x2() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " << basis_h->WN3x2() << " " <<
           std::setprecision(12) << basis_i->GetInvNorm() << " " << basis_g->GetInvNorm()
           << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}

double CylinderBasisSet3D::tensorEntryCast(const basisPtr3DCyl basis_i, const basisPtr3DCyl basis_g, const basisPtr3DCyl basis_h) {
    return CylinderBasis3D::computeTensorEntryScale(*basis_i, *basis_g, *basis_h, scale3_);
}

#define dotProdMarco(arg, i,j) dotProdCast(arg[i], arg[j])
// Run MGS on a set of basis functions stored in in, and orthogonalize them. The kept basis
// is stored in out. The basis functions with distinct part smalelr than thresh of existing basis
// are thrown away. Coef are a matrix which kepts the coefficients of MGS. m is the number of
// basis functions that are kept.
void CylinderBasisSet3D::runMGS(const double thresh, const vector<basisPtr3DCyl>& in, vector<basisPtr3DCyl>& out,
            Eigen::MatrixXd& Coef, int& m) {
  out.clear();
  // inner product matrix of all basis.
  Eigen::MatrixXd H = Eigen::MatrixXd::Zero(in.size(), in.size());
  // temp buffer.
  Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(in.size(), in.size());
  // Coefficients matrix.
  Coef = Eigen::MatrixXd::Zero(in.size(), in.size());
  // map from row/col index of H matrix to basis index
  Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(in.size());
  Coef(0,0) = 1.0; 
  H(0,0) = dotProdMarco(in, 0,0);
  HC.col(0) = H*Coef.row(0).transpose();
  idxMap[0] = 0;
  // The first one.
  out.push_back(in[0]);
  // size of the final allocated basis.
  m = 1;

  for(int i = 1; i < in.size(); i++) {
    Coef(m,m) = 1.0;
    H(m,m) = dotProdMarco(in, i,i);
    for (int j = 0; j < m; j++)
      H(j,m) = H(m,j) = dotProdMarco(in, i,idxMap[j]);
    for (int j = 0; j < m; j++) {
      HC(m,j) = H.row(m)*Coef.row(j).transpose();
    }

    for (int j = 0; j < m; j++) {
      double dotProd = Coef.row(m)*HC.col(j);
      Coef.row(m) -= dotProd*Coef.row(j);
    }

    // compute norm.
    HC.col(m) = H*Coef.row(m).transpose();
    double norm2 = Coef.row(m)*HC.col(m);

    if (norm2 > thresh) {
      idxMap[m] = i;
      Coef.row(m) /= sqrt(norm2);
      HC.col(m) /= sqrt(norm2);
      m++;
      out.push_back(in[i]);
    }
    else {
      LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";
    }
  }
  CHECK(m <= in.size());
  CHECK(m == out.size());
  // test
  // Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  // for (int i = 0; i < reduced.rows(); i++) {
  //   reduced(i,i) -= 1.0;
  // }
  // LOG(INFO) << reduced.norm();
}

#define RESEED_POLAR(arg)\
arg.position[0] = r*cos(t);\
arg.position[1] = r*sin(t);\

// [-1,1]^2x[-b/2, b/2]*scale
void CylinderBasisSet3D::ReSeedParticles(vector<ParticleSph3D>& particles, vector<Eigen::Vector3d>& initPos) {
  // Reseed the particles at random position.
  uniform_real_distribution<double> u(0., 1.);
  for (int i = 0; i < particles.size(); i++) {
    double px = u(m_gen_);
    double py = u(m_gen_);
    double r = sqrtf(px);
    double t = 2.0*M_PI*py;
    RESEED_POLAR(particles[i]);
    particles[i].position[2] = (u(m_gen_) - 0.5)*b_;
    particles[i].position *= scale_;
    particles[i].velocity.setZero();
    initPos[i] = particles[i].position;
  }
}

void CylinderBasisSet3D::projBackParticles(const vector<Eigen::Vector3d>& initPos, vector<ParticleSph3D>& particles) {
  for (int i = 0; i < particles.size(); i++) {
    double dist = 0;
    const Eigen::Vector3d& p = particles[i].position/scale_;
    dist = sqrt(p[0]*p[0] + p[1]*p[1]);
    if (dist > 0.99 || p[2] < -b_*0.5 || p[2] > b_*0.5) {
      particles[i].position = initPos[i];
      particles[i].velocity.setZero();
    }
  }
}

void CylinderBasisSet3D::writeToFile(std::ofstream& out, const vector<Adv_Tensor_Type>& Adv_tensor_) const {

  out.write(reinterpret_cast<const char *>(&isDirichletR_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&rK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&thetaK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&zK_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&b_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&zBndCndIdx_), sizeof(int));
  
  // write the size of each modes.
  int modeSizes[phiCoef_.size()];
  for (int i = 0; i < phiCoef_.size(); i++)
    modeSizes[i] = phiCoef_[i].size();
  out.write(reinterpret_cast<const char *>(modeSizes), sizeof(int)*phiCoef_.size());

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }

  writeEigenDense_binary(out, H_);
  writeEigenDense_binary(out, A_);
  int tensorType = 0;
  WriteTensor(Adv_tensor_, tensorType, out);
}

void CylinderBasisSet3D::readFromFile(std::ifstream& in) {

  in.read(reinterpret_cast<char *>(&isDirichletR_), sizeof(bool));
  in.read(reinterpret_cast<char *>(&rK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&thetaK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&zK_), sizeof(int));
  in.read(reinterpret_cast<char *>(&numBasisAll_), sizeof(int));
  in.read(reinterpret_cast<char *>(&numBasisOrtho_), sizeof(int));
  in.read(reinterpret_cast<char *>(&b_), sizeof(double));
  in.read(reinterpret_cast<char *>(&zBndCndIdx_), sizeof(int));
      
  // largeest dimension is b
  if (b_ > 2.0)
    scale_ = 2.0/b_;
  else // largest dimension is R
    scale_ = 1.0;
  
  scale3_ = scale_*scale_*scale_;
  
  LOG(INFO) << numBasisAll_;
  phiCoef_.resize(6);
  int modeSizes[6];
  in.read(reinterpret_cast<char*>(modeSizes), sizeof(int)*6);

  for (int i = 0; i < numBasisAll_; i++) {
    all_basis_.push_back(basisPtr3DCyl(CylinderBasis3D::fromFile(in)));
  }
  initPhiCoef();

  readEigenDense_binary(in, H_);
  readEigenDense_binary(in, A_);
}

// center align
VEC3 CylinderBasisSet3D::getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) {
  // p: [-1, 1]^2x[-b/2, b/2]
  // dx = 2/xres
  VEC3 nPos = p;
  const int xRes = velocity.xRes();
  nPos[0] = (nPos[0] + 1.0)*0.5; // [0, 1]
  nPos[1] = (nPos[1] + 1.0)*0.5;
  double zPos = velocity.zRes()/2 + nPos[2]*0.5*xRes;
  if (zPos < 0 || zPos >= velocity.zRes())
    return VEC3(0,0,0);
  
  return velocity.GetVelocity(nPos[0]*xRes, nPos[1]*xRes, zPos);
}

// should be [-1, 1]^2[-b/2, b/2]*scale
template<typename DT, typename VT, typename MT>
void CylinderBasisSet3D::getVelocityPosT(const VT& pos, VT& uCat) {
  VT uSph(0,0,0);
  uCat.setZero();

  // parameter space.
  VT posOrig = pos/scale_;
  VT sphCord = Transform::Cylinderical::toCylinderical(posOrig, b_);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, 2pi]
  const DT& z = sphCord[2] + 0.5; // [0, 1]
  //CHECK(isfinite(r) && isfinite(t) && isfinite(p)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.
  if (r > 1.0 || z < 0 || z > 1)  // velocity is zero
    return;

  int r0 = (int)(r/dR_);
  int r1 = r0 + 1;
  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int z0 = (int)(z/dZ_);
  int z1 = z0 + 1;
  
  // clamp
  CLAMPR(r0);
  CLAMPR(r1);
  // periodic bc
  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPZ(z0);
  CLAMPZ(z1);

  // get interpolation weights
  const DT wp1 = z/dZ_ - z0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;
  const DT wr1 = r/dR_ - r0;
  const DT wr0 = 1.0 - wr1;

  const int i000 = z0 + t0 * nZ_ + r0 * nZTheta_;
  const int i010 = z0 + t1 * nZ_ + r0 * nZTheta_;
  const int i100 = z1 + t0 * nZ_ + r0 * nZTheta_;
  const int i110 = z1 + t1 * nZ_ + r0 * nZTheta_;
  const int i001 = z0 + t0 * nZ_ + r1 * nZTheta_;
  const int i011 = z0 + t1 * nZ_ + r1 * nZTheta_;
  const int i101 = z1 + t0 * nZ_ + r1 * nZTheta_;
  const int i111 = z1 + t1 * nZ_ + r1 * nZTheta_;

  uSph << interPol(vrTemp_), interPol(vtTemp_), interPol(vpTemp_);
  MT transMat;
  Transform::Cylinderical::toCartesianMat(t, transMat);
  // toCartesian
  uCat = transMat*uSph;
}

template void CylinderBasisSet3D::getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(const Eigen::Vector3d&, Eigen::Vector3d&);
template void CylinderBasisSet3D::getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(const Eigen::Vector3f&, Eigen::Vector3f&);

template<typename DT, typename VT>
void CylinderBasisSet3D::addParticleForce(const double& ptlWeight, const VT& pos, const VT& f, VECTOR3_FIELD_3D& buf) {
  // parameter space.
  VT posOrig = pos/scale_;
  VT sphCord = Transform::Cylinderical::toCylinderical(posOrig, b_);

  const DT& r = sphCord[0]; // [0, 1]
  const DT& t = sphCord[1]; // [0, 2pi]
  const DT& z = sphCord[2] + 0.5; // [0, 1]
  CHECK(isfinite(r) && isfinite(t) && isfinite(z)) << posOrig.transpose() << " " << sphCord.transpose();
  // center aligned.
  if (r > 1.0 || z < 0 || z > 1)  // velocity is zero
    return;

  int r0 = (int)(r/dR_);
  int r1 = r0 + 1;
  int t0 = (int)(t/dTheta_);
  int t1 = t0 + 1;
  int z0 = (int)(z/dZ_);
  int z1 = z0 + 1;
  
  // clamp
  CLAMPR(r0);
  CLAMPR(r1);
  // periodic bc
  CLAMPT(t0);
  CLAMPT(t1);
  CLAMPZ(z0);
  CLAMPZ(z1);

  // get interpolation weights
  const DT wp1 = z/dZ_ - z0;
  const DT wp0 = 1.0 - wp1;
  const DT wt1 = t/dTheta_ - t0;
  const DT wt0 = 1.0 - wt1;
  const DT wr1 = r/dR_ - r0;
  const DT wr0 = 1.0 - wr1;

  const int i000 = z0 + t0 * nZ_ + r0 * nZTheta_;
  const int i010 = z0 + t1 * nZ_ + r0 * nZTheta_;
  const int i100 = z1 + t0 * nZ_ + r0 * nZTheta_;
  const int i110 = z1 + t1 * nZ_ + r0 * nZTheta_;
  const int i001 = z0 + t0 * nZ_ + r1 * nZTheta_;
  const int i011 = z0 + t1 * nZ_ + r1 * nZTheta_;
  const int i101 = z1 + t0 * nZ_ + r1 * nZTheta_;
  const int i111 = z1 + t1 * nZ_ + r1 * nZTheta_;

  for (int i = 0; i < 3; i++) {
    buf[i000][i] += ptlWeight*wr0*wp0*wt0*f[i];
    buf[i010][i] += ptlWeight*wr0*wp0*wt1*f[i];
    buf[i100][i] += ptlWeight*wr0*wp1*wt0*f[i];
    buf[i110][i] += ptlWeight*wr0*wp1*wt1*f[i];
    buf[i001][i] += ptlWeight*wr1*wp0*wt0*f[i];
    buf[i011][i] += ptlWeight*wr1*wp0*wt1*f[i];
    buf[i101][i] += ptlWeight*wr1*wp1*wt0*f[i];
    buf[i111][i] += ptlWeight*wr1*wp1*wt1*f[i];
  }
}

template void CylinderBasisSet3D::addParticleForce<double, Eigen::Vector3d>(const double&, const Eigen::Vector3d&, const Eigen::Vector3d&, VECTOR3_FIELD_3D&);
template void CylinderBasisSet3D::addParticleForce<float, Eigen::Vector3f>(const double&, const Eigen::Vector3f&, const Eigen::Vector3f&, VECTOR3_FIELD_3D&);

Eigen::Vector3d CylinderBasisSet3D::getVelocityPos(const Eigen::Vector3d& pos) {
  Eigen::Vector3d result(0,0,0);
  getVelocityPosT<double, Eigen::Vector3d, Eigen::Matrix3d>(pos, result);
  return result;
}

Eigen::Vector3f CylinderBasisSet3D::getVelocityPos(const Eigen::Vector3f& pos) {
  Eigen::Vector3f result(0,0,0);
  getVelocityPosT<float, Eigen::Vector3f, Eigen::Matrix3f>(pos, result);
  return result;
}

// should be [-1, 1]^2[-b/2, b/2]*scale
void CylinderBasisSet3D::projPosBack(ParaParticle3Dd& p) {
  Eigen::Vector3d posOrig = p.position_/scale_;
  Eigen::Vector3d sphCord = Transform::Cylinderical::toCylinderical(posOrig, b_);
  if (sphCord[0] <= 1.0 && sphCord[2] <= 0.5 && sphCord[2] >= -0.5)
    return;

  sphCord[0] = (sphCord[0] > 1.0) ? 1.0 : sphCord[0];
  sphCord[2] = (sphCord[2] < -0.5) ? -0.5 : sphCord[2];
  sphCord[2] = (sphCord[2] > 0.5) ? 0.5 : sphCord[2];
  
  p.position_ = Transform::Cylinderical::toCartesian(sphCord, b_);
  p.weight_ = 0.0;
  p.life_ = 0;
}

void CylinderBasisSet3D::projPosBack(ParaParticle3Df& p) {
  Eigen::Vector3f posOrig = p.position_/scale_;
  Eigen::Vector3f sphCord = Transform::Cylinderical::toCylinderical(posOrig, b_);
  if (sphCord[0] <= 1.0 && sphCord[2] <= 0.5 && sphCord[2] >= -0.5)
    return;

  sphCord[0] = (sphCord[0] > 1.0) ? 1.0 : sphCord[0];
  sphCord[2] = (sphCord[2] < -0.5) ? -0.5 : sphCord[2];
  sphCord[2] = (sphCord[2] > 0.5) ? 0.5 : sphCord[2];
  
  p.position_ = Transform::Cylinderical::toCartesian(sphCord, b_);
  p.weight_ = 0.0;
  p.life_ = 0;
}

void CylinderBasisSet3D::computeLaplacianMatrix(Eigen::MatrixXd& laplacian) {
  laplacian.resize(numBasisAll_, numBasisAll_);
  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++)
    for (int j = i; j < numBasisAll_; j++) {
      const double vij = all_basis_[i]->LaplacianDotScale(*all_basis_[j])*all_basis_[i]->GetInvNorm()*all_basis_[j]->GetInvNorm();
      laplacian(i,j) = vij;
      laplacian(j,i) = vij;
    }
}