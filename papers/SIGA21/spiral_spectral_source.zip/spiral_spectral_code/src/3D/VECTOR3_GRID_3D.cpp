/*
 This file is part of SSFR (Zephyr).
 
 Zephyr is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Zephyr is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Zephyr.  If not, see <http://www.gnu.org/licenses/>.
 
 Copyright 2013 Theodore Kim
 */
#include <omp.h>
#include <Eigen/Eigen>

#include "VECTOR3_GRID_3D.h"

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>::VECTOR3_GRID_3D(const int& xRes, const int& yRes, const int& zRes,
    const T& center, const T& lengths) :
  _xRes(xRes), _yRes(yRes), _zRes(zRes), _center(center), _lengths(lengths), _initialized(true)
{
  _totalCells = _xRes * _yRes * _zRes;
  _slabSize = _xRes * _yRes;
  _data = new T[_totalCells];

  _dx = _lengths[0] / _xRes;
  _dy = _lengths[1] / _yRes;
  _dz = _lengths[2] / _zRes;
  
}

template <class T>
VECTOR3_GRID_3D<T>::VECTOR3_GRID_3D() :
  _xRes(0), _yRes(0), _zRes(0), _totalCells(0), _data(NULL), _initialized(false)
{
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>::~VECTOR3_GRID_3D()
{
  delete[] _data;
}
  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::clear()
{
  if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>) {
    for (int x = 0; x < _totalCells; x++)
      _data[x].setZero();
  } else {
    for (int x = 0; x < _totalCells; x++)
    _data[x] = 0.0;
  } 
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
FIELD_3D VECTOR3_GRID_3D<T>::magnitudeField() const
{
  FIELD_3D final(_xRes, _yRes, _zRes, VEC3F(_center[0], _center[1], _center[2]), VEC3F(_lengths[0],_lengths[1],_lengths[2]));

  if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>) {
    for (int x = 0; x < _totalCells; x++)
      final[x] = _data[x].norm();
  } else {
    for (int x = 0; x < _totalCells; x++)
      final[x] = norm(_data[x]);
  }

  return final;
}

///////////////////////////////////////////////////////////////////////
// take the field dot product
///////////////////////////////////////////////////////////////////////
template <class T>
FIELD_3D operator*(const VECTOR3_GRID_3D<T>&u, const VECTOR3_GRID_3D<T>& v)
{
  assert(u.xRes() == v.xRes());
  assert(u.yRes() == v.yRes());
  assert(u.zRes() == v.zRes());

  FIELD_3D final(u.xRes(), u.yRes(), u.zRes(), u.center(), u.lengths());

  int totalCells = u.totalCells();
  for (int x = 0; x < totalCells; x++)
    final[x] = u[x] * v[x];

  return final;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T> operator*(const VECTOR3_GRID_3D<T>& v, const Real& a)
{
  return a * v;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T> operator*(const Real& a, const VECTOR3_GRID_3D<T>& v)
{
  VECTOR3_GRID_3D<T> final(v);
  
  int totalCells = v.totalCells();
  for (int x = 0; x < totalCells; x++)
    final[x] = a * v[x];

  return final;
}

///////////////////////////////////////////////////////////////////////
// take the field dot product
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T> operator*(const FIELD_3D& u, const VECTOR3_GRID_3D<T>& v)
{
  assert(u.xRes() == v.xRes());
  assert(u.yRes() == v.yRes());
  assert(u.zRes() == v.zRes());

  VECTOR3_GRID_3D<T> final(v);

  int totalCells = u.totalCells();
  for (int x = 0; x < totalCells; x++)
    final[x] = u[x] * v[x];

  return final;
}

///////////////////////////////////////////////////////////////////////
// sum two vector fields
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T> operator+(const VECTOR3_GRID_3D<T>&u, const VECTOR3_GRID_3D<T>& v)
{
  assert(u.xRes() == v.xRes());
  assert(u.yRes() == v.yRes());
  assert(u.zRes() == v.zRes());

  VECTOR3_GRID_3D<T> final(u.xRes(), u.yRes(), u.zRes(), u.center(), u.lengths());
  int totalCells = u.totalCells();
  for (int x = 0; x < totalCells; x++)
    final[x] = u[x] + v[x];

  return final;
}

///////////////////////////////////////////////////////////////////////
// diff two vector fields
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T> operator-(const VECTOR3_GRID_3D<T>&u, const VECTOR3_GRID_3D<T>& v)
{
  assert(u.xRes() == v.xRes());
  assert(u.yRes() == v.yRes());
  assert(u.zRes() == v.zRes());

  VECTOR3_GRID_3D<T> final(u.xRes(), u.yRes(), u.zRes(), u.center(), u.lengths());
  int totalCells = u.totalCells();
  for (int x = 0; x < totalCells; x++)
    final[x] = u[x] - v[x];

  return final;
}

///////////////////////////////////////////////////////////////////////
// lookup value at some real-valued spatial position
///////////////////////////////////////////////////////////////////////
template <class T>
const T VECTOR3_GRID_3D<T>::operator()(const T& position) const
{
  T positionCopy = position - _center + (Real)0.5 * _lengths - (Real)0.5 * dxs();

  positionCopy[0] *= 1.0 / _dx;
  positionCopy[1] *= 1.0 / _dy;
  positionCopy[2] *= 1.0 / _dz;

  int x0 = (int)positionCopy[0];
  int x1    = x0 + 1;
  int y0 = (int)positionCopy[1];
  int y1    = y0 + 1;
  int z0 = (int)positionCopy[2];
  int z1    = z0 + 1;

  // clamp everything
  x0 = (x0 < 0) ? 0 : x0;
  y0 = (y0 < 0) ? 0 : y0;
  z0 = (z0 < 0) ? 0 : z0;
  
  x1 = (x1 < 0) ? 0 : x1;
  y1 = (y1 < 0) ? 0 : y1;
  z1 = (z1 < 0) ? 0 : z1;

  x0 = (x0 > _xRes - 1) ? _xRes - 1 : x0;
  y0 = (y0 > _yRes - 1) ? _yRes - 1 : y0;
  z0 = (z0 > _zRes - 1) ? _zRes - 1 : z0;

  x1 = (x1 > _xRes - 1) ? _xRes - 1 : x1;
  y1 = (y1 > _yRes - 1) ? _yRes - 1 : y1;
  z1 = (z1 > _zRes - 1) ? _zRes - 1 : z1;

  // get interpolation weights
  const Real s1 = positionCopy[0]- x0;
  const Real s0 = 1.0f - s1;
  const Real t1 = positionCopy[1]- y0;
  const Real t0 = 1.0f - t1;
  const Real u1 = positionCopy[2]- z0;
  const Real u0 = 1.0f - u1;

  const int i000 = x0 + y0 * _xRes + z0 * _slabSize;
  const int i010 = x0 + y1 * _xRes + z0 * _slabSize;
  const int i100 = x1 + y0 * _xRes + z0 * _slabSize;
  const int i110 = x1 + y1 * _xRes + z0 * _slabSize;
  const int i001 = x0 + y0 * _xRes + z1 * _slabSize;
  const int i011 = x0 + y1 * _xRes + z1 * _slabSize;
  const int i101 = x1 + y0 * _xRes + z1 * _slabSize;
  const int i111 = x1 + y1 * _xRes + z1 * _slabSize;

  // interpolate
  // (indices could be computed once)
  return u0 * (s0 * (t0 * _data[i000] + t1 * _data[i010]) +
               s1 * (t0 * _data[i100] + t1 * _data[i110])) +
         u1 * (s0 * (t0 * _data[i001] + t1 * _data[i011]) +
               s1 * (t0 * _data[i101] + t1 * _data[i111]));
}

// This function assume the velocity is stored on the vertices of the grid, while for laplacian fluid
// case, the velocity is stored on the center of the grid.
template <class T>
T VECTOR3_GRID_3D<T>::GetVelocity(const float pos_x, const float pos_y, const float pos_z) const {
  int x0 = (int)pos_x;
  int x1    = x0 + 1;
  int y0 = (int)pos_y;
  int y1    = y0 + 1;
  int z0 = (int)pos_z;
  int z1    = z0 + 1;
  
  // clamp everything
  x0 = (x0 < 0) ? 0 : x0;
  y0 = (y0 < 0) ? 0 : y0;
  z0 = (z0 < 0) ? 0 : z0;
  
  x1 = (x1 < 0) ? 0 : x1;
  y1 = (y1 < 0) ? 0 : y1;
  z1 = (z1 < 0) ? 0 : z1;

  x0 = (x0 > _xRes - 1) ? _xRes - 1 : x0;
  y0 = (y0 > _yRes - 1) ? _yRes - 1 : y0;
  z0 = (z0 > _zRes - 1) ? _zRes - 1 : z0;

  x1 = (x1 > _xRes - 1) ? _xRes - 1 : x1;
  y1 = (y1 > _yRes - 1) ? _yRes - 1 : y1;
  z1 = (z1 > _zRes - 1) ? _zRes - 1 : z1;

  // get interpolation weights
  const Real s1 = pos_x- x0;
  const Real s0 = 1.0f - s1;
  const Real t1 = pos_y- y0;
  const Real t0 = 1.0f - t1;
  const Real u1 = pos_z- z0;
  const Real u0 = 1.0f - u1;

  const int i000 = x0 + y0 * _xRes + z0 * _slabSize;
  const int i010 = x0 + y1 * _xRes + z0 * _slabSize;
  const int i100 = x1 + y0 * _xRes + z0 * _slabSize;
  const int i110 = x1 + y1 * _xRes + z0 * _slabSize;
  const int i001 = x0 + y0 * _xRes + z1 * _slabSize;
  const int i011 = x0 + y1 * _xRes + z1 * _slabSize;
  const int i101 = x1 + y0 * _xRes + z1 * _slabSize;
  const int i111 = x1 + y1 * _xRes + z1 * _slabSize;

  // interpolate
  // (indices could be computed once)
  return u0 * (s0 * (t0 * _data[i000] + t1 * _data[i010]) +
               s1 * (t0 * _data[i100] + t1 * _data[i110])) +
         u1 * (s0 * (t0 * _data[i001] + t1 * _data[i011]) +
               s1 * (t0 * _data[i101] + t1 * _data[i111]));
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator-=(const VECTOR3_GRID_3D<T>& input)
{
  for (int x = 0; x < _totalCells; x++)
    _data[x] -= input[x];

  return *this;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator+=(const VECTOR3_GRID_3D<T>& input)
{
  for (int x = 0; x < _totalCells; x++)
    _data[x] += input[x];

  return *this;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator*=(const FIELD_3D& input)
{
  assert(_xRes == input.xRes());
  assert(_yRes == input.yRes());
  assert(_zRes == input.zRes());

  for (int x = 0; x < _totalCells; x++)
  {
    _data[x][0] *= input[x];
    _data[x][1] *= input[x];
    _data[x][2] *= input[x];
  }

  return *this;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator*=(const T& alpha)
{
  for (int x = 0; x < _totalCells; x++)
  {
    _data[x][0] *= alpha[0];
    _data[x][1] *= alpha[1];
    _data[x][2] *= alpha[2];
  }

  return *this;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator+=(const Real& alpha)
{
  if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>) {
    for (int x = 0; x < _totalCells; x++)
      _data[x].array() += alpha;
  } else {
    for (int x = 0; x < _totalCells; x++)
      _data[x] += alpha;
  }

  return *this;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator*=(const Real& alpha)
{
  for (int x = 0; x < _totalCells; x++)
    _data[x] *= alpha;

  return *this;
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator=(const Real& value)
{
  if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>) {
    for (int x = 0; x < _totalCells; x++)
      _data[x].array() = value;
  } else {
    for (int x = 0; x < _totalCells; x++)
      _data[x] = value;
  }

  return *this;
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class T>
VECTOR3_GRID_3D<T>& VECTOR3_GRID_3D<T>::operator=(const VECTOR3_GRID_3D<T>& input)
{
  if (input.xRes() != _xRes ||
      input.yRes() != _yRes ||
      input.zRes() != _zRes)
  {
    delete[] _data;

    _xRes = input.xRes();
    _yRes = input.yRes();
    _zRes = input.zRes();

    _totalCells = _xRes * _yRes * _zRes;
    _slabSize = _xRes * _yRes;
    _data = new T[_totalCells];
  }

  _center = input.center();
  _lengths = input.lengths();

  _dx = _lengths[0] / _xRes;
  _dy = _lengths[1] / _yRes;
  _dz = _lengths[2] / _zRes;
  
  for (int x = 0; x < _totalCells; x++)
    _data[x] = input[x];

  _initialized = input._initialized;

  return *this;
}

template<class T>
template<typename U>
void VECTOR3_GRID_3D<T>::advect(const Real dt, const VECTOR3_GRID_3D<T>& velocityGrid, const U& oldField, U& newField) {
  const int xRes = velocityGrid.xRes();
  const int yRes = velocityGrid.yRes();
  const int zRes = velocityGrid.zRes();
  const int slabSize = velocityGrid.slabSize();

  // scale dt up to grid resolution
#pragma omp parallel
#pragma omp for schedule(static)
  for (int z = 0; z < zRes; z++)
    for (int y = 0; y < yRes; y++)
      for (int x = 0; x < xRes; x++)
      {
        const int index = x + y * xRes + z * slabSize;
        
        // backtrace
        const T velocity = velocityGrid[index];
        Real xTrace = x - dt * velocity[0];
        Real yTrace = y - dt * velocity[1];
        Real zTrace = z - dt * velocity[2];

        // clamp backtrace to grid boundaries
        xTrace = (xTrace < 1.5) ? 1.5 : xTrace;
        xTrace = (xTrace > xRes - 2.5) ? xRes - 2.5 : xTrace;
        yTrace = (yTrace < 1.5) ? 1.5 : yTrace;
        yTrace = (yTrace > yRes - 2.5) ? yRes - 2.5 : yTrace;
        zTrace = (zTrace < 1.5) ? 1.5 : zTrace;
        zTrace = (zTrace > zRes - 2.5) ? zRes - 2.5 : zTrace;
        // locate neighbors to interpolate
        const int x0 = (int)xTrace;
        const int x1 = x0 + 1;
        const int y0 = (int)yTrace;
        const int y1 = y0 + 1;
        const int z0 = (int)zTrace;
        const int z1 = z0 + 1;

        // get interpolation weights
        const Real s1 = xTrace - x0;
        const Real s0 = 1.0f - s1;
        const Real t1 = yTrace - y0;
        const Real t0 = 1.0f - t1;
        const Real u1 = zTrace - z0;
        const Real u0 = 1.0f - u1;

        const int i000 = x0 + y0 * xRes + z0 * slabSize;
        const int i010 = x0 + y1 * xRes + z0 * slabSize;
        const int i100 = x1 + y0 * xRes + z0 * slabSize;
        const int i110 = x1 + y1 * xRes + z0 * slabSize;
        const int i001 = x0 + y0 * xRes + z1 * slabSize;
        const int i011 = x0 + y1 * xRes + z1 * slabSize;
        const int i101 = x1 + y0 * xRes + z1 * slabSize;
        const int i111 = x1 + y1 * xRes + z1 * slabSize;

        // interpolate
        // (indices could be computed once)
        newField[index] = u0 * (s0 * (t0 * oldField[i000] +
                                      t1 * oldField[i010]) +
                                s1 * (t0 * oldField[i100] +
                                      t1 * oldField[i110])) +
                          u1 * (s0 * (t0 * oldField[i001] +
                                      t1 * oldField[i011]) +
                                s1 * (t0 * oldField[i101] +
                                      t1 * oldField[i111]));
      }
}

template void VECTOR3_GRID_3D<VEC3F>::advect<FIELD_3D>(const Real dt, const VECTOR3_GRID_3D<VEC3F>& , const FIELD_3D& , FIELD_3D& );
template void VECTOR3_GRID_3D<VEC3F>::advect<VECTOR3_GRID_3D<VEC3F>>(const Real dt, const VECTOR3_GRID_3D<VEC3F>& ,
   const VECTOR3_GRID_3D<VEC3F>& , VECTOR3_GRID_3D<VEC3F>& );

template<class T>
template<typename U>
void VECTOR3_GRID_3D<T>::advectMacCormack(const Real dt, const VECTOR3_GRID_3D<T>& velocityGrid, U& oldField, 
                             U& newField, U& temp1, U& temp2) 
{
  U& phiHatN  = temp1;
	U& phiHatN1 = temp2;

	const int sx = oldField.xRes();
	const int sy = oldField.yRes();
	const int sz = oldField.zRes();

	for (int x = 0; x < sx * sy * sz; x++)
		phiHatN[x] = phiHatN1[x] = oldField[x];

	U& phiN    = oldField;
	U& phiN1   = newField;

	// phiHatN1 = A(phiN)
	advect(dt, velocityGrid, phiN, phiHatN1);

	// phiHatN = A^R(phiHatN1)
	advect(-1.0 * dt, velocityGrid, phiHatN1, phiHatN);

	// phiN1 = phiHatN1 + (phiN - phiHatN) / 2
	const int border = 0; 
	for (int z = border; z < sz - border; z++)
		for (int y = border; y < sy - border; y++)
			for (int x = border; x < sx - border; x++) {
				int index = x + y * sx + z * sx*sy;
				phiN1[index] = phiHatN1[index] + (phiN[index] - phiHatN[index]) * 0.50;
			}

  phiN1.copyBorderAll();

	// clamp any newly created extrema
	clampExtrema(dt, velocityGrid, oldField, newField);

	// if the error estimate was bad, revert to first order
	clampOutsideRays(dt, velocityGrid, oldField, phiHatN1, newField);  
}

template void VECTOR3_GRID_3D<VEC3F>::advectMacCormack<FIELD_3D>(const Real, const VECTOR3_GRID_3D<VEC3F>&, FIELD_3D& 
                                        , FIELD_3D& , FIELD_3D&, FIELD_3D& );

template void VECTOR3_GRID_3D<VEC3F>::advectMacCormack<VECTOR3_GRID_3D<VEC3F>>(const Real, const VECTOR3_GRID_3D<VEC3F>&, VECTOR3_GRID_3D<VEC3F>& 
                                      , VECTOR3_GRID_3D<VEC3F>& , VECTOR3_GRID_3D<VEC3F>&, VECTOR3_GRID_3D<VEC3F>& );

//////////////////////////////////////////////////////////////////////
// Reverts any backtraces that go into boundaries back to first 
// order -- in this case the error correction term was totally
// incorrect
//////////////////////////////////////////////////////////////////////
template<class T>
template<typename U>
void VECTOR3_GRID_3D<T>::clampOutsideRays(const Real dt, const VECTOR3_GRID_3D<T>& velocityField, const U&  
                                        oldField, const U& oldAdvection, U& newField)
{
  const int sx = velocityField.xRes();
  const int sy = velocityField.yRes();
  const int sz = velocityField.zRes();
  const int slabSize = velocityField.slabSize();
    #pragma omp parallel
    #pragma omp for schedule(static)
  for (int z = 1; z < sz - 1; z++)
    for (int y = 1; y < sy - 1; y++)
      for (int x = 1; x < sx - 1; x++)
      {
        const int index = x + y * sx + z * slabSize;
        // backtrace
        T velocity = velocityField[index];
        velocity *= dt;
        float xBackward = x + velocity[0];
        float yBackward = y + velocity[1];
        float zBackward = z + velocity[2];

        float xTrace    = x - velocity[0];
        float yTrace    = y - velocity[1];
        float zTrace    = z - velocity[2];

        // see if it goes outside the boundaries
        bool hasObstacle = 
          (zTrace < 1.0f)    || (zTrace > sz - 2.0f) ||
          (yTrace < 1.0f)    || (yTrace > sy - 2.0f) ||
          (xTrace < 1.0f)    || (xTrace > sx - 2.0f) ||
          (zBackward < 1.0f) || (zBackward > sz - 2.0f) ||
          (yBackward < 1.0f) || (yBackward > sy - 2.0f) ||
          (xBackward < 1.0f) || (xBackward > sx - 2.0f);

        // reuse old advection instead of doing another one...
        if(hasObstacle) 
          newField[index] = oldAdvection[index];
      }
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::copyBorderAll()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int y = 0; y < _yRes; y++)
		{
			// left slab
			index = y * _xRes + z * _slabSize;
			_data[index] = _data[index + 1];

			// right slab
			index += _xRes - 1;
			_data[index] = _data[index - 1];
		}
	for (int z = 0; z < _zRes; z++)
		for (int x = 0; x < _xRes; x++)
		{
			// bottom slab
			index = x + z * _slabSize;
			_data[index] = _data[index + _xRes]; 
			// top slab
			index += _slabSize - _xRes;
			_data[index] = _data[index - _xRes];
		}
	for (int y = 0; y < _yRes; y++)
		for (int x = 0; x < _xRes; x++)
		{
			// front slab
			index = x + y * _xRes;
			_data[index] = _data[index + _slabSize]; 
			// back slab
			index += _totalCells - _slabSize;
			_data[index] = _data[index - _slabSize];
		}
}

///////////////////////////////////////////////////////////////////////
// Clamp the extrema generated by the BFECC error correction
///////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::clampExtrema(const Real dt, const VECTOR3_GRID_3D<T>& velocityField, const FIELD_3D& 
                                    oldField, FIELD_3D& newField)
{
  const int xRes = velocityField.xRes();
	const int yRes = velocityField.yRes();
	const int zRes = velocityField.zRes();
	const int slabSize = velocityField.slabSize();
    #pragma omp parallel
    #pragma omp for schedule(static)
	for (int z = 1; z < zRes-1; z++)
		for (int y = 1; y < yRes-1; y++)
			for (int x = 1; x < xRes-1; x++)
			{
				const int index = x + y * xRes + z * slabSize;
				// backtrace
        const T velocity = velocityField[index];
        Real xTrace = x - dt * velocity[0];
        Real yTrace = y - dt * velocity[1];
        Real zTrace = z - dt * velocity[2];

				// clamp backtrace to grid boundaries
        xTrace = (xTrace < 0.5) ? 0.5 : xTrace;
        xTrace = (xTrace > xRes - 1.5) ? xRes - 1.5 : xTrace;
        yTrace = (yTrace < 0.5) ? 0.5 : yTrace;
        yTrace = (yTrace > yRes - 1.5) ? yRes - 1.5 : yTrace;
        zTrace = (zTrace < 0.5) ? 0.5 : zTrace;
        zTrace = (zTrace > zRes - 1.5) ? zRes - 1.5 : zTrace;

				// locate neighbors to interpolate
				const int x0 = (int)xTrace;
				const int x1 = x0 + 1;
				const int y0 = (int)yTrace;
				const int y1 = y0 + 1;
				const int z0 = (int)zTrace;
				const int z1 = z0 + 1;

				const int i000 = x0 + y0 * xRes + z0 * slabSize;
				const int i010 = x0 + y1 * xRes + z0 * slabSize;
				const int i100 = x1 + y0 * xRes + z0 * slabSize;
				const int i110 = x1 + y1 * xRes + z0 * slabSize;
				const int i001 = x0 + y0 * xRes + z1 * slabSize;
				const int i011 = x0 + y1 * xRes + z1 * slabSize;
				const int i101 = x1 + y0 * xRes + z1 * slabSize;
				const int i111 = x1 + y1 * xRes + z1 * slabSize;

				Real minField = oldField[i000];
				Real maxField = oldField[i000];

				minField = (oldField[i010] < minField) ? oldField[i010] : minField;
				maxField = (oldField[i010] > maxField) ? oldField[i010] : maxField;

				minField = (oldField[i100] < minField) ? oldField[i100] : minField;
				maxField = (oldField[i100] > maxField) ? oldField[i100] : maxField;

				minField = (oldField[i110] < minField) ? oldField[i110] : minField;
				maxField = (oldField[i110] > maxField) ? oldField[i110] : maxField;

				minField = (oldField[i001] < minField) ? oldField[i001] : minField;
				maxField = (oldField[i001] > maxField) ? oldField[i001] : maxField;

				minField = (oldField[i011] < minField) ? oldField[i011] : minField;
				maxField = (oldField[i011] > maxField) ? oldField[i011] : maxField;

				minField = (oldField[i101] < minField) ? oldField[i101] : minField;
				maxField = (oldField[i101] > maxField) ? oldField[i101] : maxField;

				minField = (oldField[i111] < minField) ? oldField[i111] : minField;
				maxField = (oldField[i111] > maxField) ? oldField[i111] : maxField;

				newField[index] = (newField[index] > maxField) ? maxField : newField[index];
				newField[index] = (newField[index] < minField) ? minField : newField[index];
			}
}

template <class T>
void VECTOR3_GRID_3D<T>::clampExtrema(const Real dt, const VECTOR3_GRID_3D<T>& velocityField, const VECTOR3_GRID_3D<T>& oldField, VECTOR3_GRID_3D<T>& newField)
{
  const int xRes = velocityField.xRes();
  const int yRes = velocityField.yRes();
  const int zRes = velocityField.zRes();
  const int slabSize = velocityField.slabSize();

  for (int z = 1; z < zRes-1; z++)
    for (int y = 1; y < yRes-1; y++)
      for (int x = 1; x < xRes-1; x++)
      {
        const int index = x + y * xRes + z * slabSize;
        // backtrace
        const T velocity = velocityField[index];
        Real xTrace = x - dt * velocity[0];
        Real yTrace = y - dt * velocity[1];
        Real zTrace = z - dt * velocity[2];

        // clamp backtrace to grid boundaries
        xTrace = (xTrace < 0.5) ? 0.5 : xTrace;
        xTrace = (xTrace > xRes - 1.5) ? xRes - 1.5 : xTrace;
        yTrace = (yTrace < 0.5) ? 0.5 : yTrace;
        yTrace = (yTrace > yRes - 1.5) ? yRes - 1.5 : yTrace;
        zTrace = (zTrace < 0.5) ? 0.5 : zTrace;
        zTrace = (zTrace > zRes - 1.5) ? zRes - 1.5 : zTrace;

        // locate neighbors to interpolate
        const int x0 = (int)xTrace;
        const int x1 = x0 + 1;
        const int y0 = (int)yTrace;
        const int y1 = y0 + 1;
        const int z0 = (int)zTrace;
        const int z1 = z0 + 1;

        const int i000 = x0 + y0 * xRes + z0 * slabSize;
        const int i010 = x0 + y1 * xRes + z0 * slabSize;
        const int i100 = x1 + y0 * xRes + z0 * slabSize;
        const int i110 = x1 + y1 * xRes + z0 * slabSize;
        const int i001 = x0 + y0 * xRes + z1 * slabSize;
        const int i011 = x0 + y1 * xRes + z1 * slabSize;
        const int i101 = x1 + y0 * xRes + z1 * slabSize;
        const int i111 = x1 + y1 * xRes + z1 * slabSize;

        for (int i = 0; i < 3; i++)
        {
          Real minField = oldField[i000][i];
          Real maxField = oldField[i000][i];

          minField = (oldField[i010][i] < minField) ? oldField[i010][i] : minField;
          maxField = (oldField[i010][i] > maxField) ? oldField[i010][i] : maxField;

          minField = (oldField[i100][i] < minField) ? oldField[i100][i] : minField;
          maxField = (oldField[i100][i] > maxField) ? oldField[i100][i] : maxField;

          minField = (oldField[i110][i] < minField) ? oldField[i110][i] : minField;
          maxField = (oldField[i110][i] > maxField) ? oldField[i110][i] : maxField;

          minField = (oldField[i001][i] < minField) ? oldField[i001][i] : minField;
          maxField = (oldField[i001][i] > maxField) ? oldField[i001][i] : maxField;

          minField = (oldField[i011][i] < minField) ? oldField[i011][i] : minField;
          maxField = (oldField[i011][i] > maxField) ? oldField[i011][i] : maxField;

          minField = (oldField[i101][i] < minField) ? oldField[i101][i] : minField;
          maxField = (oldField[i101][i] > maxField) ? oldField[i101][i] : maxField;

          minField = (oldField[i111][i] < minField) ? oldField[i111][i] : minField;
          maxField = (oldField[i111][i] > maxField) ? oldField[i111][i] : maxField;

          newField[index][i] = (newField[index][i] > maxField) ? maxField : newField[index][i];
          newField[index][i] = (newField[index][i] < minField) ? minField : newField[index][i];
        }
        
      }
}

//////////////////////////////////////////////////////////////////////
// set everything on the border to zero
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setZeroBorder()
{
  // TIMER functionTimer(__FUNCTION__);
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int y = 0; y < _yRes; y++)
		{
			// left slab
			index = y * _xRes + z * _slabSize;

      if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
        _data[index].setZero();
      else
			  _data[index] = 0.0f;

			// right slab
			index += _xRes - 1;
      if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
        _data[index].setZero();
      else
			  _data[index] = 0.0f;
		}
	
  for (int z = 0; z < _zRes; z++)
		for (int x = 0; x < _xRes; x++)
		{
			// bottom slab
			index = x + z * _slabSize;
      if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
        _data[index].setZero();
      else
        _data[index] = 0.0f;

			// top slab
			index += _slabSize - _xRes;
			if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
        _data[index].setZero();
      else
        _data[index] = 0.0f;
		}
	
  for (int y = 0; y < _yRes; y++)
		for (int x = 0; x < _xRes; x++)
		{
			// front slab
			index = x + y * _xRes;
			if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
        _data[index].setZero();
      else
        _data[index] = 0.0f;

			// back slab
			index += _totalCells - _slabSize;
			if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
        _data[index].setZero();
      else
        _data[index] = 0.0f;
		}
}

//////////////////////////////////////////////////////////////////////
// set x direction to zero
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setZeroX()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int y = 0; y < _yRes; y++)
		{
			// left slab
			index = y * _xRes + z * _slabSize;
			_data[index][0] = 0.0f;

			// right slab
			index += _xRes - 1;
			_data[index][0] = 0.0f;
		}
}

//////////////////////////////////////////////////////////////////////
// set y direction to zero
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setZeroY()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int x = 0; x < _xRes; x++)
		{
			// bottom slab
			index = x + z * _slabSize;
			_data[index][1] = 0.0f;

			// top slab
			index += _slabSize - _xRes;
			_data[index][1] = 0.0f;
		}
}

//////////////////////////////////////////////////////////////////////
// set z direction to zero
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setZeroZ()
{
	int index;
	for (int y = 0; y < _yRes; y++)
		for (int x = 0; x < _xRes; x++)
		{
			// front slab
			index = x + y * _xRes;
			_data[index][2] = 0.0f;

			// back slab
			index += _totalCells - _slabSize;
			_data[index][2] = 0.0f;
		}
}

//////////////////////////////////////////////////////////////////////
// set x direction to Neumann boundary conditions
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setNeumannX()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int y = 0; y < _yRes; y++)
		{
			// left slab
			index = y * _xRes + z * _slabSize;
			_data[index][0] = _data[index + 2][0];

			// right slab
			index += _xRes - 1;
			_data[index][0] = _data[index - 2][0];
		}
}


//////////////////////////////////////////////////////////////////////
// set y direction to Neumann boundary conditions
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setNeumannY()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int x = 0; x < _xRes; x++)
		{
			// bottom slab
			index = x + z * _slabSize;
			_data[index][1] = _data[index + 2 * _xRes][1];

			// top slab
			index += _slabSize - _xRes;
			_data[index][1] = _data[index - 2 * _xRes][1];
		}
}

//////////////////////////////////////////////////////////////////////
// set z direction to Neumann boundary conditions
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::setNeumannZ()
{
	int index;
	for (int y = 0; y < _yRes; y++)
		for (int x = 0; x < _xRes; x++)
		{
			// front slab
			index = x + y * _xRes;
			_data[index][2] = _data[index + 2 * _slabSize][2];

			// back slab
			index += _totalCells - _slabSize;
			_data[index][2] = _data[index - 2 * _slabSize][2];
		}
}

//////////////////////////////////////////////////////////////////////
// copy grid boundary
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::copyBorderX()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int y = 0; y < _yRes; y++)
		{
			// left slab
			index = y * _xRes + z * _slabSize;
			_data[index][0] = _data[index + 1][0];

			// right slab
			index += _xRes - 1;
			_data[index][0] = _data[index - 1][0];
		}
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::copyBorderY()
{
	int index;
	for (int z = 0; z < _zRes; z++)
		for (int x = 0; x < _xRes; x++)
		{
			// bottom slab
			index = x + z * _slabSize;
			_data[index][1] = _data[index + _xRes][1]; 
			// top slab
			index += _slabSize - _xRes;
			_data[index][1] = _data[index - _xRes][1];
		}
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::copyBorderZ()
{
	int index;
	for (int y = 0; y < _yRes; y++)
		for (int x = 0; x < _xRes; x++)
		{
			// front slab
			index = x + y * _xRes;
			_data[index][2] = _data[index + _slabSize][2]; 
			// back slab
			index += _totalCells - _slabSize;
			_data[index][2] = _data[index - _slabSize][2];
		}
}

//////////////////////////////////////////////////////////////////////
// BLAS-like interface, output += alpha * input
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::axpy(const Real& alpha, const VECTOR3_GRID_3D<T>& field)
{
  assert(field.xRes() == _xRes);
  assert(field.yRes() == _yRes);
  assert(field.zRes() == _zRes);
  for (int x = 0; x < _totalCells; x++)
    _data[x] += alpha * field[x];
}

//////////////////////////////////////////////////////////////////////
// swap the contents with another object
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::swapPointers(VECTOR3_GRID_3D<T>& field)
{
  assert(field.xRes() == _xRes);
  assert(field.yRes() == _yRes);
  assert(field.zRes() == _zRes);
  
  T* temp = _data;
  _data = field._data;
  field._data = temp;
}

//////////////////////////////////////////////////////////////////////
// take the dot product of the current field with another vector field
// and return the scalar field
//////////////////////////////////////////////////////////////////////
template <class T>
FIELD_3D VECTOR3_GRID_3D<T>::dot(const VECTOR3_GRID_3D<T>& rhs)
{
  FIELD_3D final(_xRes, _yRes, _zRes);

  assert(rhs.xRes() == _xRes);
  assert(rhs.yRes() == _yRes);
  assert(rhs.zRes() == _zRes);

  //for (int x = 0; x < _totalCells; x++)
  //  final[x] = rhs[x] * (*this)[x];
  for (int z = 0; z < _zRes; z++)
    for (int y = 0; y < _yRes; y++)
      for (int x = 0; x < _xRes; x++)
      {

        if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
          final(x,y,z) = rhs(x,y,z).dot((*this)(x,y,z));
        else
          final(x,y,z) = rhs(x,y,z) * (*this)(x,y,z);
        if (x == 0 && y == 0 && z == 0)
        {
          std::cout << "RHS: " << rhs(x,y,z) << std::endl;
          std::cout << "this: " << (*this)(x,y,z) << std::endl;
          std::cout << "final: " << final(x,y,z) << std::endl;
        }

      }

  return final;
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class T>
void VECTOR3_GRID_3D<T>::normalizeToLargest()
{
  Real maxMagnitude = 0.0;
  for (int x = 0; x < _totalCells; x++)
  {
    Real candidate = 0;
    if constexpr (std::is_same_v<T, Eigen::Vector3d> || std::is_same_v<T, Eigen::Vector3f>)
      candidate = _data[x].norm();
    else 
      candidate = norm(_data[x]);

    if (candidate > maxMagnitude)
      maxMagnitude = candidate;
  }

  Real inverse = 1.0 / maxMagnitude;
  for (int x = 0; x < _totalCells; x++)
    _data[x] *= inverse;
}

//////////////////////////////////////////////////////////////////////
// absolute max single entry
//////////////////////////////////////////////////////////////////////
template <class T>
Real VECTOR3_GRID_3D<T>::maxAbsScalar()
{
  Real final = 0;
  for (int x = 0; x < _totalCells; x++)
    for (int y = 0; y < 3; y++)
      final = (fabs(_data[x][y]) > final) ? fabs(_data[x][y]) : final;

  return final;
}

//////////////////////////////////////////////////////////////////////
// 2 norm of the whole field
//////////////////////////////////////////////////////////////////////
template <class T>
Real VECTOR3_GRID_3D<T>::twoNorm()
{
  Real final = 0;
  for (int x = 0; x < _totalCells; x++)
    for (int y = 0; y < 3; y++)
      final += _data[x][y] * _data[x][y];

  return sqrt(final);
}

template <class T>
Real VECTOR3_GRID_3D<T>::twoNormSqared()
{
  Real final = 0;
  for (int x = 0; x < _totalCells; x++)
    for (int y = 0; y < 3; y++)
      final += _data[x][y] * _data[x][y];

  return final;
}

template class VECTOR3_GRID_3D<VEC3F>;
template class VECTOR3_GRID_3D<Eigen::Vector3d>;

template FIELD_3D operator*(const VECTOR3_GRID_3D<VEC3F>&u, const VECTOR3_GRID_3D<VEC3F>& v);
template VECTOR3_GRID_3D<VEC3F> operator*(const Real& a, const VECTOR3_GRID_3D<VEC3F>& v);
template VECTOR3_GRID_3D<VEC3F> operator*(const VECTOR3_GRID_3D<VEC3F>& v, const Real& a);
template VECTOR3_GRID_3D<VEC3F> operator*(const FIELD_3D& u, const VECTOR3_GRID_3D<VEC3F>& v);
template VECTOR3_GRID_3D<VEC3F> operator+(const VECTOR3_GRID_3D<VEC3F>& u, const VECTOR3_GRID_3D<VEC3F>& v);
template VECTOR3_GRID_3D<VEC3F> operator-(const VECTOR3_GRID_3D<VEC3F>& u, const VECTOR3_GRID_3D<VEC3F>& v);