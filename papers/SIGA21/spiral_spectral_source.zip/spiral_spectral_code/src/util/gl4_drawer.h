#ifndef GL4_DRAWER_H
#define GL4_DRAWER_H

#include <Eigen/Eigen>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <stdlib.h>
#include <glog/logging.h>
#include <gflags/gflags.h>
#include <learnopengl/shader_m.h>
#include <learnopengl/model.h>
#include <memory>

#include "2D/particle_2d.h"
#include "3D/particle_3d.h"
#include "common/particle_sph_3d.h"

struct coordAxis {
  coordAxis() {

    float vertices[] = {
      // positions         // colors
      -2.f, 0.f, 0.f,  1.0f, 0.0f, 0.0f,  // x-axis
       2.f, 0.f, 0.f,  1.0f, 0.0f, 0.0f,
       0.f, -2.f, 0.f, 0.0f, 1.0f, 0.0f,  // y-axis
       0.f, 2.f, 0.f,  0.0f, 1.0f, 0.0f, 
       0.f, 0.f, -2.f, 0.f, 0.0f, 1.0f,  // z-axis
       0.f, 0.f, 2.f,  0.f, 0.0f, 1.0f
    };

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    // bind the Vertex Array Object first, then bind and set vertex buffer(s), and then configure vertex attributes(s).
    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // color attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // note that this is allowed
    //glBindBuffer(GL_ARRAY_BUFFER, 0);
    //glBindVertexArray(0); 
  };

  void Draw() {
    glLineWidth(3.0f);
    glBindVertexArray(VAO);
    glDrawArrays(GL_LINES, 0, 6);
    glLineWidth(1.0f);
  }

  ~coordAxis(){
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
  }
  unsigned int VBO, VAO; 
};

struct particle3DGL4 {
  particle3DGL4(const int psize):nParticle_(psize) {
    posBuf_ = (float*)malloc(sizeof(float)*nParticle_*6);
    memset(posBuf_, 0x00, sizeof(float)*nParticle_*6);
    unsigned int indices[nParticle_];
    for (unsigned int i = 0; i < nParticle_; i++) {
      indices[i] = 2*i;
    }

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    // bind the Vertex Array Object first, then bind and set vertex buffer(s), and then configure vertex attributes(s).
    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float)*nParticle_*6, posBuf_, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // indices buffer
    glGenBuffers(1, &ELEB);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ELEB);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, nParticle_*sizeof(unsigned int), indices, GL_STATIC_DRAW);
  };
  
  ~particle3DGL4() {
    free(posBuf_);
    free(lineBuf_);
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
  };
  
  void updatePos(const std::vector<ParticleSph3D>& particles, float weightFact) {
    CHECK(nParticle_ == particles.size());
    for(int i = 0; i < particles.size(); i++) {
      posBuf_[i*6] = particles[i].position[0];
      posBuf_[i*6+1] = particles[i].position[1];
      posBuf_[i*6+2] = particles[i].position[2];
      posBuf_[i*6+3] = particles[i].position[0] + particles[i].velocity[0]*weightFact;
      posBuf_[i*6+4] = particles[i].position[1] + particles[i].velocity[1]*weightFact;
      posBuf_[i*6+5] = particles[i].position[2] + particles[i].velocity[2]*weightFact;
    }

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float)*nParticle_*6, posBuf_);
  }

  void updatePos(const std::vector<Particle3D>& particles, float weightFact) {
    CHECK(nParticle_ == particles.size());
    for(int i = 0; i < particles.size(); i++) {
      posBuf_[i*6] = particles[i].position[0];
      posBuf_[i*6+1] = particles[i].position[1];
      posBuf_[i*6+2] = particles[i].position[2];
      posBuf_[i*6+3] = particles[i].position[0] + particles[i].velocity[0]*weightFact;
      posBuf_[i*6+4] = particles[i].position[1] + particles[i].velocity[1]*weightFact;
      posBuf_[i*6+5] = particles[i].position[2] + particles[i].velocity[2]*weightFact;
    }

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float)*nParticle_*6, posBuf_);
  }
  
  void updatePos(const std::vector<Particle2D>& particles, const double dx, float weightFact,
                const double xShift, const double yShift) {

    CHECK(nParticle_ == particles.size());
    for(int i = 0; i < particles.size(); i++) {
      posBuf_[i*6] = particles[i].position[0]*dx - xShift;
      posBuf_[i*6+1] = 0.0;
      // align center, flip y
      posBuf_[i*6+2] = yShift - particles[i].position[1]*dx;
      posBuf_[i*6+3] = particles[i].position[0]*dx + particles[i].velocity[0]*weightFact - xShift;
      posBuf_[i*6+4] = 0.0;
      posBuf_[i*6+5] = yShift - particles[i].position[1]*dx + particles[i].velocity[1]*weightFact;
    }

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float)*nParticle_*6, posBuf_);
  }

  void Draw() {
    glPointSize(2.5);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ELEB);
    glDrawElements(GL_POINTS, nParticle_, GL_UNSIGNED_INT, (void*)0);
    glDrawArrays(GL_LINES, 0, nParticle_*2);
    glPointSize(1.0);;
  }

  unsigned int VBO, VAO, ELEB;
  const int nParticle_;
  // contains the position of the particles, and the point where the speed points to.
  float* posBuf_;
  float* lineBuf_;
};

struct coeffcientDrawGL4 {
  coeffcientDrawGL4(const Eigen::VectorXd& coef, const double multi_factor) {
    nCoef = coef.size();
    // two trigs each coef
    int totalSize = coef.size()*18;
    buf = (float*) malloc(sizeof(float)*totalSize);
    memset(buf, 0x00, sizeof(float)*totalSize);
    
    float start_y = 0.5;
    float step_y = -1.0 / coef.size();
    float start_x = 0.75;

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    // bind the Vertex Array Object first, then bind and set vertex buffer(s), and then configure vertex attributes(s).
    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float)*totalSize, buf, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    cnt = 0;
  }
  
  void Draw(const Eigen::VectorXd& coef, const double multi_factor) {
    
    Eigen::Map<Eigen::VectorXf> bufV(buf, nCoef*18);
    float start_y = 0.5;
    float step_y = -1.0 / coef.size();
    float start_x = 0.75;
    
    if (cnt % 10 == 0 && cnt != 0) {
      double maxV = -1.0;
      for (int i = 0; i < coef.size(); i++) {
        maxV = std::max(abs(coef[i]), maxV);
      }
      if (maxV*multi_factor > 1e-6)
        nf = 0.3 / (maxV*multi_factor);
      //if (maxV*mul)
    }
    
    for (int i = 0; i < coef.size(); i++) {
      float height = coef[i]*multi_factor;
      bufV.segment(i*18 + 0, 3) = Eigen::Vector3f(start_x, start_y , 0);
      bufV.segment(i*18 + 3, 3) = Eigen::Vector3f(start_x, start_y + step_y , 0);
      bufV.segment(i*18 + 6, 3) = Eigen::Vector3f(start_x + height, start_y , 0);
      bufV.segment(i*18 + 9, 3) = Eigen::Vector3f(start_x, start_y + step_y , 0);
      bufV.segment(i*18 + 12, 3) = Eigen::Vector3f(start_x + height, start_y , 0);
      bufV.segment(i*18 + 15, 3) = Eigen::Vector3f(start_x + height, start_y + step_y, 0);
      start_y += step_y;
    }

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float)*nCoef*18, buf);

    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, nCoef*6);
    cnt++;
  }

  ~coeffcientDrawGL4() {
    free(buf);
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
  }

  unsigned int VBO, VAO;
  float* buf;
  int nCoef;
  int cnt;
  double nf = 1.0;
};

struct denstityDrawerSurface {
  denstityDrawerSurface(const int nPhi, const int nTheta):nPhi_(nPhi), nTheta_(nTheta) {
    model.reset(new Model("./models/planet/planet.obj"));
    const int totalSize = nPhi_*nTheta_;

    textureData = (float*)malloc(sizeof(float)*totalSize);
    memset(textureData, 0x00, sizeof(float)*totalSize);
    for (int i = 0; i < totalSize; i++)
      textureData[i] = 1.0;
    textureID_ = model->assignFloatTexture(nPhi_, nTheta_, textureData);

  };
  
  denstityDrawerSurface(const int nPhi, const int nTheta, const std::string& modelFile):nPhi_(nPhi), nTheta_(nTheta) {
    model.reset(new Model(modelFile));
    const int totalSize = nPhi_*nTheta_;

    textureData = (float*)malloc(sizeof(float)*totalSize);
    memset(textureData, 0x00, sizeof(float)*totalSize);
    for (int i = 0; i < totalSize; i++)
      textureData[i] = 1.0;
    textureID_ = model->assignFloatTexture(nPhi_, nTheta_, textureData);

  };

  void Draw(Shader& shader) {
    model->updateFloatTexture(nPhi_, nTheta_, textureData, textureID_);
    model->Draw(shader);
  }
  ~denstityDrawerSurface(){
    free(textureData);
  };

  std::unique_ptr<Model> model;
  const int nPhi_;
  const int nTheta_;
  float* textureData;
  unsigned int textureID_;
};

struct densityDraw2D
{
  densityDraw2D(const int xRes, const int yRes):xRes_(xRes), yRes_(yRes) {
    const int totalSize = xRes_*yRes_;
    textureData = (float*)malloc(sizeof(float)*totalSize);
    memset(textureData, 0x00, sizeof(float)*totalSize);
    for (int i = 0; i < totalSize; i++)
      textureData[i] = 1.0;
    
    glGenTextures(1, &textureID_);
    GLenum format = GL_RED;
    glBindTexture(GL_TEXTURE_2D, textureID_);
    glTexImage2D(GL_TEXTURE_2D, 0, format, xRes, yRes, 0, format, GL_FLOAT, textureData);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    int maxRes = std::max(xRes, yRes);
    float xDim = xRes/(float)(maxRes);
    float yDim = yRes/(float)(maxRes);
    // geometry
    // ------------------------------------------------------------------
    float vertices[] = {
      // positions        // texture coords
       xDim, 0.0f, -yDim, 1.0f, 1.0f, // top right
       xDim, 0.0f, yDim, 1.0f, 0.0f, // bottom right
      -xDim, 0.0f, yDim, 0.0f, 0.0f, // bottom left
      -xDim, 0.0f, -yDim, 0.0f, 1.0f  // top left 
    };
    unsigned int indices[] = {  
      0, 1, 3, // first triangle
      1, 2, 3  // second triangle
    };
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

  }
  ~densityDraw2D(){
    free(textureData);
  }
  
  void Draw() {
    // update texture
    Model::updateFloatTexture(xRes_, yRes_, textureData, textureID_);
    // bind Texture
    glBindTexture(GL_TEXTURE_2D, textureID_);
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
  }

  unsigned int VBO, VAO, EBO;
  const int xRes_;
  const int yRes_;
  float* textureData;
  unsigned int textureID_; 
};

struct densityDraw2DRGB
{
  densityDraw2DRGB(const int xRes, const int yRes):xRes_(xRes), yRes_(yRes) {
    const int totalSize = xRes_*yRes_;
    textureData = (float*)malloc(sizeof(float)*totalSize*3);
    memset(textureData, 0x00, sizeof(float)*totalSize*3);
    for (int i = 0; i < totalSize*3; i++)
      textureData[i] = 1.0;
    
    glGenTextures(1, &textureID_);
    GLenum format = GL_RGB;
    glBindTexture(GL_TEXTURE_2D, textureID_);
    glTexImage2D(GL_TEXTURE_2D, 0, format, xRes, yRes, 0, format, GL_FLOAT, textureData);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    int maxRes = std::max(xRes, yRes);
    float xDim = xRes/(float)(maxRes);
    float yDim = yRes/(float)(maxRes);
    // geometry
    // ------------------------------------------------------------------
    float vertices[] = {
      // positions        // texture coords
       xDim, 0.0f, -yDim, 1.0f, 1.0f, // top right
       xDim, 0.0f, yDim, 1.0f, 0.0f, // bottom right
      -xDim, 0.0f, yDim, 0.0f, 0.0f, // bottom left
      -xDim, 0.0f, -yDim, 0.0f, 1.0f  // top left 
    };
    unsigned int indices[] = {  
      0, 1, 3, // first triangle
      1, 2, 3  // second triangle
    };
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // texture coord attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

  }
  ~densityDraw2DRGB(){
    free(textureData);
  }
  
  void Draw() {
    // update texture
    Model::updateFloatTextureRGB(xRes_, yRes_, textureData, textureID_);
    // bind Texture
    glBindTexture(GL_TEXTURE_2D, textureID_);
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
  }

  unsigned int VBO, VAO, EBO;
  const int xRes_;
  const int yRes_;
  float* textureData;
  unsigned int textureID_; 
};

#endif  // GL4_DRAWER_H