#ifndef OBSTACLE_SOLVER_H
#define OBSTACLE_SOLVER_H

#include <Eigen/Eigen>

void SolveObstacleImplicit(const Eigen::VectorXd& omega_in,
        const Eigen::MatrixXd& proj_matrix, Eigen::VectorXd* omega_out);

#endif  // OBSTACLE_SOLVER_H
