/* Rewrite from  https://graphics.ethz.ch/teaching/former/imagesynthesis_06/miniprojects/p3/index.html
 *Author: Johannes Schmid and Ingemar Rask, 2006, johnny@grob.org */

#ifndef SMOKE_RENDER_3D_H
#define SMOKE_RENDER_3D_H

#ifdef APPLE
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <cstdlib>
#include <Eigen/Eigen>

#include "setting.h"
#include "3D/FIELD_3D.h"

#ifndef ALMOST_EQUAL
#define ALMOST_EQUAL(a, b) ((std::abs(a-b)<0.00001)?true:false)
#endif

#define SLICE_NUM			64.0f


class Renderer3D
{
public:
  	void InitGL();
	Renderer3D(const int xRes, const int yRes, const int zRes);
	~Renderer3D();
	void SetLightPostion(const Eigen::Vector3f &pos);
	void SetRendering(bool isRendering);
	void SetSliceOutline(bool isDrawSliceOutline);


	void FillTexture(const FIELD_3D& density_field, const float multiplier,
                     const int low_cut);		// generate texture from smoke density 
	void Render();					// draw the volume
	// draw the outline of the cube
	void DrawCube();
	void DrawLight();
	void DrawVolumeData();

private:

	// texture data
	unsigned char* _textureData;
	// texture handle
	unsigned int _hTexture;				
	//lighting infomations
	Eigen::Vector3f _lightDir;
	Eigen::Vector3f _lightPos;
	int _rayTemplate[4096][3];
	// Real *_volumeData;

	GLfloat _cubeVertices[8][3];
	GLfloat _cubeEdges[12][2][3];

	// draw the slices. mvMatrix must be the MODELVIEW_MATRIX
	void DrawSlices(GLdouble mvMatrix[16]);

	// intersect a plane with the cube, helper function for DrawSlices()
	// plane equation is Ax + By + Cz + D = 0
	std::vector<Eigen::Vector3f> IntersectEdges(float A, float B, float C, float D);

	void GenerateRayTemplate();
	void CastLight(const FIELD_3D& density, unsigned char* intensity);
	inline void LightRay(int x, int y, int z, float decay, 
			const FIELD_3D& density, unsigned char* intensity);




	// if _isDrawSliceOutline==true, the outline of the slices will be drawn as well
	bool _isDrawSliceOutline;
	bool _isRendering;

	int _SIZE;		//size of volume data
  const int xRes_;
  const int yRes_;
  const int zRes_;
  int MaxRes_;
  int Slabsize_;
  float xN_;
  float yN_;
  float zN_;
  float invxN_;
  float invyN_;
  float invzN_;
  
};


#endif  // SMOKE_RENDER_3D_H

