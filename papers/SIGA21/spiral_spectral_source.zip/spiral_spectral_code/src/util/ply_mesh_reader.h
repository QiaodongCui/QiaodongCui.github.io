
#ifndef PLY_MESH_READER_H
#define PLY_MESH_READER_H

#include <iostream>
#include <Eigen/Eigen>

class PlyMeshReader{
public:
  PlyMeshReader(std::string name);
  ~PlyMeshReader(){_vlist.clear();}
  bool readNumPlyVerts(FILE *&inFile, int& nVerts);
  bool readNumPlyTris(FILE *&inFile, int& nTris);
  bool readPlyHeader(FILE *&inFile);
  bool readPlyVerts(FILE *&inFile);
  bool readPlyTris(FILE *&inFile);
  bool loadFromFile(const char* filename);
  void ChangeStrToLower(char* pszUpper)
 {
    for(char* pc = pszUpper; pc < pszUpper + strlen(pszUpper); pc++) {
      *pc = (char)tolower(*pc);
    }
  }
  void WriteVertexAndTriToFile(std::string filename);
  int _numVerts;
  int _numTriangles;
  std::vector<Eigen::Vector3f> _vlist;
  std::vector<Eigen::Vector3i> _tlist;
};

#endif
