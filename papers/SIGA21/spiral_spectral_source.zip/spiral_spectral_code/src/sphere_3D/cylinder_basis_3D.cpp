#include <Eigen/Eigen>
#include <math.h>

#include "common/basic_function.h"
#include "3D/trig_integral_3d.h"
#include "sphere_3D/cylinder_basis_3D.h"
#include "util/transform.h"
#include "util/util.h"

using namespace std;

namespace {
// {SIN, COS, ZERO, ONE};
// int_{phi = 0}^{2 \Pi} type1(i1*\phi) d\phi 
double computePhiOneInt(const FUNTYPE type1, const int i1) {
  if (type1 == SIN || type1 == ZERO)
    return 0;
  else if (type1 == COS)
    return i1 == 0 ? 2.0*M_PI : 0;
  else if (type1 == ONE)
    return 2.0*M_PI;

  LOG(FATAL) << "unsupported type";
  return 0.0;
};

// {SIN, COS, ZERO, ONE};
// int_{\theta = 0}^{Pi} fun1*sin(\theta) d\theta 
double computeThetaOneInt(const BasicFunc& fun1) {
  if (fun1.type == ZERO)
    return 0;
  else if (fun1.type == ONE)  // int_{t = 0}^{Pi} sin(t) dt = 2.0
    return fun1.coef*2.0;
  else if (fun1.type == COS)  // cos(i1 t)sin(t) -> sin
    return fun1.coef*0.5*(-IntegralSinInt(fun1.wnx2/2 - 1) + IntegralSinInt(fun1.wnx2/2 + 1));
  else if (fun1.type == SIN)  // sin(i1 t)sin(t) -> cos
    return fun1.coef*0.5*(IntegralCosInt(fun1.wnx2/2 + 1) - IntegralCosInt(fun1.wnx2/2 + 1));

  LOG(FATAL) << "unsupported type";
  return 0.0;  
};

// {SIN, COS, ZERO, ONE};
// int_{r = 0}^{1} fun1*r^2 dr 
double computeROneInt(const BasicFunc& fun1) {
  CHECK(fun1.dir == R);

  BasicFunc fr2(fun1);
  fr2.rPower += 2;
  return fr2.integrate();
};

};

void CylinderBasis3D::initBasicCoef() {
  double invk2 = 1.0;
  if (k2x2 != 0)
    invk2 = 1.0/k2;
  double invk3 = 1.0;
  if (k3x2 != 0)
    invk3 = 1.0/k3;

  // specify F(z) in basis functions.
  // include b from phi_z
  // seee from cylindrical.pdf in the doc
  switch (index_) {
    // two regular basis
    case 0:
    case 1:  // use r instead of define a new direction, things should work out as usually
             // r \in [0, 1].
            if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) { // b F(z) = b sin(i3 pi z)
              phiFunc_[0] = BasicFunc(COS, R, k3x2, k3*M_PI); // F'(z) = i3 pi cos(i3 pi z)
              phiFunc_[1] = phiFunc_[0];
              phiFunc_[2] = BasicFunc(SIN, R, k3x2, b_);
              CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 > 0);
            } else {   // b F(z) = b cos(i3 pi z)
                       // F'(z) = - i3 pi sin(i3 pi z)
              phiFunc_[0] = BasicFunc(SIN, R, k3x2, -k3*M_PI);
              phiFunc_[1] = phiFunc_[0];
              phiFunc_[2] = BasicFunc(COS, R, k3x2, b_);
              CHECK(k1x2 > 0 && k2x2 > 0 && k3x2 >= 0);
            }
    break;
    
    case 2:  // enrich 1
    case 3:  // enrich 2
            if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) { // b F(z) = b sin(i3 pi z)
              phiFunc_[0] = BasicFunc(COS, R, k3x2, k3*M_PI); // F'(z) = i3 pi cos(i3 pi z)
              phiFunc_[1] = phiFunc_[0];
              phiFunc_[2] = BasicFunc(SIN, R, k3x2, b_);
              CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 > 0);
            } else {   // b F(z) = b cos(i3 pi z)
                       // F'(z) = - i3 pi sin(i3 pi z)
              phiFunc_[0] = BasicFunc(SIN, R, k3x2, -k3*M_PI);
              phiFunc_[1] = phiFunc_[0];
              phiFunc_[2] = BasicFunc(COS, R, k3x2, b_);
              CHECK(k1x2 >= 0 && k2x2 == 2 && k3x2 >= 0);
              CHECK(! (k1x2 == 0 && k3x2 == 0)); // cant be both zero.
            }
    break;

    // enrich along z
    case 4:
            if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1) { // b F(z) = b sin(i3 pi z)
              phiFunc_[0] = BasicFunc(COS, R, k3x2, k3*M_PI); // F'(z) = i3 pi cos(i3 pi z)
              phiFunc_[1] = BasicFunc(ZERO, R, 0,0);
              phiFunc_[2] = BasicFunc(SIN, R, k3x2, b_);
              CHECK(k1x2 >= 0 && k2x2 == 0 && k3x2 > 0);
            } else {   // b F(z) = b cos(i3 pi z)
                       // F'(z) = - i3 pi sin(i3 pi z)
              phiFunc_[0] = BasicFunc(SIN, R, k3x2, -k3*M_PI);
              phiFunc_[1] = BasicFunc(ZERO, R, 0,0);
              phiFunc_[2] = BasicFunc(COS, R, k3x2, b_);
              CHECK(k1x2 >= 0 && k2x2 == 0 && k3x2 >= 0);
            }
    break;

    case 5:
            phiFunc_[0] = BasicFunc(ZERO, R, 0, 0);
            phiFunc_[1] = BasicFunc(COS, R, k3x2, 1);
            phiFunc_[2] = BasicFunc(ZERO, R, 0, 0);
            CHECK(k1x2 > 0 && k2x2 == 0 && k3x2 >= 0);
    break;

    default:
    LOG(FATAL) << "idx " << index_ << "not supported";
  };

  if (index_ == 0) {
    RTMultiply r0;
    // sin(pi/2*r)*sin(i1*Pi*r)
    r0.rComp = {BasicFunc(COS, R, k1x2 - 1, 0.5), BasicFunc(COS, R, k1x2 + 1, -0.5)};
    // -i2cos(i2 t)
    r0.tComp = {BasicFunc(COS, T, k2x2, -k2)};
  
    RTMultiply t0;
    t0.rComp = r0.rComp;
    t0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RTMultiply p0;
    // pi/2*cos(pi/2 r)sin(i1 pi r)
    // pi*i1*sin(pi/2 r) cos(i1 pi r)
    p0.rComp = {BasicFunc(SIN, R, k1x2 + 1, 0.25*M_PI), BasicFunc(SIN, R, k1x2 - 1, 0.25*M_PI), 
                BasicFunc(SIN, R, k1x2 + 1, M_PI*k1*0.5), BasicFunc(SIN, R, k1x2 - 1, -M_PI*k1*0.5)};
    // i2*cos(i2 t)
    p0.tComp = {BasicFunc(COS, T, k2x2, k2)};
    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 1) { // shares expression
    RTMultiply r0;
    // sin(pi/2*r)*sin(i1*Pi*r)
    r0.rComp = {BasicFunc(COS, R, k1x2 - 1, 0.5), BasicFunc(COS, R, k1x2 + 1, -0.5)};
    // i2 sin(i2 t)
    r0.tComp = {BasicFunc(SIN, T, k2x2, k2)};
    
    RTMultiply t0;
    t0.rComp = r0.rComp;
    t0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
    
    RTMultiply p0;
    p0.rComp = {BasicFunc(SIN, R, k1x2 + 1, 0.25*M_PI), BasicFunc(SIN, R, k1x2 - 1, 0.25*M_PI), 
            BasicFunc(SIN, R, k1x2 + 1, M_PI*k1*0.5), BasicFunc(SIN, R, k1x2 - 1, -M_PI*k1*0.5)};
    // -i2*sin(i2 t)
    p0.tComp = {BasicFunc(SIN, T, k2x2, -k2)};
  
    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 2) {

    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(COS, T, 2, 1.0)};
  
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, -1.0)};
    t0.tComp = {BasicFunc(SIN, T, 2, 1.0)};

    RTMultiply p0;
    p0.rComp = {BasicFunc(SIN, R, k1x2, k1*M_PI)};
    p0.tComp = {BasicFunc(COS, T, 2, 1.0)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 3) {
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, 2, 1.0)};
  
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    t0.tComp = {BasicFunc(COS, T, 2, 1.0)};

    RTMultiply p0;
    p0.rComp = {BasicFunc(SIN, R, k1x2, k1*M_PI)};
    p0.tComp = {BasicFunc(SIN, T, 2, 1.0)};

    RT_[0] = {r0}; RT_[1] = {t0}; RT_[2] = {p0};
  } else if (index_ == 4) {
    // if dirichlet, k1x2 % 2 != 0
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0, 1)};
    r0.tComp = {BasicFunc(ONE, T, 2, 1.0)};

    RTMultiply p0;
    p0.rComp = {BasicFunc(COS, R, k1x2, -2.0), BasicFunc(SIN, R, k1x2, k1*M_PI, 1)};
    p0.tComp = {BasicFunc(ONE, T, 2, 1.0)};
    if (! isDirichletR_) {  // Neumann  k1x2 % 2 == 0
      r0.rComp.push_back(BasicFunc(SIN, R, k1x2+1, -1.0, 1));
      p0.rComp.push_back(BasicFunc(SIN, R, k1x2+1, 2.0));
      p0.rComp.push_back(BasicFunc(COS, R, k1x2+1, (k1+0.5)*M_PI, 1));
    }
    RT_[0] = {r0}; RT_[1] = {}; RT_[2] = {p0};
  } else if (index_ == 5) {
    RTMultiply t0;
    t0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
    t0.tComp = {BasicFunc(ONE, T, 2, 1.0)};
    RT_[0] = {}; RT_[1] = {t0}; RT_[2] = {};
  } else {
    LOG(FATAL) << "idx " << index_ << "not supported";
  }
}

double CylinderBasis3D::weightF(const double& r) {

 return sin(0.5*M_PI*r);
}

double CylinderBasis3D::weightFDeriv(const double& r) {

  return 0.5*M_PI*cos(0.5*M_PI*r);
}

#define PHI0 -k2*weightF(r)*sin(k1*M_PI*r)*cos(k2*t),\
             weightF(r)*sin(k1*M_PI*r)*sin(k2*t),\
             k2*(weightFDeriv(r)*sin(k1*M_PI*r) + k1*M_PI*weightF(r)*cos(k1*M_PI*r))*cos(k2*t)

#define PHI1 k2*weightF(r)*sin(k1*M_PI*r)*sin(k2*t),\
             weightF(r)*sin(k1*M_PI*r)*cos(k2*t),\
             -k2*(weightFDeriv(r)*sin(k1*M_PI*r) + k1*M_PI*weightF(r)*cos(k1*M_PI*r))*sin(k2*t)

#define PHI2 cos(k1*M_PI*r)*cos(t),\
             -cos(k1*M_PI*r)*sin(t),\
             k1*M_PI*sin(k1*M_PI*r)*cos(t)

#define PHI3 cos(k1*M_PI*r)*sin(t),\
             cos(k1*M_PI*r)*cos(t),\
             k1*M_PI*sin(k1*M_PI*r)*sin(t)

#define PHI4D r*cos(k1*M_PI*r),\
             0,\
             (-2.0*cos(k1*M_PI*r) + k1*M_PI*r*sin(k1*M_PI*r))

#define PHI4A Eigen::Vector3d(r*sin((k1+0.5)*M_PI*r), 0,\
             (-2.0*sin((k1+0.5)*M_PI*r) - (k1+0.5)*M_PI*r*cos((k1+0.5)*M_PI*r)))

#define PHI5 0,\
             sin(k1*M_PI*r)*cos(k3*M_PI*z),\
             0

#define computeBasis switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4D;\
            if (! isDirichletR_)\
              v -= PHI4A;\
          break;\
\
          case 5:\
            v << PHI5;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }

#define FzPhi04Sin k3*M_PI*cos(k3*M_PI*z),\
                   k3*M_PI*cos(k3*M_PI*z),\
                   b_*sin(k3*M_PI*z)

#define FzPhi04Cos -k3*M_PI*sin(k3*M_PI*z),\
                   -k3*M_PI*sin(k3*M_PI*z),\
                   b_*cos(k3*M_PI*z)

void CylinderBasis3D::DiscretizeAdd(const double coef, FIELD_3D& radius, FIELD_3D& theta, FIELD_3D& zF,
            VECTOR3_FIELD_3D* vfield) {
  
  Eigen::Matrix3d trans;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < vfield->zRes(); k++)
    for (int j = 0; j < vfield->yRes(); j++)
      for (int i = 0; i < vfield->xRes(); i++) {

        double r = radius(i,j,k);
        double t = theta(i,j,k);
        double z = zF(i,j,k);

        if (r > 1.0)
          continue;
        
        Eigen::Vector3d v;
        v.setZero();
        computeBasis;
        Eigen::Vector3d fz(1,1,1);
        if (index_ <= 4) {
          if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
            fz << FzPhi04Sin;
          else
            fz << FzPhi04Cos;
        }
        v = v.array()*fz.array();
        
        Transform::Cylinderical::toCartesianMat(t, trans);
        Eigen::Vector3d uCartesian = invNorm_*coef*trans*v;
        (*vfield)(i,j,k)[0] = uCartesian[0];
        (*vfield)(i,j,k)[1] = uCartesian[1];
        (*vfield)(i,j,k)[2] = uCartesian[2];
      }
}

// compute on a spherical grid.
void CylinderBasis3D::AddUniformU(const double coef, const int nR, const int nTheta,
                                const int nZ, double* ur, double* ut, double* up) const {
  double dR = 1.0 / nR;
  double dT = 2.0*M_PI / nTheta;
  double dZ = 1.0/nZ;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nZ; i++) {
        
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-2pi]
        double z = ((double)(i) + 0.5)*dZ; // [0, 1]

        Eigen::Vector3d v;
        v.setZero();
        
        computeBasis;
        Eigen::Vector3d fz(1,1,1);
        if (index_ <= 4) {
          if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
            fz << FzPhi04Sin;
          else
            fz << FzPhi04Cos;
        }
        v = v.array()*fz.array();
        
        v *= coef*invNorm_;
        int idx = i + j*nZ + k*nZ*nTheta;

        ur[idx] += v[0];
        ut[idx] += v[1];
        up[idx] += v[2];
      }
    }
  }
}

double CylinderBasis3D::ProjectUniformU(const int nR, const int nTheta, const int nZ,
                                      const double* fr, const double* ft, const double* fp) const {
  double dR = 1.0 / nR;
  double dT = 2.0*M_PI / nTheta;
  double dZ = 1.0/nZ;
  
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double invk3 = (k3x2 == 0) ? 1.0 : 1.0/k3;
  double result = 0;

  for (int k = 0; k < nR; k++) {
    for (int j = 0; j < nTheta; j++) {
      for (int i = 0; i < nZ; i++) {
        double r = ((double)(k) + 0.5)*dR; // [0-1]
        double t = ((double)(j) + 0.5)*dT; // [0-2pi]
        double z = ((double)(i) + 0.5)*dZ; // [0, 1]
        
        Eigen::Vector3d v;
        v.setZero();

        computeBasis;
        Eigen::Vector3d fz(1,1,1);
        if (index_ <= 4) {
          if (zBndCndIdx_ == 0 || zBndCndIdx_ == 1)
            fz << FzPhi04Sin;
          else
            fz << FzPhi04Cos;
        }
        v = v.array()*fz.array();

        int idx = i + j*nZ + k*nZ*nTheta;
        result += v[0]*fr[idx] + v[1]*ft[idx] + v[2]*fp[idx];
      }
    }
  }
  result *= invNorm_;
  result *= dR*dT*dZ;

  return result;
}

// {SIN, COS, ZERO, ONE};
// int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
double CylinderBasis3D::computePhiInt(const BasicFunc& fun1, const BasicFunc& fun2) {
 
  vector<BasicFunc> mult = BasicFunc::multiply(fun1, fun2);
  double result = 0;
  for (auto& f : mult) {
    result += f.integrate();
  }
  return result;
}

// enum FUNTYPE {SIN, COS, ZERO, ONE};
// int_{\theta = 0}^{2Pi} fun1*fun2*sin(\theta) d\theta 
double CylinderBasis3D::computeThetaInt(const BasicFunc& fun1) {
  CHECK(fun1.dir == T);
  return fun1.integrateP2Pi();
}

// {SIN, COS, ZERO, ONE};
// int_{r = 0}^{1} fun1*fun2*rb dr 
double CylinderBasis3D::computeRInt(const BasicFunc& fun1) const {
  CHECK(fun1.dir == R);
  BasicFunc fcpy = fun1;
  fcpy.rPower += 1;  // jacobian
  fcpy *= b_;
  return fcpy.integrate();
}

double CylinderBasis3D::computeRTMultInt(const RTMultiply& rt1) const {
  double thetaInt = 0;
  for (const auto& fun1 : rt1.tComp)
    thetaInt += computeThetaInt(fun1);

  double rInt = 0;
  for (const auto& fun1 : rt1.rComp)
    rInt += computeRInt(fun1);

  return thetaInt*rInt;
}

Eigen::Vector3d CylinderBasis3D::computeRTP(const CylinderBasis3D& other) const {
  Eigen::Vector3d result(0,0,0);

  for (int i = 0; i < 3; i++) {
    // <phi_i, phi_i>    
    double pINT = computePhiInt(phiFunc_[i], other.getPhiFunc(i));
    //LOG(INFO) << k3x2/2;

    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and phi.
      double rtINT = 0;
      vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
      for (const auto& rt1 : RTProd)
        rtINT += computeRTMultInt(rt1);

      result[i] = pINT*rtINT;
    }
  }

  return result;
}

double CylinderBasis3D::dotProd(const CylinderBasis3D& other) const {
  return computeRTP(other).sum();
}

double CylinderBasis3D::dotProdScale(const CylinderBasis3D& other) const {
  return computeRTP(other).sum()*scale3_;
}

void CylinderBasis3D::Normalize() {
  norm2_ = dotProdScale(*this);
  invNorm_ = 1.0/sqrt(norm2_);
}
// This includes r^2 sin(t) term in integral, please refer to basisAnalysis_3DTensor.pdf
// this does not include the norm
void CylinderBasis3D::curlSph() {
  
  // b D[fz, t] - r D[ft, z]
  // sign is grouped into phi func
  curlPhi_[0][0] = phiFunc_[2];
  curlPhi_[0][0].coef *= b_;
  curlPhi_[0][1] = -phiFunc_[1].deriv()[0];

  // (rD[fr, z] - rb D[fz, r])
  curlPhi_[1][0] = phiFunc_[0].deriv()[0];
  curlPhi_[1][1] = -phiFunc_[2];
  curlPhi_[1][1].coef *= b_;
  
  // b*[(r*D[ft, r] + ft) - D[fr, t]];
  curlPhi_[2][0] = phiFunc_[1];
  curlPhi_[2][0].coef *= b_;
  curlPhi_[2][1] = -phiFunc_[0];
  curlPhi_[2][1].coef *= b_;
  
  // D[fz, t]  
  curlRT_[0][0] = RT_[2];  // fz
  RTMultiply::derivTVec(curlRT_[0][0]); // dt
  
  // r D[ft, z]
  curlRT_[0][1] = RT_[1];  // ft
  RTMultiply::multRVec(1, curlRT_[0][1]);

  // r D[fr, z]
  curlRT_[1][0] = RT_[0];  // fr
  RTMultiply::multRVec(1, curlRT_[1][0]);
  
  // r D[fz, r]
  curlRT_[1][1] = RT_[2]; // fz
  RTMultiply::derivRVec(curlRT_[1][1]); 
  RTMultiply::multRVec(1, curlRT_[1][1]); // r

  // r*D[ft, r] + ft;
  curlRT_[2][0] = RT_[1]; // ft
  RTMultiply::derivRVec(curlRT_[2][0]); // D[ft, r]
  RTMultiply::multRVec(1, curlRT_[2][0]); // r*D[ft, r]
  // r*D[ft, r] + ft;
  curlRT_[2][0].insert(curlRT_[2][0].end(), RT_[1].begin(), RT_[1].end());
  
   // D[fr, t]
  curlRT_[2][1] = RT_[0];
  RTMultiply::derivTVec(curlRT_[2][1]);
}

void CylinderBasis3D::LaplacianX(std::vector<RTMultiply> (&LaplacinRT)[6], BasicFunc (&LaplacianZ)[6]) const {
  // D[v_r^2, r^2]
  LaplacianZ[0] = phiFunc_[0];
  LaplacinRT[0] = RT_[0]; // vr
  RTMultiply::derivRVec(LaplacinRT[0]); // D[v_r, r]
  RTMultiply::derivRVec(LaplacinRT[0]); // D[v_r^2, r^2]

  // 1/r^2*D[v_r^2, t^2]
  LaplacianZ[1] = phiFunc_[0];
  LaplacinRT[1] = RT_[0]; // vr
  RTMultiply::derivTVec(LaplacinRT[1]); // D[v_r, t]
  RTMultiply::derivTVec(LaplacinRT[1]); // D[v_r^2, t^2]
  RTMultiply::multRVec(-2, LaplacinRT[1]); // 1/r^2*
   
  // D[v_r^2, z^2]
  LaplacianZ[2] = phiFunc_[0].deriv()[0].deriv()[0];
  LaplacinRT[2] = RT_[0]; // vr

  // 1/r*D[v_r, r]
  LaplacianZ[3] = phiFunc_[0];
  LaplacinRT[3] = RT_[0]; // vr
  RTMultiply::derivRVec(LaplacinRT[3]); // D[v_r, r]
  RTMultiply::multRVec(-1, LaplacinRT[3]); // 1/r*

  // -2/r^2*D[v_t, t]
  LaplacianZ[4] = phiFunc_[1];
  LaplacianZ[4].coef *= -2.0; // -2
  LaplacinRT[4] = RT_[1]; // vt
  RTMultiply::derivTVec(LaplacinRT[4]); // D[v_t, t]
  RTMultiply::multRVec(-2, LaplacinRT[4]); // 1/r^2

  // -v_r/r^2
  LaplacianZ[5] = phiFunc_[0];
  LaplacianZ[5].coef *= -1; // -
  LaplacinRT[5] = RT_[0]; // vr
  RTMultiply::multRVec(-2, LaplacinRT[5]);
}

void CylinderBasis3D::LaplacianY(std::vector<RTMultiply> (&LaplacinRT)[6], BasicFunc (&LaplacianZ)[6]) const {
  // D[v_t^2, r^2]
  LaplacianZ[0] = phiFunc_[1];
  LaplacinRT[0] = RT_[1]; // v_t
  RTMultiply::derivRVec(LaplacinRT[0]); // D[v_t, r]
  RTMultiply::derivRVec(LaplacinRT[0]); // D[v_t^2, r^2]

  // 1/r^2*D[v_t^2, t^2]
  LaplacianZ[1] = phiFunc_[1];
  LaplacinRT[1] = RT_[1]; // v_t
  RTMultiply::derivTVec(LaplacinRT[1]); // D[v_t, t]
  RTMultiply::derivTVec(LaplacinRT[1]); // D[v_t^2, t^2]
  RTMultiply::multRVec(-2, LaplacinRT[1]); // 1/r^2 
  
  // D[v_t^2, z^2]
  LaplacianZ[2] = phiFunc_[1].deriv()[0].deriv()[0];
  LaplacinRT[2] = RT_[1]; // v_t

  // 1/r*D[v_t, r]
  LaplacianZ[3] = phiFunc_[1];
  LaplacinRT[3] = RT_[1]; // v_t
  RTMultiply::derivRVec(LaplacinRT[3]); // D[v_t, r]
  RTMultiply::multRVec(-1, LaplacinRT[3]); // 1/r

  // 2/r^2*D[v_r, t]
  LaplacianZ[4] = phiFunc_[0];
  LaplacianZ[4].coef *= 2.0; // 2
  LaplacinRT[4] = RT_[0]; // v_r
  RTMultiply::derivTVec(LaplacinRT[4]); // D[v_r, t]
  RTMultiply::multRVec(-2, LaplacinRT[4]); // 1/r^2  

  // -v_t/r^2
  LaplacianZ[5] = phiFunc_[1];
  LaplacianZ[5].coef *= -1.0; // -
  LaplacinRT[5] = RT_[1]; // v_t
  RTMultiply::multRVec(-2, LaplacinRT[5]); // 1/r^2
}

// compute Z component of \nabla^2 Phi.
void CylinderBasis3D::LaplacianZ(std::vector<RTMultiply> (&LaplacinRT)[4], BasicFunc (&LaplacianZ)[4]) const {
  // D[v_z^2, r^2]
  LaplacianZ[0] = phiFunc_[2];
  LaplacinRT[0] = RT_[2];
  RTMultiply::derivRVec(LaplacinRT[0]); // D[v_z, r]
  RTMultiply::derivRVec(LaplacinRT[0]); // D[v_z^2, r^2]

  // 1/r^2 D[v_z^2, t^2]
  LaplacianZ[1] = phiFunc_[2];
  LaplacinRT[1] = RT_[2]; // v_z
  RTMultiply::derivTVec(LaplacinRT[1]); // D[v_z, t]
  RTMultiply::derivTVec(LaplacinRT[1]); // D[v_z^2, t^2]
  RTMultiply::multRVec(-2, LaplacinRT[1]); // 1/r^2
   
  // D[v_z^2, z^2]
  LaplacianZ[2] = phiFunc_[2].deriv()[0].deriv()[0];
  LaplacinRT[2] = RT_[2]; // v_z

  // 1/r*D[v_z, r]
  LaplacianZ[3] = phiFunc_[2];
  LaplacinRT[3] = RT_[2]; // v_z
  RTMultiply::derivRVec(LaplacinRT[3]); // D[v_z, r]
  RTMultiply::multRVec(-1, LaplacinRT[3]); // 1/r*D[v_z, r]
}

double CylinderBasis3D::LaplacianDot(const CylinderBasis3D& other) const {
  double vx = 0, vy = 0, vz = 0;
  std::vector<RTMultiply> LaplacinRTX[6];
  BasicFunc LaplacianZX[6];
  other.LaplacianX(LaplacinRTX, LaplacianZX);
  // x component
  for (int i = 0; i < 6; i++) {
    double pINT = computePhiInt(phiFunc_[0], LaplacianZX[i]);
    if (pINT != 0) {
      double rtINT = 0;
      vector<RTMultiply> RTProd = RTMultiply::multV(RT_[0], LaplacinRTX[i]);
      for (const auto& rt1 : RTProd) {
        rtINT += computeRTMultInt(rt1);
      }
      vx += pINT*rtINT;
    }
  }

  std::vector<RTMultiply> LaplacinRTY[6];
  BasicFunc LaplacianZY[6];
  other.LaplacianY(LaplacinRTY, LaplacianZY);
  // y component
  for (int i = 0; i < 6; i++) {
    double pINT = computePhiInt(phiFunc_[1], LaplacianZY[i]);
    if (pINT != 0) {
      double rtINT = 0;
      vector<RTMultiply> RTProd = RTMultiply::multV(RT_[1], LaplacinRTY[i]);
      for (const auto& rt1 : RTProd)
        rtINT += computeRTMultInt(rt1);
      vy += pINT*rtINT;
    }
  }

  std::vector<RTMultiply> LaplacinRTZ[4];
  BasicFunc LaplacianZZ[4];
  other.LaplacianZ(LaplacinRTZ, LaplacianZZ);
  // z component
  for (int i = 0; i < 4; i++) {
    double pINT = computePhiInt(phiFunc_[2], LaplacianZZ[i]);
    if (pINT != 0) {
      double rtINT = 0;
      vector<RTMultiply> RTProd = RTMultiply::multV(RT_[2], LaplacinRTZ[i]);
      for (const auto& rt1 : RTProd)
        rtINT += computeRTMultInt(rt1);
      vz += pINT*rtINT;
    }
  }
  return vx + vy + vz;
}

double CylinderBasis3D::LaplacianDotScale(const CylinderBasis3D& other) const {
  return LaplacianDot(other)*scale3_;
}

// This also doesnt include norm
// a2 b3 - a3 b2
// a3 b1 - a1 b3
// a1 b2 - a2 b1
void CylinderBasis3D::crossProdPhi(const CylinderBasis3D& phiG, const CylinderBasis3D& phiH,
                                 vector<BasicFunc> (&crossPhi)[3][2]) {
  crossPhi[0][0] = BasicFunc::multiply(phiG.getPhiFunc(1), phiH.getPhiFunc(2));
  crossPhi[0][1] = BasicFunc::multiply(phiG.getPhiFunc(2), -phiH.getPhiFunc(1));
  crossPhi[1][0] = BasicFunc::multiply(phiG.getPhiFunc(2), phiH.getPhiFunc(0));
  crossPhi[1][1] = BasicFunc::multiply(phiG.getPhiFunc(0), -phiH.getPhiFunc(2));
  crossPhi[2][0] = BasicFunc::multiply(phiG.getPhiFunc(0), phiH.getPhiFunc(1));
  crossPhi[2][1] = BasicFunc::multiply(phiG.getPhiFunc(1), -phiH.getPhiFunc(0));
}

// This also doesnt include norm
// These doesnt include the sin(t) weight included in integral, the term is baked into curl.
// sign is in phi component.
// (crossPhi[0][0])*(crossRT[0][0]);
// 
void CylinderBasis3D::crossProdRT(const CylinderBasis3D& phiG, const CylinderBasis3D& phiH,
                                vector<RTMultiply> (&crossRT)[3][2]) {
  crossRT[0][0] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(2));
  crossRT[0][1] = RTMultiply::multV(phiG.getRT(2), phiH.getRT(1));
  crossRT[1][0] = RTMultiply::multV(phiG.getRT(2), phiH.getRT(0));
  crossRT[1][1] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(2));
  crossRT[2][0] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(1));
  crossRT[2][1] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(0));
}

double CylinderBasis3D::integrateCurlCross(const BasicFunc& curlP, const vector<BasicFunc>& crossP,
                                         const vector<RTMultiply>& curlRT, const vector<RTMultiply>& crossRT) {
  // first integrate along phi.
  // int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += computePhiInt(curlP, cp);
  if (fabs(phiInt) < 1e-14)
    return 0.0;

  // integrate along theta, without sin(t) term, because its already in curl.
  double rtInt = 0;
  vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  for (const auto& rt : RTProd) {
    double tInt = rt.integrateT2Pi();
    if (fabs(tInt) < 1e-14)  // prod is zero.
      continue;
    double rInt = rt.integrateR();
    rtInt += tInt*rInt;
  }
  return phiInt*rtInt;
}

double CylinderBasis3D::computeTensorEntry(const CylinderBasis3D& phiI, const CylinderBasis3D& phiG,
                                         const CylinderBasis3D& phiH) {
    // compute cross product.
  vector<BasicFunc> crossPhi[3][2];
  vector<RTMultiply> crossRT[3][2];
  crossProdPhi(phiG, phiH, crossPhi);
  crossProdRT(phiG, phiH, crossRT);

  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 2; ind++) {
    rVal += integrateCurlCross(phiI.getCurPhi(0,ind), crossPhi[0][0], phiI.getCurRT(0,ind), crossRT[0][0]);
    rVal += integrateCurlCross(phiI.getCurPhi(0,ind), crossPhi[0][1], phiI.getCurRT(0,ind), crossRT[0][1]);
  }

  // t component.
  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_t * {phi_g \times phi_h}_t d omega
  double tVal = 0;
  for (int ind = 0; ind < 2; ind++) {
    tVal += integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][0], phiI.getCurRT(1,ind), crossRT[1][0]);
    tVal += integrateCurlCross(phiI.getCurPhi(1,ind), crossPhi[1][1], phiI.getCurRT(1,ind), crossRT[1][1]);
  }

  // p component.
  double pVal = 0;
  for (int ind = 0; ind < 2; ind++) {
    pVal += integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][0], phiI.getCurRT(2,ind), crossRT[2][0]);
    pVal += integrateCurlCross(phiI.getCurPhi(2,ind), crossPhi[2][1], phiI.getCurRT(2,ind), crossRT[2][1]);
  }

  return (rVal + tVal + pVal)*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
}

double CylinderBasis3D::computeTensorEntryScale(const CylinderBasis3D& phiI, const CylinderBasis3D& phiG, const CylinderBasis3D& phiH, const double& scale3) {
  return computeTensorEntry(phiI, phiG, phiH)*scale3;
}

void CylinderBasis3D::writeToFile(std::ofstream& out) const {
  out.write(reinterpret_cast<const char *>(&k1x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k2x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k3x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&index_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&b_), sizeof(double));
  out.write(reinterpret_cast<const char *>(&isDirichletR_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&zBndCndIdx_), sizeof(int));
}

CylinderBasis3D* CylinderBasis3D::fromFile(std::ifstream& in) {
  int k1x2, k2x2, k3x2;
  int index_;
  double b;
  bool isDirichletR;
  int zBndCndIdx;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k3x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));
  in.read(reinterpret_cast<char *>(&b), sizeof(double));
  in.read(reinterpret_cast<char *>(&isDirichletR), sizeof(bool));
  in.read(reinterpret_cast<char *>(&zBndCndIdx), sizeof(int));

  return new CylinderBasis3D(k1x2, k2x2, k3x2, index_,
                  b, isDirichletR, zBndCndIdx);
}

void CylinderBasis3D::FillFields(FIELD_3D& rad, FIELD_3D& theta, FIELD_3D& z) const {
  double dx = 2.0 / rad.xRes();
  double dy = 2.0 / rad.yRes();
  CHECK(rad.xRes() == rad.yRes());
  //double dy = 2.0 / rad.yRes();

  for (int k = 0; k < rad.zRes(); k++)
    for (int j = 0; j < rad.yRes(); j++)
      for (int i = 0; i < rad.xRes(); i++) {
        // coordinate in physical space.
        Eigen::Vector3d pos(((double)(i) + 0.5)*dx - 1.0 , ((double)(j) + 0.5)*dx - 1.0,
                 ((double)(k) + 0.5)*dx);  // x, y, [-1, 1]^3, z > 0
        // parameter space.
        Eigen::Vector3d cylCord = Transform::Cylinderical::toCylinderical(pos, b_);
        rad(i,j,k) = cylCord[0];
        theta(i,j,k) = cylCord[1];
        z(i,j,k) = cylCord[2];
      }
}