#include <math.h>
#include <fstream>

#include <glog/logging.h>
#include "2D/VFIELD2D.h"

using namespace std;

VFIELD2D::VFIELD2D(const string& fname) {
  ifstream in(fname, ios::binary);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << fname;

  in.read(reinterpret_cast<char *>(&xRes), sizeof(int));
  in.read(reinterpret_cast<char *>(&yRes), sizeof(int));
  data = (VEC2F*) malloc(sizeof(VEC2F)*xRes*yRes);
  in.read(reinterpret_cast<char *>(data), sizeof(VEC2F)*xRes*yRes);
  in.close();
  totalcell = xRes*yRes;
}

VFIELD2D& VFIELD2D::operator=(const VFIELD2D& input) {
  if (input.getxRes() != xRes ||
      input.getyRes() != yRes)
  {
    free(data);
    xRes = input.getxRes();
    yRes = input.getyRes();
    totalcell = xRes*yRes;
    data = (VEC2F*) malloc(sizeof(VEC2F)*totalcell);
  }
  for(int i=0; i<totalcell; i++)
    { data[i] = input[i];}
  return *this;
}

//set every thing on border to zero
void VFIELD2D::set_zero_border() {
  int totals = xRes*yRes;

  for(int i = 0; i < xRes; i++) {
    // Bottom.
    data[i] = 0;
    // Top.
    data[i+ totals  - xRes ] = 0;
  }
  
  for(int j = 0; j < yRes; j++) {
    // Left.
    data[j*xRes] = 0;
    // Right.
    data[xRes - 1 + j*xRes] = 0.;
  }
}
// Set X to zero.
void VFIELD2D::SetZeroLeft() {
  for(int j = 0; j < yRes; j++) {
    // Left.
    data[j*xRes][0] = 0;
  }
}
// Set X to zero.
void VFIELD2D::SetZeroRight() {
  for(int j = 0; j < yRes; j++) {
    // Right.
    data[j*xRes - 1 + xRes][0] = 0;
  }
}
// Set Y to zero.
void VFIELD2D::SetZeroTop() {
  int total = xRes*yRes;
  for(int i = 0;i < xRes; i++) {
    // Top.
    data[i+total  -xRes][1] = 0.;
  }
}
// Set Y to zero.
void VFIELD2D::SetZeroBottom() {
  for(int i = 0; i < xRes; i++) {
    // Bottom.
    data[i][1] = 0;
  }
}

void VFIELD2D::SetZeroCiricle() {
  double invDX = 2.0 / xRes;
  double invDY = 2.0 / yRes;
  double inv2DX = sqrt(invDX*invDX + invDY*invDY);

  for (int j = 0; j < yRes; j++) {
    for (int i = 0; i < xRes; i++) {
      double x = (i + 0.5)*invDX - 1.0;
      double y = (j + 0.5)*invDY - 1.0;
      double r = x*x + y*y;
      if (r >= 0.95 + inv2DX) {
        data[i + j*xRes][0] = 0.0;
        data[i + j*xRes][1] = 0.0;
      } if (r >= 0.95 && r < 0.95 + inv2DX) {
        data[i + j*xRes][0] = 0.0;
        data[i + j*xRes][1] = 0.0;
      }
    }
  }
}

// Set neumann on the left.
void VFIELD2D::SetNeumannLeft() {
  for(int j = 0; j < yRes; j++) {
    // Left.
    data[j*xRes][0] = data[j*xRes + 2][0];
   }
}

void VFIELD2D::SetNeumannRight() {
  for(int j = 0; j < yRes; j++) {
    // Right.
    data[j*xRes - 1 + xRes][0] = data[j*xRes -1 + xRes - 2][0];
   }
}

void VFIELD2D::SetNeumannTop() {
  int total = xRes*yRes;
  for(int i = 0; i < xRes; i++) {
    // Top.
    data[i + total -xRes ][1] = data[i + total -xRes - 2*xRes][1];
  }
}

void VFIELD2D::SetNeumannBottom() {
  for(int i = 0; i < xRes; i++) {
    // Bottom.
    data[i][1] = data[i + 2*xRes][1];
  }
}

// Copy border to the left.
void VFIELD2D::CopyBorderLeft() {
  for(int j = 0; j < yRes; j++) {
    //Left.
    data[j*xRes][0] = data[j*xRes + 1][0];
  }
}

void VFIELD2D::CopyBorderRight() {
  for(int j = 0; j < yRes; j++) {
    //Right.
    data[j*xRes - 1 + xRes][0] = data[j*xRes -1 + xRes - 1][0];
  }
}

void VFIELD2D::CopyBorderTop() {
  int total = xRes*yRes;
  for(int i = 0; i < xRes; i++) {
    //Top.
    data[i + total -xRes ][1] = data[i + total -xRes - xRes][1];
  }
}

void VFIELD2D::CopyBorderBottom() {
  for(int i = 0; i < xRes; i++) {
    //Bottom.
    data[i][1] = data[i + xRes][1];
  }
}

void VFIELD2D::axpy(const Real alpha, const VFIELD2D& field) {
  for(int i=0;i<totalcell;i++)
    data[i] += alpha *  field[i];
}

void VFIELD2D::advectSphere(const Real dt, const VFIELD2D& velocity_field, FIELD2D& oldField, FIELD2D& newField,
                           VEC2 north, VEC2 south) {
  int nTheta = velocity_field.getyRes();
  int nPhi = velocity_field.getxRes();
  double dT = M_PI / nTheta;
  double dP = 2.0*M_PI/nPhi;

  // first deal with the pole.
  north = -north;
  Real uabs = sqrt(north*north);
  double t0d = uabs*dt*nTheta;

  int t0 = (int) t0d;
  Real t1w = t0d - (Real)t0;
  int t1 = (int) t0 + 1;
  if (t1 >= nTheta)
    t1 = nTheta - 1;

  double phi = atan2(north[1], north[0]);
  if (uabs < 1e-12)
    phi = 0;

  if (north[1] < 0)   // [0, 2pi]
    phi += 2*M_PI;

  // to grid pos
  phi *= 0.5*nPhi/M_PI;
  int p0 = (int)phi;
  Real p1w = phi - (Real)p0;
  int p1 = p0 + 1;
  if (p1 >= nPhi)  // periodic along phi
    p1 -= nPhi; 

  
  Real t0Dens = oldField(p0, t0)*(1.0 - p1w) + oldField(p1, t0)*p1w;
  Real t1Dens = oldField(p0, t1)*(1.0 - p1w) + oldField(p1, t1)*p1w;
  Real result = t0Dens*(1.0 - t1w) + t1Dens*t1w;
  for (int i  = 0; i < nPhi; i++) {
    newField(i, 0) = result;
  }
  //LOG(INFO) << "north "<< result;
  // south
  // south = - south;
  uabs = sqrt(south*south);
  t0d = (double)nTheta - uabs*dt*nTheta;
  t0 = (int)t0d;
  t0 = (t0 >= nTheta) ? nTheta - 1 : t0;

  t1w = t0d - (Real)t0;
  t1 = t0 + 1;
  if (t1 >= nTheta)
    t1 = nTheta - 1;
  phi = atan2(south[1], south[0]);
  if (uabs < 1e-12)
    phi = 0;

  if (south[1] < 0)  // [0, 2pi]
    phi += 2*M_PI;
  // to grid pos
  phi *= 0.5*nPhi/M_PI;

  p0 = (int)phi;
  p1w = phi - (Real)p0;
  p1 = p0 + 1;
  if (p1 >= nPhi)  // periodic along phi
    p1 -= nPhi;

  t0Dens = oldField(p0, t0)*(1.0 - p1w) + oldField(p1, t0)*p1w;
  t1Dens = oldField(p0, t1)*(1.0 - p1w) + oldField(p1, t1)*p1w;
  result = t0Dens*(1.0 - t1w) + t1Dens*t1w;
  //LOG(INFO) << "south "<< result;
  for (int i = 0; i < nPhi; i++) {
    newField(i, nTheta-1) = result;
  }

  // deal with other regions.
  for (int y = 1; y < nTheta - 1; y++) {
    double theta = ((double)y + 0.5)*dT;
    double ratio = 1.0 / sin(theta);

    for (int x = 0; x < nPhi; x++) {
      int index = x + y*nPhi;
      double theta = ((double)(y) -  velocity_field[index][0]*nTheta*dt)*dT;   // [0-1]
      // phi--x, theta--y component
      bool reflectPhi = false;
      if (theta < 0) {
        theta = -theta;
        reflectPhi = true;
      }
      if (theta > M_PI) {
        theta = 2.0*M_PI - theta;
        reflectPhi = true;
      }
      int t0 = (int)(theta/dT);
      int t1 = t0 + 1;
      if (t1 >= nTheta)
        t1 = nTheta - 1;

      double phi = ((double)(x) - velocity_field[index][1]*dt*nPhi*ratio)*dP;// - M_PI;  // [0, 2*pi]
     
      if (reflectPhi)
        phi += M_PI;
      // perioidc bc
      if (phi < 0)
        phi += 2*M_PI;
      else if (phi > 2*M_PI)
        phi -= 2*M_PI;
    
      if (phi > 2*M_PI)
        phi -= 2*M_PI;
      if (phi < 0)
        phi += 2*M_PI;
      
      int p0 = (int)(phi/dP);
      int p1 = p0 + 1;
      if (p1 >= nPhi)
        p1 -= nPhi;

      Real p1w = phi/dP - p0;
      Real t1w = theta/dT - t0;
      CHECK(p0 >= 0 && p0 < nPhi) << phi << " " << ratio << " " << theta << " " << sin(theta);
      CHECK(p1 >= 0 && p1 < nPhi) << p1;
      CHECK(t0 >= 0 && t0 < nTheta) << t0;
      CHECK(t1 >= 0 && t1 < nTheta) << t1;

      double t0Dens = oldField(p0, t0)*(1.0 - p1w) + oldField(p1, t0)*p1w;
      double t1Dens = oldField(p0, t1)*(1.0 - p1w) + oldField(p1, t1)*p1w;
      newField[index] = t0Dens*(1.0 - t1w) + t1Dens*t1w;
    }
  }

  double northCap = 0, southCap = 0;
  for (int j = 0; j < 5; j++) {
    for (int i = 0; i < nPhi; i++) {
      northCap += newField[i + j*nPhi];
      southCap += newField[i + (nTheta - j - 1)*nPhi];
    }
  }
  northCap /= 5*nPhi;
  southCap /= 5*nPhi;
  //LOG(INFO) << "ns " << northCap << " " << southCap;
  
}

void VFIELD2D::advect(const Real dt, const VFIELD2D& velocity_field,
                      const FIELD2D& oldField, FIELD2D& newField) {
  int yRes = velocity_field.getyRes();
  int xRes = velocity_field.getxRes();
  #pragma omp parallel for
  for(int y=0; y<yRes;y++) {
    for(int x=0; x<xRes;x++) {
      int index = x + y*xRes;
      bool outside_bc = false;
      const VEC2F velo = velocity_field[index];
      Real xTrace = x - velo[0]*dt;
      Real yTrace = y - velo[1]*dt;
      if (std::isnan(xTrace)) {
        xTrace = x;
      }
      if (std::isnan(yTrace)) {
        yTrace = y;
      }
      if (xTrace < 1.5 || xTrace > xRes - 2.5 || yTrace < 1.5 || yTrace > yRes - 2.5) {
        outside_bc = true;
      }
      xTrace = (xTrace < 1.5) ? 1.5 : xTrace;
      xTrace = (xTrace > xRes - 2.5) ? xRes - 2.5 : xTrace;
      yTrace = (yTrace < 1.5) ? 1.5 : yTrace;
      yTrace = (yTrace > yRes - 2.5) ? yRes - 2.5 : yTrace;
      const int x0 = (int)xTrace;
      const int x1 = x0 + 1;
      const int y0 = (int)yTrace;
      const int y1 = y0 + 1;
      //interpolate
      const Real s1 = xTrace - x0;
      const Real s0 = 1.0f - s1;
      const Real t1 = yTrace - y0;
      const Real t0 = 1.0f - t1;

      const int i000 = x0 + y0 * xRes;
      const int i010 = x0 + y1 * xRes;
      const int i100 = x1 + y0 * xRes;
      const int i110 = x1 + y1 * xRes;
//      if (!outside_bc) {
        newField[index] =  s0 * (t0 * oldField[i000] +
          t1 * oldField[i010]) +
          s1 * (t0 * oldField[i100] +
          t1 * oldField[i110]);
//      } else {
//        newField[index] = 0.;
//      }
    }
  }
}

void VFIELD2D::advect(const Real dt, const VFIELD2D& velocity_field,
                      const VFIELD2D& oldField, VFIELD2D& newField) {
  int yRes = velocity_field.getyRes();
  int xRes = velocity_field.getxRes();
  for(int y=0; y<yRes;y++) {
    for(int x=0; x<xRes;x++) {
      int index = x + y*xRes;
      const VEC2F velo = velocity_field[index];
      Real xTrace = x - velo[0]*dt;
      Real yTrace = y - velo[1]*dt;
      xTrace = (xTrace < 1.5) ? 1.5 : xTrace;
      xTrace = (xTrace > xRes - 2.5) ? xRes - 2.5 : xTrace;
      yTrace = (yTrace < 1.5) ? 1.5 : yTrace;
      yTrace = (yTrace > yRes - 2.5) ? yRes - 2.5 : yTrace;
      const int x0 = (int)xTrace;
      const int x1 = x0 + 1;
      const int y0 = (int)yTrace;
      const int y1 = y0 + 1;
      //interpolate
      const Real s1 = xTrace - x0;
      const Real s0 = 1.0f - s1;
      const Real t1 = yTrace - y0;
      const Real t0 = 1.0f - t1;

      const int i000 = x0 + y0 * xRes;
      const int i010 = x0 + y1 * xRes;
      const int i100 = x1 + y0 * xRes;
      const int i110 = x1 + y1 * xRes;

      newField[index] =  s0 * (t0 * oldField[i000] +
        t1 * oldField[i010]) +
        s1 * (t0 * oldField[i100] +
        t1 * oldField[i110]);
      }
  }
}
   
void VFIELD2D::advectMacCormack(const Real dt, const VFIELD2D& velocityGrid, FIELD2D& oldField, 
                              FIELD2D& newField, FIELD2D& temp1, FIELD2D& temp2) {
  
  FIELD2D& phiHatN  = temp1;
	FIELD2D& phiHatN1 = temp2;

	const int sx = oldField.getxRes();
	const int sy = oldField.getyRes();
  
	for (int x = 0; x < sx * sy; x++)
		phiHatN[x] = phiHatN1[x] = oldField[x];

	FIELD2D& phiN    = oldField;
	FIELD2D& phiN1   = newField;
  // phiHatN1 = A(phiN)
	advect(dt, velocityGrid, phiN, phiHatN1);

	// phiHatN = A^R(phiHatN1)
	advect(-1.0 * dt, velocityGrid, phiHatN1, phiHatN);
   
  // phiN1 = phiHatN1 + (phiN - phiHatN) / 2
	const int border = 0; 
		for (int y = border; y < sy - border; y++)
			for (int x = border; x < sx - border; x++) {
				int index = x + y * sx;
				phiN1[index] = phiHatN1[index] + (phiN[index] - phiHatN[index]) * 0.50f;
			}

  phiN1.copyBorderAll();
  // clamp any newly created extrema
	clampExtrema(dt, velocityGrid, oldField, newField);

	// if the error estimate was bad, revert to first order
	clampOutsideRays(dt, velocityGrid, oldField, phiHatN1, newField);
}

void VFIELD2D::advectMacCormack(const Real dt, const VFIELD2D& velocityGrid, VFIELD2D& oldField, 
                             VFIELD2D& newField, VFIELD2D& temp1, VFIELD2D& temp2) {
  VFIELD2D& phiHatN  = temp1;
  VFIELD2D& phiHatN1 = temp2;

  const int sx = oldField.getxRes();
  const int sy = oldField.getyRes();

  for (int x = 0; x < sx * sy; x++)
    phiHatN[x] = phiHatN1[x] = oldField[x];

  VFIELD2D& phiN    = oldField;
  VFIELD2D& phiN1   = newField;
  // phiHatN1 = A(phiN)
  advect(dt, velocityGrid, phiN, phiHatN1);

  // phiHatN = A^R(phiHatN1)
  advect(-1.0 * dt, velocityGrid, phiHatN1, phiHatN);

  // phiN1 = phiHatN1 + (phiN - phiHatN) / 2
  const int border = 0; 
    for (int y = border; y < sy - border; y++)
      for (int x = border; x < sx - border; x++) {
        int index = x + y * sx;
        phiN1[index] = phiHatN1[index] + (phiN[index] - phiHatN[index]) * 0.50f;
      }

  phiN1.copyBorderAll();
  // clamp any newly created extrema
  clampExtrema(dt, velocityGrid, oldField, newField);

  // if the error estimate was bad, revert to first order
  clampOutsideRays(dt, velocityGrid, oldField, phiHatN1, newField);
}

void VFIELD2D::clampExtrema(const Real dt, const VFIELD2D& velocityField, const FIELD2D& 
                  oldField, FIELD2D& newField) {
  const int xRes = velocityField.getxRes();
	const int yRes = velocityField.getyRes();
	// const int zRes = velocityField.zRes();
	// const int slabSize = velocityField.slabSize();
  #pragma omp parallel
  #pragma omp for schedule(static)
  for (int y = 1; y < yRes-1; y++)
    for (int x = 1; x < xRes-1; x++)
    {
      const int index = x + y * xRes;
				// backtrace
        const VEC2F velocity = velocityField[index];
        Real xTrace = x - dt * velocity[0];
        Real yTrace = y - dt * velocity[1];
        
				// clamp backtrace to grid boundaries
        xTrace = (xTrace < 0.5) ? 0.5 : xTrace;
        xTrace = (xTrace > xRes - 1.5) ? xRes - 1.5 : xTrace;
        yTrace = (yTrace < 0.5) ? 0.5 : yTrace;
        yTrace = (yTrace > yRes - 1.5) ? yRes - 1.5 : yTrace;
        
				// locate neighbors to interpolate
				const int x0 = (int)xTrace;
				const int x1 = x0 + 1;
				const int y0 = (int)yTrace;
				const int y1 = y0 + 1;
        
				const int i000 = x0 + y0 * xRes;
				const int i010 = x0 + y1 * xRes;
				const int i100 = x1 + y0 * xRes;
				const int i110 = x1 + y1 * xRes;


				Real minField = oldField[i000];
				Real maxField = oldField[i000];

				minField = (oldField[i010] < minField) ? oldField[i010] : minField;
				maxField = (oldField[i010] > maxField) ? oldField[i010] : maxField;

				minField = (oldField[i100] < minField) ? oldField[i100] : minField;
				maxField = (oldField[i100] > maxField) ? oldField[i100] : maxField;

				minField = (oldField[i110] < minField) ? oldField[i110] : minField;
				maxField = (oldField[i110] > maxField) ? oldField[i110] : maxField;

				newField[index] = (newField[index] > maxField) ? maxField : newField[index];
				newField[index] = (newField[index] < minField) ? minField : newField[index];
    }
}

void VFIELD2D::clampExtrema(const Real dt, const VFIELD2D& velocityField, const VFIELD2D& 
                                      oldField, VFIELD2D& newField) {
  const int xRes = velocityField.getxRes();
  const int yRes = velocityField.getyRes();
  // const int zRes = velocityField.zRes();
  // const int slabSize = velocityField.slabSize();
  #pragma omp parallel
  #pragma omp for schedule(static)
  for (int y = 1; y < yRes-1; y++)
    for (int x = 1; x < xRes-1; x++)
    {
      const int index = x + y * xRes;
        // backtrace
        const VEC2F velocity = velocityField[index];
        Real xTrace = x - dt * velocity[0];
        Real yTrace = y - dt * velocity[1];
    
        // clamp backtrace to grid boundaries
        xTrace = (xTrace < 0.5) ? 0.5 : xTrace;
        xTrace = (xTrace > xRes - 1.5) ? xRes - 1.5 : xTrace;
        yTrace = (yTrace < 0.5) ? 0.5 : yTrace;
        yTrace = (yTrace > yRes - 1.5) ? yRes - 1.5 : yTrace;
        
        // locate neighbors to interpolate
        const int x0 = (int)xTrace;
        const int x1 = x0 + 1;
        const int y0 = (int)yTrace;
        const int y1 = y0 + 1;

        const int i000 = x0 + y0 * xRes;
        const int i010 = x0 + y1 * xRes;
        const int i100 = x1 + y0 * xRes;
        const int i110 = x1 + y1 * xRes;

      for(int i = 0; i < 2; i++) {
        Real minField = oldField[i000][i];
        Real maxField = oldField[i000][i];

        minField = (oldField[i010][i] < minField) ? oldField[i010][i] : minField;
        maxField = (oldField[i010][i] > maxField) ? oldField[i010][i] : maxField;

        minField = (oldField[i100][i] < minField) ? oldField[i100][i] : minField;
        maxField = (oldField[i100][i] > maxField) ? oldField[i100][i] : maxField;

        minField = (oldField[i110][i] < minField) ? oldField[i110][i] : minField;
        maxField = (oldField[i110][i] > maxField) ? oldField[i110][i] : maxField;

        newField[index][i] = (newField[index][i] > maxField) ? maxField : newField[index][i];
        newField[index][i] = (newField[index][i] < minField) ? minField : newField[index][i];
      }
    }
}

void VFIELD2D::clampOutsideRays(const Real dt, const VFIELD2D& velocityField, const FIELD2D&  
                             oldField, const FIELD2D& oldAdvection, FIELD2D& newField) {
  const int sx = velocityField.getxRes();
	const int sy = velocityField.getyRes();
//	const int sz = velocityField.zRes();
//	const int slabSize = velocityField.slabSize();
  #pragma omp parallel
  #pragma omp for schedule(static)
  for (int y = 1; y < sy - 1; y++)
    for (int x = 1; x < sx - 1; x++)
    {
        const int index = x + y * sx;
				// backtrace
        VEC2F velocity = velocityField[index];
        velocity *= dt;
				float xBackward = x + velocity[0];
				float yBackward = y + velocity[1];
				
				float xTrace    = x - velocity[0];
				float yTrace    = y - velocity[1];
				
				// see if it goes outside the boundaries
				bool hasObstacle = 
					(yTrace < 1.0f)    || (yTrace > sy - 2.0f) ||
					(xTrace < 1.0f)    || (xTrace > sx - 2.0f) ||
					(yBackward < 1.0f) || (yBackward > sy - 2.0f) ||
					(xBackward < 1.0f) || (xBackward > sx - 2.0f);

				// reuse old advection instead of doing another one...
				if(hasObstacle) { newField[index] = oldAdvection[index]; }
      
    }
}

void VFIELD2D::clampOutsideRays(const Real dt, const VFIELD2D& velocityField, const VFIELD2D&  
                                    oldField, const VFIELD2D& oldAdvection, VFIELD2D& newField) {
  const int sx = velocityField.getxRes();
  const int sy = velocityField.getyRes();
//  const int sz = velocityField.zRes();
//  const int slabSize = velocityField.slabSize();
  #pragma omp parallel
  #pragma omp for schedule(static)
  for (int y = 1; y < sy - 1; y++)
    for (int x = 1; x < sx - 1; x++)
    {
        const int index = x + y * sx;
        // backtrace
        VEC2F velocity = velocityField[index];
        velocity *= dt;
        float xBackward = x + velocity[0];
        float yBackward = y + velocity[1];
        
        float xTrace    = x - velocity[0];
        float yTrace    = y - velocity[1];
        
        // see if it goes outside the boundaries
        bool hasObstacle = 
          (yTrace < 1.0f)    || (yTrace > sy - 2.0f) ||
          (xTrace < 1.0f)    || (xTrace > sx - 2.0f) ||
          (yBackward < 1.0f) || (yBackward > sy - 2.0f) ||
          (xBackward < 1.0f) || (xBackward > sx - 2.0f);

        // reuse old advection instead of doing another one...
        if(hasObstacle) { newField[index] = oldAdvection[index]; }
      
    }
}

void VFIELD2D::swapPointer( VFIELD2D& field) {
  VEC2F* temp = data;
  data = field.data;
  field.data = temp;
}

void VFIELD2D::clear() {
  for(int i=0;i<totalcell;i++)
    data[i] = 0;
}

void VFIELD2D::SaveVelocity(FILE* out) const {
  fwrite(data, sizeof(VEC2F),totalcell,out); 
}

void VFIELD2D::SaveVelocity(const string& fname) const {
  ofstream out(fname, ios::binary);
  // write resolution
  out.write(reinterpret_cast<const char *>(&xRes), sizeof(int));
  out.write(reinterpret_cast<const char *>(&yRes), sizeof(int));
  out.write(reinterpret_cast<const char *>(data), sizeof(VEC2F)*totalcell);
  out.close();
}

void VFIELD2D::SaveMagnitude(const string& fname) const {
  ofstream out(fname, ios::binary);
  // write resolution
  out.write(reinterpret_cast<const char *>(&xRes), sizeof(int));
  out.write(reinterpret_cast<const char *>(&yRes), sizeof(int));
  for (int i = 0; i < totalcell; i++) {
    double mag = data[i]*data[i];
    out.write(reinterpret_cast<const char *>(&mag), sizeof(double));
  }
  out.close();
}

void VFIELD2D::LoadVelocity(const string& fname) {
  ifstream in(fname, ios::binary);
  if (! in.is_open())
    LOG(FATAL) << "cannot open: " << fname;
  int x, y;
  in.read(reinterpret_cast<char *>(&x), sizeof(int));
  in.read(reinterpret_cast<char *>(&y), sizeof(int));
  if (x != xRes || y != yRes)
    LOG(FATAL) << "resolution mismatch.";
  in.read(reinterpret_cast<char *>(&data), sizeof(VEC2F)*totalcell);
  in.close();
}

void VFIELD2D::Draw(float magnitute) {
  LOG(FATAL) << "deprecated";
}

void VFIELD2D::Draw_X(float magnitute, int mode) {
  LOG(FATAL) << "deprecated";
}

double VFIELD2D::GetEnergy() {
  double result = 0;
  int index = 0;
  for (int j = 0; j < yRes; j++) {
    for (int i = 0; i < xRes; i++) {
      result += data[index][0] * data[index][0];
      result += data[index][1] * data[index][1];
      index++;
    }
  }
  return result/(totalcell);
}

double VFIELD2D::GetMaximumVelocity() {
  double result = -1.0;
  int index = 0;
  for (int j = 0; j < yRes; j++) {
    for (int i = 0; i < xRes; i++) {
      double temp = data[index][0] * data[index][0] + data[index][1] * data[index][1];
      if (temp > result) {
        result = temp;
      }
      index++;
    }
  }
  return sqrt(result);
}

VEC2 VFIELD2D::GetVelocity(const float pos_x, const float pos_y) const {

  int x0 = (int)pos_x;
  int x1 = x0 + 1;
  int y0 = (int)pos_y;
  int y1 = y0 + 1;
  
  // clamp everything
  x0 = (x0 < 0) ? 0 : x0;
  y0 = (y0 < 0) ? 0 : y0;
  x1 = (x1 < 0) ? 0 : x1;
  y1 = (y1 < 0) ? 0 : y1;
  
  x0 = (x0 > xRes - 1) ? xRes - 1 : x0;
  y0 = (y0 > yRes - 1) ? yRes - 1 : y0;
  x1 = (x1 > xRes - 1) ? xRes - 1 : x1;
  y1 = (y1 > yRes - 1) ? yRes - 1 : y1;
  
  //interpolate
  const Real s1 = pos_x - x0;
  const Real s0 = 1.0f - s1;
  const Real t1 = pos_y - y0;
  const Real t0 = 1.0f - t1;

  const int i00 = x0 + y0 * xRes;
  const int i01 = x0 + y1 * xRes;
  const int i10 = x1 + y0 * xRes;
  const int i11 = x1 + y1 * xRes;
  
  return s0 * (t0 * data[i00] +
    t1 * data[i01]) +
    s1 * (t0 * data[i10] +
    t1 * data[i11]);
}

void VFIELD2D::AddVelocity(const float pos_x, const float pos_y, const VEC2& v, int* cntGrid) const {
  int x0 = (int)pos_x;
  int x1 = x0 + 1;
  int y0 = (int)pos_y;
  int y1 = y0 + 1;
  
  // clamp everything
  x0 = (x0 < 0) ? 0 : x0;
  y0 = (y0 < 0) ? 0 : y0;
  x1 = (x1 < 0) ? 0 : x1;
  y1 = (y1 < 0) ? 0 : y1;
  
  x0 = (x0 > xRes - 1) ? xRes - 1 : x0;
  y0 = (y0 > yRes - 1) ? yRes - 1 : y0;
  x1 = (x1 > xRes - 1) ? xRes - 1 : x1;
  y1 = (y1 > yRes - 1) ? yRes - 1 : y1;
  
  //interpolate
  const Real s1 = pos_x - x0;
  const Real s0 = 1.0f - s1;
  const Real t1 = pos_y - y0;
  const Real t0 = 1.0f - t1;

  const int i000 = x0 + y0 * xRes;
  const int i010 = x0 + y1 * xRes;
  const int i100 = x1 + y0 * xRes;
  const int i110 = x1 + y1 * xRes;
  cntGrid[i000] ++;
  cntGrid[i010] ++;
  cntGrid[i100] ++;
  cntGrid[i110] ++;
  
  data[i000] += s0*t0*v;
  data[i010] += s0*t1*v;
  data[i100] += s1*t0*v;
  data[i110] += s1*t1*v;
}

double VFIELD2D::DotProduct(const VFIELD2D& b) {
  double result = 0;
  for (int i = 0; i < totalcell; i++) {
    result += data[i][0] * b[i][0] + data[i][1] * b[i][1];
  }
  
  return result;
}

void VFIELD2D::copyBorderAll() {

  for(int i = 0; i < xRes; i++) {
    data[i] = data[i + xRes];
    data[i + totalcell -xRes] = data[i+totalcell -2*xRes];
  }
  
  for(int j = 0; j < yRes; j++) {
    data[j*xRes] = data[j*xRes + 1];
    data[j*xRes + xRes - 1] = data[j*xRes + xRes -2];
  }
}

void VFIELD2D::checkValue() {
  for (int i = 0; i < totalcell; i++)
    CHECK(std::isfinite(data[i][0]) && std::isfinite(data[i][1])) << "x: " << i%xRes << " y: " << i/xRes;
}

void VFIELD2D::checkDivergence() {
  double maxVal = -1;
  const double dx = 1.0 / max(xRes, yRes);

  int index = xRes + 1;
  int x,y;
  for (y = 1; y < yRes - 1; y++, index += 2) {
    for (x = 1; x < xRes - 1; x++, index++) {
      
      Real xright = data[index + 1][0];
      Real xleft  = data[index - 1][0];
      Real yup    = data[index + xRes][1];
      Real ydown  = data[index - xRes][1];

      maxVal = max(maxVal,
        xright - xleft +
        yup - ydown);
    }
  }

  LOG(INFO) << "maxDiv: " << maxVal;
}