use strict;
use warnings;
use Time::HiRes;
my $BIN_PATH = "bin/output_tensor_entry_historgram";

my $basis_tensor_fname = "--basis_tensor_fname="."./Tensor/T3DType2Dim1010X128Y64Z64PX";
my $historgram_file = "--historgram_file=./hist_T2_1010.txt";
#all_dirichlet, one_neumann, two_neumann_x, four_neumann_xz, six_neumann
my $basis_type = "--basis_type=two_neumann_x";
#principle_x, principle_y. principle_z, random, uniform
my $constant_init_strategy = "principle_x";



system($BIN_PATH." ".$basis_tensor_fname." ".$basis_type." ".$constant_init_strategy." ".
	   $historgram_file." --logtostderr");