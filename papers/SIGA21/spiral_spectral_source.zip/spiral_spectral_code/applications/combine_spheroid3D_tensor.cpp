#include <algorithm>
#include <Eigen/Eigen>
#include <experimental/filesystem>
#include <fstream>
#include <glog/logging.h>
#include <string>
#include <sstream>
#include <math.h>
#include <memory>

#include "common/basis_set.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/sphere_basis_set_3D.h"
#include "sphere_3D/cylinder_basis_set_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"

#include "setting.h"
#include "util/util.h"
#include "util/read_write_tensor.h"
#include "util/timer.h"

using namespace Eigen;
using namespace std;

DEFINE_string(basis_type, "sphere_3d_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");

DEFINE_string(Tensor_file,"", "The folder to put the tensor, with slash.");
DEFINE_double(b, 0.9, "The shorter axis.");
DEFINE_double(majorA, 3.0, "The major axis");
DEFINE_bool(computeBasisOnly, false, "only compute the basis without tensor");
DEFINE_string(basis_file, "", "The basis file without tensor info.");

int main(int argc, char ** argv){
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);
  
  bool is_prolate = false, is_oblate = false;

  if (FLAGS_basis_type == "prolate_3d")
    is_prolate = true;
  else if (FLAGS_basis_type == "oblate_3d")
    is_oblate = true;
  else if (FLAGS_basis_type == "sphere_3d")
    ;
  else 
    LOG(FATAL) << "unknown type: " << FLAGS_basis_type;

  const int xRes = 64;
 
  std::unique_ptr<SphereBasisSet3D> basis;
  if (FLAGS_basis_file.size() != 0) {
    ifstream in(FLAGS_basis_file);
    if (! in.is_open())
      LOG(FATAL) << "cannot open " << FLAGS_basis_file;
    basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, in));
  }
  CHECK(FLAGS_Tensor_file.size() != 0);
  std::vector<std::string> fileNames;

  for (const auto& entry : experimental::filesystem::directory_iterator(FLAGS_Tensor_file))
    fileNames.push_back(entry.path());
  std::sort(fileNames.begin(), fileNames.end());
  const int numBasisAll = basis->numBasisAll();
  
  vector<Adv_Tensor_Type> Adv_tensor_;
  Adv_tensor_.reserve(numBasisAll);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll; i++) {
    Adv_Tensor_Type Ck(numBasisAll, numBasisAll);
    Ck.setZero();
    Adv_tensor_.emplace_back(Ck);
  }
  
  int numSlice = 0;

  for (const auto& fileName : fileNames) {
    LOG(INFO) << fileName;
    int iStart, iEnd;
    ifstream in(fileName, std::ios::binary);
    in.read(reinterpret_cast<char*>(&iStart), sizeof(int));
    in.read(reinterpret_cast<char*>(&iEnd), sizeof(int));
    // void ReadTensorSlice(std::ifstream& infile, Adv_Tensor_Type& slice);
    for (int i = iStart; i < iEnd; i++)
      ReadTensorSlice(in, Adv_tensor_[i]);
    numSlice += (iEnd - iStart);
  }
  CHECK(numSlice == numBasisAll);

  std::string file_name = fileNames[0];
  while(file_name.back() != '_')
    file_name.pop_back();
  file_name.pop_back();
  while(file_name.back() != '_')
    file_name.pop_back();
  file_name.pop_back();

  LOG(INFO) << "Writting tensor to file: " << file_name;
  ofstream out(file_name, std::ios::binary);
  basis->writeToFile(out, Adv_tensor_);
  out.close();
  
  return 0;
}
