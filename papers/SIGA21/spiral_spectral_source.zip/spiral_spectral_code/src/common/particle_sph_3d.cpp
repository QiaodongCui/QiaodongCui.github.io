#include <Eigen/Eigen>
#include <fstream>
#include <random>

#include "common/particle_sph_3d.h"
#include "polar_2D/torus_basis_2D.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "util/transform.h"
#include "util/util.h"
#include "util/timer.h"

using namespace std;

// seed nparticles with rad distance around the seed particle.
void ParticleSystem::seedSphere(const int nParticle, const float rad, default_random_engine &gen, std::vector<ParaParticle3Df>& pVec) {
	const Eigen::Vector3f& center = seedParticle_.position_;
	uniform_real_distribution<float> u(0., 1.);
	for (int i = 0; i < nParticle; i++) {
		Eigen::Vector3f pos = sampleOnSpheref(gen);
		pos *= pow(u(gen), 1/3.0); // [-1, 1]^3
		pos *= rad; // [-rad, rad]^3, center 0.
		pos += center;
		ParaParticle3Df pttl(pos, 1.0);
		pVec.push_back(pttl);
	}
}

void ParticleSystem::resetAtSeed(ParaParticle3Df& ptl, const float rad, default_random_engine& gen) {
	const Eigen::Vector3f& center = seedParticle_.position_;
	uniform_real_distribution<float> u(0., 1.);
	Eigen::Vector3f pos = sampleOnSpheref(gen);
	pos *= pow(u(gen), 1/3.0); // [-1, 1]^3
	pos *= rad; // [-rad, rad]^3, center 0.
	pos += center;
	ptl.position_ = pos;
	ptl.weight_ = 1.0;
	ptl.life_ = 1.0;
}

#define setRing \
float r = u(gen)*0.1;\
float t = u(gen)*2.0*M_PI;\
float p = u(gen)*2.0*M_PI;\
Eigen::Vector3f cat = Transform::Torodial::toCartesian(Eigen::Vector3f(r,t,p), a_);\
cat *= scale;

void ParticleSystem::seedRing(const int nParticle, const double a_, const double scale, default_random_engine &gen,
	std::vector<ParaParticle3Df>& pVec) {

  uniform_real_distribution<double> u(0., 1.);
  for (int i = 0; i < nParticle; i++) {
		setRing;
		ParaParticle3Df pttl(cat, 1.0);
   	pVec.push_back(pttl);
  }
}

void ParticleSystem::resetAtRing(ParaParticle3Df& ptl, const double a_, const double scale, default_random_engine &gen) {
  	uniform_real_distribution<double> u(0., 1.);
		setRing;
    ptl.position_ = cat;
		ptl.weight_ = 1.0;
		ptl.life_ = 1.0;
}

#define setCylinder \
double px = u(gen);\
double py = u(gen);\
double pz = u(gen);\
double r = sqrtf(px)*rad;\
double t = 2.0*M_PI*py;\
Eigen::Vector3f cat(r*sin(t), r*cos(t),-pz*h/scale + 1.0/scale);\
cat *= scale;

void ParticleSystem::seedCylinder(const int nParticle, const double rad, const double h, 	
																	const double scale, const bool random, std::default_random_engine &gen,
																	std::vector<ParaParticle3Df>& pVec) {
  uniform_real_distribution<double> u(0., 1.);
  for (int i = 0; i < nParticle; i++) {
		setCylinder;
		ParaParticle3Df pttl(cat, 1.0);
		if (random)
			pttl.life_ = u(gen);
    pVec.push_back(pttl);
  }
}

void ParticleSystem::resetAtCylinder(ParaParticle3Df& ptl, const double rad, const double h, const double scale,
																	 std::default_random_engine &gen) {
	uniform_real_distribution<double> u(0., 1.);
	setCylinder;
	ptl.position_ = cat;
	ptl.weight_ = 1.0;
	ptl.life_ = 1.0;
}

void ParticleSystem::seedCylinderColor(const int nParticle, const double rad, const double h, const double scale,
                       const bool random, std::default_random_engine &gen, const ColorMap& cmap, std::vector<ParaParticle3Df>& pVec,
                       std::vector<Eigen::Vector3f>& colorF) {
  uniform_real_distribution<double> u(0., 1.);
  for (int i = 0; i < nParticle; i++) {
		setCylinder;
		ParaParticle3Df pttl(cat, 1.0);
		if (random)
			pttl.life_ = u(gen);
    pVec.push_back(pttl);
    colorF.push_back(cmap.getColor(py));
  }
}

void ParticleSystem::resetAtCylinderColor(ParaParticle3Df& ptl, Eigen::Vector3f& colorF, const ColorMap& cmap,
              const double rad, const double h, const double scale, std::default_random_engine &gen) {
	uniform_real_distribution<double> u(0., 1.);
	setCylinder;
	ptl.position_ = cat;
	ptl.weight_ = 1.0;
	ptl.life_ = 1.0;
	colorF = cmap.getColor(py);
}

#define setDome \
float dist = 100.f;\
float r,t,z,rRnd;\
while(dist > 0.96) {\
	rRnd = sqrt(u(gen));\
	r = rRnd*sin(tmax);\
	t = u(gen)*2.f*M_PI;\
	z = u(gen)*(cos(tmin) - cos(tmax)) + cos(tmax);\
	dist = r*r + z*z;\
}\
Eigen::Vector3f cat(r*cos(t), r*sin(t), z);\

void ParticleSystem::seedDome(const int nParticle, const float tmin, const float tmax, 
															std::default_random_engine &gen, const bool random, std::vector<ParaParticle3Df>& pVec) {
	uniform_real_distribution<float> u(0., 1.0);
	
	for (int i = 0; i < nParticle; i++) {
		setDome;
		ParaParticle3Df pttl(cat, 1.0);
		if (random)
			pttl.life_ = u(gen);
    pVec.push_back(pttl);
  }
}

void ParticleSystem::seedDomeColor(const int nParticle, const float tmin, const float tmax,
                       std::default_random_engine &gen, const bool random, std::vector<ParaParticle3Df>& pVec,
                       std::vector<Eigen::Vector3f>& colorF) {
	uniform_real_distribution<float> u(0., 1.0);
	
	for (int i = 0; i < nParticle; i++) {
		setDome;
		ParaParticle3Df pttl(cat, 1.0);
		Eigen::Vector3f hsv(t/M_PI/2.f, 1.f, 1.f);
		Eigen::Vector3f rgb = hsv2rgb(hsv);
		colorF.push_back(rgb);
		if (random)
			pttl.life_ = u(gen);
    pVec.push_back(pttl);
  }
}

void ParticleSystem::seedDomeRing(const int nParticle, const float tmin, const float tmax, const float zmin, 
																	const float zmax, const float a, const float scale,
                         					std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec) {
	uniform_real_distribution<float> u(0., 1.0);
	for (int i = 0; i < nParticle; i++) {
		float p = u(gen)*2.0*M_PI;
		float ua = ((u(gen)) - (u(gen)))*0.5 + 0.5;
		float t = ua*(tmax - tmin) + tmin;
		float z = u(gen)*(zmax - zmin) + zmin;
		Eigen::Vector3f cat((sin(t) + a)*cos(p), (sin(t) + a)*sin(p), z);
		cat *= scale;
		ParaParticle3Df pttl(cat, 1.0);
    pVec.push_back(pttl);
  }
}

void ParticleSystem::resetDome(ParaParticle3Df& ptl, const float tmin, const float tmax,
                   						const bool random, std::default_random_engine &gen) {
	uniform_real_distribution<float> u(0., 1.0);
	setDome;
	ptl.position_ = cat;
	ptl.weight_ = 1.0;
	if (random)
		ptl.life_ = u(gen);
	else
		ptl.life_ = 1.0;
}
  
void ParticleSystem::resetDomeColor(ParaParticle3Df& ptl, Eigen::Vector3f& colorF, const float tmin, const float tmax,
                           const bool random, std::default_random_engine &gen) {
	uniform_real_distribution<float> u(0., 1.0);
	setDome;
	ptl.position_ = cat;
	ptl.weight_ = 1.0;
	Eigen::Vector3f hsv(t/M_PI/2.f, 1.f, 1.f);
	colorF = hsv2rgb(hsv);
	if (random)
		ptl.life_ = u(gen);
	else
		ptl.life_ = 1.0;
}

void ParticleSystem::seedSphPatch(const int nParticle, const float rmin, const float rmax, const float tmin, const float tmax,
                   const float pmin, const float pmax, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec) {
	// get theta, phi.
	std::vector<Eigen::Vector2f> tps;
	sampleSpherePatch(nParticle, tmin, tmax, pmin, pmax, gen, tps);
	uniform_real_distribution<float> u(rmin, rmax);

	for (int i = 0; i < nParticle; i++) {
		float r = u(gen);
		Eigen::Vector3f cat(r*sin(tps[i][0])*cos(tps[i][1]), r*sin(tps[i][0])*sin(tps[i][1]), r*cos(tps[i][0]));
		ParaParticle3Df pttl(cat, 1.0);
    pVec.push_back(pttl);
  }
}

void ParticleSystem::resetSphPatch(ParaParticle3Df& ptl, const float rmin, const float rmax, const float tmin, const float tmax,
																	 const float pmin, const float pmax, std::default_random_engine &gen) {
 	float u1min = 0.5f - 0.5f*cos(tmin);
  float u1max = 0.5f - 0.5f*cos(tmax);

  uniform_real_distribution<float> u(0.f, 1.f);

  float rnd1 = u1min + (u1max - u1min)*u(gen);
  // theta, in radian
  float t = acos(1.0 - 2.0*rnd1);
    // phi
  float p = pmin + (pmax - pmin)*u(gen);
  float r = rmin + (rmax - rmin)*u(gen);
  ptl.position_[0] = r*sin(t)*cos(p);
  ptl.position_[1] = r*sin(t)*sin(p);
  ptl.position_[2] = r*cos(t);
 	
 	ptl.weight_ = 1.0;
	ptl.life_ = 1.0;
}

void ParticleSystem::resetIntoSphere(ParaParticle3Df& ptl, std::default_random_engine &gen) {
	Eigen::Vector3f sphCord = Transform::Spherical::toSpherical(ptl.position_);
	sphCord[0] *= 0.95;
	ptl.position_ = Transform::Spherical::toCartesian(sphCord);
	ptl.life_ = 1.0;
}

void ParticleSystem::seedCube(const int nParticle, const float xL, const float yL, const float zL,
                              std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec) {

	uniform_real_distribution<float> u1(-xL/2, xL/2);
	uniform_real_distribution<float> u2(-yL/2, yL/2);
	uniform_real_distribution<float> u3(-zL/2, zL/2);
	for (int i = 0; i < nParticle; i++) {
		Eigen::Vector3f cat = seedParticle_.position_;
		cat += Eigen::Vector3f(u1(gen), u2(gen), u3(gen));
		ParaParticle3Df pttl(cat, 1.0);
    pVec.push_back(pttl);
  }
}

void ParticleSystem::seedCubeColor(const int nParticle, const float xL, const float yL, const float zL,
                              std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec, 
                              std::vector<Eigen::Vector3f>& colorF) {

	uniform_real_distribution<float> u1(-xL/2, xL/2);
	uniform_real_distribution<float> u2(-yL/2, yL/2);
	uniform_real_distribution<float> u3(-zL/2, zL/2);
	for (int i = 0; i < nParticle; i++) {
		float yp = u2(gen);
		float zp = u3(gen);
		float xp = -u1(gen);

		Eigen::Vector3f cat = seedParticle_.position_;
		cat += Eigen::Vector3f(xp, yp, zp);
		ParaParticle3Df pttl(cat, 1.0);
    pVec.push_back(pttl);
    Eigen::Vector3f hsv(zp/zL + 0.5, 1.f, 1.f);
		Eigen::Vector3f rgb = hsv2rgb(hsv);
		colorF.push_back(rgb);
  }
}

void ParticleSystem::samplesSurface(const int x, const int y, const int width, const int height, 
                                    const int nTheta_, const int nPhi_, const int maxParticlePerCell, 
                                    std::default_random_engine &gen,
                                    std::vector<ParaParticle3Df>& densityParticles) {
	int startx = x - width / 2;
  int starty = y - height / 2;
  int endx = x + width / 2;
  int endy = y + height / 2;
  startx = startx < 0 ? 0 : startx;
  starty = starty < 0 ? 0 : starty;
  endx = endx >= nPhi_ ? nPhi_-1 : endx;
  endy = endy >= nTheta_ ? nTheta_ -1 : endy;
  
  double dTheta_ = M_PI / nTheta_;
  double dPhi_ = 2.0*M_PI / nPhi_;

  double tmim = starty*dTheta_;
  double tmax = endy*dTheta_;
  double pmin = startx*dPhi_;
  double pmax = endx*dPhi_;
  double areaSample = computeSpherePatchArea(tmim, tmax, pmin, pmax);
  // over sample a bit.
  int numWant = ceil(areaSample/dTheta_/dPhi_*maxParticlePerCell*1.2);

  std::vector<VEC2> samples;

  sampleSpherePatch(numWant, tmim, tmax, pmin, pmax, gen, samples);

  for (int i = 0; i < numWant; i++) {
    float theta = (float)samples[i][0];
    float phi = (float)samples[i][1];

    ParaParticle3Df newP(Eigen::Vector3f(sin(theta)*cos(phi), sin(theta)*sin(phi), cos(theta)));
    densityParticles.push_back(newP);
  }
}
  
void ParticleSystem::seedSurface(const int nParticle, const float tmin, const float tmax, const float pmin, const float pmax, 
                        const bool random, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec) {
	
	std::vector<Eigen::Vector2f> samples;
  sampleSpherePatch(nParticle, tmin, tmax, pmin, pmax, gen, samples);
  uniform_real_distribution<float> u(0.f, 1.f);
	for (int i = 0; i < nParticle; i++) {
    float theta = (float)samples[i][0];
    float phi = (float)samples[i][1];

    ParaParticle3Df newP(Eigen::Vector3f(sin(theta)*cos(phi), sin(theta)*sin(phi), cos(theta)));
    if (random)
    	newP.weight_ = u(gen);
    pVec.push_back(newP);
  }
}

void ParticleSystem::seedSurface(const int nParticle, const bool random, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec) {
	uniform_real_distribution<float> u(0.f, 1.f);
	
	for (int i = 0; i < nParticle; i++) {
    Eigen::Vector3d pos = sampleOnSphere(gen);
    ParaParticle3Df newP(Eigen::Vector3f(pos[0], pos[1], pos[2]));
    if (random)
    	newP.weight_ = u(gen);
    pVec.push_back(newP);
  }
}

void ParticleSystem::resetSurface(ParaParticle3Df& ptl, const float tmin, const float tmax, const float pmin, const float pmax, 
                        const bool random, std::default_random_engine &gen) {
	float u1min = 0.5 - 0.5*cos(tmin);
  float u1max = 0.5 - 0.5*cos(tmax);

  uniform_real_distribution<float> u1(u1min, u1max);
  uniform_real_distribution<float> u2(0.f, 1.f);
  float rnd1 = u1(gen);
  // theta, in radian
  float t = acos(1.0 - 2.0*rnd1);
  // phi
  float p = u2(gen)*(pmax - pmin) + pmin;

  ptl.position_ << sin(t)*cos(p), sin(t)*sin(p), cos(t);
 	
 	ptl.weight_ = 1.0;
 	if (random)
 		ptl.weight_ = u2(gen);
 	else
		ptl.weight_ = 1.0;
}

void ParticleSystem::seedTorusSurf(const int nParticle, const float tmin, const float tmax, const float pmin, const float pmax,
																	 const double a_, const float scale, 
                                   const bool random, std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec,
                                   std::vector<Eigen::Vector3f>& colorF) {
	uniform_real_distribution<float> u1(tmin, tmax);
  uniform_real_distribution<float> u2(pmin, pmax);
	uniform_real_distribution<float> u3(0.f, 1.f);
  for (int i = 0; i < nParticle; i++) {
    Eigen::Vector3f torCord(1, u1(gen), u2(gen));
    Eigen::Vector3f catCord = Transform::Torodial::toCartesian(torCord, a_)*scale;
    // [0-1]
    Eigen::Vector3f hsv(torCord[2]/M_PI*0.5f, 1.f, 1.f);
		colorF.push_back(hsv2rgb(hsv));
    ParaParticle3Df newP(catCord);
    if (random)
    	newP.weight_ = u3(gen);
    pVec.push_back(newP);
  }
}

#define random_sampleTorus \
while (w > (a_ + sin(t))/(a_ + 1.0)) {\
	w = u(gen);\
	t = u1(gen)*2.f*M_PI;\
	p = u2(gen)*2.f*M_PI;\
}

void ParticleSystem::seedTorusSurf(const int nParticle, const double a_, const float scale, const bool random,
                          std::default_random_engine &gen, std::vector<ParaParticle3Df>& pVec, const ColorMap& cmap,
                          std::vector<Eigen::Vector3f>& colorF) {
	
	uniform_real_distribution<float> u(0.f, 1.f);
	uniform_real_distribution<float> u1(0.f, 1.f);
	uniform_real_distribution<float> u2(0.f, 1.f);
	
	for (int i = 0; i < nParticle; i++) {
		float t = 0.f, p = 0.f, w = 100.f;
		random_sampleTorus;
		Eigen::Vector3f torCord(1.f, t, p);
    Eigen::Vector3f catCord = Transform::Torodial::toCartesian(torCord, a_)*scale;
    int perd = int(torCord[1]/M_PI*0.5*256); //[0, 255]
    perd = (perd*6) % 256;
    // [0-1]
    Eigen::Vector3f hsv(float(perd)/256.0, 1.f, 1.f);
		colorF.push_back(hsv2rgb(hsv));
		//colorF.push_back(cmap.getColor(float(perd)/256.0));
    ParaParticle3Df newP(catCord);
    if (random)
    	newP.weight_ = u(gen);
    pVec.push_back(newP);
	}
}

void ParticleSystem::saveParticleLocation(const std::string& fname, const uint64_t numToSave) {
	std::ofstream out(fname);
	if (! out.is_open()) {
		LOG(FATAL) << "cannot open " << fname;
	}
	uint64_t totalSize = 0;
	for (int i = 0; i < particles_.size(); i++) {
		totalSize += particles_[i].size();
	}
	for (int i = 0; i < particles_.size(); i++) {
		uint64_t curSave = ceil((double)(particles_[i].size())/(double)(totalSize)*numToSave);
		for (uint64_t idx = 0; idx < curSave && idx < particles_[i].size(); idx ++) {
			Eigen::Vector3f poss = particles_[i][idx].position_;
			poss[2] = -poss[2];
			out.write(reinterpret_cast<const char*>(poss.data()), sizeof(Eigen::Vector3f));
		}
	}
	out.close();
}