#ifndef TRAPEZOIDALC_H
#define TRAPEZOIDALC_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>

#include "setting.h"
// Trapezoidal update rule for complex coefficients of Fourier series
// simulation.

class TrapezoidalC {
public:
  TrapezoidalC(){};
  ~TrapezoidalC(){};
  void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd& CoefROld,
                        const Eigen::VectorXd& CoefIOld,
                        const double dt,
                        Eigen::VectorXd* CoefRNew,
                        Eigen::VectorXd* CoefINew,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time);
protected:
};


#endif  // TRAPEZOIDALC_H
