#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <string>
#include <sstream>
#include <math.h>
#include <memory>

#include "common/basis_set.h"
#include "elliptic/elliptic_basis_set_2D.h"
#include "polar_2D/polar_basis_set_2D.h"
#include "polar_2D/scomp_basis_set_2D.h"
#include "polar_2D/sphere_basis_set_2D.h"
#include "polar_2D/torus_basis_set_2D.h"
#include "util/util.h"
#include "util/read_write_tensor.h"

DEFINE_int32(basis_dim, 20, "The number of wanted basis.");
DEFINE_string(basis_type, "all_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");
DEFINE_string(Tensor_file, "", "The file which stores all the tensor.");
DEFINE_double(b, 0.9, "The shorter axis.");

using namespace std;

#define outPut \
LOG(INFO) << "Fill the advection tensor...";\
basis_.get()->FillVariationalTensor(&Adv_tensor_);\
std::stringstream outName;\
outName << FLAGS_Tensor_file;\
if (basis_type_int <=4)\
  outName << "polar_" << Adv_tensor_.size() << "Type" << basis_type_int;\
else if (basis_type_int == 5)\
  outName << "sphere2d_" << Adv_tensor_.size() << "Type" << basis_type_int;\
else if (basis_type_int == 6)\
  outName << "elliptic2d_" << Adv_tensor_.size() << "Type" << basis_type_int;\
ofstream out(outName.str(), std::ios::binary);\
basis_.get()->writeToFile(out, Adv_tensor_);\
out.close();\

int main(int argc, char ** argv) {

  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);

  int numBasisAll = FLAGS_basis_dim;
	std::string basis_type_ = FLAGS_basis_type;
	int xRes_ = 64;

  int radK = floor(sqrtf((double)(numBasisAll)*0.5));
  int angK = radK + 1;
  vector<Adv_Tensor_Type> Adv_tensor_;
  // Initialize the basis.
  int basis_type_int;
  LOG(INFO) << "radK " << radK << " angK " << angK;
  if (basis_type_ == "scomp_dirichlet") {
    std::unique_ptr<SCompBasisSet2D> basis_;
    basis_type_int = 3;
    basis_.reset(new SCompBasisSet2D(xRes_, radK, angK, true));
    outPut;
  } else if (basis_type_ == "scomp_neumann") {
    std::unique_ptr<SCompBasisSet2D> basis_;
    basis_type_int = 4;
    basis_.reset(new SCompBasisSet2D(xRes_, radK, angK, false));
    outPut;
  } else if (basis_type_ == "sphere_2d") {
    std::unique_ptr<SphereBasisSet2D> basis_;
    basis_.reset(new SphereBasisSet2D(xRes_, radK, angK));
    LOG(INFO) << "Fill the advection tensor...";
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
    std::stringstream outName;
    outName << FLAGS_Tensor_file;
    outName << "sphere2d_" << Adv_tensor_.size();
    ofstream out(outName.str(), std::ios::binary);
    basis_.get()->writeToFile(out, Adv_tensor_);
    out.close();
  } else if (basis_type_ == "elliptic_dirichlet") {
    std::unique_ptr<EllipticBasisSet2D> basis_;
    basis_type_int = 6;
    basis_.reset(new EllipticBasisSet2D(xRes_, radK, angK, true, FLAGS_b));
    outPut;
  } else if (basis_type_ == "prolate_2d") {
    std::unique_ptr<SphereBasisSet2D> basis_;
    basis_.reset(new SphereBasisSet2D(xRes_, radK, angK, true, FLAGS_b));
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
    std::stringstream outName;
    outName << FLAGS_Tensor_file;
    outName << "prolate_2d_" << Adv_tensor_.size() << "_b_" << FLAGS_b;
    ofstream out(outName.str(), std::ios::binary);
    basis_.get()->writeToFile(out, Adv_tensor_);
    out.close();
  } else if (basis_type_ == "oblate_2d") {
    std::unique_ptr<SphereBasisSet2D> basis_;
    basis_.reset(new SphereBasisSet2D(xRes_, radK, angK, false, true, FLAGS_b));
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
    std::stringstream outName;
    outName << FLAGS_Tensor_file;
    outName << "oblate_2d_" << Adv_tensor_.size() << "_b_" << FLAGS_b;
    ofstream out(outName.str(), std::ios::binary);
    basis_.get()->writeToFile(out, Adv_tensor_);
    out.close();
  } else if (basis_type_ == "torus_2d") {
    std::unique_ptr<TorusBasisSet2D> basis_;
    radK = floor(sqrtf((double)(numBasisAll)/8.0));
    basis_.reset(new TorusBasisSet2D(xRes_, radK, radK*4, 3.0));
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
    std::stringstream outName;
    outName << FLAGS_Tensor_file;
    outName << "torus_2d_" << Adv_tensor_.size() << "_a_" << "3";
    ofstream out(outName.str(), std::ios::binary);
    basis_.get()->writeToFile(out, Adv_tensor_);
    out.close();
  } else {
    LOG_ASSERT(false) << "Unknow basis tpye: " ;
	}

  return 0;
}
