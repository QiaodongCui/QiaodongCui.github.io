#include <Eigen/Eigen>
#include <math.h>

#include "sphere_3D/sphere_basis_3D.h"
#include "common/basic_function.h"
#include "3D/trig_integral_3d.h"
#include "util/util.h"

using namespace std;

 vector<vector<int>> testTrip = {{1, 2, 2}, {1, 2, 4}, {1, 2, 6}, {1, 2, 8}, {1, 2, 10}, {1, 4, 
  2}, {1, 4, 4}, {1, 4, 6}, {1, 4, 8}, {1, 4, 10}, {1, 6, 2}, {1, 6, 
  4}, {1, 6, 6}, {1, 6, 8}, {1, 6, 10}, {1, 8, 2}, {1, 8, 4}, {1, 8, 
  6}, {1, 8, 8}, {1, 8, 10}, {1, 10, 2}, {1, 10, 4}, {1, 10, 6}, {1, 
  10, 8}, {1, 10, 10}, {2, 2, 2}, {2, 2, 4}, {2, 2, 6}, {2, 2, 8}, {2,
   2, 10}, {2, 4, 2}, {2, 4, 4}, {2, 4, 6}, {2, 4, 8}, {2, 4, 10}, {2,
   6, 2}, {2, 6, 4}, {2, 6, 6}, {2, 6, 8}, {2, 6, 10}, {2, 8, 2}, {2, 
  8, 4}, {2, 8, 6}, {2, 8, 8}, {2, 8, 10}, {2, 10, 2}, {2, 10, 4}, {2,
   10, 6}, {2, 10, 8}, {2, 10, 10}, {3, 2, 2}, {3, 2, 4}, {3, 2, 
  6}, {3, 2, 8}, {3, 2, 10}, {3, 4, 2}, {3, 4, 4}, {3, 4, 6}, {3, 4, 
  8}, {3, 4, 10}, {3, 6, 2}, {3, 6, 4}, {3, 6, 6}, {3, 6, 8}, {3, 6, 
  10}, {3, 8, 2}, {3, 8, 4}, {3, 8, 6}, {3, 8, 8}, {3, 8, 10}, {3, 10,
   2}, {3, 10, 4}, {3, 10, 6}, {3, 10, 8}, {3, 10, 10}, {4, 2, 2}, {4,
   2, 4}, {4, 2, 6}, {4, 2, 8}, {4, 2, 10}, {4, 4, 2}, {4, 4, 4}, {4, 
  4, 6}, {4, 4, 8}, {4, 4, 10}, {4, 6, 2}, {4, 6, 4}, {4, 6, 6}, {4, 
  6, 8}, {4, 6, 10}, {4, 8, 2}, {4, 8, 4}, {4, 8, 6}, {4, 8, 8}, {4, 
  8, 10}, {4, 10, 2}, {4, 10, 4}, {4, 10, 6}, {4, 10, 8}, {4, 10, 
  10}, {5, 2, 2}, {5, 2, 4}, {5, 2, 6}, {5, 2, 8}, {5, 2, 10}, {5, 4, 
  2}, {5, 4, 4}, {5, 4, 6}, {5, 4, 8}, {5, 4, 10}, {5, 6, 2}, {5, 6, 
  4}, {5, 6, 6}, {5, 6, 8}, {5, 6, 10}, {5, 8, 2}, {5, 8, 4}, {5, 8, 
  6}, {5, 8, 8}, {5, 8, 10}, {5, 10, 2}, {5, 10, 4}, {5, 10, 6}, {5, 
  10, 8}, {5, 10, 10}};
vector<vector<int>> testTrip1 = {{19, 58, 50}, {19, 58, 28}, {19, 58, 44}, {19, 16, 50}, {19, 16, 
  28}, {19, 16, 44}, {19, 10, 50}, {19, 10, 28}, {19, 10, 44}, {14, 
  58, 50}, {14, 58, 28}, {14, 58, 44}, {14, 16, 50}, {14, 16, 
  28}, {14, 16, 44}, {14, 10, 50}, {14, 10, 28}, {14, 10, 44}, {3, 58,
   50}, {3, 58, 28}, {3, 58, 44}, {3, 16, 50}, {3, 16, 28}, {3, 16, 
  44}, {3, 10, 50}, {3, 10, 28}, {3, 10, 44}};

 vector<vector<int>> testTwo = {{1, 2}, {1, 4}, {1, 6}, {1, 8}, {1, 10}, {2, 2}, {2, 4}, {2, 6}, {2, 
  8}, {2, 10}, {3, 2}, {3, 4}, {3, 6}, {3, 8}, {3, 10}, {4, 2}, {4, 
  4}, {4, 6}, {4, 8}, {4, 10}, {5, 2}, {5, 4}, {5, 6}, {5, 8}, {5, 
  10}};

vector<int> testOne = {1, 2, 3, 4, 5};

  vector<vector<int>> sixWn = {{5, 40, 14, 5, 48, 6}, {12, 10, 56, 27, 2, 32}, {20, 60, 20, 30, 50, 
  20}, {14, 42, 36, 21, 26, 54}, {30, 36, 2, 30, 10, 22}, {7, 38, 40, 
  1, 12, 8}, {17, 54, 6, 28, 34, 12}, {7, 16, 22, 22, 20, 58}, {9, 18,
   36, 10, 4, 28}, {17, 2, 20, 12, 60, 14}, {4, 52, 6, 19, 4, 18}, {3,
   26, 20, 27, 18, 8}, {23, 56, 52, 11, 22, 40}, {24, 22, 4, 15, 46, 
  60}, {26, 10, 50, 27, 42, 48}, {14, 32, 30, 8, 20, 14}, {25, 14, 18,
   28, 2, 56}, {8, 30, 4, 8, 44, 38}, {27, 2, 52, 21, 8, 22}, {25, 42,
   60, 20, 26, 54}, {13, 20, 60, 22, 56, 26}, {4, 36, 18, 8, 30, 
  32}, {1, 16, 26, 11, 42, 38}, {24, 42, 38, 23, 52, 4}, {4, 18, 8, 
  11, 16, 46}, {29, 60, 26, 27, 38, 50}, {21, 12, 24, 14, 42, 34}};

namespace {

  // Test the norm
  void testDotProdMode0() {

    vector<double> val1 = {8.20093, 6.02554, 5.62269, 5.48169, 5.41643, 2.30135, 1.57622, \
    1.44194, 1.39494, 1.37318, 1.15991, 0.976792, 0.942882, 0.931013, \
    0.92552, 0.915998, 0.799369, 0.777771, 0.770212, 0.766713, 0.78948, \
    0.713823, 0.699812, 0.694909, 0.692639, 6.05991, 4.4395, 4.13943, \
    4.0344, 3.98579, 1.58171, 1.04157, 0.941544, 0.906535, 0.890331, \
    0.740764, 0.604365, 0.579106, 0.570266, 0.566174, 0.559927, 0.473052, \
    0.456964, 0.451333, 0.448727, 0.46588, 0.409525, 0.399088, 0.395436, \
    0.393745, 18.0457, 13.1648, 12.2609, 11.9446, 11.7981, 4.20084, \
    2.57387, 2.27258, 2.16713, 2.11832, 1.70735, 1.2965, 1.22041, \
    1.19379, 1.18146, 1.16624, 0.904557, 0.856098, 0.839137, 0.831287, \
    0.883786, 0.714035, 0.6826, 0.671597, 0.666505, 21.7676, 15.8676, \
    14.775, 14.3926, 14.2156, 4.95346, 2.9868, 2.6226, 2.49514, 2.43614, \
    1.94809, 1.45146, 1.35949, 1.3273, 1.3124, 1.29479, 0.978476, \
    0.919899, 0.899397, 0.889908, 0.953551, 0.748358, 0.710359, 0.69706, \
    0.690904, 38.7907, 28.2504, 26.2985, 25.6153, 25.2991, 8.58619, \
    5.07277, 4.42213, 4.19441, 4.08901, 3.23558, 2.34835, 2.18405, \
    2.12654, 2.09993, 2.07015, 1.50505, 1.40041, 1.36378, 1.34683, \
    1.46091, 1.09434, 1.02645, 1.00269, 0.991697};

    for (int i = 0; i < testTrip.size(); i++) {
      SphereBasis3D basis1(testTrip[i][0], testTrip[i][1], testTrip[i][2], 0);
      SphereBasis3D basis2(testTrip[i][0], testTrip[i][1], testTrip[i][2], 1);
      CHECK(fabs(basis1.dotProd(basis1) - val1[i]) < 1e-4);
      CHECK(fabs(basis2.dotProd(basis2) - val1[i]) < 1e-4);
    }

    vector<double> val11 = {0.574672, 0.575302, 0.574756, 3.30616, 3.31443, 3.30726, 7.91201, \
7.93305, 7.91481, 0.468988, 0.469327, 0.469033, 1.93789, 1.94233, \
1.93848, 4.41485, 4.42616, 4.41635, 0.381119, 0.381143, 0.381122, \
0.484042, 0.484354, 0.484084, 0.657814, 0.658606, 0.657919};
   
    for (int i = 0; i < testTrip1.size(); i++) {
      SphereBasis3D basis1(testTrip1[i][0], testTrip1[i][1], testTrip1[i][2], 0);
      SphereBasis3D basis2(testTrip1[i][0], testTrip1[i][1], testTrip1[i][2], 1);
      CHECK(fabs(basis1.dotProd(basis1) - val11[i]) < 1e-4);
      CHECK(fabs(basis2.dotProd(basis2) - val11[i]) < 1e-4);
    }

    vector<double> val2 = {6.19845, 2.25765, 1.53738, 1.24187, 1.10024, 4.37299, 1.48638, \
0.956834, 0.73904, 0.634596, 12.1341, 3.64679, 2.08139, 1.43525, \
1.12514, 14.4382, 4.22477, 2.33908, 1.56021, 1.18635, 25.3091, \
7.15976, 3.80483, 2.41801, 1.7522};
    for (int i = 0; i < testTwo.size(); i++) {
      SphereBasis3D basis1(testTwo[i][0], testTwo[i][1], 2, 2);
      SphereBasis3D basis2(testTwo[i][0], testTwo[i][1], 2, 3);
      CHECK(fabs(basis1.dotProd(basis1) - val2[i]) < 1e-4);
      CHECK(fabs(basis2.dotProd(basis2) - val2[i]) < 1e-4);
    }


    vector<double> val3 = {0.927349, 5.36783, 5.6274, 11.4497, 13.941};
    vector<double> val4 = {1.48376, 6.07526, 9.00385, 15.8063, 22.3056};

    for (int i = 0; i < testOne.size(); i++) {
      SphereBasis3D basis1(testOne[i], 0, 0, 4);
      SphereBasis3D basis2(testOne[i], 2, 2, 5);
      SphereBasis3D basis3(testOne[i], 2, 2, 6);
      CHECK(fabs(basis1.dotProd(basis1) - val3[i]) < 1e-4);
      CHECK(fabs(basis2.dotProd(basis2) - val4[i]) < 1e-4);
      CHECK(fabs(basis3.dotProd(basis3) - val4[i]) < 1e-4);
    }
   vector<double> val5 = {2.24509, 1.79607, 1.73193, 1.71054, 1.70083, 1.18406, 0.947245, \
0.913415, 0.902139, 0.897013, 1.49058, 1.19246, 1.14987, 1.13568, \
1.12923, 1.34321, 1.07457, 1.03619, 1.0234, 1.01758, 1.43022, \
1.14417, 1.10331, 1.08969, 1.0835};
  for (int i = 0; i < testTwo.size(); i++) {
    SphereBasis3D basis1(testTwo[i][0], testTwo[i][1], 0, 7);
    CHECK(fabs(basis1.dotProd(basis1) - val5[i]) < 1e-4);
  }
  
  vector<vector<int>> testWnTwoN = {{1, 0}, {2, 0}, {3, 0}, {4, 0}, {5, 0}};
  vector<double> val6 = {12.6898, 9.4524, 28.4719, 34.4166, 61.4849};
  for (int i = 0; i < testWnTwoN.size(); i++) {
    SphereBasis3D basis1(testWnTwoN[i][0], testWnTwoN[i][1], 2, 2);
    SphereBasis3D basis2(testWnTwoN[i][0], testWnTwoN[i][1], 2, 3);
    CHECK(fabs(basis1.dotProd(basis1) - val6[i]) < 1e-4);
    CHECK(fabs(basis2.dotProd(basis2) - val6[i]) < 1e-4);
  }
  
  {
    SphereBasis3D basis1(0, 0, 0, 4);
    SphereBasis3D basis2(0, 2, 2, 5);
    SphereBasis3D basis3(0, 2, 2, 6);
    CHECK(fabs(basis1.dotProd(basis1) - 4.18879) < 1e-4);
    CHECK(fabs(basis2.dotProd(basis2) - 4.18879) < 1e-4);
    CHECK(fabs(basis3.dotProd(basis3) - 4.18879) < 1e-4);
  }

  }

  // test prod with other modes. 
  void testDotProdMode1() {
    
    for (int i = 0; i < testTrip.size(); i++) {
      SphereBasis3D basis1(testTrip[i][0], testTrip[i][1], testTrip[i][2], 0);
      SphereBasis3D basis2(testTrip[i][0], testTrip[i][1], testTrip[i][2], 1);
      CHECK(fabs(basis1.dotProd(basis2) - 0) < 1e-12);
    }
    
    for (int i = 0; i < sixWn.size(); i++) {
      SphereBasis3D basis1(sixWn[i][0], sixWn[i][1], sixWn[i][2], 0);
      SphereBasis3D basis2(sixWn[i][3], sixWn[i][4], sixWn[i][5], 1);
      CHECK(fabs(basis1.dotProd(basis2) - 0) < 1e-12);
    }
    vector<double> val1 = {0., 0., 0., 0., 0.0271495, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
    vector<double> val2 = {0., 0., 0., 0., 0.00217963, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};

    for (int i = 0; i < sixWn.size(); i++) {
      SphereBasis3D basis1(sixWn[i][0], sixWn[i][1], sixWn[i][2], 0);
      SphereBasis3D basis2(sixWn[i][3], sixWn[i][4], 2, 2);
      SphereBasis3D basis3(sixWn[i][3], sixWn[i][4], 2, 3);
      SphereBasis3D basis4(sixWn[i][3], 0, 0, 4);
      SphereBasis3D basis5(sixWn[i][3], 2, 2, 5);
      SphereBasis3D basis6(sixWn[i][3], 2, 2, 6);
      SphereBasis3D basis7(sixWn[i][3], sixWn[i][4], 0, 7);

      CHECK(fabs(basis1.dotProd(basis2) - val1[i]) < 1e-5);
      CHECK(fabs(basis1.dotProd(basis5) - val2[i]) < 1e-5);
      CHECK(fabs(basis1.dotProd(basis3) - 0) < 1e-5);
      CHECK(fabs(basis1.dotProd(basis4) - 0) < 1e-5);
      CHECK(fabs(basis1.dotProd(basis6) - 0) < 1e-5);
      if (basis1.dotProd(basis7) < -1e-5) {
        LOG(INFO) << sixWn[i][0] << " " << sixWn[i][1] << " " << sixWn[i][2];
        LOG(INFO) << sixWn[i][3] << " " << sixWn[i][4];
      }
      //CHECK(fabs(basis1.dotProd(basis7) - 0) < 1e-5);
    }

  }

  void testCrossProduct() {
    SphereBasis3D basis1(2,2,2, 0);
    SphereBasis3D basis2(2,2,2, 0);
    SphereBasis3D basis3(2,4,6, 0);
    vector<BasicFunc> crossPhi[3][2];
    SphereBasis3D::crossProdPhi(basis2, basis3, crossPhi);
    //LOG(INFO) << crossPhi[0][0].size();
    //for(int i = 0; i < 3; i++)
    //  for (int j = 0; j < 2; j++) {
    //    for (const auto& v : crossPhi[i][j]) {
    //      v.print();
    //    }
    //    printf("\n");
    //  }

    vector<RTMultiply> crossRT[3][2];
    SphereBasis3D::crossProdRT(basis2, basis3, crossRT);
    //for (const auto& v : crossRT[0][0])
    //  v.print();
    for (const auto& v : basis3.getCurRT(0,0))
      v.print();
  }



}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);

  testDotProdMode0();
  testDotProdMode1();
  testCrossProduct();
  //SphereBasis3D basis1(27, 2, 52, 0);
  //SphereBasis3D basis7(21, 8, 0, 7);
  //LOG(INFO) << basis1.dotProd(basis7);


  return 0;
}