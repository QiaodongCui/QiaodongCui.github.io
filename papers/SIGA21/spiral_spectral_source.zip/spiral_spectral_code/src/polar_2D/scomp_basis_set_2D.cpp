#include <algorithm>
#include <cmath>
#include <Eigen/Eigen>
#include <fftw3.h>
#include <iomanip>
#include <glog/logging.h>
#include <math.h>
#include <random>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <fstream>

#include "polar_2D/scomp_basis_set_2D.h"
#include "setting.h"
#include "util/util.h"
#include "util/read_write_tensor.h"
#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "3D/trig_integral_3d.h"
#include "polar_2D/polar_basis_all.h"
#include "elliptic/elliptic_polar_share.h"

#define FAST_TENSOR

void SCompBasisSet2D::allocateBasis() {
  LOG(FATAL) << "deprecated";
}

#define POLARALLARG
void SCompBasisSet2D::allocateBasisMGS() {
  ALLOCATE_MGS_SHARE(basisPtrAll,PolarBasisAll, POLARALLARG);

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    waveNum2_[i] = k1*k1 + k2*k2;
  }
}

#undef POLARALLARG

void SCompBasisSet2D::collectPairedCoef(const Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size());
  std::vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    double C_x = all_basis_[i]->GetInvNorm()*all_basis_[i]->GetDCTNorm();
    phiCoef_[index][Coefidx[index]].coef = fieldCoef[i]*C_x;
    Coefidx[index]++;
  }
}

//#define TEST

// 1) Do int wavenumber first, with two different kinds.
// 2) USE [0, 2Pi] in theta range to avoid additional dcts.
void SCompBasisSet2D::InverseTransformToVelocity(
  const Eigen::VectorXd& coefficients, VFIELD2D* field) {

  Eigen::VectorXd fieldCoef = A_.transpose()*coefficients;
  
  // test
#ifdef TEST
    srand((unsigned int) (time(0)));
    fieldCoef = Eigen::VectorXd::Random(fieldCoef.size());
#endif

 collectPairedCoef(fieldCoef);
  /*----------------------------FFTW ur----------------------------------*/
  /* Iterate over all the coefficients and put it into the field.*/
  ClearuR();
  ClearOdd();
  int divd = !boundaryCnd_ ? 1 : 2;
  int divd1 = boundaryCnd_ ? 1 : 2;
  for (const auto& p : phiCoef_[0]) {
    /* r: RODFT01, theta: RODFT01*/
    if ((p.i2x2 - 1) >= 0 && (p.i1x2/divd - 1) >= 0)
      urTemp_[p.i2x2 - 1 + (p.i1x2/divd - 1)*nTheta_] += p.coef;
  }
  for (const auto& p : phiCoef_[2]) {
    /* r: REDFT01, theta: RODFT01*/
    if ((p.i2x2 - 1) >= 0)
      oddTemp_[p.i2x2 - 1 + (p.i1x2/divd1)*nTheta_] += p.coef;
  }

  /* TODO, CHANGE to FFTW_MEASURE*/
  fftw_execute_r2r(IsinR_, urTemp_, urTemp_);
  fftw_execute_r2r(IcosREn_, oddTemp_, oddTemp_);

  Eigen::Map<Eigen::VectorXd> urV(urTemp_, nTheta_*nR_);
  Eigen::Map<Eigen::VectorXd> oddV(oddTemp_, nTheta_*nR_);
  /* total = Phi + Psi*/
  urV = urV + oddV;
  fftw_execute_r2r(IsinTheta_ , urTemp_, urTemp_);

  /*----------------------------FFTW ut----------------------------------*/
  ClearuT();
  ClearOdd();
  ClearExt();
  for (const auto& p : phiCoef_[0]) {
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
    /* r: RODFT01, theta: REDFT01*/
    if ((p.i1x2/divd - 1) >= 0)
    extTemp_[p.i2x2 + (p.i1x2/divd - 1)*nTheta_] += p.coef*invi2;
  }
  for (const auto& p : phiCoef_[2]) {
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
    /* r: REDFT01, theta: REDFT01*/
    oddTemp_[p.i2x2 + (p.i1x2/divd1)*nTheta_] += p.coef*invi2;
  }

  Eigen::Map<Eigen::VectorXd> utV(utTemp_, nTheta_*nR_);
  Eigen::Map<Eigen::VectorXd> extV(extTemp_, nTheta_*nR_);

  fftw_execute_r2r(IsinR_, extTemp_, extTemp_);
  fftw_execute_r2r(IcosREn_, oddTemp_, oddTemp_);

  utV = extV + oddV;

  /* second part.*/
  ClearOdd();
  ClearExt();

  for (const auto& p : phiCoef_[0]) {
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
    double i1 = p.i1x2*0.5;
    /* r: REDFT01, theta: REDFT01*/
    extTemp_[p.i2x2 + p.i1x2/divd*nTheta_] += p.coef*invi2*i1;
  }
  for (const auto& p : phiCoef_[2]) {
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;
    double i1 = p.i1x2*0.5;
    /* r: RODFT01, theta: REDFT01*/
    if ((p.i1x2/divd1-1) >= 0)
      oddTemp_[p.i2x2 + (p.i1x2/divd1-1)*nTheta_] += p.coef*invi2*i1;
  }

  fftw_execute_r2r(IcosR_, extTemp_, extTemp_);
  fftw_execute_r2r(IsinREn_, oddTemp_, oddTemp_);

for (int j = 0; j < nR_; j++) {
  for (int i = 0; i < nTheta_; i++) {
    double r = ((double)(j) + 0.5)*dr_;
    oddTemp_[i + j*nTheta_] *= M_PI*r;
    extTemp_[i + j*nTheta_] *= M_PI*r;
  }
}

  utV += oddV;

  /* thats the second part.*/
  utV += extV;
  fftw_execute_r2r(IcosTheta_,  utTemp_, utTemp_);\


  // last part, phi^4
  int rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;
  clearPointerSize(rtemp0_,  rsize);
  // NEED 1D PLANS
  for (const auto& p : phiCoef_[4]) {
    // RODFT
    rtemp0_[p.i1x2/divd - 1] += p.coef;
  }
  fftw_execute_r2r(IsinR1D_, rtemp0_, rtemp1_);
  for (int j = 0; j < nR_; j++ )
  for (int i = 0; i < nTheta_; i++) {
    utV[i + j*nTheta_] += rtemp1_[j];
  }

  InversetTransformEnrich(fieldCoef, urV, utV);

#ifdef TEST
    double *rtest, *ttest;
    rtest = (double*) malloc(sizeof(double)*nTheta_*nR_);
    std::memset(rtest, 0x00, sizeof(double)*nTheta_*nR_);
    ttest = (double*) malloc(sizeof(double)*nTheta_*nR_);
    std::memset(ttest, 0x00, sizeof(double)*nTheta_*nR_);
    computeUniformRTNumerical(fieldCoef, nR_, nTheta_, rtest, ttest);
    Eigen::Map<Eigen::VectorXd> rtestV(rtest, nTheta_*nR_);
    Eigen::Map<Eigen::VectorXd> ttestV(ttest, nTheta_*nR_);
    LOG(INFO) << (rtestV - urV).norm() << " tdiff " << (ttestV - utV).norm();
    exit(0);
#endif

  interpolateToCartesian(field); 
}


void SCompBasisSet2D::InversetTransformEnrich(const Eigen::VectorXd& fieldCoef, Eigen::Map<Eigen::VectorXd>& vr, Eigen::Map<Eigen::VectorXd>& vt) {

  INVERSE_R2_SHARE();

  INVERSE_T3_SHARE();

  INVERSE_T4_SHARE(POLAR_T4_WEIGHT);
}

//#define TEST

// Input a std::vector field, transform and output the basis coefficients.
void SCompBasisSet2D::ForwardTransformtoFrequency(
  const VFIELD2D& field, Eigen::VectorXd* coefficients) {

  const double dTheta = 2.0*M_PI/nTheta_;
  const double dr = 1.0 / nR_;

  Eigen::VectorXd fieldCoef = Eigen::VectorXd::Zero(all_basis_.size());
  clearPairCoef();
  interpolateToPolar(field);
  weightR(urTemp_);
  weightR(utTemp_);
  int divd = !boundaryCnd_ ? 1 : 2;
  int divd1 = boundaryCnd_ ? 1 : 2;

  //----------------------------FFTW ur----------------------------------
  // Iterate over all the coefficients and put it into the field.
  ClearOdd();
  ClearExt();
  /*for (int j = 0; j < nR_; j++) {
    for (int i = 0; i < nTheta_; i++) {
      urTemp_[i + j*nTheta_] = polarF_(i,j)[0];
      utTemp_[i + j*nTheta_] = polarF_(i,j)[1];
    }
  }
  polarF_.clear();*/

  // now the field is interpolated to ur, ut field.
  // test
#ifdef TEST
    srand((unsigned int) (time(0)));
    double *ur, *ut;
    ur = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
    ut = (double*) fftw_malloc(sizeof(double)*nR_*nTheta_);
    Eigen::Map<Eigen::VectorXd> urV(ur, nR_*nTheta_);
    Eigen::Map<Eigen::VectorXd> utV(ut, nR_*nTheta_);
    urV.setZero();
    utV.setZero();
    urV = Eigen::VectorXd::Random(nR_*nTheta_);
    utV = Eigen::VectorXd::Random(nR_*nTheta_);
    weightR(ur);
    weightR(ut);
    ClearuT();
    ClearuR();
    memcpy(urTemp_, ur, sizeof(double)*nR_*nTheta_);
    memcpy(utTemp_, ut, sizeof(double)*nR_*nTheta_);
#endif

  int rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;

  fftw_execute_r2r(FsinTheta_, urTemp_, oddTemp_);
  memcpy(extTemp_, oddTemp_, sizeof(double)*rsize*nTheta_);


  fftw_execute_r2r(FsinR_, oddTemp_, oddTemp_);
  fftw_execute_r2r(FcosREn_, extTemp_, extTemp_);

  /* gather the coefficients.*/
  for (auto& p : phiCoef_[0]) {
    if ((p.i2x2 - 1 ) >= 0 && (p.i1x2/divd - 1) >= 0)
      p.coef += oddTemp_[p.i2x2 - 1 + (p.i1x2/divd - 1)*nTheta_];
  }
  for (auto& p : phiCoef_[2]) {
    if ((p.i2x2 - 1) >= 0)
    p.coef += extTemp_[p.i2x2 - 1 + (p.i1x2/divd1)*nTheta_];
  }

  ForwardTransformEnrichUR(fieldCoef);

/*----------------------------FFTW ut----------------------------------*/
  ClearOdd();
  ClearExt();
  ClearWUtr();

  fftw_execute_r2r(FcosTheta_, utTemp_, utrWTemp_);

  fftw_execute_r2r(FsinR_, utrWTemp_, oddTemp_);
  fftw_execute_r2r(FcosREn_, utrWTemp_, extTemp_);

  for (auto& p : phiCoef_[0]) {
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
    if ((p.i1x2/divd - 1) >= 0)
      p.coef += oddTemp_[p.i2x2 + (p.i1x2/divd - 1)*nTheta_]*invi2;
  }
  for (auto& p : phiCoef_[2]) {
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
    p.coef += extTemp_[p.i2x2 + (p.i1x2/divd1)*nTheta_]*invi2;
  }

 /* second part.*/
  ClearOdd();
  ClearExt();

  for (int j = 0; j < nR_; j++) {
    double r = ((double)(j) + 0.5)*dr_;
    for (int i = 0; i < nTheta_; i++) {
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*M_PI*r;
    }
  }
  memcpy(extTemp_, oddTemp_, sizeof(double)*rsize*nTheta_);

  fftw_execute_r2r(FcosR_, oddTemp_, oddTemp_);
  fftw_execute_r2r(FsinREn_, extTemp_, extTemp_);

  for (auto& p : phiCoef_[0]) {
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;
    double i1 = p.i1x2*0.5;
    p.coef += oddTemp_[p.i2x2 + (p.i1x2/divd)*nTheta_]*invi2*i1;
  }
  for (auto& p : phiCoef_[2]) {
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;
    double i1 = p.i1x2*0.5;
    if ((p.i1x2/divd1-1) >= 0)
      p.coef += extTemp_[p.i2x2 + (p.i1x2/divd1-1)*nTheta_]*invi2*i1;
  }

  //FORWARD_T2_SHARE(POLAR_T2F_WEIGHT);
  // last part, phi^4
  rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;
  clearPointerSize(rtemp0_,  rsize);

  for (int j = 0; j < nR_; j++ ) {
    double sum = 0;
    for (int i = 0; i < nTheta_; i++) {
      sum += utTemp_[i + j*nTheta_];
    }
    rtemp0_[j] = sum;
  }
  fftw_execute_r2r(FsinR1D_, rtemp0_, rtemp1_);

  // NEED 1D PLANS
  for (auto& p : phiCoef_[4]) {
    // we are doing one dct, need to offset 0.25 factor in assignPairCoef
    // RODFT
    p.coef += rtemp1_[p.i1x2/divd - 1]*2.0;
  }

  ForwardTransformEnrichUT1(fieldCoef);
  ForwardTransformEnrichUT2(fieldCoef);

  assignPairCoef(fieldCoef);

  *coefficients = A_*fieldCoef;
#ifdef TEST
    Eigen::VectorXd projCoef = Eigen::VectorXd::Zero(all_basis_.size());
    for (int i = 0; i < all_basis_.size(); i++) {
      projCoef[i] = all_basis_[i]->ProjectUniformU(nR_, nTheta_, ur, ut);
    }
    LOG(INFO) << "diff: " << (projCoef - fieldCoef).norm() << " " << projCoef.norm() << " " << fieldCoef.norm();
    exit(0);
#endif

}

#undef TEST

void SCompBasisSet2D::ForwardTransformEnrichUR(Eigen::VectorXd& fieldCoef) {
  FORWARD_R2_SHARE();
}

void SCompBasisSet2D::ForwardTransformEnrichUT1(Eigen::VectorXd& fieldCoef) {
  FORWARD_T3_SHARE(POLAR_T3F_WEIGHT);
}

void SCompBasisSet2D::ForwardTransformEnrichUT2(Eigen::VectorXd& fieldCoef) {
  FORWARD_T4_SHARE(POLAR_T4F_WEIGHT);
}

void SCompBasisSet2D::debugInfo(const PolarBasis2D& basis_i, const PolarBasis2D& basis_g,
                        const PolarBasis2D& basis_h) {
  bool iKind = basis_i.kind();
  bool gKind = basis_g.kind();
  bool hKind = basis_h.kind();
  
  // second wavenumber,i,g,h
  int i2x2 = basis_i.WN2x2();
  int g2x2 = basis_g.WN2x2();
  int h2x2 = basis_h.WN2x2();

  //first wavenumber,i,g,h
  int i1x2 = basis_i.WN1x2();
  int g1x2 = basis_g.WN1x2();
  int h1x2 = basis_h.WN1x2();

  LOG(INFO) << "i " << iKind << " " << i1x2 << " " << i2x2 << " g " << gKind << " " << g1x2 << " "
    << g2x2 << " h " << hKind << " " << h1x2 << " " << h2x2;
}

#ifdef FAST_TENSOR
#include "tensorCompute/polar2DTensor.h"
#endif

void SCompBasisSet2D::FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) {
#ifdef FAST_TENSOR
  polar2DTensor tensorEval;
#endif
  
  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }
  const double pow_w = - 0.00;
  float print_percentage = 0; 

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }
  const int five_percent = numBasisAll_ / 20;

#pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
    if (i % five_percent == 0) {
      LOG(INFO) << "% 5 " << "Tensor computed.";
    }
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = g+1; h < numBasisAll_; h++) {
        //
        const PolarBasisAll& basis_i = *all_basis_[i];
        const PolarBasisAll& basis_g = *all_basis_[g];
        const PolarBasisAll& basis_h = *all_basis_[h];
        double Cigh = 0;
#ifdef FAST_TENSOR
        const int idx = basis_i.index()*25 + basis_g.index()*5 + basis_h.index();
        double invWn = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
        Cigh = tensorEval.pointers_[idx](basis_i, basis_g, basis_h)*invWn;
#else
        Cigh = PolarBasisAll::computeTensorEntry(basis_i, basis_g, basis_h);
#endif
        CHECK(std::isfinite(Cigh));

        if (Cigh == 0) {
          continue;
        }
        
        tripletList.push_back(T(g,h, Cigh));
        tripletList.push_back(T(h,g, -Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }
  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  //VerifyAntisymmetric(*Adv_tensor);
  //exit(0);
}

void SCompBasisSet2D::outputTestTensorEntries(const int numWant, const std::string& fname,
        std::vector<Adv_Tensor_Type> *Adv_tensor) {

  CHECK_NOTNULL(Adv_tensor)->clear();
  Adv_tensor->reserve(numBasisAll_);
  // Fill the tensor with zeros.
  for (int i = 0; i < numBasisAll_; i++) {
    Adv_Tensor_Type Ck(numBasisAll_, numBasisAll_);
    Ck.setZero();
    Adv_tensor->emplace_back(Ck);
  }

  std::vector<Eigen::Vector3i> indices;

  for (int i = 0; i < numBasisAll_; i++) {
    typedef Eigen::Triplet<double> T;
    std::vector<T> tripletList;
    LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const PolarBasisAll& basis_i = *all_basis_[i];
        const PolarBasisAll& basis_g = *all_basis_[g];
        const PolarBasisAll& basis_h = *all_basis_[h];

        double Cigh = PolarBasisAll::computeTensorEntry(basis_i, basis_g, basis_h);
        CHECK(std::isfinite(Cigh));

        if (Cigh == 0) {
          continue;
        }
        indices.push_back(Eigen::Vector3i(i,g,h));
        tripletList.push_back(T(g,h, Cigh));
      }
    }
    (*Adv_tensor)[i].setFromTriplets(tripletList.begin(), tripletList.end());
  }

  // Make makeCompressed.
  for (int i = 0; i < numBasisAll_; i++) {    
    (*Adv_tensor)[i].makeCompressed();
  }

  VerifyAntisymmetric(*Adv_tensor);
  std::shuffle(indices.begin(), indices.end(), std::default_random_engine(0));
  std::ofstream out(fname);
  for (int i = 0; i < numWant && i < indices.size(); i++) {
    basisPtrAll basis_i = all_basis_[indices[i][0]];
    basisPtrAll basis_g = all_basis_[indices[i][1]];
    basisPtrAll basis_h = all_basis_[indices[i][2]];
    out << basis_i->index() << " " << basis_i->WN1x2() << " " << basis_i->WN2x2() << " " << std::setprecision(12) << basis_i->GetInvNorm() << " " <<
           basis_g->index() << " " << basis_g->WN1x2() << " " << basis_g->WN2x2() << " " << basis_g->GetInvNorm() << " " <<
           basis_h->index() << " " << basis_h->WN1x2() << " " << basis_h->WN2x2() << " " << basis_h->GetInvNorm() << " " <<
           AccessMatrix((*Adv_tensor)[indices[i][0]],indices[i][1],indices[i][2]) << "\n";
  }
  out.close();
}

void SCompBasisSet2D::readFromFile(std::ifstream& in) {

  in.read(reinterpret_cast<char*>(&boundaryCnd_), sizeof(bool));
  in.read(reinterpret_cast<char*>(&numBasisAll_), sizeof(int));
  in.read(reinterpret_cast<char*>(&numBasisOrtho_), sizeof(int));
  
  // neumann
  for (int i = 0; i < numBasisAll_; i++) {
    all_basis_.push_back(basisPtrAll(PolarBasisAll::fromFile(in)));
  }

  readEigenDense_binary(in, A_);
  //std::ofstream out("A_polar.bin", ios::binary);
  //writeEigenDense_binary(out, A_);
  //out.close();

  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());
  for (int i = 0; i < all_basis_.size(); i++) {
    double k1 = all_basis_[i]->WN1D();
    double k2 = all_basis_[i]->WN2D();
    waveNum2_[i] = k1*k1 + k2*k2;
  }
  
  phiCoef_.resize(5);
  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    phiCoef_[index].push_back(pairedCoefPolar(all_basis_[i]->WN1x2(), all_basis_[i]->WN2x2(), 0));
  }
  LOG(INFO) << "all_basis_: " << all_basis_.size();
  // Tensor is read in fluid cpp
}

// int N, int radiusK, int angK, bool bndCnd
void SCompBasisSet2D::writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const {
  // boundaryCnd_
  out.write(reinterpret_cast<const char *>(&boundaryCnd_), sizeof(bool));
  out.write(reinterpret_cast<const char *>(&numBasisAll_), sizeof(int));
  out.write(reinterpret_cast<const char *>(&numBasisOrtho_), sizeof(int));

  // all basis functions and matrices
  for (int i = 0; i < all_basis_.size(); i++) {
    all_basis_[i]->writeToFile(out);
  }
  //writeEigenDense_binary(out, H_);
  writeEigenDense_binary(out, A_);
  int tensorType = 0;
  if (boundaryCnd_)
    tensorType = 3;
  else
    tensorType = 4;

  WriteTensor(Adv_tensor_, tensorType, out);
}

// compute the ur, ut on a uniform r, t grid, test only.
void SCompBasisSet2D::computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut) {
  memset(ur, 0x00, sizeof(double)*nTheta*nR);
  memset(ut, 0x00, sizeof(double)*nTheta*nR);
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    all_basis_[i]->AddUniformU(fullCoef[i], nR, nTheta, ur, ut);
  }
}

void SCompBasisSet2D::projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef) {
  fullCoef.setZero();
  CHECK(fullCoef.size() == all_basis_.size());
  for (int i = 0; i < fullCoef.size(); i++) {
    fullCoef[i] = all_basis_[i]->ProjectUniformU(nR, nTheta, fr, ft);
  }
}

#define dotProdMarco(arg, i,j) arg[i]->dotProd(*arg[j])*arg[i]->GetInvNorm()*arg[j]->GetInvNorm();
// Run MGS on a set of basis functions stored in in, and orthogonalize them. The kept basis
// is stored in out. The basis functions with distinct part smalelr than thresh of existing basis
// are thrown away. Coef are a matrix which kepts the coefficients of MGS. m is the number of
// basis functions that are kept.
void SCompBasisSet2D::runMGS(const double thresh, const std::vector<basisPtrAll>& in, std::vector<basisPtrAll>& out,
            Eigen::MatrixXd& Coef, int& m) {
  RUNMGS_SHARE(dotProdMarco);
  // test
  // Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
  // for (int i = 0; i < reduced.rows(); i++) {
  //   reduced(i,i) -= 1.0;
  // }
  // LOG(INFO) << reduced.norm();
}

#undef dotProdMarco


void SCompBasisSet2D::assignPairCoef(Eigen::VectorXd& fieldCoef) {
  CHECK(fieldCoef.size() == all_basis_.size()) << fieldCoef.size() << " vs " << all_basis_.size();
  fieldCoef.setZero();
  std::vector<int> Coefidx(phiCoef_.size(), 0);

  for (int i = 0; i < all_basis_.size(); i++) {
    int index = all_basis_[i]->index();
    // 0.125 comes from 2 factor from foward dcts. This funcion assumes doing dcts along three
    // directions.
    double C_x = all_basis_[i]->GetInvNorm()*0.25;
    fieldCoef[i] += phiCoef_[index][Coefidx[index]].coef*C_x*dr_*dTheta_;
    Coefidx[index]++;
  }
}