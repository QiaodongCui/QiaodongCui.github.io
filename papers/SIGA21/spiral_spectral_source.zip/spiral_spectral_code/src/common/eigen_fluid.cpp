#include <Eigen/Eigen>
#include "common/eigen_fluid.h"
#include "solver/bi_cg_s_solver.h"
#include "solver/bi_cg_stab_preconditioned.h"
#include "solver/integrator_2d.h"
#include "solver/integrator_RK4.h"
#include "solver/integrator_semi_implicit.h"
#include "solver/symmetric_cg.h"
#include "solver/trapezoidal.h"

// set the integrator
void EigenFluid::Initialize() {
  // Initialize the integrator.
  if (integrator_type_ == "trapezoidal") {
    integrator_.reset(new Trapezoidal());
  } else {
    LOG_ASSERT(false) << "Unknow integrator type: " << integrator_type_;
  } 
}

double EigenFluid::CalculateEnergy() {
	double energy=0.0;
  for (int i = 0; i < numBasisOrtho; i++)
     energy += (basis_coefficients_[i] * basis_coefficients_[i]);
  return energy;
}

// TODO: correctly model diffusion.
void EigenFluid::DissipateEnergy() {
  //Eigen::VectorXd diffVec = Eigen::VectorXd::Zero();
  //for (int i = 0; i < basis_dim_; i++) {
  //  coefficients_[i] *= exp(-1.0 * eigenValues_[i] * dt_ * visc_);
  //}
  for (int i = 0; i < numBasisOrtho; i++) {
    basis_coefficients_[i] *= exp(- projWav_[i]*dt_*visc_);
  }
  //Eigen::VectorXd fullVec = A_.transpose()*basis_coefficients_;
  //for (int i = 0; i < numBasisAll; i++) {
  //  fullVec[i] *= diffVec[i];
  //}
  //basis_coefficients_ = A_*fullVec;
  //LOG(INFO) << (A_*A_.transpose()).diagonal().transpose();
  //exit(0);

  //Eigen::VectorXd projDiff = A_*diffVec;
  //for (int i = 0; i < numBasisOrtho; i++) {
  //  basis_coefficients_[i] *= projDiff[i]/A_.row(i).sum();
  //}
}

void EigenFluid::computeSortedIdx(const Eigen::VectorXd& waveN2) {

  Eigen::MatrixXd Aabs = A_.array().abs();
  projWav_ = Aabs*waveN2;
  //sortedWaveNum_.resize(numBasisOrtho);
  std::vector<std::pair<double, int>> pairedProjWav;
  for (int i = 0; i < projWav_.size(); i++)
    pairedProjWav.push_back(std::make_pair(projWav_[i], i));
  sort(pairedProjWav.begin(), pairedProjWav.end(), 
      [](const std::pair<double, int>& a, const std::pair<double, int>& b){
        return a.first < b.first;
      });
  for (int i = 0; i < pairedProjWav.size(); i++)
    sortedIndex_.push_back(pairedProjWav[i].second);
}

void EigenFluid::Quit() {
  LOG(INFO) << "Total frame simulated: " << total_frame_;
  LOG(INFO) << "Average time for integrator per frame: " 
      << integrator_time_ / total_frame_;
  LOG(INFO) << "Average time for DCT and DST: "
      << transformation_time_ / total_frame_;
  LOG(INFO) << "Average time for advection of density and particles: "
      << density_advection_time_ / total_frame_;
  LOG(INFO) << "Maximum condition number: " << maximum_condition_number_;
  quit_ = true;
 // exit(0);
}