#ifndef TRANSFORM_H
#define TRANSFORM_H

#include <cmath>
#include <Eigen/Eigen>

namespace Transform::Spherical {
	
  // (x,y,z) -> (r, theta, phi)
  template<typename VT>
  static VT toSpherical(const VT& cat) {
    VT result;
    // r
    result[0] = cat.norm();
    // theta
    result[1] = acos(cat[2]/result[0]);
    // phi
    result[2] = atan2(cat[1], cat[0]);
    // [0, 2pi]
    if (cat[1] < 0)
      result[2] += 2*M_PI;

    return result;
  }

  // (r, theta, phi) -> (x,y,z)
  template<typename VT>
  static VT toCartesian(const VT& sph) {
    VT result;
    result << sph[0]*sin(sph[1])*cos(sph[2]), sph[0]*sin(sph[1])*sin(sph[2]), sph[0]*cos(sph[1]);
    return result;
  }

  template<typename T, typename MAT>
  static void toCartesianMat(const T& t, const T& p, MAT& mat) {
    T sinT = sin(t);
    T cosT = cos(t);
    T sinP = sin(p);
    T cosP = cos(p);
    mat << sinT*cosP, cosT*cosP, -sinP,
           sinT*sinP, cosT*sinP, cosP,
           cosT,      -sinT,     0;
  }

} // Transform::Spherical 

namespace Transform::Torodial {

    // (x,y,z) -> (r, theta, phi)
  template<typename T>
  static T toTorodial(const T& cat, const double& a) {
    T result;
    double t = cat[0]*cat[0] + cat[1]*cat[1];
    double tmp = (a - sqrt(t))*(a - sqrt(t)) + cat[2]*cat[2];
    result[0] = sqrt(tmp);
    double zr = 0;   // near the center line
    if (result[0] > 1e-6) // avoid divid by zero.
      zr = cat[2]/result[0];
    zr = zr > 1.0 ? 1.0 : zr;
    zr = zr < -1.0 ? -1.0 : zr;
    result[1] = acos(zr); // [0,pi]

    if ((cat[0]*cat[0] + cat[1]*cat[1]) <  a*a) {
      result[1] = 2*M_PI - result[1];
    }
    result[2] = atan2(cat[1], cat[0]);
    // [0, 2pi]
    if (cat[1] < 0)
      result[2] += 2*M_PI;
    return result;
  }

  // (r, theta, phi) -> (x,y,z)
  template<typename T>
  static T toCartesian(const T& sph, const double& a) {
    T result;
    result[0] = (sph[0]*sin(sph[1]) + a)*cos(sph[2]);
    result[1] = (sph[0]*sin(sph[1]) + a)*sin(sph[2]);
    result[2] = sph[0]*cos(sph[1]);
    return result;
  }

  template<typename VT, typename MAT>
  static void toCartesianMat(const VT& t, const VT& p, MAT& mat) {
    VT sinT = sin(t);
    VT cosT = cos(t);
    VT sinP = sin(p);
    VT cosP = cos(p);
    mat << sinT*cosP, cosT*cosP, -sinP,
           sinT*sinP, cosT*sinP, cosP,
           cosT,      -sinT,     0;
  }

}; // Transform::Torodial

namespace Transform::Cylinderical {

  // (x,y,z) -> (r, theta, z)
  template<typename VT>
  static VT toCylinderical(const VT& cat, const double& b_) {
    VT result;
    // r
    result[0] = sqrt(cat[0]*cat[0] + cat[1]*cat[1]);
    // theta
    result[1] = atan2(cat[1], cat[0]);
    // z
    result[2] = cat[2]/b_;
    // [0, 2pi]
    if (cat[1] < 0)
      result[1] += 2*M_PI;

    return result;
  }

  // (r, theta, z) -> (x,y,z)
  template<typename VT>
  static VT toCartesian(const VT& sph, const double b){
    VT result;
    result << sph[0]*cos(sph[1]), sph[0]*sin(sph[1]), b*sph[2];
    return result;
  }

  template<typename T, typename MAT>
  static void toCartesianMat(const T& t, MAT& mat) {
    T sinT = sin(t);
    T cosT = cos(t);
    mat << cosT, -sinT, 0,
           sinT, cosT, 0,
           0,0,1;
  }

}; // Transform::Cylinderical

namespace Transform::Spheroid {
  
  template<typename T>
  static inline T computeh(const T& r, const T& t, const double& c) {
    return sqrt(c*c*r*r + sin(t)*sin(t));
  };

  template<typename T>
  static inline T computehc(const T& r, const T& t, const double& c) {
    return sqrt(c*c*r*r + cos(t)*cos(t));
  };

 template<typename T, typename DT>
  static void CatersianToProlate(const double a, const double c, const T& pos, DT& r, DT& theta, DT& phi) {
    const DT t2 = pos[0]*pos[0] + pos[1]*pos[1]; // x^2 + y^2
    const DT B = t2 + pos[2]*pos[2] - a*a;
    const DT sqrtac = sqrt(B*B + 4.0*a*a*t2);
    const DT q = (B + sqrtac)*0.5/a/a;
    const DT p = (-B + sqrtac)*0.5/a/a;
    
    r = sqrt(q)/c;
    // p > 0, theta \in [0, pi/2]
    theta = asin(sqrt(p));
    // correct angle
    if (pos[2] < 0)  // [0, pi.]
      theta = M_PI - theta;
    
    phi = atan2(pos[1], pos[0]);  // [-pi, pi]
    if (pos[1] < 0)   // [0, 2pi]
      phi += 2*M_PI;
  }

  template<typename T, typename DT>
  static void ProlateToCatersian(const double a, const double c, const DT& r, const DT& theta, const DT& phi, T& pos) {
    pos[0] = a*c*r*sin(theta)*cos(phi);
    pos[1] = a*c*r*sin(theta)*sin(phi);
    pos[2] = a*sqrt(1.0 + c*c*r*r)*cos(theta);
  }

  template<typename T, typename DT>
  static void CatersianToOblate(const double a, const double c, const T& pos, DT& r, DT& theta, DT& phi) {
    const DT t2 = pos[0]*pos[0] + pos[1]*pos[1]; // x^2 + y^2
    const DT z2 = pos[2]*pos[2];
    const DT B = t2 + z2 - a*a;

    const DT sqrtac = sqrt(B*B + 4.0*a*a*z2);
    const DT q = (B + sqrtac)*0.5/a/a;
    const DT p = (-B + sqrtac)*0.5/a/a;
    
    r = sqrt(q)/c;
    // p > 0, theta \in [0, pi/2]
    theta = acos(sqrt(p));
    
    // correct angle
    if (pos[2] < 0)  // [0, pi.]
      theta = M_PI - theta;
    
    phi = atan2(pos[1], pos[0]);  // [-pi, pi]
    if (pos[1] < 0)   // [0, 2pi]
      phi += 2*M_PI;
  }

  template<typename T, typename DT>
  static void OblateToCatersian(const double a, const double c, const DT& r, const DT& theta, const DT& phi, T& pos) {
    pos[0] = a*sqrt(1.0 + c*c*r*r)*sin(theta)*cos(phi);
    pos[1] = a*sqrt(1.0 + c*c*r*r)*sin(theta)*sin(phi);
    pos[2] = a*c*r*cos(theta);
  }

  // coordinate transformations.
  template<typename T>
  static void CatersianToProlate(const double a, const double c, const T& pos, T& outPos) {
    CatersianToProlate(a, c, pos, outPos[0], outPos[1], outPos[2]);
  }

  template<typename T>
  static void ProlateToCatersian(const double a, const double c, const T& pos, T& outPos) {
    ProlateToCatersian(a, c, pos[0], pos[1], pos[2], outPos);
  }

  template<typename T>
  static void CatersianToOblate(const double a, const double c, const T& pos, T& outPos) {
    CatersianToOblate(a, c, pos, outPos[0], outPos[1], outPos[2]);
  }

  template<typename T>
  static void OblateToCatersian(const double a, const double c, const T& pos, T& outPos) {
    OblateToCatersian(a, c, pos[0], pos[1], pos[2], outPos);
  }

  template<typename T, typename MAT>
  static void toCartesianMatProlate(const T& r, const T& t, const T& p, const double& c, MAT& mat) {
    const T h = computeh(r,t, c);
    const T sqrtCR = sqrt(1.0 + c*c*r*r);
    mat << sqrtCR/h*sin(t)*cos(p), c*r/h*cos(t)*cos(p), -sin(p),
           sqrtCR/h*sin(t)*sin(p), c*r/h*cos(t)*sin(p), cos(p),
           c*r/h*cos(t), -sqrtCR/h*sin(t), 0;
  }

  template<typename T, typename MAT>
  static void toCartesianMatOblate(const T& r, const T& t,  const T& p, const double& c, MAT& mat) {
    const T hc = computehc(r,t,c);
    const T sqrtCR = sqrt(1.0 + c*c*r*r);
    mat << c*r/hc*sin(t)*cos(p), sqrtCR/hc*cos(t)*cos(p), -sin(p),
           c*r/hc*sin(t)*sin(p), sqrtCR/hc*cos(t)*sin(p), cos(p),
           sqrtCR/hc*cos(t), -c*r/hc*sin(t), 0;
  }

};  // Transform::Spheroid 

#endif  // TRANSFORM_H