#ifndef TRIG_INTEGRAL_H
#define TRIG_INTEGRAL_H

#include <cmath>

namespace TrigInt {
// ONLY USED WHEN wnx2%2==0
// int_{t=0}^{2*Pi} sin(a2/2*t) dt
inline double IntegrateSinPi_D2(const int wnx2) {
  return ((wnx2/2)%2 == 0 ? 0 : 2.0/(wnx2/2));
}

// ONLY USED WHEN wnx2%2==0
// int_{t=0}^{2*Pi} cos(a2/2*t) dt
inline double IntegrateCosPi_D2(const int wnx2) {
  return (wnx2 == 0 ? M_PI : 0);
}

// int_{t=0}^{2*Pi} sin(a2/2*t) dt
inline double IntegrateSin2Pi_D2(const int a2) {
  return a2 % 2 == 0 ? 0 : 4.0/a2;
}

// int_{t=0}^{2*Pi} cos(a2/2*t) dt
inline double IntegrateCos2Pi_D2(const int a2) {
  return a2 == 0 ? 2.0*M_PI : 0;
}

// Evaluate cos(k*M_PI), where k can be an integer, or integer offset by half.
// The argument passed in is k*2. When k is an integer, kx2 will be even, otherwise it
// will be odd
inline double CheapCos_D2(int kx2) {
  // even function.
  kx2 = std::abs(kx2);
  // cos is always zero at half pi.
  if (kx2 % 2 != 0)
    return 0;
  int k = kx2/2;
  // cos(0), cos(2pi), etc
  if (k % 2 == 0)
    return 1.0;
  else
    return -1.0;
}

// Evaluate sin(k*M_PI), where k can be an integer, or integer offset by half.
// The argument passed in is k*2. When k is an integer, kx2 will be even, otherwise it
// will be odd
inline double CheapSin_D2(int kx2) {
  // odd function.
  if (kx2 < 0)
    return -CheapSin_D2(std::abs(kx2));
  // sin is always zero at pi.
  if (kx2 % 2 == 0)
    return 0;
  int k = kx2/2;
  // sin(0.5), sin(2.5pi), etc
  if (k % 2 == 0)
    return 1.0;
  else
    return -1.0;
}

#define Power(val, p) std::pow(val, p)
#define CheapCosD2 CheapCos_D2
#define CheapSinD2 CheapSin_D2

inline double IntegralS_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;

return 0.3183098861837907/a - (0.3183098861837907*CheapCosD2(a2))/a;
}

inline double IntegralC_D2_ONE(const int a2) {
  if (a2 == 0)
    return 1.0;

  const double a = a2*0.5;

return (0.3183098861837907*CheapSinD2(a2))/a;
}

inline double IntegralRS_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;

  return (-0.3183098861837907*CheapCosD2(a2))/a + (0.10132118364233778*CheapSinD2(a2))/(a*a);
}

inline double IntegralRC_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0.5;

  const double a = a2*0.5;

return -0.10132118364233778/(a*a) + (0.10132118364233778*CheapCosD2(a2))/(a*a) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}

inline double IntegralR2S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;

  return -0.06450306886639899/(a*a*a) + (0.06450306886639899*CheapCosD2(a2))/(a*a*a) - 
   (0.3183098861837907*CheapCosD2(a2))/a + (0.20264236728467555*CheapSinD2(a2))/(a*a);
}

inline double IntegralR2C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 1.0/3.0;

  const double a = a2*0.5;

return (0.20264236728467555*CheapCosD2(a2))/(a*a) - (0.06450306886639899*CheapSinD2(a2))/(a*a*a) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}

inline double IntegralR3S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  const double a = a2*0.5;
  return (0.19350920659919696*CheapCosD2(a2))/(a*a*a) - (0.3183098861837907*CheapCosD2(a2))/a - 
   (0.061595893528106016*CheapSinD2(a2))/(a*a*a*a) + (0.3039635509270133*CheapSinD2(a2))/(a*a);
}

inline double IntegralR3C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0.25;

  const double a = a2*0.5;

  return 0.061595893528106016/(a*a*a*a) - (0.061595893528106016*CheapCosD2(a2))/(a*a*a*a) + 
   (0.3039635509270133*CheapCosD2(a2))/(a*a) - (0.19350920659919696*CheapSinD2(a2))/(a*a*a) + 
   (0.3183098861837907*CheapSinD2(a2))/a;

}

inline double IntegralR4S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

return 0.07842632743328126/Power(a,5) - (0.07842632743328126*CheapCosD2(a2))/Power(a,5) + (0.3870184131983939*CheapCosD2(a2))/Power(a,3) - 
   (0.3183098861837907*CheapCosD2(a2))/a - (0.24638357411242406*CheapSinD2(a2))/Power(a,4) + 
   (0.4052847345693511*CheapSinD2(a2))/Power(a,2);
}

inline double IntegralR4C_D2_ONE(const int a2) {
if (a2 == 0)
  return 0.2;

const double a = a2*0.5;

return (-0.24638357411242406*CheapCosD2(a2))/Power(a,4) + (0.4052847345693511*CheapCosD2(a2))/Power(a,2) + 
   (0.07842632743328126*CheapSinD2(a2))/Power(a,5) - (0.3870184131983939*CheapSinD2(a2))/Power(a,3) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}


inline double IntegralR5S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

  return (-0.3921316371664063*CheapCosD2(a2))/Power(a,5) + (0.6450306886639899*CheapCosD2(a2))/Power(a,3) - 
   (0.3183098861837907*CheapCosD2(a2))/a + (0.12481937679550231*CheapSinD2(a2))/Power(a,6) - 
   (0.6159589352810602*CheapSinD2(a2))/Power(a,4) + (0.5066059182116889*CheapSinD2(a2))/Power(a,2);
}

inline double IntegralR5C_D2_ONE(const int a2) {
if (a2 == 0)
  return 1.0/6.0;

const double a = a2*0.5;

  return -0.12481937679550231/Power(a,6) + (0.12481937679550231*CheapCosD2(a2))/Power(a,6) - (0.6159589352810602*CheapCosD2(a2))/Power(a,4) + 
   (0.5066059182116889*CheapCosD2(a2))/Power(a,2) + (0.3921316371664063*CheapSinD2(a2))/Power(a,5) - 
   (0.6450306886639899*CheapSinD2(a2))/Power(a,3) + (0.3183098861837907*CheapSinD2(a2))/a;
}

inline double IntegralR6S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

  return -0.23838744972784817/Power(a,7) + (0.23838744972784817*CheapCosD2(a2))/Power(a,7) - (1.176394911499219*CheapCosD2(a2))/Power(a,5) + 
   (0.9675460329959849*CheapCosD2(a2))/Power(a,3) - (0.3183098861837907*CheapCosD2(a2))/a + 
   (0.7489162607730139*CheapSinD2(a2))/Power(a,6) - (1.2319178705621203*CheapSinD2(a2))/Power(a,4) + 
   (0.6079271018540267*CheapSinD2(a2))/Power(a,2);

}

inline double IntegralR6C_D2_ONE(const int a2) {

if (a2 == 0)
  return 1.0/7.0;

const double a = a2*0.5;

return (0.7489162607730139*CheapCosD2(a2))/Power(a,6) - (1.2319178705621203*CheapCosD2(a2))/Power(a,4) + 
   (0.6079271018540267*CheapCosD2(a2))/Power(a,2) - (0.23838744972784817*CheapSinD2(a2))/Power(a,7) + 
   (1.176394911499219*CheapSinD2(a2))/Power(a,5) - (0.9675460329959849*CheapSinD2(a2))/Power(a,3) + 
   (0.3183098861837907*CheapSinD2(a2))/a;
}

inline double IntegralR7S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;

  const double a = a2*0.5;

  return (1.6687121480949372*CheapCosD2(a2))/Power(a,7) - (2.744921460164844*CheapCosD2(a2))/Power(a,5) + 
   (1.3545644461943789*CheapCosD2(a2))/Power(a,3) - (0.3183098861837907*CheapCosD2(a2))/a - 
   (0.5311675739336081*CheapSinD2(a2))/Power(a,8) + (2.6212069127055484*CheapSinD2(a2))/Power(a,6) - 
   (2.1558562734837103*CheapSinD2(a2))/Power(a,4) + (0.7092482854963644*CheapSinD2(a2))/Power(a,2);
}

inline double IntegralR7C_D2_ONE(const int a2) {

if (a2 == 0)
  return 0.125;

const double a = a2*0.5;

return 
  0.5311675739336081/Power(a,8) - (0.5311675739336081*CheapCosD2(a2))/Power(a,8) + (2.6212069127055484*CheapCosD2(a2))/Power(a,6) - 
   (2.1558562734837103*CheapCosD2(a2))/Power(a,4) + (0.7092482854963644*CheapCosD2(a2))/Power(a,2) - 
   (1.6687121480949372*CheapSinD2(a2))/Power(a,7) + (2.744921460164844*CheapSinD2(a2))/Power(a,5) - 
   (1.3545644461943789*CheapSinD2(a2))/Power(a,3) + (0.3183098861837907*CheapSinD2(a2))/a;
}

// int_{r = 0}^{1} r^8*cos(a*pi*r) dr
inline double IntegralR8S_D2_ONE(const int a2) {

  if (a2 == 0)
    return 0;
  
  const double a = a2*0.5;
  return 1.3526071200266163/Power(a,9) - (1.3526071200266163*CheapCos_D2(a2))/Power(a,9) + 
   (6.674848592379749*CheapCos_D2(a2))/Power(a,7) - (5.489842920329688*CheapCos_D2(a2))/Power(a,5) + 
   (1.8060859282591717*CheapCos_D2(a2))/Power(a,3) - (0.3183098861837907*CheapCos_D2(a2))/a - 
   (4.249340591468865*CheapSin_D2(a2))/Power(a,8) + (6.989885100548129*CheapSin_D2(a2))/Power(a,6) - 
   (3.449370037573937*CheapSin_D2(a2))/Power(a,4) + (0.8105694691387022*CheapSin_D2(a2))/Power(a,2);  
}

// int_{r = 0}^{1} r^8*cos(a*pi*r) dr
inline double IntegralR8C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 1.0/9.0;
  
  const double a = a2*0.5;
  
  return (-4.249340591468865*CheapCos_D2(a2))/Power(a,8) + (6.989885100548129*CheapCos_D2(a2))/Power(a,6) - 
   (3.449370037573937*CheapCos_D2(a2))/Power(a,4) + (0.8105694691387022*CheapCos_D2(a2))/Power(a,2) + 
   (1.3526071200266163*CheapSin_D2(a2))/Power(a,9) - (6.674848592379749*CheapSin_D2(a2))/Power(a,7) + 
   (5.489842920329688*CheapSin_D2(a2))/Power(a,5) - (1.8060859282591717*CheapSin_D2(a2))/Power(a,3) + 
   (0.3183098861837907*CheapSin_D2(a2))/a;
}

// int_{r = 0}^{1} r^9*cos(a*pi*r) dr
inline double IntegralR9S_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0;
  
  const double a = a2*0.5;

  return (-12.173464080239548*CheapCosD2(a2))/Power(a,9) + (20.024545777139245*CheapCosD2(a2))/Power(a,7) - 
   (9.88171725659344*CheapCosD2(a2))/Power(a,5) + (2.3221104791903637*CheapCosD2(a2))/Power(a,3) - 
   (0.3183098861837907*CheapCosD2(a2))/a + (3.8749339658435145*CheapSinD2(a2))/Power(a,10) - 
   (19.122032661609893*CheapSinD2(a2))/Power(a,8) + (15.72724147623329*CheapSinD2(a2))/Power(a,6) - 
   (5.174055056360905*CheapSinD2(a2))/Power(a,4) + (0.91189065278104*CheapSinD2(a2))/Power(a,2);
}

inline double IntegralR9C_D2_ONE(const int a2) {
  if (a2 == 0)
    return 0.1;
  
  const double a = a2*0.5;

  return -3.8749339658435145/Power(a,10) + (3.8749339658435145*CheapCosD2(a2))/Power(a,10) - (19.122032661609893*CheapCosD2(a2))/Power(a,8) + 
   (15.72724147623329*CheapCosD2(a2))/Power(a,6) - (5.174055056360905*CheapCosD2(a2))/Power(a,4) + 
   (0.91189065278104*CheapCosD2(a2))/Power(a,2) + (12.173464080239548*CheapSinD2(a2))/Power(a,9) - 
   (20.024545777139245*CheapSinD2(a2))/Power(a,7) + (9.88171725659344*CheapSinD2(a2))/Power(a,5) - 
   (2.3221104791903637*CheapSinD2(a2))/Power(a,3) + (0.3183098861837907*CheapSinD2(a2))/a;
}

}  // TrigInt

#endif  // TRIG_INTEGRAL_H