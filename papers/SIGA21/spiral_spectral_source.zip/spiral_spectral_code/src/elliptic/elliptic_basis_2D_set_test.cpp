#include <Eigen/Eigen>

#include "2D/FIELD2D.h"
#include "2D/VFIELD2D.h"
#include "elliptic/elliptic_basis_set_2D.h"
#include "polar_2D/scomp_basis_set_2D.h"

using namespace std;


namespace {

void testBasisSet() {
  const int res = 128;

  const double b = 0.9;
  EllipticBasisSet2D basis(res, 8,8, true, b);
  
  SCompBasisSet2D polarB(128, 8,8, true);
  
  VFIELD2D temp2(res, res);
  const int numBasisOrtho = basis.GetnumBasisOrtho();
  Eigen::VectorXd basis_coefficients_ = Eigen::VectorXd::Zero(numBasisOrtho);
  //basis.InverseTramsformToVelocity(basis_coefficients_, &temp2);
  //polarB.InverseTramsformToVelocity(basis_coefficients_, &temp2);

  basis.ForwardTransformtoFrequency(temp2, &basis_coefficients_);
  polarB.ForwardTransformtoFrequency(temp2, &basis_coefficients_);

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  testBasisSet();
  LOG(INFO) << sizeof(Eigen::Vector2d);
  return 0;
}