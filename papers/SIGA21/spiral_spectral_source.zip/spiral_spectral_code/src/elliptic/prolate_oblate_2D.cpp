#include "common/query_table.h"
#include "elliptic/elliptic_basis_2D.h"
#include "elliptic/prolate_oblate_2D.h"
#include "elliptic/prolate_sphere_2D_share.h"
#include "sphere_3D/sphere_basis_3D.h"

void ProlateOblate2D::DiscretizeAdd(const double coef, VFIELD2D* vfield) const {
  const int nT = vfield->getyRes();
  const int nP = vfield->getxRes();
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double dT = M_PI / nT;
  double dP = 2.0*M_PI/nP;

  const double vtConst = (is_prolate_) ? 1.0/b_ : 1/(a_*sqrt(1.0 + c_*c_)); 
  for (int j = 0; j < nT; j++) {
    for (int i = 0; i < nP; i++) {
      double t = ((double)(j) + 0.5)*dT;   // [0-1]
      double p = ((double)(i) + 0.5)*dP;// - M_PI;  // [0, 2*pi]
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;

      const double vpConst = (is_prolate_) ? 1.0/(a_*sqrt(c_*c_ + sin(t)*sin(t))) : 1.0/(a_*sqrt(c_*c_ + cos(t)*cos(t)));
      v[0] *= vtConst;
      v[1] *= vpConst;

      v *= coef*invNorm_;
      (*vfield)(i,j)[0] = v[0];
      (*vfield)(i,j)[1] = v[1];
    }
  }
}

void ProlateOblate2D::AddUniformU(const double coef, const int nT, const int nP, double* ut, double* up) const {
  double dT = M_PI / nT;
  double dP = 2.0*M_PI/nP;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;

  const double vtConst = (is_prolate_) ? 1.0/b_ : 1/(a_*sqrt(1.0 + c_*c_));

  for (int j = 0; j < nT; j++) {
    for (int i = 0; i < nP; i++) {
      double t = ((double)(j) + 0.5)*dT;   // [0-1]
      double p = ((double)(i) + 0.5)*dP;// - M_PI;  // [0, 2*pi]
      const double vpConst = (is_prolate_) ? 1.0/(a_*sqrt(c_*c_ + sin(t)*sin(t))) : 1.0/(a_*sqrt(c_*c_ + cos(t)*cos(t)));

      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      
      v[0] *= vtConst;
      v[1] *= vpConst;

      v *= coef*invNorm_;
      ut[i + j*nP] += v[0];
      up[i + j*nP] += v[1];
    }
  }
}

double ProlateOblate2D::ProjectUniformU(const int nT, const int nP, double* fr, double* ft) const {
  double dT = M_PI / nT;
  double dP = 2.0*M_PI/nP;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double result = 0;

  const double vtConst = (is_prolate_) ? 1.0/b_ : 1/(a_*sqrt(1.0 + c_*c_));

  for (int j = 0; j < nT; j++) {
    for (int i = 0; i < nP; i++) {
      double t = ((double)(j) + 0.5)*dT;   // [0-1]
      double p = ((double)(i) + 0.5)*dP;// - M_PI;  // [0, 2*pi]
      const double vpConst = (is_prolate_) ? 1.0/(a_*sqrt(c_*c_ + sin(t)*sin(t))) : 1.0/(a_*sqrt(c_*c_ + cos(t)*cos(t)));

      Eigen::Vector2d v;
      v.setZero();
      computeBasis;

      v[0] *= vtConst;
      v[1] *= vpConst;

      result += (v[0]*fr[i + j*nP] + v[1]*ft[i + j*nP]);
    }
  }

  result *= invNorm_;
  result *= dT*dP;

  return result;
}
  
double ProlateOblate2D::computeVThetaInt(const std::vector<BasicFunc>& t1, const EllipticFactor& ef,
                              const bool withJacobian, const IntTable1DData& tabData) const {
  double result = 0;
  for (const auto& fun1 : t1)
      result += computeThetaInt(fun1, ef, withJacobian, tabData);

  return result;
}

void ProlateOblate2D::computeVThetaPattern(const std::vector<BasicFunc>& t1, const EllipticFactor& ef,
                                          const bool withJacobian, std::unordered_set<uint64_t>& set) {
  for (const auto& fun1 : t1)
      computeThetaPattern(fun1, ef, withJacobian, set);
}

// int_{\theta = 0}^{Pi} fun1*sin(\theta) d\theta 
double ProlateOblate2D::computeThetaInt(const BasicFunc& fun1, const EllipticFactor& ef, const bool withJacobian,
                              const IntTable1DData& tabData) const {
  CHECK(fun1.dir == T);

  BasicFunc sinT(SIN, T, 2, 1.0);
  std::vector<BasicFunc> addVec;
  EllipticFactor efCpy = ef;
  if (withJacobian) {
    addVec = BasicFunc::multiply(fun1, sinT);
    if (is_prolate_) efCpy *= tabData.a*tabData.b; // abhSin(t)
    else efCpy *= tabData.a*tabData.a*sqrt(1.0 + tabData.c*tabData.c);  // a*a*sqrt(1+c*c)h_c sin(t)
    efCpy.hPow_ += 1;
  } else {
    addVec = {fun1};
  }

  double result = 0;

  for (const auto& f : addVec) {
    // query the table.
    FUNTYPE type = f.type;
    int wn = f.wnx2/2;

    if (type == ZERO || (type == SIN && wn%2 == 0) || (type == COS && wn%2 != 0))
      continue;
    // analytically integrate.
    if (efCpy.hPow_ == 0 && efCpy.sqrtCRPow_ == 0)
      result += efCpy.coef_*f.integrate();
    else
      result += tabData.queryTable(efCpy, f);
  }
  return result;
}

void ProlateOblate2D::computeThetaPattern(const BasicFunc& fun1, const EllipticFactor& ef,
                                         const bool withJacobian, std::unordered_set<uint64_t>& set) {
  CHECK(fun1.dir == T);

  BasicFunc sinT(SIN, T, 2, 1.0);
  std::vector<BasicFunc> addVec;
  EllipticFactor efCpy = ef;
  if (withJacobian) {
    addVec = BasicFunc::multiply(fun1, sinT);
    //efCpy *= a_*b_;
    efCpy.hPow_ += 1;
  } else {
    addVec = {fun1};
  }

  for (const auto& f : addVec) {
    FUNTYPE ftype = f.type;
    if (ftype == ZERO)
      continue;
    if (ftype == ONE)
      ftype = COS;
    // analytically integrate.
    if (efCpy.hPow_ == 0 && efCpy.sqrtCRPow_ == 0)
      continue;
    uint64_t hash = EllipticBasis2D::tripleInfoToHash(efCpy.hPow_, efCpy.sqrtCRPow_, 0, ftype, ONE);
    set.insert(hash);
  }
}

double ProlateOblate2D::dotProd(const ProlateOblate2D& other, const IntTable1DData& tabData) const {
  Eigen::Vector2d result(0,0);

  for (int i = 0; i < 2; i++) {
    // <phi_i, phi_i>    
    double pINT = SphereBasis3D::computePhiInt(phiFunc_[i], other.getPhiFunc(i));
    if (pINT == 0)
      result[i] = 0.0;
    else {
      // compute the ellipticfactor mult, in case of dot prod, h is only a function of theta
      // therefore the integration is seperable.
      EllipticFactor efM = eFact_[i];
      efM *= other.getEFactor(i);
      // then integrate along theta.
      double rtINT = 0;
      std::vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
      for (const auto& rt : RTProd)
        rtINT += computeVThetaInt(rt.tComp, efM, true, tabData);

      result[i] = pINT*rtINT;
    }
  }
  
  return result.sum();
}

void ProlateOblate2D::dotProdPattern(const ProlateOblate2D& other, std::unordered_set<uint64_t>& set) const {

  for (int i = 0; i < 2; i++) {
    // compute the ellipticfactor mult, in case of dot prod, h is only a function of theta
    // therefore the integration is seperable.
    EllipticFactor efM = eFact_[i];
    efM *= other.getEFactor(i);
    // then integrate along theta.
    std::vector<RTMultiply> RTProd = RTMultiply::multV(RT_[i], other.getRT(i));
    for (const auto& rt1 : RTProd)
      computeVThetaPattern(rt1.tComp, efM, true, set);
  }
}

void ProlateOblate2D::curlSph() {
  // cos(theta), sin(theta), cos(3*theta)
  BasicFunc cosT(COS, T, 2, 1.0, 0);
  BasicFunc sinT(SIN, T, 2, 1.0, 0);
  BasicFunc cos3T(COS, T, 6, 1.0, 0);
  const double sqrtC = sqrt(1.0 + c_*c_);

  if (is_prolate_) {
    // sign is grouped into phi func
    curlPhi_[0] = phiFunc_[1];
    curlPhi_[1] = phiFunc_[1];
    curlPhi_[2] = -phiFunc_[0].deriv()[0];
    curlPhi_[3] = -phiFunc_[1];
    curlPhi_[4] = phiFunc_[1];

    curlRT_[0] = RT_[1];  // u_p
    RTMultiply::multThetaVec(cosT, curlRT_[0]);  //cos(t)*u_p

    curlRT_[1] = RT_[1];  // u_p
    RTMultiply::derivTVec(curlRT_[1]);  // D[u_p, t]
    RTMultiply::multThetaVec(sinT, curlRT_[1]);  //sin(t)*D[u_p, t]

    curlRT_[2] = RT_[0]; // u_t

    curlRT_[3] = RT_[1]; // u_p
    RTMultiply::multThetaVec(cosT, curlRT_[3]);  //cos(t)*u_p

    curlRT_[4] = RT_[1]; // u_p
    RTMultiply::multThetaVec(cos3T, curlRT_[4]);  //cos(3t)*u_p

    // sign is already grouped.
    curlEF_[0] = EllipticFactor(-1, 0, 0, c_);
    curlEF_[1] = curlEF_[0];
    curlEF_[2] = EllipticFactor(1, 0, 0, 1.0/c_); 
    curlEF_[3] = EllipticFactor(-3, 0, 0, c_*0.25);
    curlEF_[4] = EllipticFactor(-3, 0, 0, c_*0.25);

    crossEF_ = EllipticFactor(-1, 0, 0, 1.0/a_/b_);

  } else {   // oblate
    // sign is grouped into phi func
    curlPhi_[0] = phiFunc_[1];
    curlPhi_[1] = phiFunc_[1];
    curlPhi_[2] = -phiFunc_[0].deriv()[0];
    curlPhi_[3] = phiFunc_[1];
    curlPhi_[4] = -phiFunc_[1];

    curlRT_[0] = RT_[1];  // u_p
    RTMultiply::multThetaVec(cosT, curlRT_[0]);  //cos(t)*u_p

    curlRT_[1] = RT_[1];  // u_p
    RTMultiply::derivTVec(curlRT_[1]);  // D[u_p, t]
    RTMultiply::multThetaVec(sinT, curlRT_[1]);  //sin(t)*D[u_p, t]

    curlRT_[2] = RT_[0]; // u_t

    curlRT_[3] = RT_[1]; // u_p
    RTMultiply::multThetaVec(cosT, curlRT_[3]);  //cos(t)*u_p
    
    curlRT_[4] = RT_[1]; // u_p
    RTMultiply::multThetaVec(cos3T, curlRT_[4]);  //cos(3t)*u_p
    
    // sign is already grouped.
    curlEF_[0] = EllipticFactor(-1, 0, 0, sqrtC);
    curlEF_[1] = curlEF_[0];
    curlEF_[2] = EllipticFactor(1, 0, 0, 1.0/sqrtC); 
    curlEF_[3] = EllipticFactor(-3, 0, 0, sqrtC*0.25);
    curlEF_[4] = EllipticFactor(-3, 0, 0, sqrtC*0.25);

    crossEF_ = EllipticFactor(-1, 0, 0, 1.0/a_/a_/sqrtC);
  }
}

double ProlateOblate2D::integrateCurlCross(const BasicFunc& curlP, const std::vector<BasicFunc>& crossP,
                                 const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT,
                                 const EllipticFactor& curlEF, const EllipticFactor& crossEF, const IntTable1DData& tabData) const {
  // first integrate along phi.
  // int_{phi = 0}^{2 \Pi} fun1(i1*\phi)*fun2(i2*\phi) d\phi 
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += SphereBasis3D::computePhiInt(curlP, cp);
  if (fabs(phiInt) < 1e-14)
    return 0.0;

  EllipticFactor efM  = curlEF;
  efM *= crossEF;

  // integrate along theta, without sin(t) term, because its already in curl.
  double rtInt = 0;
  std::vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  // ef*std::vector<basicFunc>
  for (const auto& rt : RTProd) {
    rtInt += computeVThetaInt(rt.tComp, efM, false, tabData);
  }

  return phiInt*rtInt;
}

void ProlateOblate2D::patternCurlCross(const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT,
                                       const EllipticFactor& curlEF, const EllipticFactor& crossEF, std::unordered_set<uint64_t>& set) {
  
  std::vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  EllipticFactor efM  = curlEF;
  efM *= crossEF;

  // no jacobian, as jacobian is already in curl
  // efM*std::vector<basicFunc>
  for (const auto& rt : RTProd) {
    computeVThetaPattern(rt.tComp, efM, false, set);
  }

}

double ProlateOblate2D::computeTensorEntry(const ProlateOblate2D& phiG,
       const ProlateOblate2D& phiH, const IntTable1DData& tabData) {
  // crossEF_*crossPhi[0]*crossRT[0] + crossEF_*crossPhi[1]*crossRT[1];
  // compute cross product.
  std::vector<BasicFunc> crossPhi[2];
  std::vector<RTMultiply> crossRT[2];
  SphereBasis2DAll::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis2DAll::crossProdRT(phiG, phiH, crossRT);
  // curlEF_[i]*curlPhi_[i]*curlRT_[i];
  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 5; ind++) {
    rVal += integrateCurlCross(curlPhi_[ind], crossPhi[0], curlRT_[ind], crossRT[0],
                                                curlEF_[ind], phiG.getcrossEF(), tabData);
    rVal += integrateCurlCross(curlPhi_[ind], crossPhi[1], curlRT_[ind], crossRT[1],
                                                curlEF_[ind], phiG.getcrossEF(), tabData);
  }

  return (rVal)*invNorm_*phiG.GetInvNorm()*phiH.GetInvNorm();
}

void ProlateOblate2D::computeTensorPattern(const ProlateOblate2D& phiI, const ProlateOblate2D& phiG,
     const ProlateOblate2D& phiH, std::unordered_set<uint64_t>& set) {
  // crossEF_*(crossPhi[0]*crossRT[0] + crossPhi[1]*crossRT[1]);
  // compute cross product.
  std::vector<BasicFunc> crossPhi[2];
  std::vector<RTMultiply> crossRT[2];
  SphereBasis2DAll::crossProdPhi(phiG, phiH, crossPhi);
  SphereBasis2DAll::crossProdRT(phiG, phiH, crossRT);
  // curlEF_[i]*curlPhi_[i]*curlRT_[i]*;
  // crossEF_*(crossPhi[0]*crossRT[0] + crossPhi[1]*crossRT[1])
  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 5; ind++) {
    // curlEF_[i]*curlRT_[i]*crossEF_*(crossRT[0] + crossRT[1])
    ProlateOblate2D::patternCurlCross(phiI.getCurRT(ind), crossRT[0], phiI.getcurlEF(ind), phiG.getcrossEF(), set);
    ProlateOblate2D::patternCurlCross(phiI.getCurRT(ind), crossRT[1], phiI.getcurlEF(ind), phiG.getcrossEF(), set);
  }
}

ProlateOblate2D* ProlateOblate2D::fromFile(std::ifstream& in, const IntTable1DData& tabData, const bool is_prolate) {
  int k1x2, k2x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));
  return new ProlateOblate2D(k1x2, k2x2, index_, tabData, is_prolate);
}