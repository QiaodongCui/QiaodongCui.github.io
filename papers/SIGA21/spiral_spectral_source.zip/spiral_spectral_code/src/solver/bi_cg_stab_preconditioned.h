#ifndef BI_CG_STAB_PRECONDITIONED_H
#define BI_CG_STAB_PRECONDITIONED_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>

#include "integrator_2d.h"
#include "setting.h"

// This class is to implement a preconditioned version of matrix solver.
// It tries to use I + P*dt as a preconditioner. It remains to be seen
// Whether this will work.

class BiCGSTABPreconditioned : public Integrator2D{
public:
  BiCGSTABPreconditioned(){};
  ~BiCGSTABPreconditioned(){};
  void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) override;
protected:
  
};

#endif
