#include <Eigen/Eigen>

#include "2D/FIELD2D.h"
#include "2D/VFIELD2D.h"
#include "common/query_table.h"
#include "elliptic/prolate_oblate_3D.h"
#include "elliptic/elliptic_basis_set_2D.h"
#include "polar_2D/scomp_basis_set_2D.h"

using namespace std;


namespace {

std::vector<std::string> DataNames = {
"Pro2D04_T_1.bin",
"Pro2D04_T_2.bin",
"Pro2D04_T_3.bin",
"Pro2D04_T_4.bin",
"Pro2D04_T_5.bin",
};

std::vector<std::string> PatternNames = {
"prolate_tensor_2D_1.txt",
"prolate_tensor_2D_2.txt",
"prolate_tensor_2D_3.txt",
"prolate_tensor_2D_4.txt",
"prolate_tensor_2D_5.txt",
};

void mergeTensorTable() {

  std::ofstream outDat("./Tensor/tables/tmp/Pro2D04_T.bin");
  std::ofstream out("./Tensor/tables/tmp/prolate_tensor_2D.txt");
  
  int oneSetSize = 0;
  std::ifstream in("./Tensor/tables/prolate3D/TensorListWn.csv");
  in >> oneSetSize;
  in.close();
  std::unordered_set<uint64_t> totalPattern;
  
  for (int i = 0; i < PatternNames.size(); i++) {
    std::ifstream in("./Tensor/tables/tmp/" + PatternNames[i]);
    int hpow, sqrtPow, rpow;
    int rType, tType;
    int setSize = 0;
    while (in >> hpow && in >> sqrtPow && in >> rpow && in >> rType && in >> tType) {
      uint64_t hash = EllipticBasis2D::tripleInfoToHash(hpow, sqrtPow, rpow, static_cast<FUNTYPE>(rType), static_cast<FUNTYPE>(tType));
      totalPattern.insert(hash);
      out << hpow << " " << sqrtPow << " " << rpow << " " << rType << " " << tType << "\n";
      setSize++;
    }
    in.close();
    
    // merge the data
    std::ifstream inDat("./Tensor/tables/tmp/" + DataNames[i], ios::binary);
    double* buf;
    buf = (double*)malloc(sizeof(double)*setSize*oneSetSize);
    inDat.read((char*)(buf), sizeof(double)*setSize*oneSetSize);
    outDat.write((char*)(buf), sizeof(double)*setSize*oneSetSize);
    free(buf);
  }

  outDat.close();
  out.close();
  //LOG(INFO) << "totalPatternsize: " << totalPattern.size();
}

void mergeTensor1() {
  std::vector<std::string> PatternNames = {"prolate_tensor_pow2.txt", "prolate_tensor_2D.txt"};
  std::vector<std::string> DataNames = {"Pro2D09_T_7.bin", "Pro2D09_T.bin"};
  
  int oneSetSize = 0;
  std::ifstream in("./Tensor/tables/prolate3D/TensorListWn.csv");
  in >> oneSetSize;
  in.close();

  
  std::ofstream out("./Tensor/tables/prolate3D/prolate_tensor_2D_M.txt");
  std::ofstream outDat("./Tensor/tables/prolate3D/Pro2D09_M.bin");

  for (int i = 0; i < PatternNames.size(); i++) {
    std::ifstream in("./Tensor/tables/prolate3D/" + PatternNames[i]);
    int hpow, sqrtPow, rpow;
    int rType, tType;
    int setSize = 0;
    while (in >> hpow && in >> sqrtPow && in >> rpow && in >> rType && in >> tType) {
      out << hpow << " " << sqrtPow << " " << rpow << " " << rType << " " << tType << "\n";
      setSize++;
    }
    in.close();
    
    // merge the data
    std::ifstream inDat("./Tensor/tables/prolate3D/" + DataNames[i], ios::binary);
    double* buf;
    buf = (double*)malloc(sizeof(double)*setSize*oneSetSize);
    inDat.read((char*)(buf), sizeof(double)*setSize*oneSetSize);
    outDat.write((char*)(buf), sizeof(double)*setSize*oneSetSize);
    free(buf);
  }
  outDat.close();
  out.close();
}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  mergeTensorTable();
  return 0;
}