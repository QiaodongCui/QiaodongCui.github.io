#ifndef OBSTACLE_SPHERE_CYL_H
#define OBSTACLE_SPHERE_CYL_H

#include <Eigen/Eigen>
#include <vector>

#include "3D/VECTOR3_FIELD_3D.h"
#include "common/particle_sph_3d.h"
#include "util/util.h"

class ObstacleSphereCyl {
public:
  ObstacleSphereCyl(const Eigen::Vector3d& center, const double radius):
  center_(center), radius_(radius) {
    Init();
  }
  
  ObstacleSphereCyl(const std::string& locations, const double radius, const double dt);

  ~ObstacleSphereCyl(){};
  // Calculate the normal component of a given velocity field along the 
  // border of the obstacles. This function won't clear the content of
  // normal_component. Instead it will add the addtion value to it.
  void CalculateNormalForce(const int nR, const int nTheta, const int nZ, const double* vr, const double* vt, const double* vz,
                            const double amp, const double b, const double scale,
                            VECTOR3_FIELD_3D& f) const;
  
  void SetNormalForce(const int nR, const int nTheta, const int nZ, const double* vr, const double* vt, const double* vz,
                            const double amp, const double b, const double scale,
                            VECTOR3_FIELD_3D& f) const;

  // is the passed in point inside the sphere?
  bool inside(const Eigen::Vector3d& point) const ;

  void SetVelocity(const Eigen::Vector3d& velo) {
    velocity_ = velo;
  }
  void SetPosition(const Eigen::Vector3d& pos) {
    center_ = pos;
  }
  void move(const double dt) {
    center_ += velocity_*dt;
  }

  void update() {
    index ++;
    if (index < locations_.size()) {
      center_ = locations_[index];
      velocity_ = velocitys_[index];
    }
  }
  
  void updateTrace(std::vector<ParticleSph3D>& particles_, const int start, const int end) {
    Eigen::Vector3d curPos = center_;
    Eigen::Vector3d prevPos = center_;
    const int prevIdx = index - 1;
    if (index >= 0 && index < locations_.size())
      prevPos =locations_[prevIdx];
    for (int i = start; i < end && i < particles_.size(); i++)
      particles_[i].position += (curPos - prevPos);
  }

  Eigen::Vector3d getSurfaceSamples(std::default_random_engine &gen) {
    Eigen::Vector3d pos = sampleOnSphere(gen);
    pos *= radius_;
    pos += center_;
    return pos;
  }

protected:
  void Init();
  int index = 0;
  // in Cartesian cord.
  Eigen::Vector3d center_;
  Eigen::Vector3d original_center_;
  double radius_;
  double radius_squared_;
  const double interalRatio_ = 0.95;
  // in Cartesian cord.
  Eigen::Vector3d velocity_;
  
  std::vector<Eigen::Vector3d> locations_;
  std::vector<Eigen::Vector3d> velocitys_;

};

#endif  // OBSTACLE_SPHERE_CYL_H
