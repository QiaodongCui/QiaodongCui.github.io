#include <cmath>
#include <glog/logging.h>
#include <float.h>
#include <Eigen/Eigen>
#include <vector>

#include "3D/laplacian_basis_set_3d.h"
#include "setting.h"
#include "util/util.h"

void LaplacianBasisSet3D::MultiplyweightTensor(std::vector<Adv_Tensor_Type>& C, const Eigen::VectorXd& weights) {
  CHECK_EQ(C.size(), weights.size());
  //CHECK_EQ(weights.size(), basis_dim_);
  Eigen::MatrixXd WW(weights.size(), weights.size());
  WW = weights * weights.transpose();
  
  for (int k = 0; k < weights.size(); k++) {
    Adv_Tensor_Type Cknew = weights[k] * C[k].cwiseProduct(WW);
    Cknew.makeCompressed();
    C[k] = Cknew;
  }
}

void LaplacianBasisSet3D::VerifyAntisymmetric(const std::vector<Adv_Tensor_Type>& C) {
  int num_non_zero = 0;
  double max_entries = FLT_MIN;
  for (int i = 0; i < basis_dim_; i++) {
    for (int g = 0; g < basis_dim_; g++) {
      for (int h = 0; h < basis_dim_; h++) {
        double Cigh = AccessMatrix(C[i],g,h);
        if (Cigh != 0) {
          num_non_zero ++;
          double Cihg = AccessMatrix(C[i],h,g);
          if ((Cigh + Cihg) > 1e-10) {
            LOG(INFO) << "Non symeetric entries found.";
          }
          if (! isfinite(Cigh)) {
            LOG(INFO) << "Nan found";
          }
          if (std::abs(Cigh) > max_entries) {
            max_entries = std::abs(Cigh);
          }
        }
      }
    }
  }
  LOG(INFO) << "Number of non-zero elements in tensor: " << num_non_zero
      << " Maximum abs entry: " << max_entries;
}
