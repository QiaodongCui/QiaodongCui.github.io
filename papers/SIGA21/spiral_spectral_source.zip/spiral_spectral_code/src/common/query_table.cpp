#include <algorithm>
#include <utility>

#include "elliptic/elliptic_basis_2D.h"
#include "common/query_table.h"
#include "util/util.h"

using namespace std;

double IntTable1DData::queryTable(const EllipticFactor& ef, const BasicFunc& fun) const {
  return tab->queryTable(ef, fun, bidx);
}

IntegrationTable1DPtn::IntegrationTable1DPtn(const string& bName, const string& kName,
                     const string& datName, const string& ptnName) {
 // load b.
  ifstream in(bName);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << bName;
  // load number of b.
  in >> nBValues_;
  bList_ = (double*)malloc(sizeof(double)*nBValues_);
  memset(bList_, 0x00, sizeof(double)*nBValues_);
  for (int i = 0; i < nBValues_; i++)
    in >> bList_[i];

  in.close();
  // load range of wanumbersx2
  in.open(kName);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << kName;

  in >> nKValues_;
  in >> k1x2Min_;
  for (int i = 0; i < nKValues_; i++)
    in >> k1x2Max_;
  in.close();
  k1Delta_ = (k1x2Max_ - k1x2Min_)/(nKValues_ -1);

  in.open(ptnName);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << ptnName;
  int hpow, sqrtPow, rpow;
  int rType, tType;
  int idx = 0;
  while (in >> hpow && in >> sqrtPow && in >> rpow && in >> rType && in >> tType) {
    hashToIdx[EllipticBasis2D::tripleInfoToHash(hpow, sqrtPow, rpow, static_cast<FUNTYPE>(rType), ONE)] = idx++;
  }
  in.close();

  in.open(datName, ios::binary);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << datName;
  setSize_ = nBValues_*nKValues_;
  data_ = (double*)malloc(sizeof(double)*hashToIdx.size()*setSize_);
  memset(data_, 0x00, sizeof(double)*hashToIdx.size()*setSize_);
  CHECK(getFileSize(datName) == sizeof(double)*hashToIdx.size()*setSize_) << "file size mismatch. " << datName;
  in.read(reinterpret_cast<char*>(data_), sizeof(double)*hashToIdx.size()*setSize_);
  in.close();
}

double IntegrationTable1DPtn::queryTable(const EllipticFactor& ef, const BasicFunc& fun, const int bIdx) const {
  int rpow = ef.rPow_ + fun.rPower;

  int sgn = (fun.type == SIN && fun.wnx2 < 0) ? -1 : 1;
  int absWn2 = abs(fun.wnx2);
  CHECK(absWn2 <= k1x2Max_);

  FUNTYPE type = fun.type;
  if (type == ZERO)
    return 0;
  if (type == ONE) {
    absWn2 = 0;
    type = COS;
  }

  double coef = ef.coef_*fun.coef;

  uint64_t hash = EllipticBasis2D::tripleInfoToHash(ef.hPow_, ef.sqrtCRPow_, rpow, static_cast<FUNTYPE>(type), ONE);

  unordered_map<uint64_t, int>::const_iterator it = hashToIdx.find(hash);
  if (it != hashToIdx.end()) {
    return sgn*data_[it->second*setSize_ + bIdx*nKValues_ + absWn2/k1Delta_]*coef;
  } else {
    LOG(FATAL) << "pattern not found " << ef.hPow_ << " " << ef.sqrtCRPow_ << " " <<  rpow << " " << type;
  }

  return 0;
}

// do a binary search to see if b is in the list
int IntegrationTable1DPtn::findBidx(const double bq) const {
  int l = 0;
  int r = nBValues_;
  while (l < r) {
    int m = (l+r)/2;
    if (bList_[m] > bq)
      r = m;
    else
      l = m+1;
  }

  // r-1
  if (abs(bList_[r-1] - bq) < 1e-6)
    return r-1;
  else if (r < nBValues_ && abs(bList_[r] - bq) < 1e-6)
    return r;
  else {
    LOG(FATAL) << "cant find close enough b val";
    return 0;
  }
}

TensorTable2D::TensorTable2D(const string& kName, const double& bwant, const string& blistTableName,
                             const string& ptnName, const bool theta_2Pi):theta_2Pi_(theta_2Pi) {
	// load different patterns.
  ifstream in(ptnName);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << ptnName;
  int hpow, sqrtPow, rpow;
  int rType, tType;
  int idx = 0;

  while (in >> hpow && in >> sqrtPow && in >> rpow && in >> rType && in >> tType) {
    hashToIdx[EllipticBasis2D::tripleInfoToHash(hpow, sqrtPow, rpow, static_cast<FUNTYPE>(rType), static_cast<FUNTYPE>(tType))] = idx++;
  }
  in.close();

  // load range of wanumbersx2
  in.open(kName);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << kName;
  in >> setSize_; 
  in >> k1x2Min_; in >> k1x2Max_; in >> k1Delta_;
  in >> k2x2Min_; in >> k2x2Max_; in >> k2Delta_;
  nk1_ = (k1x2Max_ - k1x2Min_)/k1Delta_ + 1;
  nk2_ = (k2x2Max_ - k2x2Min_)/k2Delta_ + 1;
  CHECK(nk1_*nk2_ == setSize_);
  in.close();

  in.open(blistTableName);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << blistTableName;
  double bval; string bTabName;
  while(in >> bval && in >> bTabName) {
    listOfDat_.push_back(make_pair(bval, bTabName));
  }
  sort(listOfDat_.begin(), listOfDat_.end(), [](const pair<double, string>& a, const pair<double, string>& b){
    return a.first < b.first;
  });
  // linear search the list of b values, this is only for loading.
  string fname = "";
  for (int i = 0; i < listOfDat_.size(); i++) {
    if (fabs(listOfDat_[i].first - bwant) < 1e-6) {
      fname = listOfDat_[i].second;
      break;
    }
  }
  CHECK(fname != "") << "cant find close enough b val";
  in.close();
  CHECK(getFileSize(fname) == sizeof(double)*hashToIdx.size()*setSize_) << "file size mismatch.";
  //setSize_ = nk1_*nk2_;
  in.open(fname, ios::binary);
  if (! in.is_open())
    LOG(FATAL) << "cannot open " << fname;

  data_ = (double*)malloc(sizeof(double)*hashToIdx.size()*setSize_);
  memset(data_, 0x00, sizeof(double)*hashToIdx.size()*setSize_);
  in.read(reinterpret_cast<char*>(data_), sizeof(double)*hashToIdx.size()*setSize_);
  in.close();
  LOG(INFO) << setSize_ << " " << hashToIdx.size();
  verifyTable();
}

void TensorTable2D::verifyTable() {
  double maxAbs = -1.0;
  for (int i = 0 ; i < hashToIdx.size()*setSize_; i++) {
    CHECK(isfinite(data_[i]));
    if (abs(data_[i]) > maxAbs)
      maxAbs = abs(data_[i]);
  }
  LOG(INFO) << "tableMax abs: " << maxAbs;
}

double TensorTable2D::queryTable(const EllipticFactor& ef, const BasicFunc& rf, const BasicFunc& tf) const {

  if (rf.type == ZERO || tf.type == ZERO) {
    return 0;
  }
  // zero.
  if ((tf.type == SIN || tf.wnx2 % 4 != 0) && theta_2Pi_) {
    return 0;
  }

  if (((tf.type == SIN && tf.wnx2 % 4 == 0) || (tf.type == COS && tf.wnx2 % 4 != 0)) && !theta_2Pi_) {
    return 0;
  }

  FUNTYPE rType = rf.type;
  FUNTYPE tType = tf.type;
  int rwnx2 = rf.wnx2;
  int twnx2 = tf.wnx2;
  if (rType == ONE) {
    rType = COS;
    rwnx2 = 0;
  }
  if (tType == ONE) {
    tType = COS;
    twnx2 = 0;
  }

  int rpow = ef.rPow_ + rf.rPower;
  int hpow = ef.hPow_;
  int sqrtPow = ef.sqrtCRPow_;
  uint64_t hash = EllipticBasis2D::tripleInfoToHash(hpow, sqrtPow, rpow, rType, tType);
  unordered_map<uint64_t, int>::const_iterator it = hashToIdx.find(hash);
  if (it == hashToIdx.end()) {
    LOG(FATAL) << "cannot find pattern: " << hpow << " " << sqrtPow << " " <<  rpow;
    return 0;
  }
  // handle negative wavenumbers
  int kr = abs(rwnx2);
  int kt = abs(twnx2);
  int sgnR = (rType == SIN && rwnx2 < 0) ? -1 : 1;
  int sngT = (tType == SIN && twnx2 < 0) ? -1 : 1;
  
  if (kr > k1x2Max_ || kt > k2x2Max_)
    LOG(FATAL) << "outside of the range";

  int idx = (it->second)*setSize_ + kr/k1Delta_*nk2_ + kt/k2Delta_;

  double coef = ef.coef_*rf.coef*tf.coef;

  return data_[idx]*sgnR*coef*sngT;
}