#ifndef SPH2D_EVAL_P_H
#define SPH2D_EVAL_P_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define Sin2Pi TrigInt::IntegrateSin2Pi_D2
#define Cos2Pi TrigInt::IntegrateCos2Pi_D2
#define Pi M_PI


class sph2DpEval{
public:
sph2DpEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~sph2DpEval(){};
/* Sin[g2*p]Sin[i2*p]Cos[h2*p]*/
static double evalP_0(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2-i2x2)+Cos2Pi(g2x2+h2x2-i2x2)-Cos2Pi(g2x2-h2x2+i2x2)-Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[h2*p]Sin[i2*p]Cos[g2*p]*/
static double evalP_1(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(g2x2-h2x2-i2x2)+Cos2Pi(g2x2+h2x2-i2x2)+Cos2Pi(g2x2-h2x2+i2x2)-Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[g2*p]Sin[h2*p]Sin[i2*p]*/
static double evalP_2(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2-i2x2)+Sin2Pi(g2x2+h2x2-i2x2)+Sin2Pi(g2x2-h2x2+i2x2)-Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[i2*p]Cos[g2*p]Cos[h2*p]*/
static double evalP_3(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2-i2x2)-Sin2Pi(g2x2+h2x2-i2x2)+Sin2Pi(g2x2-h2x2+i2x2)+Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[i2*p]Cos[g2*p]*/
static double evalP_4(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-i2x2)+Sin2Pi(g2x2+i2x2))/2.;
};

/* Sin[2*p]Sin[i2*p]Cos[g2*p]*/
static double evalP_5(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2-i2x2)+Cos2Pi(2+g2x2-i2x2)-Cos2Pi(2-g2x2+i2x2)-Cos2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[g2*p]Sin[i2*p]Cos[2*p]*/
static double evalP_6(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(2-g2x2-i2x2)+Cos2Pi(2+g2x2-i2x2)+Cos2Pi(2-g2x2+i2x2)-Cos2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[i2*p]Cos[2*p]Cos[g2*p]*/
static double evalP_7(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2-i2x2)-Sin2Pi(2+g2x2-i2x2)+Sin2Pi(2-g2x2+i2x2)+Sin2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[2*p]Sin[g2*p]Sin[i2*p]*/
static double evalP_8(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2-i2x2)+Sin2Pi(2+g2x2-i2x2)+Sin2Pi(2-g2x2+i2x2)-Sin2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[g2*p]Sin[i2*p]*/
static double evalP_9(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-i2x2)-Cos2Pi(g2x2+i2x2))/2.;
};

/* Sin[i2*p]Cos[h2*p]*/
static double evalP_10(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(h2x2-i2x2)+Sin2Pi(h2x2+i2x2))/2.;
};

/* Sin[h2*p]Sin[i2*p]*/
static double evalP_11(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(h2x2-i2x2)-Cos2Pi(h2x2+i2x2))/2.;
};

/* 1*/
static double evalP_12(const int i2x2, const int g2x2, const int h2x2){
return 2*Pi;
};

/* Sin[i2*p]Cos[2*p]*/
static double evalP_13(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-i2x2)+Sin2Pi(2+i2x2))/2.;
};

/* Sin[2*p]Sin[i2*p]*/
static double evalP_14(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-i2x2)-Cos2Pi(2+i2x2))/2.;
};

/* Sin[2*p]Sin[i2*p]Cos[h2*p]*/
static double evalP_15(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-h2x2-i2x2)+Cos2Pi(2+h2x2-i2x2)-Cos2Pi(2-h2x2+i2x2)-Cos2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[h2*p]Sin[i2*p]Cos[2*p]*/
static double evalP_16(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(2-h2x2-i2x2)+Cos2Pi(2+h2x2-i2x2)+Cos2Pi(2-h2x2+i2x2)-Cos2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[2*p]Sin[h2*p]Sin[i2*p]*/
static double evalP_17(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-h2x2-i2x2)+Sin2Pi(2+h2x2-i2x2)+Sin2Pi(2-h2x2+i2x2)-Sin2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[i2*p]Cos[2*p]Cos[h2*p]*/
static double evalP_18(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-h2x2-i2x2)-Sin2Pi(2+h2x2-i2x2)+Sin2Pi(2-h2x2+i2x2)+Sin2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[2*p]Sin[i2*p]Cos[2*p]*/
static double evalP_19(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(4-i2x2)-Cos2Pi(4+i2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Sin[i2*p]*/
static double evalP_20(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(4-i2x2)+2*Sin2Pi(i2x2)-Sin2Pi(4+i2x2))/4.;
};

/* Sin[i2*p]Cos[2*p]Cos[2*p]*/
static double evalP_21(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(4-i2x2)+2*Sin2Pi(i2x2)+Sin2Pi(4+i2x2))/4.;
};

/* Sin[g2*p]Cos[h2*p]Cos[i2*p]*/
static double evalP_22(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(g2x2-h2x2-i2x2)+Sin2Pi(g2x2+h2x2-i2x2)+Sin2Pi(g2x2-h2x2+i2x2)+Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[h2*p]Cos[g2*p]Cos[i2*p]*/
static double evalP_23(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2-i2x2)+Sin2Pi(g2x2+h2x2-i2x2)-Sin2Pi(g2x2-h2x2+i2x2)+Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[g2*p]Sin[h2*p]Cos[i2*p]*/
static double evalP_24(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2-i2x2)-Cos2Pi(g2x2+h2x2-i2x2)+Cos2Pi(g2x2-h2x2+i2x2)-Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Cos[g2*p]Cos[h2*p]Cos[i2*p]*/
static double evalP_25(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2-i2x2)+Cos2Pi(g2x2+h2x2-i2x2)+Cos2Pi(g2x2-h2x2+i2x2)+Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Cos[g2*p]Cos[i2*p]*/
static double evalP_26(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-i2x2)+Cos2Pi(g2x2+i2x2))/2.;
};

/* Sin[2*p]Cos[g2*p]Cos[i2*p]*/
static double evalP_27(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(2-g2x2-i2x2)+Sin2Pi(2+g2x2-i2x2)+Sin2Pi(2-g2x2+i2x2)+Sin2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[g2*p]Cos[2*p]Cos[i2*p]*/
static double evalP_28(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2-i2x2)+Sin2Pi(2+g2x2-i2x2)-Sin2Pi(2-g2x2+i2x2)+Sin2Pi(2+g2x2+i2x2))/4.;
};

/* Cos[2*p]Cos[g2*p]Cos[i2*p]*/
static double evalP_29(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2-i2x2)+Cos2Pi(2+g2x2-i2x2)+Cos2Pi(2-g2x2+i2x2)+Cos2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[2*p]Sin[g2*p]Cos[i2*p]*/
static double evalP_30(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2-i2x2)-Cos2Pi(2+g2x2-i2x2)+Cos2Pi(2-g2x2+i2x2)-Cos2Pi(2+g2x2+i2x2))/4.;
};

/* Sin[g2*p]Cos[i2*p]*/
static double evalP_31(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(g2x2-i2x2)+Sin2Pi(g2x2+i2x2))/2.;
};

/* Cos[h2*p]Cos[i2*p]*/
static double evalP_32(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(h2x2-i2x2)+Cos2Pi(h2x2+i2x2))/2.;
};

/* Sin[h2*p]Cos[i2*p]*/
static double evalP_33(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(h2x2-i2x2)+Sin2Pi(h2x2+i2x2))/2.;
};

/* Cos[2*p]Cos[i2*p]*/
static double evalP_34(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-i2x2)+Cos2Pi(2+i2x2))/2.;
};

/* Sin[2*p]Cos[i2*p]*/
static double evalP_35(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(2-i2x2)+Sin2Pi(2+i2x2))/2.;
};

/* Sin[2*p]Cos[h2*p]Cos[i2*p]*/
static double evalP_36(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(2-h2x2-i2x2)+Sin2Pi(2+h2x2-i2x2)+Sin2Pi(2-h2x2+i2x2)+Sin2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[h2*p]Cos[2*p]Cos[i2*p]*/
static double evalP_37(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-h2x2-i2x2)+Sin2Pi(2+h2x2-i2x2)-Sin2Pi(2-h2x2+i2x2)+Sin2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[2*p]Sin[h2*p]Cos[i2*p]*/
static double evalP_38(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-h2x2-i2x2)-Cos2Pi(2+h2x2-i2x2)+Cos2Pi(2-h2x2+i2x2)-Cos2Pi(2+h2x2+i2x2))/4.;
};

/* Cos[2*p]Cos[h2*p]Cos[i2*p]*/
static double evalP_39(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-h2x2-i2x2)+Cos2Pi(2+h2x2-i2x2)+Cos2Pi(2-h2x2+i2x2)+Cos2Pi(2+h2x2+i2x2))/4.;
};

/* Sin[2*p]Cos[2*p]Cos[i2*p]*/
static double evalP_40(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(4-i2x2)+Sin2Pi(4+i2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Cos[i2*p]*/
static double evalP_41(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(4-i2x2)+2*Cos2Pi(i2x2)-Cos2Pi(4+i2x2))/4.;
};

/* Cos[2*p]Cos[2*p]Cos[i2*p]*/
static double evalP_42(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(4-i2x2)+2*Cos2Pi(i2x2)+Cos2Pi(4+i2x2))/4.;
};

/* Sin[g2*p]Cos[h2*p]*/
static double evalP_43(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(g2x2-h2x2)+Sin2Pi(g2x2+h2x2))/2.;
};

/* Sin[h2*p]Cos[g2*p]*/
static double evalP_44(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2)+Sin2Pi(g2x2+h2x2))/2.;
};

/* Sin[g2*p]Sin[h2*p]*/
static double evalP_45(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2)-Cos2Pi(g2x2+h2x2))/2.;
};

/* Cos[g2*p]Cos[h2*p]*/
static double evalP_46(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2)+Cos2Pi(g2x2+h2x2))/2.;
};

/* Cos[g2*p]*/
static double evalP_47(const int i2x2, const int g2x2, const int h2x2){
return Cos2Pi(g2x2);
};

/* Sin[2*p]Cos[g2*p]*/
static double evalP_48(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(2-g2x2)+Sin2Pi(2+g2x2))/2.;
};

/* Sin[g2*p]Cos[2*p]*/
static double evalP_49(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2)+Sin2Pi(2+g2x2))/2.;
};

/* Cos[2*p]Cos[g2*p]*/
static double evalP_50(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2)+Cos2Pi(2+g2x2))/2.;
};

/* Sin[2*p]Sin[g2*p]*/
static double evalP_51(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2)-Cos2Pi(2+g2x2))/2.;
};

/* Sin[g2*p]*/
static double evalP_52(const int i2x2, const int g2x2, const int h2x2){
return Sin2Pi(g2x2);
};

/* Cos[h2*p]*/
static double evalP_53(const int i2x2, const int g2x2, const int h2x2){
return Cos2Pi(h2x2);
};

/* Sin[h2*p]*/
static double evalP_54(const int i2x2, const int g2x2, const int h2x2){
return Sin2Pi(h2x2);
};

/* Cos[2*p]*/
static double evalP_55(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*p]*/
static double evalP_56(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*p]Cos[h2*p]*/
static double evalP_57(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(2-h2x2)+Sin2Pi(2+h2x2))/2.;
};

/* Sin[h2*p]Cos[2*p]*/
static double evalP_58(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-h2x2)+Sin2Pi(2+h2x2))/2.;
};

/* Sin[2*p]Sin[h2*p]*/
static double evalP_59(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-h2x2)-Cos2Pi(2+h2x2))/2.;
};

/* Cos[2*p]Cos[h2*p]*/
static double evalP_60(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-h2x2)+Cos2Pi(2+h2x2))/2.;
};

/* Sin[2*p]Cos[2*p]*/
static double evalP_61(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*p]Sin[2*p]*/
static double evalP_62(const int i2x2, const int g2x2, const int h2x2){
return Pi;
};

/* Cos[2*p]Cos[2*p]*/
static double evalP_63(const int i2x2, const int g2x2, const int h2x2){
return Pi;
};

/* Sin[2*p]Sin[g2*p]Cos[h2*p]*/
static double evalP_64(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2-h2x2)-Cos2Pi(2+g2x2-h2x2)+Cos2Pi(2-g2x2+h2x2)-Cos2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[2*p]Sin[h2*p]Cos[g2*p]*/
static double evalP_65(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2-h2x2)+Cos2Pi(2+g2x2-h2x2)-Cos2Pi(2-g2x2+h2x2)-Cos2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[2*p]Sin[g2*p]Sin[h2*p]*/
static double evalP_66(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2-h2x2)+Sin2Pi(2+g2x2-h2x2)+Sin2Pi(2-g2x2+h2x2)-Sin2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[2*p]Cos[g2*p]Cos[h2*p]*/
static double evalP_67(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(2-g2x2-h2x2)+Sin2Pi(2+g2x2-h2x2)+Sin2Pi(2-g2x2+h2x2)+Sin2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Cos[g2*p]*/
static double evalP_68(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(4-g2x2)+2*Cos2Pi(g2x2)-Cos2Pi(4+g2x2))/4.;
};

/* Sin[2*p]Sin[g2*p]Cos[2*p]*/
static double evalP_69(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(4-g2x2)-Cos2Pi(4+g2x2))/4.;
};

/* Sin[2*p]Cos[2*p]Cos[g2*p]*/
static double evalP_70(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(4-g2x2)+Sin2Pi(4+g2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Sin[g2*p]*/
static double evalP_71(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(4-g2x2)+2*Sin2Pi(g2x2)-Sin2Pi(4+g2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Cos[h2*p]*/
static double evalP_72(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(4-h2x2)+2*Cos2Pi(h2x2)-Cos2Pi(4+h2x2))/4.;
};

/* Sin[2*p]Sin[h2*p]Cos[2*p]*/
static double evalP_73(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(4-h2x2)-Cos2Pi(4+h2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Sin[h2*p]*/
static double evalP_74(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(4-h2x2)+2*Sin2Pi(h2x2)-Sin2Pi(4+h2x2))/4.;
};

/* Sin[2*p]Cos[2*p]Cos[h2*p]*/
static double evalP_75(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(4-h2x2)+Sin2Pi(4+h2x2))/4.;
};

/* Sin[2*p]Sin[2*p]Cos[2*p]*/
static double evalP_76(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*p]Sin[2*p]Sin[2*p]*/
static double evalP_77(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[2*p]Cos[2*p]Cos[2*p]*/
static double evalP_78(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

/* Sin[g2*p]Cos[2*p]Cos[h2*p]*/
static double evalP_79(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2-h2x2)+Sin2Pi(2+g2x2-h2x2)-Sin2Pi(2-g2x2+h2x2)+Sin2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[h2*p]Cos[2*p]Cos[g2*p]*/
static double evalP_80(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(2-g2x2-h2x2)-Sin2Pi(2+g2x2-h2x2)+Sin2Pi(2-g2x2+h2x2)+Sin2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[g2*p]Sin[h2*p]Cos[2*p]*/
static double evalP_81(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(2-g2x2-h2x2)+Cos2Pi(2+g2x2-h2x2)+Cos2Pi(2-g2x2+h2x2)-Cos2Pi(2+g2x2+h2x2))/4.;
};

/* Cos[2*p]Cos[g2*p]Cos[h2*p]*/
static double evalP_82(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(2-g2x2-h2x2)+Cos2Pi(2+g2x2-h2x2)+Cos2Pi(2-g2x2+h2x2)+Cos2Pi(2+g2x2+h2x2))/4.;
};

/* Sin[g2*p]Cos[2*p]Cos[2*p]*/
static double evalP_83(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(4-g2x2)+2*Sin2Pi(g2x2)+Sin2Pi(4+g2x2))/4.;
};

/* Cos[2*p]Cos[2*p]Cos[g2*p]*/
static double evalP_84(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(4-g2x2)+2*Cos2Pi(g2x2)+Cos2Pi(4+g2x2))/4.;
};

/* Sin[h2*p]Cos[2*p]Cos[2*p]*/
static double evalP_85(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(4-h2x2)+2*Sin2Pi(h2x2)+Sin2Pi(4+h2x2))/4.;
};

/* Cos[2*p]Cos[2*p]Cos[h2*p]*/
static double evalP_86(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(4-h2x2)+2*Cos2Pi(h2x2)+Cos2Pi(4+h2x2))/4.;
};

/* Cos[2*p]Cos[2*p]Cos[2*p]*/
static double evalP_87(const int i2x2, const int g2x2, const int h2x2){
return 0;
};

};

#endif // SPH2D_EVAL_P_H