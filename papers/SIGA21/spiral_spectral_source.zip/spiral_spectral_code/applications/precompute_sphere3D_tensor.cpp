#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <string>
#include <sstream>
#include <math.h>
#include <memory>

#include "common/basis_set.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/sphere_basis_set_3D.h"
#include "sphere_3D/cylinder_basis_set_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"

#include "setting.h"
#include "util/util.h"
#include "util/read_write_tensor.h"
#include "util/timer.h"

using namespace Eigen;
using namespace std;

DEFINE_int32(basis_dim_des, 20, "The number of basis desired.");
DEFINE_string(basis_type, "sphere_3d_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");

DEFINE_string(boundaryCnd, "dirichlet", "The boundary condition, dirichlet or neumann.");

DEFINE_string(Tensor_file,"", "The folder to put the tensor, with slash.");
DEFINE_int32(rK, 2, "Number of modes along r");
DEFINE_int32(thetaK, 4, "Number of modes along theta.");
DEFINE_int32(phiK, 8, "Number of modes along phi.");
DEFINE_bool(usignRKTKPK, false, "Use specified rk, thetak, phiK");
DEFINE_double(b, 0.9, "The shorter axis.");
DEFINE_double(majorA, 3.0, "The major axis");
DEFINE_double(cylinderH, 2.0, "The height of the cylinder.");
DEFINE_int32(cylinder_bnd, 0, "The boundary condition of the cylinder");

namespace {

std::string strWithoutDot(const double b) {
  std::stringstream bSStr;
  bSStr << b;
  std::string bStr = bSStr.str();

  vector<char> wodotB;
  for (int i = 0; i < bStr.size(); i++) {
    if (bStr[i] != '.')
      wodotB.push_back(bStr[i]);
  }
  std::string bwoDot(wodotB.begin(), wodotB.end());
  return bwoDot;
}

}  // namespace

int main(int argc, char ** argv){
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);

  int radK = ceil(pow((double)(FLAGS_basis_dim_des)/8.0, 1.0/3.0));
  bool boundaryCnd = true;
  if (FLAGS_boundaryCnd == "dirichlet")
    boundaryCnd = true;
  if (FLAGS_boundaryCnd == "neumann")
    boundaryCnd = false;
  
  bool is_prolate = false, is_oblate = false;
  if (FLAGS_basis_type == "prolate_3d")
    is_prolate = true;
  else if (FLAGS_basis_type == "oblate_3d")
    is_oblate = true;
  else if (FLAGS_basis_type == "sphere_3d" || FLAGS_basis_type == "cylinder_3d" || FLAGS_basis_type == "torus_3d") {
    is_prolate = false;
    is_oblate = false;
  } else {
    LOG(FATAL) << "unknown type: " << FLAGS_basis_type;
  }
  const int xRes = 64;
  
  std::unique_ptr<BasisSet3D> basis;
  if (FLAGS_basis_type == "cylinder_3d") {
    if (! FLAGS_usignRKTKPK)
      basis.reset(new CylinderBasisSet3D(xRes/2, xRes, xRes, radK, radK*2, radK*2, FLAGS_cylinderH, true, FLAGS_cylinder_bnd));
    else
      basis.reset(new CylinderBasisSet3D(xRes/2, xRes, xRes, FLAGS_rK, FLAGS_thetaK, FLAGS_phiK, FLAGS_cylinderH, true, FLAGS_cylinder_bnd));
  } else if (FLAGS_basis_type == "torus_3d") {
    if (! FLAGS_usignRKTKPK)
      basis.reset(new TorusBasisSet3D(xRes/2, xRes, xRes, radK, radK*2, radK*4, FLAGS_majorA));
    else
      basis.reset(new TorusBasisSet3D(xRes/2, xRes, xRes, FLAGS_rK, FLAGS_thetaK, FLAGS_phiK, FLAGS_majorA));
  } else if (! is_oblate && ! is_prolate) {
    if (! FLAGS_usignRKTKPK)
      basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, radK,radK*2,radK*4, boundaryCnd));
    else
      basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, FLAGS_rK, FLAGS_thetaK, FLAGS_phiK, boundaryCnd));
  } else {
    if (! FLAGS_usignRKTKPK)
      basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, radK,radK*2,radK*4, boundaryCnd, is_prolate, is_oblate, FLAGS_b));
    else
      basis.reset(new SphereBasisSet3D(xRes/2, xRes, xRes*2, FLAGS_rK, FLAGS_thetaK, FLAGS_phiK, boundaryCnd, is_prolate, is_oblate, FLAGS_b));
  }

  std::string bwoDot = strWithoutDot(FLAGS_b);

  vector<Adv_Tensor_Type> Adv_tensor_;
  basis->FillVariationalTensor(&Adv_tensor_);
  LOG(INFO) << Adv_tensor_.size();
  
  std::stringstream file_name;
  file_name << FLAGS_Tensor_file << FLAGS_basis_type;
  if (FLAGS_basis_type == "torus_3d") {
    file_name << "a" << strWithoutDot(FLAGS_majorA);
  } else if (FLAGS_basis_type == "cylinder_3d") {
    file_name << "H" << strWithoutDot(FLAGS_cylinderH) << "bnd" << FLAGS_cylinder_bnd;
  } else {
    file_name << "b" << bwoDot;
  }
  file_name << "Dim" << basis->numBasisAll();
  LOG(INFO) << "Writting tensor to file: " << file_name.str();
 // BasisSet::VerifyAntisymmetric(Adv_tensor_);
 // exit(0);
  ofstream out(file_name.str(), std::ios::binary);
  basis->writeToFile(out, Adv_tensor_);
  out.close();

  return 0;
}
