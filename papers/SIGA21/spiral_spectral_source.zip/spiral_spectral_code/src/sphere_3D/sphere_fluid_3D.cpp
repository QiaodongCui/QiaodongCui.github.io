#include <cstdlib>
#include <ctime>
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <fstream>
#include <glog/logging.h>
#include <math.h>

#include "3D/drawer_3d.h"
#include "3D/FIELD_3D.h"
#include "3D/particle_3d.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "3D/laplacian_basis_set_3d.h"
#include "Alg/VEC2.h"
#include "common/basis_set.h"

#include "polar_2D/torus_basis_2D.h"
#include "solver/bi_cg_s_solver.h"
#include "solver/bi_cg_stab_preconditioned.h"
#include "solver/integrator_2d.h"
#include "solver/integrator_RK4.h"
#include "solver/integrator_semi_implicit.h"
#include "solver/symmetric_cg.h"
#include "solver/trapezoidal.h"

#include "sphere_3D/cylinder_basis_set_3D.h"
#include "sphere_3D/obstacle_sphere_cyl.h"
#include "sphere_3D/sphere_fluid_3D.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "sphere_3D/torus_basis_3D.h"
#include "sphere_3D/torus_basis_set_3D.h"

#include "util/colorMap.h"
#include "util/gl4_drawer.h"
#include "util/transform.h"
#include "util/timer.h"
#include "util/util.h"
#include "util/read_write_tensor.h"
#include "util/write_density_pbrt.h"
#include "util/stringprintf.h"
#include "setting.h"

using namespace std;

void SphereFluid3D::Initialize() {
  // Initialize the density and velocity field.
  velocity_ = VECTOR3_FIELD_3D(xRes_, yRes_, zRes_);
  force_    = VECTOR3_FIELD_3D(xRes_, yRes_, zRes_);

  density_  = FIELD_3D(xRes_, yRes_, zRes_);
  density_old_ = FIELD_3D(xRes_, yRes_, zRes_);
  forceMag_ = FIELD_3D(xRes_, yRes_, zRes_);
  temp1 = FIELD_3D(xRes_, yRes_, zRes_);
  temp2 = FIELD_3D(xRes_, yRes_, zRes_);
  heat_ = FIELD_3D(xRes_, yRes_, zRes_);
  timer_ = Timer();

  int radK = ceil(pow((double)(numBasisAll)/8.0, 1.0/3.0));
  //int angK = radK;

  ifstream in;
  if (tensor_fname_.size() != 0) {
    in.open(tensor_fname_);
    if (! in.is_open())
      LOG(FATAL) << "cannot open " << tensor_fname_;
  }
  bool boundaryCnd = true;
  if (boundaryCnd_ == "neumann")
    boundaryCnd = false;

  // Read from file.
  if (tensor_fname_.size() != 0) {
    if (basis_type_ == "sphere_3d" || basis_type_ == "prolate_3d" || basis_type_ == "oblate_3d")
      basis_.reset(new SphereBasisSet3D(xRes_/2, xRes_, xRes_*2, in));
    else if (basis_type_ == "cylinder_3d")
      basis_.reset(new CylinderBasisSet3D(xRes_/2, xRes_, xRes_*2, in));
    else if (basis_type_ == "torus_3d")
      basis_.reset(new TorusBasisSet3D(xRes_/2, xRes_, xRes_*2, in));
    else
      LOG(FATAL) << "Unknow basis tpye: " << basis_type_;
  }
  else {
    // Initialize the basis.
    if (basis_type_ == "sphere_3d") {
      basis_.reset(new SphereBasisSet3D(xRes_/2, xRes_, xRes_*2, radK,radK*2,radK*4, boundaryCnd));
    } else if (basis_type_ == "prolate_3d") {
      basis_.reset(new SphereBasisSet3D(xRes_/2, xRes_, xRes_*2, radK,radK*2,radK*4,
                       boundaryCnd, true, false, b_));
    } else if (basis_type_ == "oblate_3d") {
      basis_.reset(new SphereBasisSet3D(xRes_/2, xRes_, xRes_*2, radK,radK*2,radK*4,
                       boundaryCnd, false, true, b_));
    } else if (basis_type_ == "cylinder_3d") {
      basis_.reset(new CylinderBasisSet3D(xRes_/2, xRes_, xRes_, radK, radK*2, radK*2, cylinderH_, true, 0));
    } else if (basis_type_ == "torus_3d" ){
      basis_.reset(new TorusBasisSet3D(xRes_/2, xRes_, 2*xRes_, radK, radK*2, radK*4, majorA_));
    } else {
      LOG(FATAL) << "Unknow basis tpye: " << basis_type_;
    }
  }
  rest_frame_ = total_frame_;
  integrator_time_ = 0.;
  transformation_time_ = 0.;
  density_advection_time_ = 0.;
  maximum_condition_number_ = 0.;
  frame_simulated_ = 0;
  //addCircSmoke();

  if (basis_type_ == "sphere_3d" || basis_type_ == "prolate_3d" || basis_type_ == "oblate_3d") {
    b_ = static_pointer_cast<SphereBasisSet3D>(basis_)->getb();
    a_ = static_pointer_cast<SphereBasisSet3D>(basis_)->geta();
    c_ = static_pointer_cast<SphereBasisSet3D>(basis_)->getc();
  }
  if (basis_type_ == "torus_3d") {
    majorA_ = static_pointer_cast<TorusBasisSet3D>(basis_)->majorA();
  }

  numBasisAll = basis_.get()->numBasisAll();
  numBasisOrtho = basis_.get()->GetnumBasisOrtho();

  LOG(INFO) << "orthogonal basis allocated: " << numBasisOrtho << " all " << numBasisAll;
  A_ = basis_.get()->transferMat();

  // Initialize the coefficients.
  basis_coefficients_.resize(numBasisOrtho);
  basis_coefficients_.setZero();

  basis_coefficients_old_.resize(numBasisOrtho);
  basis_coefficients_old_.setZero();

  tempVector_.resize(numBasisOrtho);
  tempVector_.setZero();
  if (! headless_) {
    // Initialize drawer.
    drawer_.reset(new Drawer3D());
    smoke_render_.reset(new Renderer3DGL4( xRes_, yRes_, zRes_, xRes_));
    coefDrawer_.reset(new coeffcientDrawGL4(basis_coefficients_, 1.0));
    ptlGL4_.reset(new particle3DGL4(num_particles_));
  }

  basisWeights_.resize(numBasisAll);
  basisWeights_.setOnes();

  // Fill the tensor.
  if (tensor_fname_.size() == 0) {
    LOG(INFO) << "Fill the advection tensor...";
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
  } else {
    int basis_type_int = (int)(boundaryCnd);
    LOG(INFO) << "Read tensor from file.";
    ReadTensor(in, numBasisAll, basis_type_int, &Adv_tensor_);
  }
  for (int i = 0; i < Adv_tensor_.size(); i++) {
      Adv_tensor_[i] *= tensorWeight_;
  }

  particles_.resize(num_particles_);
  initPos_.resize(num_particles_);
  
  ReSeedParticles();
  particleSys_.reset(new ParticleSystem(0.02));
  if (basis_type_ == "torus_3d") {
    Eigen::Vector3f seedPos(0, 0, 0);
    particleSys_->seedParticle_.position_ = Transform::Torodial::toCartesian(seedPos, majorA_)/(majorA_ + 1.0);
  } else if (basis_type_ == "sphere_3d" && scenario_ == 1) {
    particleSys_->particles_.resize(2);
  }

  AdvectParticles();
  //addDensityParticles();
  Eigen::VectorXd allCoef = Eigen::VectorXd::Zero(numBasisAll);
  const Eigen::VectorXd& waveN2 = basis_->waveNum2();
  computeSortedIdx(waveN2);

  Eigen::MatrixXd Aabs = A_.array().abs();
  // need to normalize Aabs
  for (int i = 0; i < Aabs.rows(); i++) {
    Aabs.row(i) /= Aabs.row(i).sum();
  }
  
  denseMatrixToSparse(A_, sparseA_);
  is_spheroid_ = (basis_type_ == "sphere_3d" || basis_type_ == "prolate_3d" || basis_type_ == "oblate_3d");
  is_oblate_ = (basis_type_ == "oblate_3d");
  is_prolate_ = (basis_type_ == "prolate_3d");

  projWav_ = Aabs*waveN2;
  if (is_spheroid_) {
    int nr = static_pointer_cast<SphereBasisSet3D>(basis_)->nR();
    int nt = static_pointer_cast<SphereBasisSet3D>(basis_)->nTheta();
    int np = static_pointer_cast<SphereBasisSet3D>(basis_)->nPhi();
    forceDirect_ = VECTOR3_FIELD_3D(np, nt, nr);
  }

  if (basis_type_ == "torus_3d") {
    int nr = static_pointer_cast<TorusBasisSet3D>(basis_)->nR();
    int nt = static_pointer_cast<TorusBasisSet3D>(basis_)->nTheta();
    int np = static_pointer_cast<TorusBasisSet3D>(basis_)->nPhi();
    forceDirect_ = VECTOR3_FIELD_3D(np, nt, nr);
  }

  if (basis_type_ == "cylinder_3d") {
    int nr = static_pointer_cast<CylinderBasisSet3D>(basis_)->nR();
    int nt = static_pointer_cast<CylinderBasisSet3D>(basis_)->nTheta();
    int nz = static_pointer_cast<CylinderBasisSet3D>(basis_)->nZ();
    forceDirect_ = VECTOR3_FIELD_3D(nz, nt, nr);
    static_pointer_cast<CylinderBasisSet3D>(basis_)->setScenario(scenario_);
  }
  colorMap_.reset(new ColorMap("./models/CET-C2.csv"));
  if (basis_type_ == "cylinder_3d") {
    std::shared_ptr<CylinderBasisSet3D> cylPtr = static_pointer_cast<CylinderBasisSet3D>(basis_);
    timer_.Reset();
    cylPtr->computeLaplacianMatrix(cylPtr->getLaplacianD());
    LOG(INFO) << timer_.ElapsedTimeInSeconds();
    denseMatrixToSparse(cylPtr->getLaplacianD(), sparseD_);
  }

  if (basis_type_ == "cylinder_3d" && scenario_ == 1) {
    for (int i = 0; i < 12; i++) {
      std::shared_ptr<ObstacleSphereCyl> ptr;
      ptr.reset(new ObstacleSphereCyl(StringPrintf("./models/sphereLoc1/locations_%02d.txt", i), 0.2, dt_));
      //ptr.reset(new ObstacleSphereCyl("./models/locations.txt", 0.2, dt_));
      obsSphCyl_.push_back(ptr);
    }
    setObstacleParticles();
  }

  if (basis_type_ == "cylinder_3d" && scenario_ == 2) {
    //std::shared_ptr<ObstacleSphereCyl> ptr;
    //ptr.reset(new ObstacleSphereCyl(Eigen::Vector3d(0.15, -0.15, 0), 0.25));
    //obsSphCyl_.push_back(ptr);
    //setObstacleParticles();
  }

  if (basis_type_ == "sphere_3d") {
    std::shared_ptr<SphereBasisSet3D> sphPtr = static_pointer_cast<SphereBasisSet3D>(basis_);
    sphPtr->computeLaplacianMatrix(sparseD_);
    Eigen::VectorXd weights;
    sphPtr->computeBasisWeight(weights);
    if (scenario_ == 3)
      LaplacianBasisSet3D::MultiplyweightTensor(Adv_tensor_, weights);
  }
}

void SphereFluid3D::Step() {
  float DCT_time = 0;
  float integrator_time = 0;
  float advection_time = 0;
  float contraction_time = 0;
  float solver_time = 0;
  //AddDensity();
  current_energy_ = CalculateEnergy();
  
  // Swap the coefficients.
  for (int i = 0; i < basis_coefficients_.size(); i++) {
    basis_coefficients_old_[i] = basis_coefficients_[i];
  }

  double condition_number = 1.0;

  integrator_.get()->IntegrateForward(Adv_tensor_, sparseA_, basis_coefficients_old_,
                                     dt_,
                                     basis_coefficients_, condition_number,
                                     contraction_time, solver_time);

  if (condition_number > maximum_condition_number_) {
    maximum_condition_number_ = condition_number;
  }

  integrator_time = contraction_time + solver_time;
  
  // Disspate energy from viscosity.
  if ((basis_type_ == "cylinder_3d" && (scenario_ == 1 || scenario_ == 2)) || (basis_type_ == "sphere_3d")) {
    basis_coefficients_old_ = basis_coefficients_;
    std::shared_ptr<CylinderBasisSet3D> cylPtr = static_pointer_cast<CylinderBasisSet3D>(basis_);
    integrator_.get()->solveDiffusion(sparseD_, sparseA_, basis_coefficients_old_, 
                                      visc_*dt_, basis_coefficients_);
    LOG(INFO) << "using diff solver";
  } else {
    DissipateEnergy();
  }

  // Reconstruct the velocity field.
  timer_.Reset();
  // coefficients for all the basis.
  fieldCoef_ = A_.transpose()*basis_coefficients_;
  AddWindField(fieldCoef_);
  basis_.get()->InverseTransformToVelocity(fieldCoef_);
  // IOP
  if (basis_type_ == "cylinder_3d" && (scenario_ == 1)) {
    const int NN = 8;
    for (int k = 0; k < NN; k++) {

      int nr = forceDirect_.zRes();
      int nt = forceDirect_.yRes();
      int np = forceDirect_.xRes();

      std::shared_ptr<CylinderBasisSet3D> ptr = static_pointer_cast<CylinderBasisSet3D>(basis_);
      const int numPerObs = particles_.size() / obsSphCyl_.size();

      for (int i = 0; i < obsSphCyl_.size(); i++) {
        obsSphCyl_[i]->SetNormalForce(nr, nt, np, ptr->getVrTemp(), ptr->getVtTemp(), ptr->getVpTemp(), 1.0, 
                ptr->getB(), ptr->getScale(), forceDirect_);
      }

      Eigen::VectorXd force_coef(numBasisOrtho); force_coef.setZero();
      basis_->ForwardTransformDirect(forceDirect_, &force_coef);
      forceDirect_.clear();
      //basis_coefficients_ += force_coef * dt_/NN;
      fieldCoef_ = A_.transpose()*force_coef;
      basis_.get()->InverseTransformToVelocity(fieldCoef_);
    }
  }

  DCT_time += timer_.ElapsedTimeInSeconds();
  
  timer_.Reset();
  if (!particleBasedAdvection_) {
    // Advect density.
    AdvectDensity();
  }
  addDensityParticles();
  // Advect particles.
  AdvectParticles();
  advection_time = timer_.ElapsedTimeInSeconds();
  rest_frame_ --;
  if (rest_frame_ <=0) {
    Quit();
  }

  timer_.Reset();
  // Add buoyancy by using DCT to transform to freq domain.
  AddBuoyancy();
  // Add external forces.
  AddExternalForce();
  DCT_time += timer_.ElapsedTimeInSeconds();

  timer_.Reset();

  LOG(INFO) << "Frame: " << frame_simulated_;
  LOG(INFO) << "Total energy: " << current_energy_;

  LOG(INFO) << "DCT time: " << DCT_time;
  LOG(INFO) << "Advection time: " << advection_time;
  LOG(INFO) << "Contraction time: " << contraction_time;
  LOG(INFO) << "Solver time: " << solver_time;
  
  integrator_time_ += integrator_time;
  density_advection_time_ += advection_time;  
  transformation_time_ += DCT_time;
  
  frame_simulated_ ++;
}

void SphereFluid3D::addDensityParticles() {
  if (basis_type_ == "torus_3d" && scenario_ == 0) {
    if (particleSys_->particles_[0].size() < maxDensityParticles_)
      particleSys_->seedRing(maxDensityParticles_/100, majorA_, basis_->scale(), m_gen_, particleSys_->particles_[0]);
    if (particleSys_->heatParticles_.size() < maxHeatParticles_)
      particleSys_->seedRing(maxHeatParticles_/25, majorA_, basis_->scale(), m_gen_, particleSys_->heatParticles_);
  } else if (basis_type_ == "torus_3d" && scenario_ == 1) {
    if (particleSys_->particles_[0].size() < maxDensityParticles_)
      particleSys_->seedDomeRing(maxDensityParticles_, -float(M_PI*0.45), float(M_PI*0.45), cos((float)(M_PI*0.45)), 1.f, majorA_, basis_->scale(),
        m_gen_, particleSys_->particles_[0]);
  }

  if (basis_type_ == "cylinder_3d" && scenario_ == 0) {
    if (particleSys_->particles_[0].size() < maxDensityParticles_)
      particleSys_->seedCylinder(maxDensityParticles_/100, 0.4, 0.1, basis_->scale(), false, m_gen_, particleSys_->particles_[0]);
    if (particleSys_->heatParticles_.size() < maxHeatParticles_)
      particleSys_->seedCylinder(maxHeatParticles_/100, 0.4, 0.1, basis_->scale(), false, m_gen_, particleSys_->heatParticles_);
  } if (basis_type_ == "cylinder_3d" && scenario_ == 1) {
    if (particleSys_->particles_[0].size() < maxDensityParticles_) {
        //particleSys_->seedCylinder(maxDensityParticles_, cylSeedR_, cylSeedH_, basis_->scale(), true, m_gen_, particleSys_->particles_[0]);
        particleSys_->seedCylinderColor(maxDensityParticles_, cylSeedR_, cylSeedH_, basis_->scale(), true, m_gen_,
           *colorMap_, particleSys_->particles_[0], particleColor_);
      }
  } else if (basis_type_ == "cylinder_3d" && scenario_ == 2) {
    if (particleSys_->particles_[0].size() < maxDensityParticles_)
      particleSys_->seedCylinderColor(maxDensityParticles_/100, cylSeedR_, cylSeedH_, basis_->scale(), true, m_gen_,
      *colorMap_, particleSys_->particles_[0], particleColor_);
  }

  if (is_spheroid_ && (scenario_ == 0)) {
    if (particleSys_->particles_[0].size() < maxDensityParticles_) {
      particleSys_->seedDomeColor(maxDensityParticles_, 0.f, float(M_PI*0.35), m_gen_, true ,
          particleSys_->particles_[0], particleColor_);

      vector<ParaParticle3Df>& densPtls = particleSys_->particles_[0];
      for (int i = 0; i < densPtls.size(); i++) {
        if (is_oblate_){
          densPtls[i].position_[2] *= b_;
        } else if (is_prolate_) {
          densPtls[i].position_[0] *= b_; densPtls[i].position_[1] *= b_;
        }
      }
    }

  } else if (is_spheroid_ && scenario_ == 1) {
    if (particleSys_->particles_[0].size() > 0)
      return;
    particleSys_->seedDome(maxDensityParticles_/4, 0, float(M_PI*0.43), m_gen_, false, particleSys_->particles_[0]);
    particleSys_->seedDome(maxDensityParticles_/4*3, 0, float(M_PI*0.387), m_gen_, false, particleSys_->particles_[1]);
  } else if (is_spheroid_ && scenario_ == 2) {
    particleSys_->seedParticle_.position_ = Eigen::Vector3f(0,0, 0.9);
    if (particleSys_->particles_[0].size() < maxDensityParticles_)
        particleSys_->seedDome(maxDensityParticles_, 0, float(M_PI*0.15), m_gen_, true, particleSys_->particles_[0]);
    if (particleSys_->heatParticles_.size() < maxHeatParticles_)
        particleSys_->seedDome(maxHeatParticles_, 0, float(M_PI*0.12), m_gen_, true, particleSys_->heatParticles_);
  } else if (is_spheroid_ && scenario_ == 3) {
    if (particleSys_->particles_[0].size() > 0)
      return;
    particleSys_->seedParticle_.position_ = Eigen::Vector3f(0.0375, -0.0375, 0.15);
    particleSys_->seedCubeColor(maxDensityParticles_/2, 0.3,0.3,0.3, m_gen_, particleSys_->particles_[0], particleColor_);
    particleSys_->seedParticle_.position_ = Eigen::Vector3f(-0.0375, 0.0375, -0.15);
    particleSys_->seedCubeColor(maxDensityParticles_/2, 0.3,0.3,0.3, m_gen_, particleSys_->particles_[0], particleColor_);
  } else if (is_spheroid_ && scenario_ == 4) {
    if (particleSys_->particles_[0].size() > 0)
      return;
    particleSys_->seedParticle_.position_ = Eigen::Vector3f(0, 0, 0);
    particleSys_->seedCubeColor(maxDensityParticles_, 0.4,0.4,1.6, m_gen_, particleSys_->particles_[0], particleColor_);
  } 

  LOG(INFO) << "density particle size: " <<  particleSys_->particles_[0].size()
            << " heat particles size: " << particleSys_->heatParticles_.size();
}

void SphereFluid3D::AddBuoyancy() {
  
  if (basis_type_ == "cylinder_3d" && scenario_ == 0) {
    if (current_energy_ > 2.0)
      return;
    Eigen::Vector3f ptlForce(0.0, 0.8, -0.8);
    ptlForce *= 3.0;
  
    for (int i = 0; i <particleSys_->heatParticles_.size(); i++) {
      static_pointer_cast<CylinderBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(heatPtlWeight_, 
          particleSys_->heatParticles_[i].position_, ptlForce, forceDirect_);
    }
  } else if (basis_type_ == "cylinder_3d" && scenario_ == 1) {
    int nr = forceDirect_.zRes();
    int nt = forceDirect_.yRes();
    int np = forceDirect_.xRes();

    std::shared_ptr<CylinderBasisSet3D> ptr = static_pointer_cast<CylinderBasisSet3D>(basis_);
    const int numPerObs = particles_.size() / obsSphCyl_.size();

    for (int i = 0; i < obsSphCyl_.size(); i++) {
      obsSphCyl_[i]->CalculateNormalForce(nr, nt, np, ptr->getVrTemp(), ptr->getVtTemp(), ptr->getVpTemp(), 20.0, 
              ptr->getB(), ptr->getScale(), forceDirect_);
      obsSphCyl_[i]->update();
      obsSphCyl_[i]->updateTrace(particles_, i*numPerObs, (i+1)*numPerObs);
    }
  } else if (basis_type_ == "cylinder_3d" && scenario_ == 2) {
    Eigen::Vector3f ptlForce(0.0, 0, -0.30);
    int nr = forceDirect_.zRes();
    int nt = forceDirect_.yRes();
    int np = forceDirect_.xRes();
    std::shared_ptr<CylinderBasisSet3D> ptr = static_pointer_cast<CylinderBasisSet3D>(basis_);
    
    for (int i = 0; i < particleSys_->particles_[0].size(); i++) {
      static_pointer_cast<CylinderBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(densityPtlWeight_, 
          particleSys_->particles_[0][i].position_, ptlForce, forceDirect_);
    }

    for (int i = 0; i < obsSphCyl_.size(); i++) {
      obsSphCyl_[i]->CalculateNormalForce(nr, nt, np, ptr->getVrTemp(), ptr->getVtTemp(), ptr->getVpTemp(), 50.0, 
              ptr->getB(), ptr->getScale(), forceDirect_);
    }
  }

  if (is_spheroid_ && scenario_ == 0) {
    if (current_energy_ > 3.0)
      return;

    if (frame_simulated_ <= 1)
      basis_coefficients_ += Eigen::VectorXd::Random(numBasisAll)*0.0001;
    
    int nr = forceDirect_.zRes();
    int nt = forceDirect_.yRes();
    int np = forceDirect_.xRes();
    for (int r = nr/10*8; r < nr; r++)
      for (int t = 0; t < nt; t++)
        for (int p = 0; p < np; p++) {
          forceDirect_[p + t*np + r*nt*np][2] = 3.0;
          forceDirect_[p + t*np + r*nt*np][1] = 0.5;
        }

  } else if (basis_type_ == "sphere_3d" && scenario_ == 1) {
    int index = static_pointer_cast<SphereBasisSet3D>(basis_)->inverseLookup(1, 0, 0, 4);
    if (frame_simulated_ < 10 || current_energy_ < 0.25) {
      Eigen::VectorXd fieldCoef1 = Eigen::VectorXd::Zero(numBasisAll);
      double coef = 0.0001;

      fieldCoef1[index] = coef/dt_;
      basis_coefficients_ += fieldCoef1; 
    }

    if (frame_simulated_ < 10) {
      std::vector<ParaParticle3Df>& denParticle = particleSys_->particles_[1];
      Eigen::Vector3f ptlForce(0.0, 0.0, 85.0);
      for (int i = 0; i < denParticle.size(); i++) {
        if (denParticle[i].position_[2] > 0.8)
          static_pointer_cast<SphereBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(heatPtlWeight_, 
              denParticle[i].position_, ptlForce, true, forceDirect_);
      }
    }
  } else if (basis_type_ == "sphere_3d" && scenario_ == 2) {

    if (current_energy_ < 2.5) {

      std::vector<ParaParticle3Df>& heatPtls = particleSys_->heatParticles_;
      //if (frame_simulated_ < 80 ) {
      Eigen::Vector3f ptlForce(0.0, 0.0, -2.0);
      for (int i = 0; i < heatPtls.size(); i++)
        static_pointer_cast<SphereBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(heatPtlWeight_, 
          heatPtls[i].position_, ptlForce, true, forceDirect_);
      //}
    }
  } else if (basis_type_ == "sphere_3d" && scenario_ == 3) {
    if (frame_simulated_ >= 1)
      return;
    
      std::vector<ParaParticle3Df>& denParticle = particleSys_->particles_[0];
      Eigen::Vector3f ptlForce(0.0, 0.0, -17.0);
      for (int i = 0; i < denParticle.size(); i++) {
        if (denParticle[i].position_[0] > 0)
        static_pointer_cast<SphereBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(heatPtlWeight_, 
            denParticle[i].position_, ptlForce, true, forceDirect_);
        else
          static_pointer_cast<SphereBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(heatPtlWeight_, 
              denParticle[i].position_, -ptlForce, true, forceDirect_);
      }
  } else if (is_spheroid_ && scenario_ == 4) {
     if (frame_simulated_ >= 1)
      return;
    
      std::vector<ParaParticle3Df>& denParticle = particleSys_->particles_[0];
      Eigen::Vector3f ptlForce(0, 0.0, 8.5);
      for (int i = 0; i < denParticle.size(); i++)
        static_pointer_cast<SphereBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(heatPtlWeight_, 
            denParticle[i].position_, ptlForce, true, forceDirect_);
  }
  
  if (basis_type_ == "torus_3d" && scenario_ == 0) {
    if (current_energy_ > 2.0)
      return;
    Eigen::Vector3f ptlForce(0,0,20);
    for (int i = 0; i <particleSys_->particles_[0].size(); i++) {
      static_pointer_cast<TorusBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(densityPtlWeight_,
           particleSys_->particles_[0][i].position_, ptlForce, forceDirect_);
    }
  } else if (basis_type_ == "torus_3d" && scenario_ == 1) {
    if (current_energy_ > 2.0)
      return;
    Eigen::Vector3f ptlForce(0, 0, 20);
    for (int i = 0; i <particleSys_->particles_[0].size(); i++) {
      static_pointer_cast<TorusBasisSet3D>(basis_)->addParticleForce<float, Eigen::Vector3f>(densityPtlWeight_,
           particleSys_->particles_[0][i].position_, ptlForce, forceDirect_);
    }
  }
}

void SphereFluid3D::AddWindField(Eigen::VectorXd& fieldCoef) {
  if (basis_type_ == "sphere_3d" && scenario_ == 2) {
    int index = static_pointer_cast<SphereBasisSet3D>(basis_)->inverseLookup(1, 0, 0, 4);
    if (index != -1)
      fieldCoef[index] *= 1.5;
  }
}

void SphereFluid3D::splatParticle() {
  density_.clear();
  for (int x = 0; x < particleSys_->particles_.size(); x++) {
    std::vector<ParaParticle3Df>& densPtls = particleSys_->particles_[x];
    for (int i = 0; i < densPtls.size(); i++) {
      double curW = densPtls[i].weight_*densityPtlWeight_;
      if (!headless_)
        basis_->splatParticle(curW, dx_, densPtls[i].position_, density_);
      if (basis_type_ == "torus_3d" && dissipateDensity_) {
        densPtls[i].life_ -= 0.01;
        if (densPtls[i].life_ <= 0) {
          particleSys_->resetAtRing(densPtls[i], majorA_, basis_->scale(), m_gen_);
        }
      } else if (basis_type_ == "cylinder_3d" && scenario_ == 0) {
        densPtls[i].life_ -= 0.01;
        if (densPtls[i].life_ <= 0)
          particleSys_->resetAtCylinder(densPtls[i], 0.4, 0.1, basis_->scale(), m_gen_);
      } else if (dissipateDensity_ && basis_type_ == "cylinder_3d" && scenario_ == 1) {
        densPtls[i].life_ -= 0.0015;
        if (densPtls[i].life_ <= 0)
          particleSys_->resetAtCylinderColor(densPtls[i], particleColor_[i], *colorMap_, cylSeedR_, cylSeedH_,basis_->scale(), m_gen_);
      } else if (basis_type_ == "cylinder_3d" && scenario_ == 2) {
        densPtls[i].life_ -= 0.024;
        if (densPtls[i].life_ <= 0)
          particleSys_->resetAtCylinderColor(densPtls[i], particleColor_[i], *colorMap_, cylSeedR_, cylSeedH_,basis_->scale(), m_gen_);
      } else if (is_spheroid_ && scenario_ == 0) {
        densPtls[i].life_ -= 0.0075;
        if (densPtls[i].life_ <= 0) {
          particleSys_->resetDomeColor(densPtls[i], particleColor_[i], 0.f, float(M_PI*0.35), true, m_gen_);
          if (is_oblate_)
            densPtls[i].position_[2] *= b_;
          else if (is_prolate_)
            {densPtls[i].position_[0] *= b_; densPtls[i].position_[1] *= b_;}
        }
      } else if (is_spheroid_ && scenario_ == 1) {
         if (densPtls[i].life_ <= 0)
          particleSys_->resetIntoSphere(densPtls[i], m_gen_);
      } else if (is_spheroid_ && scenario_ == 2) {
        densPtls[i].life_ -= 0.009;
        if (densPtls[i].life_ <= 0)
         particleSys_->resetDome(densPtls[i], 0.f, float(M_PI*0.15), true, m_gen_);
      } else if (is_spheroid_ && (scenario_ == 3 || scenario_ == 4)) {
        if (densPtls[i].life_ <= 0)
          particleSys_->resetIntoSphere(densPtls[i], m_gen_);
      }
    }
  }

  // heat particles
  heat_.clear();
  std::vector<ParaParticle3Df>& heatPtls = particleSys_->heatParticles_;
  for (int i = 0; i < heatPtls.size(); i++) {
    double curW = heatPtls[i].weight_*heatPtlWeight_;
    if (!headless_)
      basis_->splatParticle(curW, dx_, heatPtls[i].position_, heat_);
    if (basis_type_ == "torus_3d" && dissipateDensity_) {
      heatPtls[i].life_ -= 0.04;
      if (heatPtls[i].life_ <= 0) {
        particleSys_->resetAtRing(heatPtls[i], majorA_, basis_->scale(), m_gen_);
      }
    } else if (basis_type_ == "cylinder_3d" && scenario_ == 0) {
      //heatPtls[i].life_ -= 0.012;
      if (heatPtls[i].life_ <= 0)
        particleSys_->resetAtCylinder(heatPtls[i], 0.4, 0.1, basis_->scale(), m_gen_);
      if (heatPtls[i].life_ <= 0.6)
        heatPtls[i].weight_ = 1.0;// + heatPtls[i].life_*1.5;
      else if (heatPtls[i].weight_ > 0.6)
        heatPtls[i].weight_ = 1.0;/// - (heatPtls[i].life_ - 0.6)*2.0;
    } else if (is_spheroid_ && (scenario_ == 0)) {
      if (heatPtls[i].life_ <= 0)
        particleSys_->resetDome(heatPtls[i], 0.f, float(M_PI*0.2), true, m_gen_);
    } else if (is_spheroid_ && scenario_ == 1) {
      if (heatPtls[i].life_ <= 0)
        particleSys_->resetIntoSphere(heatPtls[i], m_gen_);
    } else if (is_spheroid_ && scenario_ == 2) {
      heatPtls[i].life_ -= 0.012;
      if (heatPtls[i].life_ <= 0)
        particleSys_->resetDome(heatPtls[i], 0, float(M_PI*0.12), true, m_gen_);
    } else if (is_spheroid_ && scenario_ == 3) {

    }
  }
}

// Convert the external force field into the coefficients, and then
// add the external forces.
void SphereFluid3D::AddExternalForce() {
  Eigen::VectorXd force_coef(numBasisOrtho); force_coef.setZero();

  basis_->ForwardTransformDirect(forceDirect_, &force_coef);
  forceDirect_.clear();
  // disable force filtering after frame 80, cuz things already get mixed up.
  if (basis_type_ == "cylinder_3d" && filterForce_ && frame_simulated_ < 80)
    FilterForce(force_coef, 10.0);
  for (int i = 0; i < numBasisOrtho; i++) {
    basis_coefficients_[i] += force_coef[i] * dt_;
  }
}

// Using the velocity field directed interpolated from the polar grid,
// RK4 advection.
void SphereFluid3D::AdvectParticles() {
  
  if (advectTracer_) {
  #pragma omp parallel for
    for (int i = 0; i < num_particles_; i++) {
      // substepping each with RK4.
      basis_->advectRK4(particles_[i], dt_);
    }
    basis_->projBackParticles(initPos_, particles_);
  }

  for (int x = 0; x < particleSys_->particles_.size(); x++) {
    #pragma omp parallel for
    for (int i = 0; i < particleSys_->particles_[x].size(); i++)
    basis_->advectRK4(particleSys_->particles_[x][i], dt_);
  }

  #pragma omp parallel for
  for (int i = 0; i < particleSys_->heatParticles_.size(); i++)
  basis_->advectRK4(particleSys_->heatParticles_[i], dt_);

  splatParticle();

  if (basis_type_ == "torus_3d") {
    // advect the seed location as well.
    // advectRK4(particleSys_->seedParticle_);
    const double deltaAngle = M_PI*0.02;
    particleSys_->seedParticle_.position_ = Transform::Torodial::toCartesian(Eigen::Vector3f(0,0,deltaAngle*frame_simulated_), majorA_)/(majorA_ + 1.0);
  }
}

void SphereFluid3D::AdvectDensity() {
  const double dt0 = dt_ / dx_;
  density_.swapPointers(density_old_);
  VECTOR3_FIELD_3D::advectMacCormack(dt0, velocity_, density_old_, density_, temp1, temp2);
}

void SphereFluid3D::DrawDensity(const glm::mat4& modelView, const double alpha, const bool drawDensity) {
  if (!render_initialized_) {
    smoke_render_.get()->InitGL();
    render_initialized_ = true;
  }
  if (drawDensity)
    smoke_render_.get()->FillTexture(density_, alpha, 0.0);
  else
    smoke_render_.get()->FillTexture(heat_, alpha, 0.0);
  smoke_render_.get()->Render(modelView);
}

void SphereFluid3D::DrawCoefficients(const double multi_factor) {
  Eigen::VectorXd energy_w = basis_coefficients_.cwiseProduct(basis_coefficients_);
  // sort according to the charastic wave numbers.
  Eigen::VectorXd energySorted = Eigen::VectorXd::Zero(numBasisOrtho);
  for (int i = 0; i < sortedIndex_.size(); i++)
    energySorted[i] = energy_w[sortedIndex_[i]];
  coefDrawer_->Draw(energySorted, multi_factor*20.0);
}

void SphereFluid3D::DrawParticles(const double ptl_length) {
  //drawer_.get()->DrawParticlesSimple(particles_, 1, dt_, ptl_length);
  ptlGL4_->updatePos(particles_, ptl_length*dt_);
  ptlGL4_->Draw();
}

void SphereFluid3D::Quit() {
  LOG(INFO) << "Total frame simulated: " << total_frame_;
  LOG(INFO) << "Average time for integrator per frame: " 
      << integrator_time_ / total_frame_;
  LOG(INFO) << "Average time for DCT and DST: "
      << transformation_time_ / total_frame_;
  LOG(INFO) << "Average time for advection of density and particles: "
      << density_advection_time_ / total_frame_;
  LOG(INFO) << "Maximum condition number: " << maximum_condition_number_;
  quit_ = true;
 // exit(0);
}

void SphereFluid3D::OutputToPBRT() {
  if (density_folder_.size() == 0)
    return;
  std::string fname = StringPrintf("%s%04d.pbrt", density_folder_.c_str(), frame_simulated_);
  LOG(INFO) << "Output the smoke to file: " << fname;
  WriteDensityPBRT(fname, density_, 1.0);
}

void SphereFluid3D::setObstacleParticles() {
  if (obsSphCyl_.size() == 0)
    return;
  const int numPerObstacle = particles_.size()/obsSphCyl_.size();
  for (int i = 0; i < obsSphCyl_.size(); i++)
    for (int j = i*numPerObstacle; j < particles_.size() && j < (i+1)*numPerObstacle; j++)
      particles_[j].position = obsSphCyl_[i]->getSurfaceSamples(m_gen_);
}

void SphereFluid3D::FilterForce(Eigen::VectorXd& forceCoef, const double mult) {
  Eigen::VectorXd tmp = forceCoef;
  //basis_coefficients_old_ = basis_coefficients_;
  std::shared_ptr<CylinderBasisSet3D> cylPtr = static_pointer_cast<CylinderBasisSet3D>(basis_);
  integrator_.get()->solveDiffusion(sparseD_, sparseA_, tmp, 
                                    mult*visc_*dt_, forceCoef);
}