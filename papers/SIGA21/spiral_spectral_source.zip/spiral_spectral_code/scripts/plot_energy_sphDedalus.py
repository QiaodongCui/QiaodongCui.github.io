import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt

def read_from_file(fname):
    e = []
    f = open(fname)
    for line in f:
        temp = line.split()
        e.append((float)(temp[0]))
    f.close()
    e = np.asarray(e)
    #ed = np.asarray(ed)
    result = {}
    result['e'] = e
    #result['ed'] = ed
    return result

data0 = read_from_file("./Energy_dedalus_1e3")['e']
data0 = data0[3:-1]
data0 = data0 / data0[0] * 100.0

data1 = read_from_file("./Energy_sph_1e3")['e']
data1 = data1[2:-1]
data1 = data1 / data1[0] * 100.0

data2 = read_from_file("./Energy_dedalus_1e4")['e']
data2 = data2[3:-1]
data2 = data2 / data2[0] * 100.0

data3 = read_from_file("./Energy_sph_1e4")['e']
data3 = data3[2:-1]
data3 = data3 / data3[0] * 100.0

data4 = read_from_file("./Energy_dedalus_1e5")['e']
data4 = data4[3:-1]
data4 = data4 / data4[0] * 100.0

data5 = read_from_file("./Energy_sph_1e5")['e']
data5 = data5[2:-1]
data5 = data5 / data5[0] * 100.0

data6 = read_from_file("./Energy_dedalus_zeroV0T1e2")['e']
#data6 = data6[3:-1]
data6 = data6 / data6[0] * 100.0

data7 = read_from_file("./Energy_sph_zero")['e']
data7 = data7[2:-1]
data7 = data7 / data7[0] * 100.0

index = np.arange(0, len(data1))

font_size = 30
linge_width = 2

fig, ax = plt.subplots()
#ax.set_ylabel('%  error ', fontsize = font_size)
#ax.set_xlabel('Timestep', fontsize = font_size)
#ax.set_title('Error comparison, visc = 0.002', fontsize = font_size )

idxDedalus = np.arange(0, 11, 0.01)
stride = max( int(len(idxDedalus) / 20), 1)
line0, = ax.plot(idxDedalus, data0[0:len(idxDedalus)].transpose(), color = 'red' , lw = linge_width, linestyle='--')

idxOur = np.arange(0, 11, 0.03)
line1, = ax.plot(idxOur, data1[0:len(idxOur)].transpose(), color = 'red', lw = linge_width)

line2, = ax.plot(idxDedalus, data2[0:len(idxDedalus)].transpose(), color = 'green' , lw = linge_width, linestyle='--')
line3, = ax.plot(idxOur, data3[0:len(idxOur)].transpose(), color = 'green' , lw = linge_width)

idxDedalus = np.arange(0, len(data4)*0.01, 0.01)
line4, = ax.plot(idxDedalus, data4[0:len(idxDedalus)].transpose(), color = 'blue' , lw = linge_width, linestyle='--')
line5, = ax.plot(idxOur, data5[0:len(idxOur)].transpose(), color = 'blue' , lw = linge_width)

line4, = ax.plot(idxDedalus, data4[0:len(idxDedalus)].transpose(), color = 'blue' , lw = linge_width, linestyle='--')

idxDedalus = np.arange(0, len(data6)*0.01, 0.01)
line6, = ax.plot(idxDedalus, data6[0:len(idxDedalus)].transpose(), color = 'orange' , lw = linge_width, linestyle='--')
line7, = ax.plot(idxOur, data7[0:len(idxOur)].transpose(), color = 'orange' , lw = linge_width)

#line2, = ax.plot(np.arange(0, len(data2)), data2.transpose(), color = 'green' , lw = linge_width)
#line4, = ax.plot(index, derivative.transpose()*0.05, color = 'red', lw = linge_width)
#line3, = ax.plot([1,600],[0,0], color = 'black')

plt.ylim(0, 150)
plt.xlim(0, 11)
#ax.legend(loc='upper right', bbox_to_anchor=(0., 1.0), fontsize = font_size)

#plt.xticks(np.arange(0, x_ceil, 200))
for tick in ax.xaxis.get_major_ticks():
                tick.label.set_fontsize(font_size)
for tick in ax.yaxis.get_major_ticks():
               tick.label.set_fontsize(font_size)   
plt.show()