#ifndef ELLIPTIC_BASIS_SET_2D_H
#define ELLIPTIC_BASIS_SET_2D_H

#include <cstring>
#include <Eigen/Eigen>
#include <fstream>
#include <vector>
#include <fftw3.h>

#include "2D/VFIELD2D.h"
#include "polar_2D/polar_basis_2D.h"
#include "polar_2D/polar_basis_set_2D.h"
#include "polar_2D/scomp_basis_set_2D.h"
#include "elliptic/elliptic_basis_2D.h"

#include <vector>

const std::string tableFolder = "./Tensor/tables/elliptic/";

class EllipticBasisSet2D : public PolarBasisSet2D  {

public:
  EllipticBasisSet2D(int N, int radiusK, int angK, bool bndCnd, const double b):PolarBasisSet2D(N, radiusK, angK, bndCnd),
   a_(sqrt(1.0 - b*b)), b_(b), c_(b/sqrt(1.0 - b*b)) {
    
    queryTable_.reset(new IntegrationTable1DPtn(tableFolder+"bList.csv", tableFolder + "k1x2Range.csv", tableFolder + "fun1DVal.bin",
                            tableFolder + "pattern1D.txt"));
    TensorQueryTable_.reset(new TensorTable2D(tableFolder + "TensorListWn.csv", b, tableFolder + "blistTableName.txt", 
                                              tableFolder + "patternTensor.txt", true));

    tabData_.reset(new IntTable1DData(b));
    tabData_->setIntTable(queryTable_);
    tabData_->set2DTable(TensorQueryTable_);

    nTheta_ = ((int)((double)(N)*M_PI));
    nR_ = (N/2);
    // nTheta_ must be even to ensure dst works.
    if (nTheta_ % 2 != 0)
      nTheta_ ++;

    // allocate twice memory anyway
    allocateTemp(true);
    init();
  };

  EllipticBasisSet2D(int N, std::ifstream& in):PolarBasisSet2D(N, 0,0, true) {
    nTheta_ = ((int)((double)(N)*M_PI));
    nR_ = (N/2);
    // nTheta_ must be even to ensure dst works.
    if (nTheta_ % 2 != 0)
      nTheta_ ++;
    
    // allocate twice memory anyway
    allocateTemp(true);
    readFromFile(in);
    setUpFFTWPlan();
    computeWeightF();
  };

  ~EllipticBasisSet2D(){
    free(h_);
    free(sqrtCR_);
    free(erC_); 
    free(etC_);
    free(erP_);
    free(etP_);
  };

  void allocateBasisMGS();
  void runMGS(const double thresh, const std::vector<ellipticPtr>& in, std::vector<ellipticPtr>& out,
            Eigen::MatrixXd& Coef, int& m);

  void computeWeightF();

  void InverseTransformToVelocity(const Eigen::VectorXd& coefficients, VFIELD2D* field) override;

  void InversetTransformEnrich(const Eigen::VectorXd& fieldCoef, Eigen::Map<Eigen::VectorXd>& vr, Eigen::Map<Eigen::VectorXd>& vt);
  
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut);

  // Input a std::vector field, transform and output the basis coefficients.
  void ForwardTransformtoFrequency(const VFIELD2D& field, Eigen::VectorXd* coefficients) override;
  void ForwardTransformEnrichUR(Eigen::VectorXd& fieldCoef);
  void ForwardTransformEnrichUT1(Eigen::VectorXd& fieldCoef);
  void ForwardTransformEnrichUT2(Eigen::VectorXd& fieldCoef);

  void projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef);
  const FIELD2D& getR() const {
    return r_;
  }
  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  void outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor);

  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const override;
  void readFromFile(std::ifstream& in) override;

protected:

  void init() override {
    allocateBasisMGS();
    computeWeightF();
    setUpFFTWPlan();
  }

  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);
  void assignPairCoef(Eigen::VectorXd& fieldCoef);
  void weightJacobian(double* ptr);

  void interpolateToCartesian(VFIELD2D* field);
  void interpolateToPolar(const VFIELD2D& field);

  // focus
  double a_;
  // short axis
  double b_;
  // sinh(w) = b/a
  double c_;

  std::shared_ptr<IntegrationTable1DPtn> queryTable_;
  std::shared_ptr<IntTable1DData> tabData_;
  std::shared_ptr<TensorTable2D> TensorQueryTable_;
  // pointwise scale factor
  double* h_;
  double* sqrtCR_;
  
  // basis std::vectors on cartesian lattice.
  Eigen::Vector2d* erC_;
  Eigen::Vector2d* etC_;

  // basis std::vectors on elliptic lattice.
  Eigen::Vector2d* erP_;
  Eigen::Vector2d* etP_;
  
protected:
  std::vector<ellipticPtr> all_basis_;

};

#endif  // ELLIPTIC_BASIS_SET_2D_H