#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <string>

#include "util/colorMap.h"

ColorMap::ColorMap(const std::string fname) {
	 std::ifstream in(fname);
  if (! in.is_open())
    LOG(FATAL) << "cannot open: " << fname;
  float r,g,b;
  while(in >> r && in >> g && in >> b) {
    colorMap_.push_back(Eigen::Vector3f(r,g,b));
  }
}

Eigen::Vector3f ColorMap::getColor(const float t) const {
	int i0 = (int)(t*float(colorMap_.size()));
	int i1 = i0 + 1;
	i0 = (i0 < 0) ? i0 + colorMap_.size() : i0;
	i1 = (i1 >= colorMap_.size()) ? i1 - colorMap_.size() : i1;
	float t1= t*float(colorMap_.size()) - i0;
	float t0 = 1.f - t1;
	return colorMap_[i0]*t0 + colorMap_[i1]*t1;
}