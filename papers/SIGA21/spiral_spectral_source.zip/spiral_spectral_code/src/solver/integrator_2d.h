#ifndef INTEGRATOR_2D_H
#define INTEGRATOR_2D_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <vector>
#include <glog/logging.h>

#include "setting.h"

class Integrator2D {
public:
  Integrator2D(){};
  ~Integrator2D(){};
  virtual void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                                const Eigen::VectorXd& coefficients_old,
                                const double dt,
                                Eigen::VectorXd* coefficients_new,
                                double* condition_number_, 
                                float* contraction_time,
                                float* solver_time) = 0;

  virtual void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                              const Eigen::MatrixXd& A,     // transfer matrix for non-orthogonal bases.
                              const Eigen::VectorXd& coefficients_old,
                              const double dt,
                              Eigen::VectorXd& coefficients_new,
                              double& condition_number_, 
                              float& contraction_time,
                              float& solver_time) {
    LOG(FATAL) << "not implemented";
  };

  virtual void IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                              const Eigen::MatrixXd& A,     // transfer matrix for non-orthogonal bases.
                              const Eigen::VectorXd& coefficients_old,
                              const double dt,
                              Eigen::VectorXd& coefficients_new) {
    LOG(FATAL) << "not implemented";
  };

  template<typename MAT>
  static void solveDiffusion(const MAT& D,
                             const MAT& A,     // transfer matrix for non-orthogonal bases.
                             const Eigen::VectorXd& coefficients_old,
                             const double vdt,
                             Eigen::VectorXd& coefficients_new);

  // The default choice of CG.
  static void conjugate_gradient(const Eigen::MatrixXd& mat, const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                        const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond, int& iters,
                        Eigen::VectorXd::RealScalar& tol_error);

  // solve a system of mat' = A mat A^T
  template<typename MAT>
  static void conjugate_gradient_A(const MAT& D, const MAT& A, const double vdt,
                        const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                        const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond, int& iters,
                        Eigen::VectorXd::RealScalar& tol_error);

  // CG on normal equation.                              
  static void conjugate_gradient_NE(const Eigen::MatrixXd& mat, const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                        const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond,
                        int& iters,
                        Eigen::VectorXd::RealScalar& tol_error);

  
  // CG on normal equation.                              
  static void conjugate_gradient_NEA(const Eigen::MatrixXd& C, const double dt, const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                        const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond,
                        int& iters,
                        Eigen::VectorXd::RealScalar& tol_error);

  // CG on normal equation. with transfer matrix for correction.
  template<typename MAT, typename MAT1>
  static void conjugate_gradient_NEA(const MAT1& C, const MAT& A, const double dt,  const Eigen::VectorXd& rhs,
                                     Eigen::VectorXd& x, int& iters,
                                     Eigen::VectorXd::RealScalar& tol_error);

  static Eigen::VectorXd skewSymMult(const Eigen::MatrixXd& C, const Eigen::MatrixXd& A, const Eigen::VectorXd& rhs);
protected:
};

#endif  // INTEGRATOR_2D_H
