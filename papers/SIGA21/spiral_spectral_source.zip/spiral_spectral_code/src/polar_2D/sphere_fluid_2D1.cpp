#include <cstdlib>
#include <ctime>
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <fstream>
#include <glog/logging.h>
#include <math.h>

#include <stb_image.h>
#define STBI_MSC_SECURE_CRT
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <stb_image_write.h>

#include "util/gl4_drawer.h"
#include "3D/drawer_3d.h"
#include "2D/FIELD2D.h"
#include "3D/particle_3d.h"
#include "2D/VFIELD2D.h"

#include "Alg/VEC2.h"

#include "solver/bi_cg_s_solver.h"
#include "solver/bi_cg_stab_preconditioned.h"
#include "solver/integrator_2d.h"
#include "solver/integrator_RK4.h"
#include "solver/integrator_semi_implicit.h"
#include "solver/symmetric_cg.h"
#include "solver/trapezoidal.h"

#include "polar_2D/sphere_fluid_2D1.h"
#include "polar_2D/sphere_basis_set_2D.h"
#include "polar_2D/torus_basis_set_2D.h"
#include "elliptic/prolate_oblate_2D.h"

#include "util/timer.h"
#include "util/util.h"
#include "util/read_write_tensor.h"
#include "util/stringprintf.h"
#include "util/transform.h"

#include "setting.h"
using namespace std;

void SphereFluid2D1::Initialize() {
  // Initialize the density and velocity field.
  velocity_ = VFIELD2D(nPhi_, nTheta_);
  force_    = VFIELD2D(nPhi_, nTheta_);

  density_     = FIELD2D(nPhi_, nTheta_);
  density_old_ = FIELD2D(nPhi_, nTheta_);

  densityG_     = FIELD2D(nPhi_, nTheta_);
  densityG_old_ = FIELD2D(nPhi_, nTheta_);
  
  densityB_     = FIELD2D(nPhi_, nTheta_);
  densityB_old_ = FIELD2D(nPhi_, nTheta_);

  forceMag_ = FIELD2D(nPhi_, nTheta_);
  initDensityR_ = FIELD2D(nPhi_, nTheta_);
  initDensityG_ = FIELD2D(nPhi_, nTheta_);
  initDensityB_ = FIELD2D(nPhi_, nTheta_);

  timer_ = Timer();

  int radK = floor(sqrtf((double)(numBasisAll)));
  int angK = radK;

  ifstream in;
  if (tensor_fname_.size() != 0) {
    in.open(tensor_fname_);
    if (! in.is_open())
      LOG(FATAL) << "cannot open " << tensor_fname_;
  }

  // Initialize the basis.
  int basis_type_int;
  if (basis_type_ == "sphere_2d") {
    basis_type_int = 5;
    if (tensor_fname_.size() == 0)
      basis_.reset(new SphereBasisSet2D(nTheta_, radK, angK));
    else
      basis_.reset(new SphereBasisSet2D(nTheta_, in));
  } else if (basis_type_ == "prolate_2d") {
    basis_type_int = 7;
    is_prolate_ = true;
    if (tensor_fname_.size() == 0)
      basis_.reset(new SphereBasisSet2D(nTheta_, radK, angK, true, b_));
    else
      basis_.reset(new SphereBasisSet2D(nTheta_, in));
  } else if (basis_type_ == "oblate_2d") {
    basis_type_int = 8;
    is_oblate_ = true;
    if (tensor_fname_.size() == 0)
      basis_.reset(new SphereBasisSet2D(nTheta_, radK, angK, false, true, b_));
    else
      basis_.reset(new SphereBasisSet2D(nTheta_, in));
  } else if (basis_type_ == "torus_2d") {
    if (tensor_fname_.size() == 0) {
      radK = floor(sqrtf((double)(numBasisAll)/8.0));
      basis_.reset(new TorusBasisSet2D(nTheta_, radK, radK*4, 3));
    } else
      basis_.reset(new TorusBasisSet2D(nTheta_, in));

    dTheta_ = 2.0*M_PI/nTheta_;
  } else {
    LOG_ASSERT(false) << "Unknow basis tpye: " << basis_type_;
  }

  if (basis_type_ == "sphere_2d" || basis_type_ == "prolate_2d" || basis_type_ == "oblate_2d") {
    a_ = std::static_pointer_cast<SphereBasisSet2D>(basis_)->a();
    b_ = std::static_pointer_cast<SphereBasisSet2D>(basis_)->b();
    c_ = std::static_pointer_cast<SphereBasisSet2D>(basis_)->c();
  } else if (basis_type_ == "torus_2d") {
    a_ = std::static_pointer_cast<TorusBasisSet2D>(basis_)->getMajorA();
    forceMask_ = FIELD2D(nPhi_, nTheta_);
  }

  numBasisAll = basis_.get()->numBasisAll();
  numBasisOrtho = basis_.get()->GetnumBasisOrtho();

  LOG(INFO) << "orthogonal basis allocated: " << numBasisOrtho << " all " << numBasisAll;
  A_ = basis_.get()->transferMat();
  // Initialize the coefficients.
  basis_coefficients_.resize(numBasisOrtho);
  basis_coefficients_.setZero();

  basis_coefficients_old_.resize(numBasisOrtho);
  basis_coefficients_old_.setZero();

  tempVector_.resize(numBasisOrtho);
  tempVector_.setZero();

  // Initialize drawer.
  drawer_.reset(new Drawer3D());

  basisWeights_.resize(numBasisAll);
  basisWeights_.setOnes();

  // Fill the tensor.
  if (tensor_fname_.size() == 0) {
    LOG(INFO) << "Fill the advection tensor...";
    basis_.get()->FillVariationalTensor(&Adv_tensor_);
  } else {
    LOG(INFO) << "Read tensor from file.";
    //ReadTensor(tensor_fname_, numBasisAll, basis_type_int, &Adv_tensor_);
    ReadTensor(in, numBasisAll, basis_type_int, &Adv_tensor_);
  }
  //BasisSet::VerifyAntisymmetric(Adv_tensor_);
  //exit(0);
  for (int i = 0; i < Adv_tensor_.size(); i++) {
      Adv_tensor_[i] *= tensorWeight_;
  }
  particles_.resize(num_particles_);
  basis_->ReSeedParticles(particles_);
  particleSys_.reset(new ParticleSystem(0.02));
  initDensityParticles();

  rest_frame_ = total_frame_;
  integrator_time_ = 0.;
  transformation_time_ = 0.;
  density_advection_time_ = 0.;
  maximum_condition_number_ = 0.;
  frame_simulated_ = 0;
  Eigen::VectorXd allCoef = Eigen::VectorXd::Zero(numBasisAll);
  if (! headless_) {
    coefDrawer_.reset(new coeffcientDrawGL4(basis_coefficients_, 1.0));
    drawers_.ptlGL4_.reset(new particle3DGL4(num_particles_));
    drawers_.textureShader_.reset(new Shader("./src/shaders/model_textureShader.vs", "./src/shaders/model_textureShader.fs"));
    drawers_.fixColorShader_.reset(new Shader("./src/shaders/fixColor.vs", "./src/shaders/fixColor.fs"));
    if (basis_type_ == "torus_2d")
      drawers_.densDrawer_.reset(new denstityDrawerSurface(nPhi_, nTheta_, "./models/torus/torus.obj"));
    else
      drawers_.densDrawer_.reset(new denstityDrawerSurface(nPhi_, nTheta_));
  }
  basis_coefficients_ = basis_.get()->transferMat()*allCoef;
  const Eigen::VectorXd& waveN2 = basis_->waveNum2();
  computeSortedIdx(waveN2);

  Eigen::MatrixXd Aabs = A_.array().abs();
  // need to normalize Aabs
  for (int i = 0; i < Aabs.rows(); i++) {
    Aabs.row(i) /= Aabs.row(i).sum();
  }
  denseMatrixToSparse(A_, sparseA_);

  projWav_ = Aabs*waveN2;
}

void SphereFluid2D1::Step() {

  float DCT_time = 0;
  float integrator_time = 0;
  float advection_time = 0;
  float contraction_time = 0;
  float solver_time = 0;

  current_energy_ = CalculateEnergy();
  
  // Swap the coefficients.
  for (int i = 0; i < basis_coefficients_.size(); i++) {
    basis_coefficients_old_[i] = basis_coefficients_[i];
  }

  double condition_number = 1.0;

  integrator_.get()->IntegrateForward(Adv_tensor_, sparseA_, basis_coefficients_old_,
                                       dt_,
                                       basis_coefficients_, condition_number,
                                       contraction_time, solver_time);

  if (condition_number > maximum_condition_number_) {
    maximum_condition_number_ = condition_number;
  }

  integrator_time = contraction_time + solver_time;
  
  // Disspate energy from viscosity.
  DissipateEnergy();
  // Reconstruct the velocity field.
  timer_.Reset();
  // coefficients for all the basis.

  fieldCoef_ = A_.transpose()*basis_coefficients_;
  basis_.get()->InverseTramsformToVelocity(fieldCoef_, &velocity_);

  DCT_time += timer_.ElapsedTimeInSeconds();
  
  timer_.Reset();
  // Advect density.
  AdvectDensity();

  // Advect particles.
  //AdvectParticles();
  advection_time = timer_.ElapsedTimeInSeconds();
  rest_frame_ --;
  if (rest_frame_ <=0) {
    Quit();
  }

  // Add buoyancy by using DCT to transform to freq domain.
  AddBuoyancy();

  timer_.Reset();
  DCT_time += timer_.ElapsedTimeInSeconds();
  // Add external forces.
  AddExternalForce();
  timer_.Reset();
  resetDensity();

  LOG(INFO) << "Frame: " << frame_simulated_;
  LOG(INFO) << "Total energy: " << current_energy_;

  LOG(INFO) << "DCT time: " << DCT_time;
  LOG(INFO) << "Advection time: " << advection_time;
  LOG(INFO) << "Contraction time: " << contraction_time;
  LOG(INFO) << "Solver time: " << solver_time;

  integrator_time_ += integrator_time;
  density_advection_time_ += advection_time;  
  transformation_time_ += DCT_time;
  
  frame_simulated_ ++;
}

// stripe pattern.
void SphereFluid2D1::initDensityParticles() {
  if (basis_type_ == "sphere_2d" && scenario_ == 0) {
    float area1 = computeSpherePatchArea(0.45*M_PI, 0.55*M_PI, 0., 2.0*M_PI); 
    float area2 = computeSpherePatchArea((0.38 - 0.023)*M_PI, (0.38 + 0.023)*M_PI, 0., 2.0*M_PI);
    float area3 = computeSpherePatchArea((0.32 - 0.023)*M_PI, (0.32 + 0.023)*M_PI, 0., 2.0*M_PI);
    float area4 = computeSpherePatchArea((0.26 - 0.015)*M_PI, (0.26 + 0.015)*M_PI, 0., 2.0*M_PI);
    float totaArea = area1 + 2.*area2 + 2.*area3 + 2.*area4;
    float ptlPerArea = (float)maxDensityParticles_/totaArea;
  }

  setParticleColor();

  for (int i = 0; i < nPhi_*nTheta_; i++)
    density_[i] = initDensityR_[i];

  for (int i = 0; i < nPhi_*nTheta_; i++)
    densityG_[i] = initDensityG_[i];

  for (int i = 0; i < nPhi_*nTheta_; i++)
    densityB_[i] = initDensityB_[i];
}

void SphereFluid2D1::resetDensity() {
  const double w = blendW_;
  for (int i = 0; i < nTheta_*nPhi_; i++)
    density_[i] = w*density_[i] + (1.0 - w)*initDensityR_[i];

  for (int i = 0; i < nTheta_*nPhi_; i++)
    densityG_[i] = w*densityG_[i] + (1.0 - w)*initDensityG_[i];

  for (int i = 0; i < nTheta_*nPhi_; i++)
    densityB_[i] = w*densityB_[i] + (1.0 - w)*initDensityB_[i];
}

// for plantary flow.
void SphereFluid2D1::AddBuoyancy() {
  if ((basis_type_ == "sphere_2d" || basis_type_ == "torus_2d")  && scenario_ == 0) {

    if (current_energy_ > 0.5)
      return;
    // toggle it to zero for plantary flow. 1000 for turbulent effects
    const double omega = omega_;
    // coriolis force
    double maxVal = 0.0;
    for (int j = 0; j <  nTheta_; j++) {
      double theta = ((double)j + 0.5)*dTheta_;
      double cosT = cos(theta);
      for (int i = 0; i < nPhi_; i++) {
        int sign0 = force_(i,j)[0] < 0 ? -1 : 1;
        int sign1 = force_(i,j)[1] < 0 ? -1 : 1;
        force_(i,j)[0] += clamp(velocity_(i,j)[1]*velocity_(i,j)[1]*velocity_(i,j)[1]*cosT*omega, -5., 5.);
        force_(i,j)[1] += clamp(-velocity_(i,j)[0]*velocity_(i,j)[0]*velocity_(i,j)[0]*cosT*omega, -5., 5.);
      }
    }

    if (frame_simulated_ <= 1)
      basis_coefficients_ += Eigen::VectorXd::Random(numBasisOrtho)*0.0002/dt_;

    VEC2 ff(0, 0.3);
    addForcePatch(nPhi_/2, nTheta_/2, nPhi_, (int)(nTheta_*0.1), -ff);
    addForcePatch(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.12), nPhi_, (int)(nTheta_*0.045), 1.2*ff);
    addForcePatch(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.12), nPhi_, (int)(nTheta_*0.045), 1.2*ff);
    addForcePatch(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.18), nPhi_, (int)(nTheta_*0.045), -1.4*ff);
    addForcePatch(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.18), nPhi_, (int)(nTheta_*0.045), -1.4*ff);
    addForcePatch(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.24), nPhi_, (int)(nTheta_*0.03), 2.0*ff);
    addForcePatch(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.24), nPhi_, (int)(nTheta_*0.03), 2.0*ff);

  }
}

void SphereFluid2D1::AdvectDensity() {
  //LOG(FATAL) << "depredated";
  const double dt0 = dt_/10.0;
  for (int i = 0; i < 10; i++) {
    density_.swapPointer(density_old_);
    VFIELD2D::advectSphere(dt0, velocity_, density_old_, density_, VEC2(0,0), VEC2(0,0));
    
    densityG_.swapPointer(densityG_old_);
    VFIELD2D::advectSphere(dt0, velocity_, densityG_old_, densityG_, VEC2(0,0), VEC2(0,0));
    
    densityB_.swapPointer(densityB_old_);
    VFIELD2D::advectSphere(dt0, velocity_, densityB_old_, densityB_, VEC2(0,0), VEC2(0,0));
  }
}

void SphereFluid2D1::AddSmokeTestCase(
    const int xpos, const int ypos, const int width, const int height, const double amount) {
  AddDensity(xpos, ypos, width, height, amount, &density_);  
}

void SphereFluid2D1::AddDensity(const int x, const int y, const int width,
                                const int height, const double amount, FIELD2D* field) {
  int startx = x - width / 2;
  int starty = y - height / 2;
  int endx = x + width / 2;
  int endy = y + height / 2;
  startx = startx < 0 ? 0 : startx;
  starty = starty < 0 ? 0 : starty;
  endx = endx >= nPhi_ ? nPhi_-1 : endx;
  endy = endy >= nTheta_ ? nTheta_-1 : endy;

  for (int j = starty; j <= endy; j++) {
    for (int i = startx; i <= endx; i++) {
      density_(i, j) += amount;
    }
  }
}

void SphereFluid2D1::addForcePatch(const int x, const int y, const int width,
                      const int height, const VEC2& f) {
  int startx = x - width / 2;
  int starty = y - height / 2;
  int endx = x + width / 2;
  int endy = y + height / 2;
  startx = startx < 0 ? 0 : startx;
  starty = starty < 0 ? 0 : starty;
  endx = endx >= nPhi_ ? nPhi_-1 : endx;
  endy = endy >= nTheta_ ? nTheta_-1 : endy;

  for (int j = starty; j <= endy; j++) {
    for (int i = startx; i <= endx; i++) {
      force_(i, j) += f;
    }
  }
}

// Convert the external force field into the coefficients, and then
// add the external forces.
void SphereFluid2D1::AddExternalForce() {
  Eigen::VectorXd force_coef(numBasisOrtho); force_coef.setZero();
  basis_.get()->ForwardTransformtoFrequency(force_, &force_coef);

  for (int i = 0; i < numBasisOrtho; i++) {
    basis_coefficients_[i] += force_coef[i] * dt_;
  }
  force_.clear();
}

void SphereFluid2D1::DrawDensity(const glm::mat4& projection, const glm::mat4& view, const glm::mat4& rot,
                                const double& ptl_length) {

  basis_->DrawDensity(projection, view, rot, densityB_, particles_, ptl_length*dt_, drawers_);
}

void SphereFluid2D1::DrawCoefficients(const double multi_factor) {
  Eigen::VectorXd energy_w = basis_coefficients_.cwiseProduct(basis_coefficients_);
  // sort according to the charastic wave numbers.
  Eigen::VectorXd energySorted = Eigen::VectorXd::Zero(numBasisOrtho);
  for (int i = 0; i < sortedIndex_.size(); i++)
    energySorted[i] = energy_w[sortedIndex_[i]];
  coefDrawer_->Draw(energySorted, multi_factor*20.0);
}

void SphereFluid2D1::writeTextureImage(const std::string& path) {
  char pixels[nPhi_*nTheta_*3];
  memset(pixels, 0x00, nPhi_*nTheta_*3*sizeof(char));
  for (int j = 0; j < nTheta_; j++)
    for (int i = 0; i < nPhi_; i++) {
      int idx = i + j*nPhi_;
      double dens = density_[idx];
      dens = dens < 0 ? 0 : dens;
      dens = dens > 1.0 ? 1.0 : dens;
      dens = 1.0 - dens;
      dens *= 255.0;
      pixels[idx*3] = (char)(dens);
      pixels[idx*3 + 1] = (char)(dens);
      pixels[idx*3 + 2] = (char)(dens);
    }

  std::string fname = StringPrintf("%s/%04d.png", path.c_str(), frame_simulated_);
  stbi_write_png(fname.c_str(), nPhi_, nTheta_, 3, pixels, nPhi_*3);
}

void SphereFluid2D1::averageImg(const int width, const int height, const int channels, unsigned char *img) {
  for (int j = 0; j < height; j++) {
    uint64_t Rval = 0, Gval = 0, Bval = 0;
    for (int i = 0; i < width; i++) {
      Rval += uint64_t(img[channels*(i + j*width)]);
      Gval += uint64_t(img[channels*(i + j*width) + 1]);
      Bval += uint64_t(img[channels*(i + j*width) + 2]);
    }
    Rval /= width;
    Gval /= width;
    Bval /= width;
    for (int i = 0; i < width; i++) {
      img[channels*(i + j*width)] = char(Rval);
      img[channels*(i + j*width) + 1] = char(Gval);
      img[channels*(i + j*width) + 2] = char(Bval);
    }
  }
}

void SphereFluid2D1::setParticleColor() {
  int width, height, channels;
  unsigned char *img = stbi_load("./models/Jupiter_at_a_glance.jpg", &width, &height, &channels, 0);
  if(img == NULL) {
      printf("Error in loading the image\n");
      exit(1);
  }
  //averageImg(width, height, channels, img);

  // background color
  Eigen::Vector3f col(132.0, 103.0, 71.0);
  col /= 255.0;
  setInitColor(nPhi_/2, nTheta_/2, nPhi_, (int)(nTheta_), col);
  
  col = Eigen::Vector3f(90.0, 33.0, 24.0);
  col /= 255.0;
  setInitColor(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.27), nPhi_, (int)(nTheta_*0.03), col);
  setInitColor(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.27), nPhi_, (int)(nTheta_*0.03), col);

  col = Eigen::Vector3f(60.0, 10.0, 5.0);
  col /= 255.0;
  setInitColor(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.22), nPhi_, (int)(nTheta_*0.02), col);
  setInitColor(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.22), nPhi_, (int)(nTheta_*0.02), col);

  col = Eigen::Vector3f(159.0, 163.0, 174.0);
  col /= 255.0;
  setInitColor(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.18), nPhi_, (int)(nTheta_*0.035), col);
  setInitColor(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.18), nPhi_, (int)(nTheta_*0.035), col);

  col = Eigen::Vector3f(74, 9, 15.0);
  col /= 255.0;
  setInitColor(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.12), nPhi_, (int)(nTheta_*0.034), col);
  setInitColor(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.12), nPhi_, (int)(nTheta_*0.034), col);

  setInitColor(nPhi_/2, nTheta_/2 - (int)(nTheta_*0.08), nPhi_, (int)(nTheta_*0.023), col);
  setInitColor(nPhi_/2, nTheta_/2 + (int)(nTheta_*0.08), nPhi_, (int)(nTheta_*0.023), col);

  col = Eigen::Vector3f(200.0, 204.0, 205.0);
  col /= 255.0;

  setInitColor(nPhi_/2, nTheta_/2, nPhi_, (int)(nTheta_*0.06), col);
}

void SphereFluid2D1::setInitColor(const int x, const int y, const int width,
                  const int height, const Eigen::Vector3f& col) {

  int startx = x - width / 2;
  int starty = y - height / 2;
  int endx = x + width / 2;
  int endy = y + height / 2;
  startx = startx < 0 ? 0 : startx;
  starty = starty < 0 ? 0 : starty;
  endx = endx >= nPhi_ ? nPhi_-1 : endx;
  endy = endy >= nTheta_ ? nTheta_-1 : endy;
  uniform_real_distribution<float> u(0.f, 2.f);

  for (int j = starty; j <= endy; j++) {
    Eigen::Vector3f rndCol = col;
    rndCol[0] *= u(m_gen_);
    rndCol[1] *= u(m_gen_);
    rndCol[2] *= u(m_gen_);
    if (rndCol[1] > rndCol[0] && rndCol[1] > rndCol[2])
      rndCol = col;

    if (rndCol[0] < 0) rndCol[0] = 0;
    if (rndCol[1] < 0) rndCol[1] = 0;
    if (rndCol[2] < 0) rndCol[2] = 0;
    for (int i = startx; i <= endx; i++) {
      initDensityR_[i + j*nPhi_] = rndCol[0];
      initDensityG_[i + j*nPhi_] = rndCol[1];
      initDensityB_[i + j*nPhi_] = rndCol[2];
    }
  }
}