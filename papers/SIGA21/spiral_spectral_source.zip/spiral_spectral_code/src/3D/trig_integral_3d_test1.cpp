#include <glog/logging.h>
#include <vector>
#include "3D/trig_integral_3d.h"
#include "util/util.h"

using namespace std;
vector<vector<int>> testN = {{0, 0, 0},{0, 0, 1},{0, 1, 0},{2, 2, 0},{2, 2, 2},{2, 4, 6},{2, 4, 4},{4, 2, 4},{4, 4, 4},{4, 2, 2},{8, 8, 16},{10, 14, 16},{14, 12, 16},{3, 3, 0},{3, 3, 3},{3, 5, 7},{1, 3, 3},{5, 3, 5},{5, 5, 5},{5, 3, 3},{7, 13, 15} ,{11, 15, 17},{13, 11, 15}};
vector<int> testN1 = {0,1,2,3,4,5,6,7,8,-1,-2,-3,-4};

vector<vector<int>> testN2 = {{0, 0}, {1, 1}, {2, 2}, {3, 3}, {-3, 3}, {-2, 2}, {-2, 
    1}, {1, -1}, {10, 
    12}, {10, -5}, {-5, -5}, {-3, -5}, {-4, -5}, {-5, 2}, {0, 5}, {0, 
    2}, {0, 1}, {0, 2}};

#define IR7C(a2) IntegralR7C_D2(a2)/PI8
#define IR7S(a2) IntegralR7S_D2(a2)/PI8
#define IR6C(a2) IntegralR6C_D2(a2)/PI7
#define IR6S(a2) IntegralR6S_D2(a2)/PI7
#define IR5C(a2) IntegralR5C_D2(a2)/PI6
#define IR5S(a2) IntegralR5S_D2(a2)/PI6
#define IR4C(a2) IntegralR4C_D2(a2)/PI5
#define IR4S(a2) IntegralR4S_D2(a2)/PI5

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  vector<double> vals2 = {0., 0., 0., 0., 0., 0.25, 0., 0., 0., -0.25, 0.25, 0., 0., 0., \
-0.0707355, 0.183912, 0.309215, -0.0349791, 0.0424413, -0.0810243, \
0.0464833, 0.026049, 0.0188841};
for (int i = 0; i < testN.size(); i++) {
  CHECK(fabs(ComputeIntegralCSS_D2(testN[i][0], testN[i][1], testN[i][2]) - vals2[i]) < 1e-5);
}

  vector<double> vals3 = {0., 4., 3.14159, -0.444444, -1.5708, 0.16, 1.0472, -0.0816327, \
-0.785398, -4., -3.14159, 0.444444, 1.5708};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralRS_D2(testN1[i]) - vals3[i]) < 1e-5);
}

  vector<double> vals1 = {0., 0., 0.405285, -0.0795775, 0.106103, 0.00663146, 0.0424413, \
0.148545, -0.0530516, -0.0198944, -0.00497359, -0.0185681, 0.0222312, \
0.0530516, -0.010007, 0.0980689, 0.00198507, -0.0198485, 0.00360253, \
0.100484, 0.00294901, 0.000826301, 0.00143321};
for (int i = 0; i < testN.size(); i++) {
  CHECK(fabs(ComputeIntegralRCSC_D2(testN[i][0], testN[i][1], testN[i][2]) - vals1[i]) < 1e-5);
}

vector<double> vals4 = {10.335425560099939, 3.73921, -6.28319, -5.98714, 1.5708, 3.81984, -0.698132, \
-2.77324, 0.392699, 3.73921, -6.28319, -5.98714, 1.5708};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralR2C_D2(testN1[i]) - vals4[i]) < 1e-5);
}

  vector<double> vals = {0., 0., 0., 0.141336, -0.0450316, -0.0689091, -0.00360253, \
-0.00360253, 0.0112579, 0.080167, -0.0819481, -0.00137909, \
0.000481971, 0.177925, -0.0657806, 0.0287292, 0.0531592, -0.0345443, \
0.041371, 0.0445205, -0.00118287, 0.00594158, 0.00809157};

for (int i = 0; i < testN.size(); i++) {
  CHECK(fabs(ComputeIntegralR2SSC_D2(testN[i][0], testN[i][1], testN[i][2]) - vals[i]) < 1e-5);
}

 vector<double> vals5 = {0., 0., 0., 0., 0.970262, 0.34807, 0.936168, 0.936168, 0.684105, \
0.336035, 0.377836, 0.748584, 0.817545, 0., 0.814797, 0.729986, \
0.679662, 0.806756, 0.773729, 0.727085, 0.780129, 0.783307, 0.783176};

//for (int i = 0; i < testN.size(); i++) {
//  CHECK(fabs(ComputeIntegralRInvSSS_D2(testN[i][0], testN[i][1], testN[i][2]) - vals5[i]) < 1e-5);
//}

vector<double> vals6 = {0., 0., 0., 0., 0.212207, -0.0464202, 0.169765, 0.169765, -0.106103, \
-0.0596831, -0.0149208, -0.0371362, 0.0323362, 0., -0.0350246, \
0.107075, 0.208763, -0.0251831, 0.0126089, 0.110264, 0.00561619, \
0.00213496, 0.00226762};
for (int i = 0; i < testN.size(); i++) {
  CHECK(fabs(ComputeIntegralRSSS_D2(testN[i][0], testN[i][1], testN[i][2]) - vals6[i]) < 1e-5);
}

vector<double> vals7 = {3.14159, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralCosInt(testN1[i]) - vals7[i]) < 1e-4);
}
vector<double> vals8 = {0., 2., 0., 0.666667, 0., 0.4, 0., 0.285714, 0., -2., 0., -0.666667, 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinInt(testN1[i]) - vals8[i]) < 1e-4);
}

vector<double> vals9{0., 3.14159, 0., 3.14159, 0., 3.14159, 0., 3.14159, 0., -3.14159, \
0., -3.14159, 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinDivSin(testN1[i]) - vals9[i]) < 1e-5);
}
  vector<double> Hseries;
  readOddHarmonicSeries("./src/Hseries.bin", Hseries);
  vector<double> vals10 = {56.64833659297699, 0., 52.64833659297699, 0., 51.31500325964365, 0., \
50.515003259643656, 0., 49.94357468821509, 0., 52.64833659297699, \
0., 51.31500325964365};

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralCosDivSin(testN1[i], Hseries.data()) - vals10[i]) < 1e-10);
  //LOG(INFO) << IntegralCosDivSin(testN1[i], Hseries) << " " << vals10[i];
}

vector<double> vals11 = {6.28319, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralCosInt2Pi(testN1[i]) - vals11[i]) < 1e-5);
}

vector<double> vals12 = {0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralSinInt2Pi(testN1[i]) - vals12[i]) < 1e-5);
}

vector<double> vals13 = {0., 1.33333, 1.06667, 1.02857, -1.02857, -1.06667, 0., -1.33333, \
-0.331263, 0., 1.0101, -0.31746, 0., 0., 0., 0., 0., 0.};
for (int i = 0; i < testN2.size(); i++) {
  CHECK(fabs(IntegSinSinWSin(testN2[i][0], testN2[i][1]) - vals13[i]) < 1e-5);
  CHECK(fabs(IntegSinSinWSin(testN2[i][1], testN2[i][0]) - vals13[i]) < 1e-5);
}
vector<double> vals14 = {0., 0., 0., 0., 0., 0., -0.785398, 0., 0., 0., 0., 0., -0.785398, \
0., 0., 0., 1.5708, 0.};
for (int i = 0; i < testN2.size(); i++) {
  CHECK(fabs(IntegCosSinWSin(testN2[i][0], testN2[i][1]) - vals14[i]) < 1e-5);
}

vector<double> vals15 = {2., 0.666667, 0.933333, 0.971429, 0.971429, 0.933333, 0., 0.666667, \
-0.335404, 0., 0.989899, -0.349206, 0., 0., 0., -0.666667, 0., \
-0.666667};
for (int i = 0; i < testN2.size(); i++) {
  CHECK(fabs(IntegCosCosWSin(testN2[i][0], testN2[i][1]) - vals15[i]) < 1e-5);
  CHECK(fabs(IntegCosCosWSin(testN2[i][1], testN2[i][0]) - vals15[i]) < 1e-5);
}

vector<double> vals16 = {0., 22.4353, 12.1567, -11.9743, -13.1469, 4.58381, 9.63729, \
-2.37706, -7.45704, -22.4353, -12.1567, 11.9743, 13.1469};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR3S_D2(testN1[i]) - vals16[i]) < 1e-4);
}

 vector<double> vals17 = {24.3523, 7.21611, -17.6088, -13.9006, 7.4022, 11.3497, -3.14172, \
-8.37931, 1.85055, 7.21611, -17.6088, -13.9006, 7.4022};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR3C_D2(testN1[i]) - vals17[i]) < 1e-4);
}

 vector<double> vals18 = {0., 57.7288, 26.9738, -37.0683, -33.9001, 18.1596, 28.2807, \
-9.57636, -22.5017, -57.7288, -26.9738, 37.0683, 33.9001};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR4S_D2(testN1[i]) - vals18[i]) < 1e-4);
}

 vector<double> vals19 = {61.2039, 15.3362, -48.6269, -33.008, 26.2939, 31.6295, -12.8497, \
-25.1145, 7.45704, 15.3362, -48.6269, -33.008, 26.2939};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR4C_D2(testN1[i]) - vals19[i]) < 1e-4);
}

vector<double> vals20 = {0., 153.362, 62.8853, -110.027, -87.2751, 63.2591, 80.5904, \
-35.8779, -67.1836, -153.362, -62.8853, 110.027, 87.2751};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR5S_D2(testN1[i]) - vals20[i]) < 1e-3);
}

vector<double> vals21 = {160.232, 34.7509, -134.869, -80.4521, 84.7503, 86.0887, -47.1346, \
-73.7537, 28.1272, 34.7509, -134.869, -80.4521, 84.7503};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR5C_D2(testN1[i]) - vals21[i]) < 1e-3);
}
vector<double> vals22 = {0., 417.011, 152.174, -321.808, -226.444, 206.613, 226.194, \
-126.435, -198.157, -417.011, -152.174, 321.808, 226.444};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR6S_D2(testN1[i]) - vals22[i]) < 1e-3);
}
vector<double> vals23 = {431.47, 82.4392, -377.312, -200.82, 261.825, 232.734, -161.181, \
-213.178, 100.775, 82.4392, -377.312, -200.82, 261.825};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR6C_D2(testN1[i]) - vals23[i]) < 1e-3);
}
vector<double> vals24 = {0., 1154.15, 379.112, -937.16, -593.758, 651.655, 630.676, -426.355, \
-578.716, -1154.15, -379.112, 937.16, 593.758};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR7S_D2(testN1[i]) - vals24[i]) < 1e-2);
}
vector<double> vals25={1186.07, 202.437, -1065.22, -511.756, 792.552, 629.601, -527.786, \
-610.071, 346.774, 202.437, -1065.22, -511.756, 792.552};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR7C_D2(testN1[i]) - vals25[i]) < 1e-2);
}

vector<double> vals26={0., 0.108658, 0.0324325, -0.0915615, -0.0528045, 0.0675875, \
0.0588886, -0.0467793, -0.0563112, -0.108658, -0.0324325, 0.0915615, \
0.0528045};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR8S_D2_ONE(testN1[i]) - vals26[i]) < 1e-2);
}

vector<double> vals27= {0.111111, 0.0171314, -0.101744, -0.0445334, 0.0796747, 0.057369, \
-0.0564191, -0.0582534, 0.0388282, 0.0171314, -0.101744, -0.0445334, \
0.0796747};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR8C_D2_ONE(testN1[i]) - vals27[i]) < 1e-2);
}

vector<double> vals28={0., 2., 2., 0.666667, 0., 0.4, 0.666667, 0.285714, 0., -2., -2., \
-0.666667, 0.};

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralS_D2(testN1[i]) - vals28[i]) < 1e-5) << IntegralS_D2(testN1[i]) << " " << vals28[i];
}

vector<double> vals29={3.14159, 2., 0., -0.666667, 0., 0.4, 0., -0.285714, 0., 2., 0., \
-0.666667, 0.};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralC_D2(testN1[i]) - vals29[i]) < 1e-5);
}

vector<double> vals30={0., 0.0981558, 0.026835, -0.0850526, -0.0450293, 0.06574, 0.052227, \
-0.0476811, -0.0517688, -0.0981558, -0.026835, 0.0850526, 0.0450293};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR9S_D2_ONE(testN1[i]) - vals30[i]) < 1e-5);
}

vector<double> vals31 = {0.1, 0.0140567, -0.0929123, -0.0373371, 0.0756369, 0.0498743, \
-0.0562344, -0.0526563, 0.0403299, 0.0140567, -0.0929123, -0.0373371, \
0.0756369};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR9C_D2_ONE(testN1[i]) - vals31[i]) < 1e-5);
}

vector<double> val32 = {0., 0.121636, 0.0399548, -0.0987677, -0.0625764, 0.0686782, \
0.0664672, -0.0449338, -0.0609911, -0.121636, -0.0399548, 0.0987677, \
0.0625764};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR7S_D2_ONE(testN1[i]) - val32[i]) < 1e-5);
}

vector<double> val33 = {0.125, 0.0213349, -0.112264, -0.0539341, 0.0835274, 0.0663539, \
-0.0556236, -0.0642956, 0.0365466, 0.0213349, -0.112264, -0.0539341, \
0.0835274};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR7C_D2_ONE(testN1[i]) - val33[i]) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR7C_D2_ONE(testN1[i]) - IR7C(testN1[i])) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR7S_D2_ONE(testN1[i]) - IR7S(testN1[i])) < 1e-5);
}
vector<double> val34 = {0., 0.13807, 0.0503839, -0.106549, -0.074974, 0.0684082, 0.0748914, \
-0.0418618, -0.0656084, -0.13807, -0.0503839, 0.106549, 0.074974};

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR6S_D2_ONE(testN1[i]) - val34[i]) < 1e-5);
}

vector<double> val35 = {0.142857, 0.0272951, -0.124925, -0.0664902, 0.0866887, 0.0770567, \
-0.0533659, -0.0705818, 0.0333661, 0.0272951, -0.124925, -0.0664902, \
0.0866887};

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR6C_D2_ONE(testN1[i]) - val35[i]) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR6C_D2_ONE(testN1[i]) - IR6C(testN1[i])) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR6S_D2_ONE(testN1[i]) - IR6S(testN1[i])) < 1e-5);
}

vector<double> val36 ={0.166667, 0.0361465, -0.140286, -0.0836832, 0.088154, 0.0895462, \
-0.0490276, -0.0767157, 0.0292568, 0.0361465, -0.140286, -0.0836832, \
0.088154};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR5C_D2_ONE(testN1[i]) - val36[i]) < 1e-5);
}

vector<double>val37 = {0., 0.159521, 0.0654108, -0.114445, -0.0907802, 0.0657997, 0.083827, \
-0.0373188, -0.0698818, -0.159521, -0.0654108, 0.114445, 0.0907802};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR5S_D2_ONE(testN1[i]) - val37[i]) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR5C_D2_ONE(testN1[i]) - IR5C(testN1[i])) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR5S_D2_ONE(testN1[i]) - IR5S(testN1[i])) < 1e-5);
}

vector<double>val38 ={0., 0.188644, 0.0881441, -0.12113, -0.110778, 0.0593412, 0.0924148, \
-0.0312933, -0.0735303, -0.188644, -0.0881441, 0.12113, 0.110778};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR4S_D2_ONE(testN1[i]) - val38[i]) < 1e-5);
}

vector<double>val39 = {0.2, 0.0501149, -0.158901, -0.107862, 0.0859222, 0.103358, \
-0.0419899, -0.0820683, 0.0243679, 0.0501149, -0.158901, -0.107862, \
0.0859222};
for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR4C_D2_ONE(testN1[i]) - val39[i]) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
   CHECK(fabs(IntegralR4C_D2_ONE(testN1[i]) - IR4C(testN1[i])) < 1e-5);
}

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralR4S_D2_ONE(testN1[i]) - IR4S(testN1[i])) < 1e-5);
}

vector<double> val40 = {0., 4., 0., 1.33333, 0., 0.8, 0., 0.571429, 0., -4., 0., -1.33333, \
0.};

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegrateSin2Pi_D2(testN1[i]) - val40[i]) < 1e-5);
}

vector<double> val41 = {6.28319, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegrateCos2Pi_D2(testN1[i]) - val41[i]) < 1e-5);
}

vector<double> val42 = {0., 0.23032, 0.124801, -0.122928, -0.134966, 0.0470573, 0.0989363, \
-0.0244029, -0.0765539, -0.23032, -0.124801, 0.122928, 0.134966};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralR3S_D2_ONE(testN1[i]) - val42[i]) < 1e-5);
}

vector<double> val43 = {0.25, 0.0740804, -0.180772, -0.142703, 0.0759909, 0.116516, \
-0.0322528, -0.0860219, 0.0189977, 0.0740804, -0.180772, -0.142703, \
0.0759909};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralR3C_D2_ONE(testN1[i]) - val43[i]) < 1e-5);
}

vector<double> val44 ={0., 0.294545, 0.189304, -0.109175, -0.159155, 0.0282946, 0.101325, \
-0.0180467, -0.0795775, -0.294545, -0.189304, 0.109175, 0.159155};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralR2S_D2_ONE(testN1[i]) - val44[i]) < 1e-5);
}

vector<double> val45 ={0.333333, 0.120595, -0.202642, -0.193095, 0.0506606, 0.123196, \
-0.0225158, -0.0894412, 0.0126651, 0.120595, -0.202642, -0.193095, \
0.0506606};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralR2C_D2_ONE(testN1[i]) - val45[i]) < 1e-5);
}

vector<double> val46 ={0., 0.405285, 0.31831, -0.0450316, -0.159155, 0.0162114, 0.106103, \
-0.00827112, -0.0795775, -0.405285, -0.31831, 0.0450316, 0.159155};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralRS_D2_ONE(testN1[i]) - val46[i]) < 1e-5);
}

vector<double> val47 ={0.5, 0.231335, -0.202642, -0.257238, 0., 0.111113, -0.0225158, \
-0.0992168, 0., 0.231335, -0.202642, -0.257238, 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralRC_D2_ONE(testN1[i]) - val47[i]) < 1e-5);
}

vector<double> val48 ={0., 0.63662, 0.63662, 0.212207, 0., 0.127324, 0.212207, 0.0909457, \
0., -0.63662, -0.63662, -0.212207, 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralS_D2_ONE(testN1[i]) - val48[i]) < 1e-5);
}
vector<double> val49 ={1., 0.63662, 0., -0.212207, 0., 0.127324, 0., -0.0909457, 0., \
0.63662, 0., -0.212207, 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralC_D2_ONE(testN1[i]) - val49[i]) < 1e-5);
}
//Integrate[1/r*Sin[w/2*Pi*r], {r, 0, 1}];
vector<double> val50 ={0., 1.37076, 1.85194, 1.60837, 1.41815, 1.55583, 1.67476, 1.57871, \
1.49216, -1.37076, -1.85194, -1.60837, -1.41815};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralRInvS_D2(testN1[i]) - val50[i]) < 1e-5);
}

vector<double> val51 = {13.8155, 13.2587, 12.1672, 11.4897, 11.3779, 11.301, 11.0056, \
10.7512, 10.7012, 13.2587, 12.1672, 11.4897, 11.3779};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralRInvC_D2(testN1[i]) - val51[i]) < 1e-4) << IntegralRInvC_D2(testN1[i]) << " " << val51[i];
}

vector<double> val52 ={29.0173, 0., 25.0173, 0., 23.684, 0., 22.884, 0., 22.3126, 0., \
25.0173, 0., 23.684};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinInvCosT(testN1[i]*2) - val52[i]) < 1e-4) << IntegralSinInvCosT(testN1[i]) << " " << val52[i];
}

vector<double> val53 ={0., 3.14159, 0., 3.14159, 0., 3.14158, 0., 3.14158, 0., -3.14159, \
0., -3.14159, 0.};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinInvSinT(testN1[i]*2) - val53[i]) < 1e-4) << IntegralSinInvSinT(testN1[i]*2) << " " <<val53[i];
}

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralC_D2(testN1[i]) - IntegralCosAny(testN1[i], 2, 0, 0, M_PI)) < 1e-12);
}

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralS_D2(testN1[i]) - IntegralSinAny(testN1[i], 2, 0, 0, M_PI)) < 1e-12);
}

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralC_D2(testN1[i]) - IntegralCosAny(testN1[i], 2, -testN1[i]*0.5*M_PI, M_PI, 2.0*M_PI)) < 1e-12);
}

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralS_D2(testN1[i]) - IntegralSinAny(testN1[i], 2, -testN1[i]*0.5*M_PI, M_PI, 2.0*M_PI)) < 1e-12);
}

vector<double> val54 ={0., 1.5, 2.25, 2., 1.125, 0.3, 0., 0.214286, 0.5625, -1.5, -2.25, \
-2., -1.125};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinAny(testN1[i], 3, 0, 0, M_PI) - val54[i]) < 1e-4);
  CHECK(fabs(IntegralSinAny(testN1[i], 3, 0, M_PI, 0) + val54[i]) < 1e-4);
}

vector<double> val55={1.50616, 2.56196, 2.59735, 1.75517, 0.675884, 0.014158, \
0, 0.365994, 0.649338, -0.0707898, -1.35177, -1.75517, \
-1.29868};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinAny(testN1[i], 3, 0.5, 0, M_PI) - val55[i]) < 1e-4);
  CHECK(fabs(IntegralSinAny(testN1[i], 3, 0.5, M_PI, 0) + val55[i]) < 1e-4);
}

vector<double> val56={1.50616, 2.99916, 1.35177, -0.958851, -1.29868, -0.312178, 
 0, -0.428452, -0.337942, -1.56089, -2.59735, -0.958851, \
0.675884};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralSinAny(testN1[i], 3, 0.5, M_PI*0.5, M_PI*3/2) - val56[i]) < 1e-4);
  CHECK(fabs(IntegralSinAny(testN1[i], 3, 0.5, M_PI*3/2, M_PI*0.5) + val56[i]) < 1e-4);
}

vector<double> val57={2.75701, 1.56089, 0.0613057, -0.958851, -1.10936, -0.599833, \
0, 0.222984, 0.0153264, 2.99916, 2.21872, 0.958851, \
-0.0306529};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralCosAny(testN1[i], 3, 0.5, 0, M_PI) - val57[i]) < 1e-4);
  CHECK(fabs(IntegralCosAny(testN1[i], 3, 0.5, M_PI, 0) + val57[i]) < 1e-4);
}

vector<double> val58={2.75701, 0.0707898, -2.21872, -1.75517, -0.0306529, 0.512392, 
 0, -0.0101128, 0.55468, 2.56196, -0.0613057, -1.75517, \
-1.10936};
for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(IntegralCosAny(testN1[i], 3, 0.5, M_PI*0.5, M_PI*3/2) - val58[i]) < 1e-4);
  CHECK(fabs(IntegralCosAny(testN1[i], 3, 0.5, M_PI*3/2, M_PI*0.5) + val58[i]) < 1e-4);
}


  return 0;
}
