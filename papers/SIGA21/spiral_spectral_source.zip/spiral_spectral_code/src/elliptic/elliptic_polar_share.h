#ifndef ELLIPTIC_POLAR_SHARE_2D_H
#define ELLIPTIC_POLAR_SHARE_2D_H

#define ALLOCATE_MGS_SHARE(PTRARG, CLASSARG, ADDARG)\
  /*diagonal blocks of the coefficient matrix.*/\
  std::vector<Eigen::MatrixXd> Coefs;\
  /* k1(rad) from 1 to radK*/\
  /* k2(ang) from 0 to angK*/\
  /* total of 5 modes.*/\
  phiCoef_.resize(5);\
  int offsetOdd = !boundaryCnd_ ? 1 : 0;\
  int offset = boundaryCnd_ ? 1 : 0;\
  const double thresh = 0.2;\
\
  /*Phi^2, Phi^0*/\
  for (int i2 = 1; i2 < angK_; i2++) {\
    std::vector<PTRARG> tempBuffer;\
\
    if (i2 == 1) {\
      /*phi^2*/\
      for (int i1 = 0; i1 < radK_; i1++) {\
        tempBuffer.push_back(PTRARG(new CLASSARG(i1*2 + offset, 2, 2 ADDARG)));\
      }\
    }\
    /* phi^0*/\
    for (int i1 = 1; i1 < radK_; i1++) {\
      tempBuffer.push_back(PTRARG(new CLASSARG(i1*2 - offsetOdd, i2*2, 0 ADDARG)));\
    }\
\
    /* Run MGS, reject basis, and collect coefficients.*/\
    Eigen::MatrixXd Coef;\
    int m = 1;\
    std::vector<PTRARG> allocated;\
    runMGS(thresh, tempBuffer, allocated, Coef, m);\
    all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
    Coefs.push_back(Coef.topLeftCorner(m,m));\
  }\
\
  /*Phi^3, Phi^1*/\
  for (int i2 = 1; i2 < angK_; i2++) {\
    std::vector<PTRARG> tempBuffer;\
    if (i2 == 1) {\
      /* phi^3*/\
      for (int i1 = 0; i1 < radK_; i1++) {\
        tempBuffer.push_back(PTRARG(new CLASSARG(i1*2 + offset, 2, 3 ADDARG)));\
      }\
    }\
\
    /*phi^1*/\
    for (int i1 = 1; i1 < radK_; i1++) {\
      tempBuffer.push_back(PTRARG(new CLASSARG(i1*2 - offsetOdd, i2*2, 1 ADDARG)));\
    }\
\
    /*Run MGS, reject basis, and collect coefficients.*/\
    Eigen::MatrixXd Coef;\
    int m = 1;\
    std::vector<PTRARG> allocated;\
    runMGS(thresh, tempBuffer, allocated, Coef, m);\
    all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
    Coefs.push_back(Coef.topLeftCorner(m,m));\
  }\
  /* Phi^4*/\
  std::vector<PTRARG> tempBuffer;\
  for (int i1 = 1; i1 < radK_; i1++) {\
    tempBuffer.push_back(PTRARG(new CLASSARG(i1*2, 0, 4 ADDARG)));\
  }\
\
  /* Run MGS, reject basis, and collect coefficients.*/\
  Eigen::MatrixXd Coef;\
  int m = 1;\
  std::vector<PTRARG> allocated;\
  runMGS(thresh, tempBuffer, allocated, Coef, m);\
  all_basis_.insert(all_basis_.end(), allocated.begin(), allocated.end());\
  Coefs.push_back(Coef.topLeftCorner(m,m));\
\
  /* Assemble global coefficient matrix.*/\
  A_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());\
  int colIdx = 0;\
  /* Square matrices.*/\
  for (int i = 0; i < Coefs.size(); i++) {\
    int curSize = Coefs[i].rows();\
    A_.block(colIdx, colIdx, curSize, curSize) = Coefs[i];\
    colIdx += curSize;\
  }\
\
  numBasisOrtho_ = all_basis_.size();\
  numBasisAll_ = all_basis_.size();\
\
  for (int i = 0; i < all_basis_.size(); i++) {\
    int index = all_basis_[i]->index();\
    phiCoef_[index].push_back(pairedCoefPolar(all_basis_[i]->WN1x2(), all_basis_[i]->WN2x2(), 0));\
  }\
  \
  waveNum2_ = Eigen::VectorXd::Zero(all_basis_.size());\
  for (int i = 0; i < all_basis_.size(); i++) {\
    double k1 = all_basis_[i]->WN1D();\
    double k2 = all_basis_[i]->WN2D();\
    waveNum2_[i] = k1*k1 + k2*k2;\
  }\
  /*allocateNumerical();*/\
  LOG(INFO) << "total number of basis " << numBasisAll_;\
  LOG(INFO) << "total number of ortho basis: " << numBasisOrtho_;\


#define RUNMGS_SHARE(DOT_ARGS)\
  out.clear();\
  /* inner product matrix of all basis.*/\
  Eigen::MatrixXd H = Eigen::MatrixXd::Zero(in.size(), in.size());\
  /* temp buffer.*/\
  Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(in.size(), in.size());\
  /*Coefficients matrix.*/\
  Coef = Eigen::MatrixXd::Zero(in.size(), in.size());\
  /* map from row/col index of H matrix to basis index*/\
  Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(in.size());\
  Coef(0,0) = 1.0; \
  H(0,0) = DOT_ARGS(in, 0,0);\
  HC.col(0) = H*Coef.row(0).transpose();\
  idxMap[0] = 0;\
  /* The first one.*/\
  out.push_back(in[0]);\
  /* size of the final allocated basis.*/\
  m = 1;\
\
  for(int i = 1; i < in.size(); i++) {\
    Coef(m,m) = 1.0;\
    H(m,m) = DOT_ARGS(in, i,i);\
    for (int j = 0; j < m; j++)\
      H(j,m) = H(m,j) = DOT_ARGS(in, i,idxMap[j]);\
    for (int j = 0; j < m; j++) {\
      HC(m,j) = H.row(m)*Coef.row(j).transpose();\
    }\
\
    for (int j = 0; j < m; j++) {\
      double dotProd = Coef.row(m)*HC.col(j);\
      Coef.row(m) -= dotProd*Coef.row(j);\
    }\
\
    /* compute norm.*/\
    HC.col(m) = H*Coef.row(m).transpose();\
    double norm2 = Coef.row(m)*HC.col(m);\
\
    if (norm2 > thresh) {\
      idxMap[m] = i;\
      Coef.row(m) /= sqrt(norm2);\
      HC.col(m) /= sqrt(norm2);\
      m++;\
      out.push_back(in[i]);\
    }\
    else {\
      LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";\
    }\
  }\
  CHECK(m <= in.size());\
  CHECK(m == out.size());\

#define ELLIPSE_R1_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;   /* [0-1]*/\
  for (int i = 0; i < nTheta_; i++) {\
     urTemp_[i + j*nTheta_]  *= c_*r;\
     oddTemp_[i + j*nTheta_] *= sqrtCR_[j];\
  }\
}\

#define INVERSE_R1_SHARE(WEIGHT)\
 collectPairedCoef(fieldCoef);\
  /*----------------------------FFTW ur----------------------------------*/\
  /* Iterate over all the coefficients and put it into the field.*/\
  ClearuR();\
  ClearOdd();\
  int divd = !boundaryCnd_ ? 1 : 2;\
  int divd1 = boundaryCnd_ ? 1 : 2;\
  for (const auto& p : phiCoef_[0]) {\
    /* r: RODFT01, theta: RODFT01*/\
    if ((p.i2x2 - 1) >= 0 && (p.i1x2/divd - 1) >= 0)\
      urTemp_[p.i2x2 - 1 + (p.i1x2/divd - 1)*nTheta_] += p.coef;\
  }\
  for (const auto& p : phiCoef_[2]) {\
    /* r: REDFT01, theta: RODFT01*/\
    if ((p.i2x2 - 1) >= 0)\
      oddTemp_[p.i2x2 - 1 + (p.i1x2/divd1)*nTheta_] += p.coef;\
  }\
\
  /* TODO, CHANGE to FFTW_MEASURE*/\
  fftw_execute_r2r(IsinR_, urTemp_, urTemp_);\
  fftw_execute_r2r(IcosREn_, oddTemp_, oddTemp_);\
\
WEIGHT;\
\
  Eigen::Map<Eigen::VectorXd> urV(urTemp_, nTheta_*nR_);\
  Eigen::Map<Eigen::VectorXd> oddV(oddTemp_, nTheta_*nR_);\
  /* total = Phi + Psi*/\
  urV = urV + oddV;\
  fftw_execute_r2r(IsinTheta_ , urTemp_, urTemp_);\


#define ELLIPSE_R2_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;   /* [0-1]*/\
  for (int i = 0; i < nTheta_; i++) {\
     extTemp_[i + j*nTheta_]  *= c_*r;\
     oddTemp_[i + j*nTheta_] *= c_*r;\
  }\
}\

#define INVERSE_R2_SHARE(WEIGHT)\
/*----------------------------FFTW ur----------------------------------*/\
  /* Iterate over all the coefficients and put it into the field.*/\
  ClearExt();\
  ClearOdd();\
  int divd = !boundaryCnd_ ? 1 : 2;\
  int divd1 = boundaryCnd_ ? 1 : 2;\
  for (const auto& p : phiCoef_[1]) {\
    /* r: RODFT01, theta: REDFT01*/\
    if ((p.i1x2/divd-1) >= 0)\
      extTemp_[p.i2x2 + (p.i1x2/divd-1)*nTheta_] += p.coef;\
  }\
  for (const auto& p : phiCoef_[3]) {\
    /* r: REDFT01, theta: REDFT01*/\
    oddTemp_[p.i2x2 + p.i1x2/divd1*nTheta_] += p.coef;\
  }\
\
  int rsize = nR_;\
  if (boundaryCnd_)\
    rsize = nR_*2;\
\
  Eigen::Map<Eigen::VectorXd> extV(extTemp_, nTheta_*nR_);\
  Eigen::Map<Eigen::VectorXd> oddV(oddTemp_, nTheta_*nR_);\
\
  fftw_execute_r2r(IcosREn_, oddTemp_, oddTemp_);\
  fftw_execute_r2r(IsinR_, extTemp_, extTemp_);\
\
WEIGHT;\
\
  extV = extV + oddV;\
  fftw_execute_r2r(IcosTheta_, extTemp_, extTemp_);\
  vr += extV;\



#define ELLIPSE_T1_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;   /* [0-1]*/\
  for (int i = 0; i < nTheta_; i++) {\
     extTemp_[i + j*nTheta_] *= sqrtCR_[j];\
     oddTemp_[i + j*nTheta_] *= c_*r;\
  }\
}\



#define INVERSE_T1_SHARE(WEIGHT)\
  /*----------------------------FFTW ut----------------------------------*/\
  ClearuT();\
  ClearOdd();\
  ClearExt();\
  for (const auto& p : phiCoef_[0]) {\
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;\
    /* r: RODFT01, theta: REDFT01*/\
    if ((p.i1x2/divd - 1) >= 0)\
    extTemp_[p.i2x2 + (p.i1x2/divd - 1)*nTheta_] += p.coef*invi2;\
  }\
  for (const auto& p : phiCoef_[2]) {\
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;\
    /* r: REDFT01, theta: REDFT01*/\
    oddTemp_[p.i2x2 + (p.i1x2/divd1)*nTheta_] += p.coef*invi2;\
  }\
\
  Eigen::Map<Eigen::VectorXd> utV(utTemp_, nTheta_*nR_);\
  Eigen::Map<Eigen::VectorXd> extV(extTemp_, nTheta_*nR_);\
\
  fftw_execute_r2r(IsinR_, extTemp_, extTemp_);\
  fftw_execute_r2r(IcosREn_, oddTemp_, oddTemp_);\
\
WEIGHT;\
  utV = extV + oddV;\



#define ELLIPSE_T2_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;   /* [0-1]*/\
  for (int i = 0; i < nTheta_; i++) {\
     extTemp_[i + j*nTheta_] *= sqrtCR_[j]*M_PI*r;\
     oddTemp_[i + j*nTheta_] *= sqrtCR_[j]*sqrtCR_[j]*M_PI/c_;\
  }\
}\


#define POLAR_T2_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  for (int i = 0; i < nTheta_; i++) {\
    double r = ((double)(j) + 0.5)*dr_;\
    oddTemp_[i + j*nTheta_] *= M_PI*r;\
    extTemp_[i + j*nTheta_] *= M_PI*r;\
  }\
}\


#define INVERSE_T2_SHARE(WEIGHT)\
  /* second part.*/\
  ClearOdd();\
  ClearExt();\
\
  for (const auto& p : phiCoef_[0]) {\
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    /* r: REDFT01, theta: REDFT01*/\
    extTemp_[p.i2x2 + p.i1x2/divd*nTheta_] += p.coef*invi2*i1;\
  }\
  for (const auto& p : phiCoef_[2]) {\
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    /* r: RODFT01, theta: REDFT01*/\
    if ((p.i1x2/divd1-1) >= 0)\
      oddTemp_[p.i2x2 + (p.i1x2/divd1-1)*nTheta_] += p.coef*invi2*i1;\
  }\
\
  fftw_execute_r2r(IcosR_, extTemp_, extTemp_);\
  fftw_execute_r2r(IsinREn_, oddTemp_, oddTemp_);\
\
WEIGHT;\
  utV += oddV;\
\
  /* thats the second part.*/\
  utV += extV;\
  fftw_execute_r2r(IcosTheta_,  utTemp_, utTemp_);\


#define ELLIPSE_T3_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;   /* [0-1]*/\
  for (int i = 0; i < nTheta_; i++) {\
     extTemp_[i + j*nTheta_] *= sqrtCR_[j];\
     oddTemp_[i + j*nTheta_] *= sqrtCR_[j];\
  }\
}\


#define INVERSE_T3_SHARE(WEIGHT)\
  /*----------------------------FFTW ut----------------------------------*/\
  ClearOdd();\
  ClearExt();\
  ClearWUtr();\
  Eigen::Map<Eigen::VectorXd> bufferV(utrWTemp_, nTheta_*nR_);\
\
  for (const auto& p : phiCoef_[1]) {\
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;\
    /* r: RODFT01, theta: RODFT01*/\
    if ((p.i2x2 - 1) >= 0 && (p.i1x2/divd-1) >= 0)\
      extTemp_[p.i2x2 - 1 + (p.i1x2/divd-1)*nTheta_] += p.coef*invi2;\
  }\
  for (const auto& p : phiCoef_[3]) {\
    /* r: REDFT01, theta: RODFT01*/\
    if ((p.i2x2 - 1 ) >= 0)\
      oddTemp_[p.i2x2 - 1 + p.i1x2/divd1*nTheta_] = -p.coef;\
  }\
\
  fftw_execute_r2r(IsinR_,  extTemp_, extTemp_);\
  fftw_execute_r2r(IcosREn_, oddTemp_, oddTemp_);\
  WEIGHT;\
  bufferV = extV + oddV;\


#define ELLIPSE_T4_WEIGHT \
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;   /* [0-1]*/\
  for (int i = 0; i < nTheta_; i++) {\
     extTemp_[i + j*nTheta_] *= sqrtCR_[j]*r*M_PI;\
  }\
}\


#define POLAR_T4_WEIGHT \
const double dr = 1.0 / nR_;\
for (int j = 0; j < nR_; j++) {\
  double r = ((double)(j) + 0.5)*dr_;\
  for (int i = 0; i < nTheta_; i++) {\
    extV[i + j*nTheta_] *= M_PI*r;\
  }\
}\


#define INVERSE_T4_SHARE(WEIGHT)\
  ClearOdd();\
  ClearExt();\
\
  for (const auto& p : phiCoef_[1]) {\
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    /* r: REDFT01, theta: RODFT01*/\
    if ((p.i2x2 - 1) >= 0)\
      extTemp_[p.i2x2 - 1 + (p.i1x2/divd)*nTheta_]  += p.coef*i1*invi2;\
  }\
  for (const auto& p : phiCoef_[3]) {\
    double i1 = p.i1x2*0.5;\
    /* r: RODFT01, theta: RODFT01*/\
    if ((p.i2x2 - 1 ) >= 0 && (p.i1x2/divd1 - 1) >= 0)\
      oddTemp_[p.i2x2 - 1 + (p.i1x2/divd1 - 1)*nTheta_] = p.coef*i1;\
  }\
\
  fftw_execute_r2r(IcosR_, extTemp_, extTemp_);\
  fftw_execute_r2r(IsinREn_, oddTemp_, oddTemp_);\
 \
  extV = extV + oddV;\
  WEIGHT;\
  bufferV += extV;\
  fftw_execute_r2r(IsinTheta_, utrWTemp_, utrWTemp_);\
  vt += bufferV;\


#define ELLIPSE_R1F_WEIGHT \
for (int j = 0; j < nR_; j++ ) {\
  double r = ((double)(j) + 0.5)*dr_;\
  for (int i = 0; i < nTheta_; i++) {\
    oddTemp_[i + j*nTheta_] *= c_*r;\
    extTemp_[i + j*nTheta_] *= sqrtCR_[j];\
  }\
}\

#define FORWARD_R1_SHARE(WEIGHT)\
  int rsize = nR_;\
  if (! boundaryCnd_)\
    rsize = nR_*2;\
\
  fftw_execute_r2r(FsinTheta_, urTemp_, oddTemp_);\
  memcpy(extTemp_, oddTemp_, sizeof(double)*rsize*nTheta_);\
\
WEIGHT;\
\
  fftw_execute_r2r(FsinR_, oddTemp_, oddTemp_);\
  fftw_execute_r2r(FcosREn_, extTemp_, extTemp_);\
\
  /* gather the coefficients.*/\
  for (auto& p : phiCoef_[0]) {\
    if ((p.i2x2 - 1 ) >= 0 && (p.i1x2/divd - 1) >= 0)\
      p.coef += oddTemp_[p.i2x2 - 1 + (p.i1x2/divd - 1)*nTheta_];\
  }\
  for (auto& p : phiCoef_[2]) {\
    if ((p.i2x2 - 1) >= 0)\
    p.coef += extTemp_[p.i2x2 - 1 + (p.i1x2/divd1)*nTheta_];\
  }\


#define ELLIPSE_R2F_WEIGHT \
for (int j = 0; j < nR_; j++ ) {\
  double r = ((double)(j) + 0.5)*dr_;\
  for (int i = 0; i < nTheta_; i++) {\
    oddTemp_[i + j*nTheta_] *= c_*r;\
    extTemp_[i + j*nTheta_] *= c_*r;\
  }\
}\


#define FORWARD_R2_SHARE(WEIGHT)\
  /*----------------------------FFTW ur----------------------------------*/\
  /* Iterate over all the coefficients and put it into the field.*/\
  ClearOdd();\
  ClearExt();\
  int divd = !boundaryCnd_ ? 1 : 2;\
  int divd1 = boundaryCnd_ ? 1 : 2;\
\
  int rsize = nR_;\
  if (boundaryCnd_)\
    rsize = nR_*2;\
\
  fftw_execute_r2r(FcosTheta_, urTemp_, oddTemp_);\
  memcpy(extTemp_, oddTemp_, sizeof(double)*nTheta_*rsize);\
\
WEIGHT;\
\
  fftw_execute_r2r(FsinR_, oddTemp_, oddTemp_);\
  fftw_execute_r2r(FcosREn_, extTemp_, extTemp_);\
\
\
  for (auto& p : phiCoef_[1]) {\
    if ((p.i1x2/divd - 1) >= 0)\
    p.coef += oddTemp_[p.i2x2 + (p.i1x2/divd - 1)*nTheta_];\
  }\
  for (auto& p : phiCoef_[3]) {\
    p.coef += extTemp_[p.i2x2 + (p.i1x2/divd1)*nTheta_];\
  }\


#define ELLIPSE_T1F_WEIGHT \
  for (int j = 0; j < nR_; j++ ) {\
    double r = ((double)(j) + 0.5)*dr_;\
    for (int i = 0; i < nTheta_; i++) {\
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*sqrtCR_[j];\
      extTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*c_*r;\
    }\
  }\
  fftw_execute_r2r(FsinR_, oddTemp_, oddTemp_);\
  fftw_execute_r2r(FcosREn_, extTemp_, extTemp_);\

#define POLAR_T1F_WEIGHT \
  fftw_execute_r2r(FsinR_, utrWTemp_, oddTemp_);\
  fftw_execute_r2r(FcosREn_, utrWTemp_, extTemp_);\


#define FORWARD_T1_SHARE(WEIGHT)\
/*----------------------------FFTW ut----------------------------------*/\
  ClearOdd();\
  ClearExt();\
  ClearWUtr();\
\
  fftw_execute_r2r(FcosTheta_, utTemp_, utrWTemp_);\
\
WEIGHT;\
\
  for (auto& p : phiCoef_[0]) {\
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;\
    if ((p.i1x2/divd - 1) >= 0)\
      p.coef += oddTemp_[p.i2x2 + (p.i1x2/divd - 1)*nTheta_]*invi2;\
  }\
  for (auto& p : phiCoef_[2]) {\
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;\
    p.coef += extTemp_[p.i2x2 + (p.i1x2/divd1)*nTheta_]*invi2;\
  }\


#define ELLIPSE_T2F_WEIGHT \
  for (int j = 0; j < nR_; j++) {\
    double r = ((double)(j) + 0.5)*dr_;\
    for (int i = 0; i < nTheta_; i++) {\
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*M_PI*r*sqrtCR_[j];\
      extTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*M_PI*sqrtCR_[j]*sqrtCR_[j]/c_;\
    }\
  }\

#define POLAR_T2F_WEIGHT \
  for (int j = 0; j < nR_; j++) {\
    double r = ((double)(j) + 0.5)*dr_;\
    for (int i = 0; i < nTheta_; i++) {\
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*M_PI*r;\
    }\
  }\
  memcpy(extTemp_, oddTemp_, sizeof(double)*rsize*nTheta_);\

#define FORWARD_T2_SHARE(WEIGHT)\
 /* second part.*/\
  ClearOdd();\
  ClearExt();\
\
  WEIGHT;\
\
  fftw_execute_r2r(FcosR_, oddTemp_, oddTemp_);\
  fftw_execute_r2r(FsinREn_, extTemp_, extTemp_);\
\
  for (auto& p : phiCoef_[0]) {\
    double invi2 = p.i2x2 == 0 ? 1.0 : 2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    p.coef += oddTemp_[p.i2x2 + (p.i1x2/divd)*nTheta_]*invi2*i1;\
  }\
  for (auto& p : phiCoef_[2]) {\
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    if ((p.i1x2/divd1-1) >= 0)\
      p.coef += extTemp_[p.i2x2 + (p.i1x2/divd1-1)*nTheta_]*invi2*i1;\
  }\


#define ELLIPSE_T3F_WEIGHT \
  for (int j = 0; j < nR_; j++) {\
    for (int i = 0; i < nTheta_; i++) {\
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*sqrtCR_[j];\
    }\
  }\
  fftw_execute_r2r(FcosREn_, oddTemp_, extTemp_);\
  fftw_execute_r2r(FsinR_, oddTemp_, oddTemp_);\

#define POLAR_T3F_WEIGHT \
  fftw_execute_r2r(FcosREn_, utrWTemp_, extTemp_);\
  fftw_execute_r2r(FsinR_, utrWTemp_, oddTemp_);\

#define FORWARD_T3_SHARE(WEIGHT)\
  int rsize = nR_;\
  if (boundaryCnd_)\
    rsize = nR_*2;\
  int divd = !boundaryCnd_ ? 1 : 2;\
  int divd1 = boundaryCnd_ ? 1 : 2;\
  /*----------------------------FFTW ut----------------------------------*/\
  ClearOdd();\
  ClearExt();\
  ClearWUtr();\
\
  fftw_execute_r2r(FsinTheta_, utTemp_, utrWTemp_);\
  WEIGHT;\
\
  for (auto& p : phiCoef_[1]) {\
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    if ((p.i2x2 - 1) >= 0 && (p.i1x2/divd - 1) >= 0)\
      p.coef += oddTemp_[p.i2x2 - 1 + (p.i1x2/divd - 1)*nTheta_]*invi2;\
  }\
  for (auto& p : phiCoef_[3]) {\
    if ((p.i2x2 - 1) >= 0)\
      p.coef += - extTemp_[p.i2x2 - 1 + (p.i1x2/divd1)*nTheta_];\
  }\


#define ELLIPSE_T4F_WEIGHT \
  for (int j = 0; j < nR_; j++) {\
    double r = ((double)(j) + 0.5)*dr_;\
    for (int i = 0; i < nTheta_; i++) {\
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*M_PI*r*sqrtCR_[j];\
    }\
  }\

#define POLAR_T4F_WEIGHT \
  for (int j = 0; j < nR_; j++) {\
    double r = ((double)(j) + 0.5)*dr_;\
    for (int i = 0; i < nTheta_; i++) {\
      oddTemp_[i + j*nTheta_] = utrWTemp_[i + j*nTheta_]*M_PI*r;\
    }\
  }\

#define FORWARD_T4_SHARE(WEIGHT)\
  int rsize = nR_;\
  if (boundaryCnd_)\
    rsize = nR_*2;\
  int divd = !boundaryCnd_ ? 1 : 2;\
  int divd1 = boundaryCnd_ ? 1 : 2;\
\
  ClearOdd();\
  ClearExt();\
  WEIGHT;\
  fftw_execute_r2r(FsinREn_, oddTemp_, extTemp_);\
  fftw_execute_r2r(FcosR_, oddTemp_, oddTemp_);\
\
  for (auto& p : phiCoef_[1]) {\
    double invi2 = p.i2x2 == 0 ? -1.0 : -2.0/p.i2x2;\
    double i1 = p.i1x2*0.5;\
    if ((p.i2x2 - 1 ) >= 0)\
      p.coef += oddTemp_[p.i2x2 - 1 + (p.i1x2/divd)*nTheta_]*i1*invi2;\
  }\
  for (auto& p : phiCoef_[3]) {\
    double i1 = p.i1x2*0.5;\
    if ((p.i2x2 - 1) >= 0 && (p.i1x2/divd1 - 1) >= 0)\
      p.coef += extTemp_[p.i2x2 - 1 + (p.i1x2/divd1 - 1)*nTheta_]*i1;\
  }\


#endif  // ELLIPTIC_POLAR_SHARE_2D_H