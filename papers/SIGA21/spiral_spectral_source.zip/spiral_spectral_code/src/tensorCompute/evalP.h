#ifndef EVAL_P_H
#define EVAL_P_H

#include <vector>
#include "tensorCompute/trig_integral.h"

#define SinP2Pi TrigInt::IntegrateSin2Pi_D2
#define CosP2Pi TrigInt::IntegrateCos2Pi_D2
#define Pi M_PI


class pEval{
public:
pEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~pEval(){};
/* Sin[g3*p]Sin[h3*p]Sin[i3*p]*/
static double evalP_0(const int i3x2, const int g3x2, const int h3x2){
return (-SinP2Pi(g3x2-h3x2-i3x2)+SinP2Pi(g3x2+h3x2-i3x2)+SinP2Pi(g3x2-h3x2+i3x2)-SinP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Sin[g3*p]Cos[h3*p]Cos[i3*p]*/
static double evalP_1(const int i3x2, const int g3x2, const int h3x2){
return (SinP2Pi(g3x2-h3x2-i3x2)+SinP2Pi(g3x2+h3x2-i3x2)+SinP2Pi(g3x2-h3x2+i3x2)+SinP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Sin[h3*p]Cos[g3*p]Cos[i3*p]*/
static double evalP_2(const int i3x2, const int g3x2, const int h3x2){
return (-SinP2Pi(g3x2-h3x2-i3x2)+SinP2Pi(g3x2+h3x2-i3x2)-SinP2Pi(g3x2-h3x2+i3x2)+SinP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* 1*/
static double evalP_3(const int i3x2, const int g3x2, const int h3x2){
return 2.0*M_PI;
};

/* Sin[g3*p]Sin[i3*p]Cos[h3*p]*/
static double evalP_4(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-h3x2-i3x2)+CosP2Pi(g3x2+h3x2-i3x2)-CosP2Pi(g3x2-h3x2+i3x2)-CosP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Cos[g3*p]Cos[h3*p]Cos[i3*p]*/
static double evalP_5(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-h3x2-i3x2)+CosP2Pi(g3x2+h3x2-i3x2)+CosP2Pi(g3x2-h3x2+i3x2)+CosP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Sin[g3*p]Sin[h3*p]Cos[i3*p]*/
static double evalP_6(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-h3x2-i3x2)-CosP2Pi(g3x2+h3x2-i3x2)+CosP2Pi(g3x2-h3x2+i3x2)-CosP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Sin[g3*p]Cos[i3*p]*/
static double evalP_7(const int i3x2, const int g3x2, const int h3x2){
return (SinP2Pi(g3x2-i3x2)+SinP2Pi(g3x2+i3x2))/2.;
};

/* Sin[h3*p]Sin[i3*p]Cos[g3*p]*/
static double evalP_8(const int i3x2, const int g3x2, const int h3x2){
return (-CosP2Pi(g3x2-h3x2-i3x2)+CosP2Pi(g3x2+h3x2-i3x2)+CosP2Pi(g3x2-h3x2+i3x2)-CosP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Sin[i3*p]Cos[g3*p]Cos[h3*p]*/
static double evalP_9(const int i3x2, const int g3x2, const int h3x2){
return (-SinP2Pi(g3x2-h3x2-i3x2)-SinP2Pi(g3x2+h3x2-i3x2)+SinP2Pi(g3x2-h3x2+i3x2)+SinP2Pi(g3x2+h3x2+i3x2))/4.;
};

/* Cos[g3*p]Cos[i3*p]*/
static double evalP_10(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-i3x2)+CosP2Pi(g3x2+i3x2))/2.;
};

/* Sin[h3*p]Cos[i3*p]*/
static double evalP_11(const int i3x2, const int g3x2, const int h3x2){
return (SinP2Pi(h3x2-i3x2)+SinP2Pi(h3x2+i3x2))/2.;
};

/* Cos[h3*p]Cos[i3*p]*/
static double evalP_12(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(h3x2-i3x2)+CosP2Pi(h3x2+i3x2))/2.;
};

/* Sin[g3*p]Sin[i3*p]*/
static double evalP_13(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-i3x2)-CosP2Pi(g3x2+i3x2))/2.;
};

/* Sin[i3*p]Cos[g3*p]*/
static double evalP_14(const int i3x2, const int g3x2, const int h3x2){
return (-SinP2Pi(g3x2-i3x2)+SinP2Pi(g3x2+i3x2))/2.;
};

/* Sin[h3*p]Sin[i3*p]*/
static double evalP_15(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(h3x2-i3x2)-CosP2Pi(h3x2+i3x2))/2.;
};

/* Sin[i3*p]Cos[h3*p]*/
static double evalP_16(const int i3x2, const int g3x2, const int h3x2){
return (-SinP2Pi(h3x2-i3x2)+SinP2Pi(h3x2+i3x2))/2.;
};

/* Sin[h3*p]Cos[g3*p]*/
static double evalP_17(const int i3x2, const int g3x2, const int h3x2){
return (-SinP2Pi(g3x2-h3x2)+SinP2Pi(g3x2+h3x2))/2.;
};

/* Sin[g3*p]Cos[h3*p]*/
static double evalP_18(const int i3x2, const int g3x2, const int h3x2){
return (SinP2Pi(g3x2-h3x2)+SinP2Pi(g3x2+h3x2))/2.;
};

/* Cos[g3*p]Cos[h3*p]*/
static double evalP_19(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-h3x2)+CosP2Pi(g3x2+h3x2))/2.;
};

/* Sin[g3*p]Sin[h3*p]*/
static double evalP_20(const int i3x2, const int g3x2, const int h3x2){
return (CosP2Pi(g3x2-h3x2)-CosP2Pi(g3x2+h3x2))/2.;
};

/* Sin[g3*p]*/
static double evalP_21(const int i3x2, const int g3x2, const int h3x2){
return SinP2Pi(g3x2);
};

/* Cos[g3*p]*/
static double evalP_22(const int i3x2, const int g3x2, const int h3x2){
return CosP2Pi(g3x2);
};

/* Sin[h3*p]*/
static double evalP_23(const int i3x2, const int g3x2, const int h3x2){
return SinP2Pi(h3x2);
};

/* Cos[h3*p]*/
static double evalP_24(const int i3x2, const int g3x2, const int h3x2){
return CosP2Pi(h3x2);
};

};

#endif // EVAL_P_H