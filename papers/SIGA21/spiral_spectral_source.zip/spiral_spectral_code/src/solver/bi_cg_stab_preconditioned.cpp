#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>

#include "integrator_2d.h"
#include "bi_cg_stab_preconditioned.h"

void BiCGSTABPreconditioned::IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) {
  const int num_basis = coefficients_old.size();
  // Allocate the contracted tensor. Generally, it should be dense.
  Eigen::MatrixXd w_C(num_basis, num_basis);
  Eigen::MatrixXd pre_cond(num_basis, num_basis);
  pre_cond.setIdentity();
  w_C.setIdentity();
  Eigen::VectorXd w(num_basis);
  w.setZero();
  w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);
  // w_C = I - P*dt, pre_cond = I + P*dt
  for (int i = 0; i < num_basis; i++) {
    const Eigen:: VectorXd contracted_vec = w.transpose() * Adv_tensor[i];
    w_C.row(i) -= contracted_vec * dt;
    pre_cond.row(i) += contracted_vec * dt;
  }
  Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  solver.compute(w_C);
  (*coefficients_new) = solver.solve(w);
  LOG(INFO) << "#iterations: " << solver.iterations();
  LOG(INFO) << "estimated error: " << solver.error();
  // Estimate the condition number.
  Eigen::JacobiSVD<Eigen::MatrixXd> svd(w_C);
  (*condition_number_) = svd.singularValues()(0) / svd.singularValues()(svd.singularValues().size()-1);
  LOG(INFO) << "condition number: " << *condition_number_;
  Eigen::JacobiSVD<Eigen::MatrixXd> svd1(pre_cond * w_C);
  const double new_cond = svd1.singularValues()(0) / svd1.singularValues()(svd1.singularValues().size()-1);
  LOG(INFO) << "pre_cond condition number: " << new_cond;
}
