import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import sys

f = open(sys.argv[1], "rb")
a = np.fromfile(f, dtype=np.uint64, count=2)
mat = np.fromfile(f, dtype=np.float64, count=a[0]*a[1]).reshape((a[0], a[1]), order='F')
#mat += mat.transpose()
#mat = np.power(abs(mat), 0.3)
#print(mat[-1, -1],mat[-2, -2], mat[-3, -3])

mat[np.where(abs(mat) > 1e-15)] = 1
print(mat.shape)

fig, ax = plt.subplots()
im = ax.imshow(np.abs(mat), cmap='gray_r', interpolation='bilinear')

#plt.show()
plt.axis('off')
plt.savefig("./temp.png", bbox_inches='tight', dpi=300)