static double evaltor2D_0(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_1(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_2(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_3(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_4(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_5(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_6(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_7(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_8(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_9(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_10(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_11(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_12(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
+((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_13(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_14(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_15(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_16(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_17(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_18(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
+((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_19(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_20(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_21(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_22(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_23(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_24(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_25(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_26(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_27(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_28(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_29(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_30(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_31(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_32(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_33(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_34(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_35(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_36(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_37(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_38(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_39(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_40(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_41(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_42(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_43(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_12(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_12(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_44(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_45(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_31(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_31(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_46(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_47(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_48(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
+((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_49(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_50(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_51(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_52(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_53(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_54(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
+((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_55(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_32(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_32(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_39(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_39(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_49(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_49(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_56(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_57(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_3(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_3(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_22(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_22(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_56(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_56(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_58(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_59(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_60(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_61(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_62(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_63(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_64(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_65(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_66(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_67(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_68(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_69(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_70(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_71(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_72(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_73(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_74(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_75(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_76(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_77(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_78(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_79(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_80(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_81(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_82(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_83(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_84(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_85(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_86(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_87(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_88(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_89(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_14(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_14(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_90(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_91(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_92(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_11(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_11(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
+((tor2DpEval::evalP_12(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_12(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_93(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_10(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_10(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
))
+((tor2DpEval::evalP_9(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_9(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_94(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_95(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_13(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_13(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_96(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_97(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_98(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_99(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_100(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_101(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_102(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_103(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_104(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_16(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_16(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_105(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_15(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_15(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_106(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_107(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_108(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_109(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_110(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_111(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_112(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_113(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_114(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_115(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_61(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_61(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_30(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_30(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_36(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_36(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_116(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_117(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_72(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_72(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_21(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_21(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_16(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_16(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_118(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_119(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_120(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_121(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_122(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_123(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+g1*h2+g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*a+3*a*g1*h2*i1*a*i1+g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2+3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i2*i2+a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_124(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_125(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_5(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_5(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_126(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_127(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_0(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_0(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_13(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_13(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_73(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_73(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_54(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_54(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_4(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_4(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_11(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_11(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_79(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_79(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_57(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_57(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_78(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_78(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_128(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_2(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_2(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
+((tor2DpEval::evalP_3(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_3(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+-3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+-g2*h1+-g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1+-3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i2*i2+-a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*a+-3*a*g2*h1*i1*a*i1+-g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_129(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_1(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_1(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_48(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_48(i1x2, g1x2, h1x2)*(1*(+3*g2*h1*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+6*a*g2*h1*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g2*h1*i1*a)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+-3*g2*i1)))
+((tor2DtEval::evalT_65(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_65(i1x2, g1x2, h1x2)*(1*(+g2*h1+g2*h1*i1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1+3*a*g2*h1*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-a*g2+-2*a*g2*i1*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1*a*i1+-g2*i2*i2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+-g2+-g2*i1*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i2*i2+a*g2*h1*i1*a*i1*a)))
+((tor2DtEval::evalT_50(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_50(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*a+3*a*g2*h1*i1*a*i1+g2*h1*i2*i2)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
))
+((tor2DpEval::evalP_0(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_0(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_28(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_28(i1x2, g1x2, h1x2)*(1*(+-3*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+3*a*h2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-6*a*g1*h2*i1)))
+((tor2DtEval::evalT_69(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_69(i1x2, g1x2, h1x2)*(1*(+-g1*h2+-g1*h2*i1*i1)))
+((tor2DtEval::evalT_35(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_35(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_41(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_41(i1x2, g1x2, h1x2)*(1*(+3*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*a+-3*a*g1*h2*i1*a*i1+-g1*h2*i2*i2)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*g1*h2*i1*a)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*h2*i1*a*i1+h2*i2*i2)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2+-3*a*g1*h2*i1*i1)))
+((tor2DtEval::evalT_80(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_80(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i2*i2+-a*g1*h2*i1*a*i1*a)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+a*h2+2*a*h2*i1*i1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_46(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_46(i1x2, g1x2, h1x2)*(1*(+h2+h2*i1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_130(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_131(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_4(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_4(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+3*g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+3*a*g2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*i1*a*i1+g2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g2+g2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+a*g2+2*a*g2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_132(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_133(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_134(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_135(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_136(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_137(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_138(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_139(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_140(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_7(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_7(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_141(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_6(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_6(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-3*h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-3*a*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-a*h2+-2*a*h2*i1*i1)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-h2+-h2*i1*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1*a*i1+-h2*i2*i2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_142(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_143(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_144(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
))
+((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_145(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_146(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
+((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_147(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_148(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_149(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_150(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
))
+((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_151(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_10(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_10(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_152(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
+((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_153(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_34(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_34(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_154(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_155(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_156(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
))
+((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_157(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_158(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_159(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_160(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_161(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_162(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
+((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_163(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_26(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_26(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_51(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_51(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_40(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_40(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_164(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_165(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_9(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_9(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_15(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_15(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_58(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_58(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_166(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_167(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_168(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_169(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_5(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_5(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_14(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_14(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_170(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_171(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_42(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_42(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_47(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_47(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_172(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_173(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_174(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_175(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_24(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_24(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_27(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_27(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_176(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_177(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_17(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_17(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_23(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_23(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_178(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_179(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_180(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
))
+((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_181(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_182(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2)))
))
+((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_183(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_184(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_185(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_186(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
))
+((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_187(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_25(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_25(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_37(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_37(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_38(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_38(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_188(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+g2)))
))
+((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_189(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_19(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_19(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_20(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_20(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_18(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_18(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_190(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_191(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_192(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
+((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_193(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_194(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_195(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+a*g1*h2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+a*g1*h2*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+g1*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+2*a*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_196(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_197(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_22(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_22(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_198(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h2)))
))
+((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+-g2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_199(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_1(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_1(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_70(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_70(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+h2)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_6(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_6(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_55(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_55(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_76(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_76(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_8(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_8(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_7(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_7(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_200(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_19(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_19(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+h2)))
))
+((tor2DpEval::evalP_20(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_20(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+-g2*h1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-2*a*g2*h1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+-g2*h1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*g2*h1*i1*a)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+g2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_201(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_18(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_18(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_52(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_52(i1x2, g1x2, h1x2)*(1*(+g2*h1)))
+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+a*g2*h1)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+-g2*i1)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+-a*g2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+2*a*g2*h1*i1)))
+((tor2DtEval::evalT_62(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_62(i1x2, g1x2, h1x2)*(1*(+g2*h1*i1)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*h1*i1*a)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+-g2)))
))
+((tor2DpEval::evalP_17(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_17(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_29(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_29(i1x2, g1x2, h1x2)*(1*(+-g1*h2)))
+((tor2DtEval::evalT_45(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_45(i1x2, g1x2, h1x2)*(1*(+h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2)))
+((tor2DtEval::evalT_44(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_44(i1x2, g1x2, h1x2)*(1*(+a*h2*i1)))
+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*g1*h2*i1*a)))
+((tor2DtEval::evalT_67(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_67(i1x2, g1x2, h1x2)*(1*(+-g1*h2*i1)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-2*a*g1*h2*i1)))
+((tor2DtEval::evalT_43(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_43(i1x2, g1x2, h1x2)*(1*(+h2)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_202(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_203(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_21(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_21(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+g2)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+a*g2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+g2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_204(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_205(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_53(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_53(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_63(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_63(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_64(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_64(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_206(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_207(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_59(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_59(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_75(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_75(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_77(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_77(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_208(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_209(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_210(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_211(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_2(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_2(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_74(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_74(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_71(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_71(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_212(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_24(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_24(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_213(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_23(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_23(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_66(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_66(i1x2, g1x2, h1x2)*(1*(+-a*h2*i1)))
+((tor2DtEval::evalT_33(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_33(i1x2, g1x2, h1x2)*(1*(+-h2)))
+((tor2DtEval::evalT_68(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_68(i1x2, g1x2, h1x2)*(1*(+-h2*i1)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_214(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
static double evaltor2D_215(const Basis2D& phiI, const Basis2D& phiG, const Basis2D& phiH, const double& a) {
getWaveN;
double val = +((tor2DpEval::evalP_8(i2x2, g2x2, h2x2) == 0) ? 0 :tor2DpEval::evalP_8(i2x2, g2x2, h2x2)*(+((tor2DtEval::evalT_60(i1x2, g1x2, h1x2) == 0) ? 0 :tor2DtEval::evalT_60(i1x2, g1x2, h1x2)*(1*(+0)))
))
;
return val*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
};
