// Viewer for 3D laplacian fluid simulation.
#define GLUT_DISABLE_ATEXIT_HACK

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "setting.h"
#include "util/QUICKTIME_MOVIE_GLFW.h"
#include <Eigen/Eigen>
#include <fftw3.h>
#include <iostream>
#include <sstream>

#include <glog/logging.h>
#include <gflags/gflags.h>
#include <sys/time.h>
#include <string>
#include <sstream>
#include <vector>

#include "polar_2D/sphere_fluid_2D1.h"

#include "util/trackball.h"
#include "util/glPrintString.h"
#include "util/get_current_time.h"
#include "util/gl4_drawer.h"

#include <learnopengl/shader_m.h>
#include <learnopengl/model.h>
#include <learnopengl/camera.h>

const double spectra_draw_factor = 0.1;
DEFINE_int32(window_x, 1920, "The x resolution of the window");
DEFINE_int32(window_y, 1080, "The y resolution of the window");

DEFINE_bool(add_density, true, "Whether to add density into the fluid.");
DEFINE_double(added_smoke_density, 2.0, "The density of added smoke.");
DEFINE_int32(xRes, 512, "The xReslution of the fluid.");
DEFINE_int32(yRes, 512, "The yReslution of the fluid.");
DEFINE_int32(basis_dim, 20, "The number of wanted basis.");
DEFINE_double(dt, 0.1, "The time step of the simulation.");
DEFINE_double(buoyancy, 0.0001, "The buoyancy of the fluid.");
DEFINE_double(viscosity, 0.005, "The viscosity of the fluid.");
DEFINE_double(b, 0.9, "The shorter axis.");

DEFINE_string(basis_type, "all_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");
DEFINE_string(integrator_type, "RK4", "The integrator_type. Can be RK4, semi_implicit"
              "BiCGSTAB");
DEFINE_int32(total_frame, 2000, "The total frame want to simulate.");
DEFINE_int32(total_num_particles, 1000, "The total number of particles");
DEFINE_double(particle_length_factor, 0.1, "How long is the particles.");
DEFINE_double(tensor_weight, 1.0, "Weight of the tensor.");
DEFINE_double(force_scale, 0.5, "The force scale to apply the force by mouse");
DEFINE_string(Tensor_file, "", "The file which stores all the tensor.");
DEFINE_bool(add_density_once, false, "Only add the density to the first of the frame");

DEFINE_bool(capture_video, false, "Whether to capture the video.");
DEFINE_string(preview_fpath, "", "The folder to put the preview video.");
DEFINE_double(densityPtlWeight, 1.f, "weight of density particles.");
DEFINE_int32(maxDensityParticles, 2, "maximum number of density particles.");
DEFINE_int32(scenario, 2, "which scenario is it");
DEFINE_double(blendW, 0.9, "Blend wegiht.");
DEFINE_double(omega, 0, "coriolis wegiht.");

// IO
DEFINE_bool(output_texture, false, "whether to output the texture.");
DEFINE_string(texture_folder, "", "The folder to dump the texture.");
DEFINE_bool(writeRGB, false, "Write RGB image.");
DEFINE_bool(writeVelocity, false, "Write velocity image.");

/* ascii codes for various special keys */
#define ESCAPE 27
#define PAGE_UP 73
#define PAGE_DOWN 81
#define UP_ARROW 72
#define DOWN_ARROW 80
#define LEFT_ARROW 75
#define RIGHT_ARROW 77

SphereFluid2D1* fluid = NULL;

// Quicktime movie to capture to
QUICKTIME_MOVIE movie;

int light;
// Toggle light
int lp;

static int fluid_win_id;
static int spectra_win_id;

GLfloat zt = -6.0f; // depth into the screen.
GLfloat xt = 0, yt = 0;

int window_x_res, window_y_res;

int mouse_ax, mouse_ay;
float mouse_x_norm, mouse_y_norm;
// quat0 =  {-0.154058, 0.196378, 0.0745471, 0.965476}
float _quat[4] = {0,0,0,1};  // view rotation quaternion
bool isRotate = false;

float aplha_multipler = 0.05;

int low_cut = 0;

std::string printstr;
bool is_pause = false;
bool add_smoke = true;
bool write_dens_pbrt = false;
bool draw_particles = true;
bool captuerInit = false;

Eigen::Matrix3f rotGlobal;
Shader* fixColorShader = NULL;
Shader* varColorShader = NULL;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
coordAxis* axis = NULL;

double b = 1.0;
bool is_prolate = false;
bool is_oblate = false;

namespace {

void SavePreviewAndQuit() {
  if (FLAGS_capture_video) {
    std::string datetime = getCurrentDateTime(true);
    replace(datetime.begin(), datetime.end(), ' ', '_');
    std::stringstream outname;
    outname << FLAGS_preview_fpath << datetime << ".mov";

    movie.writeMovie(outname.str().c_str());

    // reset the movie object
    movie = QUICKTIME_MOVIE();
  }
  // delete fluid;
  
  LOG(INFO) << "Exitting...";
  exit(0);
}

void copyMatrix(float* m, const Eigen::Matrix3f& rot) {
  m[0] = rot(0,0);
  m[1] = rot(1,0);
  m[2] = rot(2,0);
  m[3] = 0.0;
  m[4] = rot(0,1);
  m[5] = rot(1,1);
  m[6] = rot(2,1);
  m[7] = 0.0;
  m[8] = rot(0,2);
  m[9] = rot(1,2);
  m[10] = rot(2,2);
  m[11] = 0.0;
  m[12] = 0.0;
  m[13] = 0.0;
  m[14] = 0.0;
  m[15] = 1.0;
}

}  // namespace

GLvoid InitGLFluid(GLsizei Width, GLsizei Height) {

  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LESS);
}

// Fluid window.
void fluid_display_func(GLFWwindow* window) {

  glClearColor(1.f, 1.f, 1.f,1.f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glm::mat4 m1;
  glm::mat4 mgl;
  float m[4][4];
  copyMatrix((float*)glm::value_ptr(mgl), rotGlobal);
  build_rotmatrix(m, _quat);
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
    m1[i][j] = m[i][j];

  m1 = m1*mgl;
    
  glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)window_x_res / (float)window_y_res, 0.1f, 100.0f);
  float ratio =  (float)window_y_res / (float)window_x_res;
  glm::mat4 orthoProj = glm::ortho(-1.0f, 1.0f, -ratio, ratio, 0.1f, 100.0f);

  glm::mat4 view = camera.GetViewMatrix();
  glm::mat4 model = glm::translate(glm::mat4(1.f), glm::vec3(-1.5,0.0,0.0));//glm::mat4(1.0f);
  model = glm::translate(model, glm::vec3(0.0f, 0.0, -3.f)); // translate it down so it's at the center of the scene
  model = model*m1;

  fluid->DrawDensity(projection, view, m1, FLAGS_particle_length_factor);

  model = glm::scale(model, glm::vec3(2.0, 2.0, 2.0));

  fixColorShader->use();
  fixColorShader->setMat4("projection", orthoProj);
  fixColorShader->setMat4("view", view);
  fixColorShader->setMat4("model", glm::translate(glm::mat4(1.f), glm::vec3(0.0,0.0,0.0)));
  fixColorShader->setVec4("color",glm::vec4(0.0,0.0,0.0,1.0));
  fluid->DrawCoefficients(spectra_draw_factor);

  if (FLAGS_capture_video && captuerInit && !is_pause) {
      movie.addFrameGL(window); // This function will eat lots of memory afterwards.
  }
  if (!captuerInit)
    captuerInit = true;
}

static void idle_func ( void ) {
  if (!is_pause) {
    fluid->Step();
    
    if (add_smoke) {
      
    }
    if (write_dens_pbrt) {
      //fluid->OutputSmokeToFolder();
    }
    if (fluid->isFinished()) {
      SavePreviewAndQuit();
    }
  }
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{

}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}


static void cursor_pos_callback(GLFWwindow* window, double x, double y) {
  if (isRotate) {
    float spin_quat[4];

    float sx2 = window_x_res*0.5f, sy2 = window_y_res*0.5f;

    trackball(spin_quat,
        (mouse_ax - sx2) / sx2,
        -(mouse_ay - sy2) / sy2,
        (x - sx2) / sx2,
        -(y - sy2) / sy2);
    add_quats(spin_quat, _quat, _quat);
  }

  mouse_ax = x;
  mouse_ay = y;
  //LOG(INFO) << _quat[0] << ", " << _quat[1]  << ", " << _quat[2] << ", " << _quat[3];
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
  if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
    isRotate = true;
  if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
    isRotate = false;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
  if (action != GLFW_PRESS)
    return;
/* avoid thrashing this procedure */  
  usleep(100);

  switch (key) {    
  case GLFW_KEY_ESCAPE: 
    SavePreviewAndQuit();             
    break;
  case 't':
    aplha_multipler *= 0.8;
    break;
  case 'T':
    aplha_multipler *= 1.2;
    break;
  case 'x': // cut more
    low_cut += 1;
    if (low_cut > 255) low_cut = 255; 
    break;
  case 'X': // cut less
    low_cut -= 1;
    if (low_cut < 0) low_cut = 0; 
    break;
  case 'c':
  case 'C':
    //fluid->ClearDensity();
    break;
  case 'r':
  case 'R':
    fluid->ReSeedParticles();
    break;
  case 'v':
  case 'V':
    //fluid->ResetCoeff();
    break;
  case 'p':
  case 'P':
    is_pause = !is_pause;
    break;
  case 'a':
  case 'A':
    add_smoke = !add_smoke;
    break;
  case 'd':
  case 'D':
    ;
    break;
  case 'w':
  case 'W':
    write_dens_pbrt = !write_dens_pbrt;
    break;
  case 'm':
  case 'M':
    draw_particles = !draw_particles;
    break;
  case GLFW_KEY_PAGE_UP:
    camera.moveAlongZ(-2);
    break;

  case GLFW_KEY_PAGE_DOWN:
    camera.moveAlongZ(2);
    break;

  default:
    break;
  }
}

int main(int argc, char ** argv) {

  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  b = FLAGS_b;
  if (FLAGS_basis_type == "sphere_2d") {
    b = 1.0;
  } else if (FLAGS_basis_type == "oblate_2d") {
    is_oblate = true;
  } else if (FLAGS_basis_type == "prolate_2d") {
    is_prolate = true;
  }
  //glutInit (&argc, argv);
  // glfw: initialize and configure
  // ------------------------------
  glfwInit();
  glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
  glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
  glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

  // For problems of smaller size, use less threads are better.
  fftw_init_threads();
  fftw_plan_with_nthreads(6);

  CHECK(FLAGS_xRes == FLAGS_yRes);

/* Initialize our window. */
  window_x_res = FLAGS_window_x;
  window_y_res = FLAGS_window_y;
  // glfw window creation
  // -------------------

  GLFWwindow* window = glfwCreateWindow(window_x_res, window_y_res, "fluid", NULL, NULL);
  if (window == NULL) {
      std::cout << "Failed to create GLFW window" << std::endl;
      glfwTerminate();
      return -1;
  }

  glfwMakeContextCurrent(window);
  glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
  //glfwSetFramebufferSizeCallback(window_spec, framebuffer_size_callback);
  glfwSetCursorPosCallback(window, cursor_pos_callback);
  glfwSetMouseButtonCallback(window, mouse_button_callback);
  glfwSetKeyCallback(window, key_callback);

  if(!gladLoadGL()) {
      printf("Cant load GLAD!\n");
      exit(-1);
  }

  fluid = new SphereFluid2D1(FLAGS_xRes, FLAGS_yRes, FLAGS_basis_dim,
      FLAGS_dt, FLAGS_basis_type, FLAGS_integrator_type, FLAGS_buoyancy, FLAGS_viscosity,
      FLAGS_total_num_particles, FLAGS_total_frame, FLAGS_added_smoke_density, FLAGS_Tensor_file,
      FLAGS_tensor_weight, b, FLAGS_densityPtlWeight, FLAGS_maxDensityParticles, FLAGS_scenario,
      FLAGS_output_texture, FLAGS_texture_folder, false, FLAGS_writeRGB, FLAGS_writeVelocity,
      FLAGS_blendW, FLAGS_omega);

  // in case load basis from file, reload.
  b = fluid->b();
  //write_dens_pbrt = FLAGS_write_density_to_PBRT;
  rotGlobal = Eigen::Quaternionf().setFromTwoVectors(Eigen::Vector3f(0,0,-1),Eigen::Vector3f(0,1,0));

  add_smoke = FLAGS_add_density;
  
  std::stringstream printstr_;
  //printstr_ << "basis_dim: " << fluid->GetBasiDim(); 
  printstr = printstr_.str();
  
  //open_glut_window();
  trackball(_quat, 0.0, 0.0, 0.0, 0.0);
  //_quat[0] = -0.154058; _quat[1]= 0.196378; _quat[2] = 0.0745471; _quat[3]= 0.965476;
  fixColorShader = new Shader("./src/shaders/fixColor.vs", "./src/shaders/fixColor.fs");
  varColorShader = new Shader("./src/shaders/varColor.vs", "./src/shaders/varColor.fs");
 
  axis = new coordAxis();
  
  InitGLFluid(FLAGS_window_x, FLAGS_window_y);
  // render loop
  // -----------
  while (!glfwWindowShouldClose(window)) {
      
    glfwMakeContextCurrent(window);
    processInput(window);
    // render
    fluid_display_func(window);

    idle_func();
    glfwSwapBuffers(window);
    
    glfwPollEvents();
  }
    
  return 0;
}
