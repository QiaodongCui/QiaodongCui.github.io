#include <Eigen/Eigen>
#include <math.h>
#include "polar_2D/polar_basis_all.h"


using namespace std;

std::vector<std::vector<int>> normTestWn = {{1, 2}, {1, 4}, {1, 6}, {1, 8}, {1, 10}, {2, 2}, {2, 4}, {2, 6}, {2, 
  8}, {2, 10}, {3, 2}, {3, 4}, {3, 6}, {3, 8}, {3, 10}, {4, 2}, {4, 
  4}, {4, 6}, {4, 8}, {4, 10}, {5, 2}, {5, 4}, {5, 6}, {5, 8}, {5, 
  10}};

std::vector<std::vector<int>> dotProdWn = {{5, 40, 14, 5, 48, 6}, {12, 10, 56, 27, 2, 32}, {20, 60, 20, 30, 50, 
   20}, {14, 42, 36, 21, 26, 54}, {30, 36, 2, 30, 10, 22}, {7, 38, 40,
    1, 12, 8}, {17, 54, 6, 28, 34, 12}, {7, 16, 22, 22, 20, 58}, {9, 
   18, 36, 10, 4, 28}, {17, 2, 20, 12, 60, 14}, {4, 52, 6, 19, 4, 
   18}, {3, 26, 20, 27, 18, 8}, {23, 56, 52, 11, 22, 40}, {24, 22, 4, 
   15, 46, 60}, {26, 10, 50, 27, 42, 48}, {14, 32, 30, 8, 20, 
   14}, {25, 14, 18, 28, 2, 56}, {8, 30, 4, 8, 44, 38}, {27, 2, 52, 
   21, 8, 22}, {25, 42, 60, 20, 26, 54}, {13, 20, 60, 22, 56, 26}, {4,
    36, 18, 8, 30, 32}, {1, 16, 26, 11, 42, 38}, {24, 42, 38, 23, 52, 
   4}, {4, 18, 8, 11, 16, 46}, {29, 60, 26, 27, 38, 50}, {21, 12, 24, 
   14, 42, 34}};

std::vector<double> val1 = {3.40991, 1.68026, 1.35995, 1.24785, 1.19596, 5.05388, 1.85252, \
1.25967, 1.05218, 0.956138, 10.7371, 3.29984, 1.92258, 1.44053, \
1.21742, 16.6812, 4.75936, 2.5516, 1.77889, 1.42123, 26.2062, \
7.15016, 3.62125, 2.38614, 1.81446};

std::vector<double> val2 = {1.66958, 1.66958, 1.66958, 1.66958, 1.66958, 5.83928, 5.83928, \
5.83928, 5.83928, 5.83928, 9.84556, 9.84556, 9.84556, 9.84556, \
9.84556, 17.4666, 17.4666, 17.4666, 17.4666, 17.4666, 25.3827, \
25.3827, 25.3827, 25.3827, 25.3827};

std::vector<double> val3 = {2.20742, 2.20742, 2.20742, 2.20742, 2.20742, 1.5708, 1.5708, 1.5708, \
1.5708, 1.5708, 1.64153, 1.64153, 1.64153, 1.64153, 1.64153, 1.5708, \
1.5708, 1.5708, 1.5708, 1.5708, 1.59626, 1.59626, 1.59626, 1.59626, \
1.59626};

std::vector<double> val5 = {0., 0., 0., 0., 0., 0., 0., 0., 0., 39.206, 0., 0., 0., 0., 0., 0., \
0., 0., 246.535, 0., 0., 0., 0., 0., 0., 0., 0.};


std::vector<double> val7 = {0.00960275, 0., 0.123234, 0., -0.0728979, 0., 0., -0.0555098, 0., \
0., -0.00213337, 0., 0.0564781, 0., 0., -0.076017, 0., 0., 0., 0., \
0.119057, -0.0457417, 0.00429012, 0., 0., -0.292612, 0.542363};

std::vector<double> val8 = {0., 0., 0., 0., 0., 0., 0., 0., 0., 39.206, 0., 0., 0., 0., 0., 0., \
0., 0., 246.535, 0., 0., 0., 0., 0., 0., 0., 0.};

namespace {

  // Test the norm
  void testDotProdMode0() {
    for (int i = 0; i < normTestWn.size(); i++) {
      PolarBasisAll basis1(normTestWn[i][0], normTestWn[i][1], 0);
      CHECK(fabs(basis1.dotProd(basis1) - val1[i]) < 1e-4) << val1[i] << " " << basis1.dotProd(basis1);
      // the same
      PolarBasisAll basis2(normTestWn[i][0], normTestWn[i][1], 1);
      CHECK(fabs(basis2.dotProd(basis2) - val1[i]) < 1e-4) << val1[i] << " " << basis2.dotProd(basis2);

      PolarBasisAll basis3(normTestWn[i][0], 2, 2);
      CHECK(fabs(basis3.dotProd(basis3) - val2[i]) < 1e-4) << val2[i] << " " << basis3.dotProd(basis3);

      PolarBasisAll basis4(normTestWn[i][0], 2, 3);
      CHECK(fabs(basis4.dotProd(basis4) - val2[i]) < 1e-4) << val2[i] << " " << basis4.dotProd(basis4);

      PolarBasisAll basis5(normTestWn[i][0], 0, 4);
      CHECK(fabs(basis5.dotProd(basis5) - val3[i]) < 1e-4) << val3[i] << " " << basis5.dotProd(basis5);
    }

    for (int i = 0; i < dotProdWn.size(); i++) {
      PolarBasisAll basis1(dotProdWn[i][0], dotProdWn[i][1], 0);
      PolarBasisAll basis2(dotProdWn[i][3], dotProdWn[i][4], 1);
      CHECK(fabs(basis1.dotProd(basis2) - 0.0) < 1e-12) << 0.0 << " " << basis2.dotProd(basis1);
      PolarBasisAll basis3(dotProdWn[i][3], 2, 2);
      CHECK(fabs(basis1.dotProd(basis3) - val5[i]) < 1e-3) << val5[i] << " " << basis3.dotProd(basis1);
      PolarBasisAll basis4(dotProdWn[i][3], 2, 3);
      CHECK(fabs(basis1.dotProd(basis4) - 0.0) < 1e-12) << 0.0 << " " << basis4.dotProd(basis1);
      PolarBasisAll basis5(dotProdWn[i][3], 0, 4);
      CHECK(fabs(basis1.dotProd(basis5) - 0) < 1e-12) << 0 << " " << basis5.dotProd(basis1);
      PolarBasisAll basis1_1(dotProdWn[i][3], dotProdWn[i][4], 1);
      CHECK(fabs(basis1.dotProd(basis1_1) - 0) < 1e-12) << 0 << " " << basis1_1.dotProd(basis1);
    }

    for (int i1 = 2; i1 < 20; i1+=2) {
      for (int i2 = 2; i2 < 20; i2+=2)
        for (int j2 = 2; j2 < 20; j2+=2) {
          if (i2 == j2) continue;
          PolarBasisAll basis1(i1, i2, 0);
          PolarBasisAll basis11(i1, j2, 0);
          CHECK(fabs(basis1.dotProd(basis11) - 0) < 1e-12) << 0 << " " << basis11.dotProd(basis1);     
        }
    }

    for (int i = 0; i < dotProdWn.size(); i++) {
      PolarBasisAll basis2(dotProdWn[i][0], dotProdWn[i][1], 1);
      PolarBasisAll basis3(dotProdWn[i][3], 2, 2);
      CHECK(fabs(basis2.dotProd(basis3) - 0.0) < 1e-12) << 0.0 << " " << basis2.dotProd(basis3);
      PolarBasisAll basis4(dotProdWn[i][3], 2, 3);
      CHECK(fabs(basis2.dotProd(basis4) - val8[i]) < 1e-3 ) << val8[i] << " " << basis2.dotProd(basis4);
      PolarBasisAll basis5(dotProdWn[i][3], 0, 4);
      CHECK(fabs(basis2.dotProd(basis5) - 0.0) < 1e-12 ) << 0.0 << " " << basis2.dotProd(basis4);
    }

    for (int i = 0; i < dotProdWn.size(); i++) {
      PolarBasisAll basis3(dotProdWn[i][0], 2, 2);
      PolarBasisAll basis4(dotProdWn[i][3], 2, 3);
      CHECK(fabs(basis3.dotProd(basis4) - 0.0) < 1e-12) << 0.0 << " " << basis3.dotProd(basis4);
    }
  }
#define dotProdMarco(arg, i,j) arg[i]->dotProd(*arg[j])*arg[i]->GetInvNorm()*arg[j]->GetInvNorm();
typedef std::shared_ptr<PolarBasisAll> basisPtrAll;

void dumpVFIELD(const std::string& name, VFIELD2D& v) {
    //std::stringstream name;
    //name << "./MGS_" << i;
  std::ofstream out(name + "_x", ios::binary);
  for (int i = 0; i < v.getxRes()*v.getyRes(); i++)
    out.write((char*)(&v[i][0]), sizeof(double));
  out.close();
  out.open(name + "_y", ios::binary);
  for (int i = 0; i < v.getxRes()*v.getyRes(); i++)
    out.write((char*)(&v[i][1]), sizeof(double));
  out.close();
}

void MGSTest() {
    std::vector<basisPtrAll> all_basis_;

    all_basis_.push_back(basisPtrAll(new PolarBasisAll(1,2,2)));
    all_basis_.push_back(basisPtrAll(new PolarBasisAll(2,2,0)));
    for (int i1 = 2; i1 < 16; i1+=1) {
     // all_basis_.push_back(basisPtrAll(new PolarBasisAll(2,2,0)));
      all_basis_.push_back(basisPtrAll(new PolarBasisAll(i1*2, 2, 0)));
    }


    //all_basis_.push_back(basisPtrAll(new PolarBasisAll(2,2,0)));
    // In MGS, Coef matrix diagonalizes inner product matrix H,
    // therefore Coef*Phi is the orthogonalized basis.
    Eigen::MatrixXd H_ = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
    Eigen::MatrixXd HC = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
    Eigen::MatrixXd Coef = Eigen::MatrixXd::Zero(all_basis_.size(), all_basis_.size());
    // map from row/col index of H matrix to basis index
    Eigen::VectorXi idxMap = Eigen::VectorXi::Zero(all_basis_.size());

    Coef(0,0) = 1.0; 
    H_(0,0) = dotProdMarco(all_basis_, 0,0);
    HC.col(0) = H_*Coef.row(0);
    idxMap[0] = 0;
    int m = 1;
    for(int i = 1; i < all_basis_.size(); i++) {
      Coef(m,m) = 1.0;
      H_(m,m) = dotProdMarco(all_basis_, i,i);
      for (int j = 0; j < m; j++)
        H_(j,m) = H_(m,j) = dotProdMarco(all_basis_,i,idxMap[j]);
      for (int j = 0; j < m; j++) {
        //HC.col(j) = H_*Coef.row(j).transpose();
        HC(m,j) = H_.row(m)*Coef.row(j).transpose();
      }

      for (int j = 0; j < m; j++) {
        //Coef(i,j) = -Coef.row(i)*H_*Coef.row(j).transpose();
        //double dotProd = Coef.row(i)*H_*Coef.row(j).transpose();
        //H_(j,i) = H_(i,j) = dotProd(i,j); 
        double dotProd = Coef.row(m)*HC.col(j);
        Coef.row(m) -= dotProd*Coef.row(j);
      }

      // compute norm.
      HC.col(m) = H_*Coef.row(m).transpose();
      double norm2 = Coef.row(m)*HC.col(m);
      LOG(INFO) << norm2;
      if (norm2 > 0.4) {
        idxMap[m] = i;
        Coef.row(m) /= sqrt(norm2);
        HC.col(m) /= sqrt(norm2);
        m++;
      }
      else {
        LOG(INFO) << "small norm " << norm2 << " index " << i << " skipped.";
      }
    }
    
    CHECK(m <= all_basis_.size());
    Eigen::MatrixXd reduced = Coef.topLeftCorner(m,m)*H_.topLeftCorner(m,m)*Coef.topLeftCorner(m,m).transpose();
    Eigen::JacobiSVD<Eigen::MatrixXd> svd(Coef.topLeftCorner(m,m));
    //LOG(INFO) << Coef.diagonal().transpose();
    LOG(INFO) << svd.singularValues().transpose();
    for (int i = 0; i < reduced.rows(); i++) {
      reduced(i,i) -= 1.0;
    }
    LOG(INFO) << reduced.norm();
    //Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(H_.topLeftCorner(m,m));
    //Eigen::VectorXd eigs = es.eigenvalues();
    //Eigen::VectorXd invEigs = 1.0 / eigs.array().sqrt();
    //LOG(INFO) << invEigs.transpose();

  // only compute half cuz symmetric
  for(int i = 0; i < all_basis_.size(); i++) {
    for (int j = i; j < all_basis_.size(); j++) {
      H_(i,j) = dotProdMarco(all_basis_, i,j);
      H_(j,i) = H_(i,j);
    }
  }

  // H should be positive definite.
  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(H_);
  Eigen::VectorXd eigs = es.eigenvalues();

  double maxEig = eigs[H_.rows() - 1];
  // count number of truncated eigenvalues
  int i = 0;
  for (i = 0; i < H_.rows(); i++) {
    if (eigs[i] > 0.1*maxEig)
      break;
  }
  Eigen::VectorXd lEigs = eigs.tail(eigs.size() - i);
  Eigen::VectorXd sEigs = eigs.segment(0, i);
  Eigen::VectorXd linvEigs = 1.0 / lEigs.array().sqrt();
  Eigen::VectorXd sinvEigs = 1.0 / sEigs.array().sqrt();
  LOG(INFO) << sEigs.transpose();
  
  LOG(INFO) << lEigs.size() << " " << sEigs.size() << " " << all_basis_.size();
  LOG(INFO) << "percentage discared: " << 1.0 - (double)(lEigs.size())/ eigs.size();
  Eigen::MatrixXd AL_ = linvEigs.asDiagonal()*(es.eigenvectors().rightCols(lEigs.size())).transpose();
  Eigen::MatrixXd AS_ = sinvEigs.asDiagonal()*(es.eigenvectors().leftCols(i)).transpose();
  
  const int N_ = 64;
  VFIELD2D basisV(N_, N_);
  basisV.clear();
  VFIELD2D totalV(N_, N_);
  totalV.clear();
  FIELD2D r(N_,N_);
  FIELD2D theta(N_, N_);
  double dx = 2.0 / N_;
  double dy = 2.0 / N_;

  for (int j = 0; j < N_; j++) {
    for (int i = 0; i < N_; i++) {
      double x = ((double)(i) + 0.5)*dx - 1.0;
      double y = ((double)(j) + 0.5)*dy - 1.0;
      double rad = sqrt(x*x + y*y);
      double t = atan2(y, x);
      if (y < 0)
        t += 2*M_PI;

      r(i,j) = rad;
      theta(i,j) = t;
    }
  }
  /*for (int i = 0; i < AS_.rows(); i++) {
    totalV.clear();
    for (int j = 0; j < AS_.cols(); j++) {
      basisV.clear();
      all_basis_[j]->DiscretizeAdd(AS_(i,j), r, theta, &basisV);
      totalV.addField(1.0, basisV);
    }
    std::stringstream name;
    name << "./AS_" << i;
    std::ofstream out(name.str() + "_x", ios::binary);
    for (int i = 0; i < N_*N_; i++)
      out.write((char*)(&totalV[i][0]), sizeof(double));
    out.close();
    out.open(name.str() + "_y", ios::binary);
    for (int i = 0; i < N_*N_; i++)
      out.write((char*)(&totalV[i][1]), sizeof(double));
    out.close();
  }*/

  /*Eigen::MatrixXd coefKept = Coef.topLeftCorner(m,m);
  for (int i = 0; i < m; i++) {
    totalV.clear();
    for (int j = 0; j < m; j++) {
      basisV.clear();
      all_basis_[idxMap[j]]->DiscretizeAdd(coefKept(i,j), r, theta, &basisV);
      totalV.addField(1.0, basisV);
    }

    std::stringstream name;
    name << "./MGS_" << i;
    std::ofstream out(name.str() + "_x", ios::binary);
    for (int i = 0; i < N_*N_; i++)
      out.write((char*)(&totalV[i][0]), sizeof(double));
    out.close();
    out.open(name.str() + "_y", ios::binary);
    for (int i = 0; i < N_*N_; i++)
      out.write((char*)(&totalV[i][1]), sizeof(double));
    out.close();
  }*/
  /*for (int i = 0; i < all_basis_.size(); i++) {
    basisV.clear();
    all_basis_[i]->DiscretizeAdd(1.0, r, theta, &basisV);
    std::stringstream name;
    name << "./basis_" << i;
    dumpVFIELD(name.str(), basisV);
  }*/
  //std::ofstream out("./AS.bin", ios::binary);
  //out.write((char*)(AS_.data()), sizeof(double)*AS_.rows()*AS_.cols());
  //out.close();
  
  }

void MGSTest1() {
  Eigen::Matrix3d V = Eigen::Matrix3d::Random();
  Eigen::Matrix3d U;
  Eigen::Matrix3d Coef;
  Coef.setZero();
  
  Eigen::Matrix3d H_;
  for (int i = 0; i < 3; i++)
    for (int j = i; j < 3; j++) {
      H_(i,j) = V.col(i).transpose()*V.col(j);
      H_(j,i) = H_(i,j);
    }

  U.setZero();
  U.col(0) = V.col(0) / sqrt(V.col(0).transpose()*V.col(0));
  Coef(0,0) = 1.0 / sqrt(H_(0,0));
  

  for (int i = 1; i < 3; i++) {
    U.col(i) = V.col(i);
    Coef(i,i) = 1.0;
    for (int j = 0; j < i; j++) {
      double dotProd = U.col(j).transpose()*U.col(i);
      double uNorm = U.col(j).transpose()*U.col(j);
      //double dotProd1 = Coef.row(j)*H_*Coef.row(i).transpose();
      //double uNorm1 = Coef.row(j)*H_*Coef.row(j).transpose();
      U.col(i) = U.col(i) - dotProd/uNorm*U.col(j);
      //Coef(i,j) = - dotProd / uNorm;
      Coef.row(i) -= dotProd/uNorm*Coef.row(j);
    }
    double uNorm = U.col(i).transpose()*U.col(i);
    U.col(i) /= sqrt(uNorm);
    //double uNorm1 = Coef.row(i)*H_*Coef.row(i).transpose();
    Coef.row(i) /= sqrt(uNorm);
  }
  LOG(INFO) << U.transpose()*U;
  LOG(INFO) << Coef*H_*Coef.transpose();
}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  testDotProdMode0();
  MGSTest();
  //MGSTest1();

  return 0;
}