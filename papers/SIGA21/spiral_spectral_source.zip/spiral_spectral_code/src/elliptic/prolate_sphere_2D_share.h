#ifndef PROLATE_SPHERE_2D_SHARE_H
#define PROLATE_SPHERE_2D_SHARE_H

#define PHI0 sin(k1*t)*cos(k2*p),\
             -invk2*(cos(t)*sin(k1*t) + k1*sin(t)*cos(k1*t))*sin(k2*p)

#define PHI1 sin(k1*t)*sin(k2*p),\
             invk2*(cos(t)*sin(k1*t) + k1*sin(t)*cos(k1*t))*cos(k2*p)

#define PHI2 0,\
             sin(k1*t)

#define PHI3 cos(k1*t)*cos(p),\
             (-cos(t)*cos(k1*t) + k1*sin(t)*sin(k1*t))*sin(p)

#define PHI4 cos(k1*t)*sin(p),\
             (cos(t)*cos(k1*t) - k1*sin(t)*sin(k1*t))*cos(p)

#define computeBasis switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }
        
#endif // PROLATE_SPHERE_2D_SHARE_H