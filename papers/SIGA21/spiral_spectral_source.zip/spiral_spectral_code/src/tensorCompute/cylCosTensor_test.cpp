#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "tensorCompute/cylCosTensor.h"
#include "sphere_3D/cylinder_basis_3D.h"
#include "sphere_3D/cylinder_basis_set_3D.h"
#include "util/timer.h"

namespace {

void test() {
  const int zK_ = 8;
  const int rK_ = 6;
  const int thetaK_ = 6;
  const bool isDirichletR_ = true;
  const int zBndCndIdx_ = 2;
  const double b_ = 2.0;

// half integer for dirichlet bc
  int offsetR = isDirichletR_ ? 0 : 1;
  int offsetZ = (zBndCndIdx_ == 1 || zBndCndIdx_ == 3) ? 1 : 0;
  int offsetEn = isDirichletR_ ? 1 : 0;
  //int offsetOdd = !boundaryCnd_ ? 1 : 0;
  std::vector<basisPtr3DCyl> all_basis_;

  // allocate Phi^0, Psi^2, Psi^5
  for (int i3 = 1; i3 < zK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {
      // put enrichment basis functions first
      // interestingly, when i2==1, the linear space of Phi^0 almost coverlaps with Phi^2
      // Phi^2
      if (i2 == 1) {
        for (int i1 = 1; i1 < rK_; i1++) {
          int k1x2 = i1*2 - offsetEn;
          int k3x2 = i3*2 - offsetZ;
          if (! isDirichletR_)
            k1x2 = (i1-1)*2;   // starts with 0.
          if (zBndCndIdx_ == 2)   // neumann both ends
            k3x2 = (i3-1)*2;

          if (k1x2 != 0 || k3x2 != 0)
            all_basis_.push_back(basisPtr3DCyl(new CylinderBasis3D(k1x2, 2, k3x2, 2, b_, isDirichletR_, zBndCndIdx_)));
        }
      }

      // Phi^0
      for (int i1 = 1; i1 < rK_; i1++) {
        int k3x2 = i3*2 - offsetZ;
        if (zBndCndIdx_ == 2) // neumann both ends.
          k3x2 = (i3-1)*2;
        all_basis_.push_back(basisPtr3DCyl(new CylinderBasis3D(i1*2 - offsetR, i2*2, k3x2, 0, b_, isDirichletR_, zBndCndIdx_)));
      }
    }

  for (int i3 = 1; i3 < zK_; i3++)
    for (int i2 = 1; i2 < thetaK_; i2++) {
      // Phi^3
      if (i2 == 1) {
        for (int i1 = 1; i1 < rK_; i1++) {
          int k1x2 = i1*2 - offsetEn;
          int k3x2 = i3*2 - offsetZ;
          if (! isDirichletR_)
            k1x2 = (i1-1)*2;   // starts with 0.
          if (zBndCndIdx_ == 2)   // neumann both ends
            k3x2 = (i3-1)*2;

          if (k1x2 != 0 || k3x2 != 0)
            all_basis_.push_back(basisPtr3DCyl(new CylinderBasis3D(k1x2, 2, k3x2, 3, b_, isDirichletR_, zBndCndIdx_)));
        }
      }

      // Phi^1
      for (int i1 = 1; i1 < rK_; i1++) {
        int k3x2 = i3*2 - offsetZ;
        if (zBndCndIdx_ == 2) // neumann both ends.
          k3x2 = (i3-1)*2;
        all_basis_.push_back(basisPtr3DCyl(new CylinderBasis3D(i1*2 - offsetR, i2*2, k3x2, 1, b_, isDirichletR_, zBndCndIdx_)));
      }
    }

    // Phi^4
    for (int i3 = 1; i3 < zK_; i3++) {
      for (int i1 = 1; i1 < rK_; i1++) {
        int k1x2 = i1*2 - offsetEn;
        int k3x2 = i3*2 - offsetZ;
        if (! isDirichletR_)
          k1x2 = (i1-1)*2;
        if (zBndCndIdx_ == 2) // both neumann, need dc
          k3x2 = (i3-1)*2;
        // this one allows both wavenumber goes to zero when both neumann along z.
        all_basis_.push_back(basisPtr3DCyl(new CylinderBasis3D(k1x2, 0, k3x2, 4, b_, isDirichletR_, zBndCndIdx_)));
      }    }
  
  // Phi^5
  for (int i3 = 0; i3 < zK_; i3++) {
    for (int i1 = 1; i1 < rK_; i1++)
      all_basis_.push_back(basisPtr3DCyl(new CylinderBasis3D(i1*2, 0, i3*2, 5, b_, isDirichletR_, zBndCndIdx_)));
  }


  const int numBasisAll_ = all_basis_.size();

  Timer timer;
  timer.Reset();
  LOG(INFO) << numBasisAll_;

  cylCosTensor tensorEval;

  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
  	//LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const CylinderBasis3D& basis_i = *all_basis_[i];
        const CylinderBasis3D& basis_g = *all_basis_[g];
        const CylinderBasis3D& basis_h = *all_basis_[h];
        volatile double Cigh = CylinderBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
				const int idx = basis_i.index()*36 + basis_g.index()*6 + basis_h.index();
        volatile double Cnew = tensorEval.pointers_[idx](basis_i, basis_g, basis_h, b_);
        CHECK(fabs(Cigh -  Cnew) < 1e-6) << Cigh << " " << Cnew << " " << i << " " << g << " " << h;
      }
    }
  }
  LOG(INFO) << timer.ElapsedTimeInSeconds();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
	
	test();

  return 0;
}