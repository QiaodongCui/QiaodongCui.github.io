import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt

def read_from_file(fname):
    w = []
    num = []
    f = open(fname)
    for line in f:
        temp = line.split()
        w.append((float)(temp[0]))
        num.append((float)(temp[1]))
    f.close()
    w = np.asarray(w)
    num = np.asarray(num)
    result = {}
    result['w'] = w
    result['num'] = num
    return result

data = read_from_file("./preview/projNew/errorCurve")
data1 = read_from_file("./preview/projNew1/errorCurve")
data2 = read_from_file("./preview/projNew2/errorCurve")
data3 = read_from_file("./preview/projNew3/errorCurve")
data4 = read_from_file("./preview/projNew4/errorCurve")

index = np.arange(0, len(data['w']))

font_size = 12
linge_width = 2

fig, ax = plt.subplots()
#ax.set_ylabel('Residual errors', fontsize = font_size)
#ax.set_xlabel('Number of basis functions', fontsize = font_size)
#ax.set_title(', fontsize = font_size )
num = len(index)

#line1, = ax.plot(data['w'].transpose(), data['num'].transpose(), 'o-', color = 'blue' , lw = linge_width)
line1, = ax.plot(data1['w'].transpose(), (data1['num'].transpose()/100), 'o-', color = 'red' , lw = linge_width)
#line1, = ax.plot(data2['w'].transpose(), data2['num'].transpose(), 'o-', color = 'blue' , lw = linge_width)
line1, = ax.plot(data3['w'].transpose(), (data3['num'].transpose()/100), 'o-', color = 'green' , lw = linge_width)
line1, = ax.plot(data4['w'].transpose(), (data4['num'].transpose()/100), 'o-', color = 'blue' , lw = linge_width)
plt.xlim(0,10400)
ax.set_yscale('log')
#plt.ylim(0, 20)
#plt.ylim(-1.2,0)
#ax.legend(loc='upper left', bbox_to_anchor=(0., 1.0), fontsize = font_size)

#plt.xticks(np.arange(0, x_ceil, 200))
for tick in ax.xaxis.get_major_ticks():
                tick.label.set_fontsize(font_size)
for tick in ax.yaxis.get_major_ticks():
               tick.label.set_fontsize(font_size)   
#plt.show()
plt.savefig("./errorCurve4.pdf", bbox_inches='tight')