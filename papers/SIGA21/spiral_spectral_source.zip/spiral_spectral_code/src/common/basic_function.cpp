#include <glog/logging.h>
#include <unordered_map>
#include <unordered_set>

#include "common/basic_function.h"
#include "elliptic/elliptic_basis_2D.h"

 double BasicFunc::computeRSINCOS(const FUNTYPE& type, const int rpow, const int a2) {
  if (type == COS) {
    switch (rpow) {
      case 0:
        return IR0C(a2);
      break;

      case 1:
        return IR1C(a2);
      break;
      
      case 2:
        return IR2C(a2);
      break;
      
      case 3:
        return IR3C(a2);
      break;

      case 4:
        return IR4C(a2);
      break;
      
      case 5:
        return IR5C(a2);
      break;

      case 6:
        return IR6C(a2);
      break;

      case 7:
        return IR7C(a2);
      break;

      case 8:
        return IR8C(a2);
      break;

      case 9:
        return IR9C(a2);
      break;
      
      case -1:
        return IntegralRInvC_D2(a2);
      break;

      default:
      LOG(FATAL) << "unsupported power " << rpow;
    }
  }

  if (type == SIN) {
    switch (rpow) {
      
      case 0:
        return IR0S(a2);
      break;

      case 1:
        return IR1S(a2);
      break;
      
      case 2:
        return IR2S(a2);
      break;
      
      case 3:
        return IR3S(a2);
      break;

      case 4:
        return IR4S(a2);
      break;

      case 5:
        return IR5S(a2);
      break;

      case 6:
        return IR6S(a2);
      break;

      case 7:
        return IR7S(a2);
      break;

      case 8:
        return IR8S(a2);
      break;

      case 9:
        return IR9S(a2);
      break;
      
      case -1:
        return IntegralRInvS_D2(a2);
      break;

      default:
      LOG(FATAL) << "unsupported power " << rpow;
    }
  }

  LOG(FATAL) << "invalid type " << type;
  return 0.0;
}

double BasicFunc::computeRSIN(const int a2, const int rpow) {
  switch (rpow) {
    case 0:
      return IR0S(a2);
    break;

    case 1:
      return IR1S(a2);
    break;
    
    case 2:
      return IR2S(a2);
    break;
    
    case 3:
      return IR3S(a2);
    break;

    case 4:
      return IR4S(a2);
    break;

    case 5:
      return IR5S(a2);
    break;

    case 6:
      return IR6S(a2);
    break;

    case 7:
      return IR7S(a2);
    break;

    case 8:
      return IR8S(a2);
    break;

    case 9:
      return IR9S(a2);
    break;
    
    case -1:
      return IntegralRInvS_D2(a2);
    break;

    default:
    LOG(FATAL) << "unsupported power " << rpow;
  }

  return 0;
}

double BasicFunc::computeRCOS(const int a2, const int rpow) {
  switch (rpow) {
    case 0:
      return IR0C(a2);
    break;

    case 1:
      return IR1C(a2);
    break;
    
    case 2:
      return IR2C(a2);
    break;
    
    case 3:
      return IR3C(a2);
    break;

    case 4:
      return IR4C(a2);
    break;
    
    case 5:
      return IR5C(a2);
    break;

    case 6:
      return IR6C(a2);
    break;

    case 7:
      return IR7C(a2);
    break;

    case 8:
      return IR8C(a2);
    break;

    case 9:
      return IR9C(a2);
    break;
    
    case -1:
      return IntegralRInvC_D2(a2);
    break;

    default:
    LOG(FATAL) << "unsupported power " << rpow;
  }
  return 0;
}