#include <glog/logging.h>
#include <vector>
#include "tensorCompute/trig_integral.h"

using namespace std;
std::vector<int> testN1 = {0,1,2,3,4,5,6,7,8,-1,-2,-3,-4};

int main(int argc, char ** argv) {
std::vector<double> val = {0., 2., 0., 0.666667, 0., 0.4, 0., 0.285714, 0., -2., 0., -0.666667, \
0.};

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(TrigInt::IntegrateSinPi_D2(testN1[i]*2) - val[i]) < 1e-5);
}
std::vector<double> val1 ={3.14159, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};

for (int i = 0; i < testN1.size(); i++) {
  CHECK(fabs(TrigInt::IntegrateCosPi_D2(testN1[i]) - val1[i]) < 1e-5);
}
  return 0;
}
