#ifndef EIGEN_FLUID_H
#define EIGEN_FLUID_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>

#include "2D/drawer_2d.h"
#include "solver/integrator_2d.h"
#include "polar_2D/polar_basis_set_2D.h"

#include "2D/FIELD2D.h"
#include "2D/particle_2d.h"
#include "util/timer.h"
#include "setting.h"
#include "2D/VFIELD2D.h"
#include "solver/trapezoidal.h"

class EigenFluid {
public:
  EigenFluid(const int basis_dim, const double dt, const double buoyancy, const double visc,
               const int num_particles, const int total_frame,
               const std::string& basis_type, const std::string& tensor_fname,
              const double tensorW, const std::string& integrator_type):numBasisAll(basis_dim), dt_(dt), 
              buoyancy_(buoyancy), visc_(visc),num_particles_(num_particles),
              total_frame_(total_frame),basis_type_(basis_type),
              tensor_fname_(tensor_fname),tensorWeight_(tensorW),integrator_type_(integrator_type)  {
    Initialize();
  }

  ~EigenFluid(){}
  void Initialize();
  bool quit_ = false;
  void Quit();
  
  double dt() {
    return dt_;
  }
protected:

  // The dimension of all basis of the basis field.
  int numBasisAll;
  // Timestep
  const double dt_;
  // Buoyancy.
  const double buoyancy_;
  // Viscosity.
  const double visc_;
  const int num_particles_;
  const int total_frame_;
  std::string basis_type_;
  const std::string tensor_fname_;
  double tensorWeight_ = 1.0;

  std::unique_ptr<Trapezoidal> integrator_;
  std::string integrator_type_;

  // The energy of current timestep.
  double current_energy_;

  // The dimension of extracted orthogonal basis.
  int numBasisOrtho;

  Eigen::VectorXd basis_coefficients_;
  Eigen::VectorXd basis_coefficients_old_;

  Eigen::MatrixXd A_;
  // weight for each basis function.
  Eigen::VectorXd basisWeights_;

  Timer timer_;
  // timing info
  int rest_frame_;
  int frame_simulated_ = 0;
  double integrator_time_;
  double transformation_time_;
  double density_advection_time_;

  std::vector<Adv_Tensor_Type> Adv_tensor_;

  double maximum_condition_number_;


  double CalculateEnergy();

  // projected wavenumber for diffusion.
  Eigen::VectorXd projWav_;
  // sorted wavenumber of projWav_, roughtly describes the frequency of each coefficients.
  std::vector<int> sortedIndex_;
  void computeSortedIdx(const Eigen::VectorXd& waveN2);
  void DissipateEnergy();
};

#endif  // EIGEN_FLUID_H
