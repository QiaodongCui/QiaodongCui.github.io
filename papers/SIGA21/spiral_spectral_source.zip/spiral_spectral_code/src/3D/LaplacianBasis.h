#pragma once

#include <Eigen/Sparse>

#define USE_MATH_DEFINES
#include <cmath>

#define PI_CUBE M_PI*M_PI*M_PI

class LaplacianBasis {
public:
	LaplacianBasis(const int k1, const int k2, const int k3,
		const double A, const double B, const double C, const int set)
		: _k1(k1), _k2(k2), _k3(k3), _A(A), _B(B), _C(C), _index(set)
	{
		_invNorm = 0;
		int nZeros = 0;
		if (k1 == 0) nZeros++;
		if (k2 == 0) nZeros++;
		if (k3 == 0) nZeros++;

		if (nZeros == 0) {
			_DCTNorm = 0.125;
		}
		else if (nZeros == 1) {
			_DCTNorm = 0.25;
		}
		else if (nZeros == 2) {
			_DCTNorm = 0.5;
		}
		else {
			_DCTNorm = 1.0;
		}
	}


	/*virtual double comptueBasisAt(const int xpos, const int ypos,
		const int zpos, const int mode, const UT_Vector3F& dxys)
		const = 0;*/

	virtual void Normalize() = 0;

	//UT_Vector3I GetWaveNum() const {
	//	return UT_Vector3I(_k1, _k2, _k3);
	//}

	double GetVxCoef() const {
		return _invNorm * _A;
	}
	// Get the const coeff for vy.
	double GetVyCoef() const {
		return _invNorm * _B;
	}
	// Get the const coeff for vz.
	double GetVzCoef() const {
		return _invNorm * _C;
	}
	double GetDCTNorm() const {
		return _DCTNorm;
	}
	double GetInvNorm() const {
		return _invNorm;
	}

	int getSetIndex() const { return _index;  }
	double getA() const { return _A; }
	double getB() const { return _B; }
	double getC() const { return _C; }
	virtual double getLambdaSquared() const = 0;

	int k1() const {return _k1;}
	int k2() const {return _k2;}
	int k3() const {return _k3;}
	int index() const {return _index;}
	double a() const { return _A; }
	double b() const { return _B; }
	double c() const { return _C; }

protected:
	const int _k1;
	const int _k2;
	const int _k3;

	const double _A;
	const double _B;
	const double _C;

	const int _index;

	double _invNorm;
	double _DCTNorm;
};