#ifndef VFIELD2D_H
#define VFIELD2D_H

#include <fstream>
#include <glog/logging.h>

#include "Alg/VEC2.h"
#include "setting.h"
#include "2D/FIELD2D.h"
#include <cassert>

class VFIELD2D
{
public:
  VFIELD2D():data(NULL), xRes(0), yRes(0){};
  VFIELD2D(int _xRes, int _yRes): xRes(_xRes), yRes(_yRes) {
    data = (VEC2F*) malloc(sizeof(VEC2F)*xRes*yRes);
    for(int i=0;i<xRes*yRes;i++)
    { data[i][0] = 0.; data[i][1] = 0.;}
    totalcell = xRes*yRes;
  }

  VFIELD2D(const std::string& fname);

  ~VFIELD2D(){
    free(data);
  };

  VFIELD2D& operator=(const VFIELD2D& input);
  inline VEC2F& operator()(int x, int y) { 
    assert(  y >= 0 && y < yRes && x >= 0 && x < xRes);
    return data[ y * xRes + x]; 
  }
  inline const VEC2F& operator()(int x, int y) const {
    assert(  y >= 0 && y < yRes && x >= 0 && x < xRes);
    return data[ y * xRes + x];
  }
  inline VEC2F& operator [] (int x) {
    assert(x>=0 && x<totalcell);
    return data[x];
  }
  const VEC2F operator [] (int x) const {
    assert(x>=0 && x<totalcell);
    return data[x];
  }

  void addField(const double a, VFIELD2D& b) {
    assert(b.getxRes() == xRes && b.getyRes() == yRes);
    for (int i = 0; i < totalcell; i++) {
      data[i] += a*b[i];
    }
  }
  
  // Get the velocity at a specific position.
  // pos_x, pos_y in grid position [0-xres, 0-yres].
  VEC2 GetVelocity(const float pos_x, const float pos_y) const;
  void AddVelocity(const float pos_x, const float pos_y, const VEC2& v, int* cntGrid) const;
  void set_zero_border();

  void SetZeroLeft();
  void SetZeroRight();
  void SetZeroTop();
  void SetZeroBottom();
  void SetZeroCiricle();
  
  int getyRes()const{return yRes;}
  int getxRes()const{return xRes;}
  
  void SetNeumannLeft();
  void SetNeumannRight();
  void SetNeumannTop();
  void SetNeumannBottom();
  void CopyBorderRight();
  void CopyBorderLeft();
  void CopyBorderTop();
  void CopyBorderBottom();
  void axpy(const Real alpha, const VFIELD2D&);
  void swapPointer( VFIELD2D& field);
  static void advect(const Real dt, const VFIELD2D& velocity_field, const FIELD2D& oldField, FIELD2D& newField);
  static void advectSphere(const Real dt, const VFIELD2D& velocity_field, FIELD2D& oldField, FIELD2D& newField,
                           VEC2 north, VEC2 south);
  static void advect(const Real dt, const VFIELD2D& velocity_field, const VFIELD2D& oldField, VFIELD2D& newField);
   
  static void advectMacCormack(const Real dt, const VFIELD2D& velocityGrid, FIELD2D& oldField, 
                               FIELD2D& newField, FIELD2D& temp1, FIELD2D& temp2);

  static void advectMacCormack(const Real dt, const VFIELD2D& velocityGrid, VFIELD2D& oldField, 
                               VFIELD2D& newField, VFIELD2D& temp1, VFIELD2D& temp2);

  static void clampExtrema(const Real dt, const VFIELD2D& velocityField, const FIELD2D& 
                                      oldField, FIELD2D& newField);

  static void clampExtrema(const Real dt, const VFIELD2D& velocityField, const VFIELD2D& 
                                      oldField, VFIELD2D& newField);

  static void clampOutsideRays(const Real dt, const VFIELD2D& velocityField, const FIELD2D&  
                                        oldField, const FIELD2D& oldAdvection, FIELD2D& newField);

  static void clampOutsideRays(const Real dt, const VFIELD2D& velocityField, const VFIELD2D&  
                                      oldField, const VFIELD2D& oldAdvection, VFIELD2D& newField);
  
  void clear();
  void SaveVelocity(FILE* out) const;
  void SaveVelocity(const std::string& fname) const;
  void SaveMagnitude(const std::string& fname) const;
  void LoadVelocity(const std::string& fname);
  void Draw(float magnitute);
  void Draw_X(float magnitute, int mode);
  double GetEnergy();
  double GetMaximumVelocity();
  // Do a dot product with another std::vector field in 2D.
  double DotProduct(const VFIELD2D& b);
  void copyBorderAll();
  // debug only.
  void checkValue();
  void checkDivergence();
  
protected:
  int totalcell;
  VEC2F* data;
  int xRes;
  int yRes;
};

#endif
