#ifndef SphereBasis3DLap_H
#define SphereBasis3DLap_H
#include <math.h>
#include <vector>
#include "common/basic_function.h"
#include "3D/trig_integral_3d.h"
#include "sphere_3D/basis_3D.h"

#define GETWN double val = 0;\
const int i1x2 = Basis_i.WN1x2();\
const int i2x2 = Basis_i.WN2x2();\
const int i3x2 = Basis_i.WN3x2();\
const int j1x2 = Basis_j.WN1x2();\
const int j2x2 = Basis_j.WN2x2();\
const int j3x2 = Basis_j.WN3x2();\
const double i1 = Basis_i.WN1D();\
const double i2 = Basis_i.WN2D();\
const double i3 = Basis_i.WN3D();\
const double j1 = Basis_j.WN1D();\
const double j2 = Basis_j.WN2D();\
const double j3 = Basis_j.WN3D();

#define CosInvT IntegralSinInvCosT
#define SinInvT IntegralSinInvSinT
#define CosT IntegralC_D2
#define SinT IntegralS_D2
#define CosR BasicFunc::computeRCOS
#define SinR BasicFunc::computeRSIN
#define CosP IntegrateCos2Pi_D2
#define SinP IntegrateSin2Pi_D2
#define Pi M_PI

class SphereBasis3DLap{
public:
SphereBasis3DLap();
~SphereBasis3DLap(){};
#include "sphere_3D/SphereBasis3DLapapp.txt"
std::vector<double (*)(const Basis3D&, const Basis3D&)> pointers_;
};
#undef GETWN
#undef CosInvT
#undef SinInvT
#undef CosT
#undef SinT
#undef CosR
#undef SinR
#undef CosP
#undef SinP
#undef Pi

#endif