#ifndef TORUS_BASIS_2D_ALL_H
#define TORUS_BASIS_2D_ALL_H

#include <Eigen/Eigen>
#include <fstream>

#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "common/basic_function.h"
#include "2D/basis_2D.h"
#include "util/util.h"

class TorusBasis2D : public Basis2D {

public:
	TorusBasis2D(const int k12, const int k22, const int idx, const double& a):
  	Basis2D(k12, k22), index_(idx), a_(a),
    scale_(1.0/(a+1.0)), scale3_(scale_*scale_*scale_) {
  	
  	invNorm_ = 0; // Default zero.
    // Initialize DCT norm.
    int num_zeros = 0;
    if (k1x2 == 0) num_zeros ++;
    if (k2x2 == 0) num_zeros ++;

    // need dct both directions
    if (num_zeros == 0) {
      DCTNorm_ = 0.25;
    } else if (num_zeros == 1) { // only dct one direction
      DCTNorm_ = 0.5;
    } else {  // dc component
      DCTNorm_ = 1.;
    }

    initBasicCoef();
    Normalize();
    curlSph();
	};

	~TorusBasis2D(){};

  double GetDCTNorm() const {
    return DCTNorm_;
  }
  
  double GetInvNorm() const {
    return invNorm_;
  }

  void debugPrint() const {
    LOG(INFO) << "k1 " << k1 << " k2 " << k2 << " index " << index_ << " norm " << invNorm_;
  }
  
  int index() const {
    return  index_;
  }
	void DiscretizeAdd(const double coef, VFIELD2D* vfield) const;
	void AddUniformU(const double coef, const int nT, const int nP, double* ut, double* up) const;
	double ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const;
  
  double dotProd(const TorusBasis2D& other) const;
	void Normalize();

	const BasicFunc& getPhiFunc(int idx) const {
    return phiFunc_[idx];
  }
  
  const std::vector<RTMultiply>& getRT(int idx) const {
    return RT_[idx];
  }

  const BasicFunc& getCurPhi(int i) const {
    return curlPhi_[i];
  }
  
  const std::vector<RTMultiply>& getCurRT(int i) const {
    return curlRT_[i];
  }
  static void crossProdPhi(const TorusBasis2D& phiG, const TorusBasis2D& phiH,
                                 std::vector<BasicFunc> (&crossPhi)[2]);

  static void crossProdRT(const TorusBasis2D& phiG, const TorusBasis2D& phiH,
                                std::vector<RTMultiply> (&crossRT)[2]);
  
  static double integrateCurlCross(const BasicFunc& curP, const std::vector<BasicFunc>& crossP,
                                   const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT);
	static double computeTensorEntry(const TorusBasis2D& phiI, const TorusBasis2D& phiG, const TorusBasis2D& phiH);
	
	void writeToFile(std::ofstream& out) const;
  static TorusBasis2D* fromFile(std::ifstream& in);

  const double getInvWaveN() const {
    if (index_  <= 3) {
      return 1.0/k2;
    }
    return 1.0;
  }
protected:
	void initBasicCoef();
  // sin(t)*\nabla x f = sin(t)*D[f_p, t] + cos(t)f_p - D[f_t, p]
  void curlSph();
  double computeRTMultInt(const RTMultiply& rt1) const;

  double DCTNorm_;
  double norm2_;
  // index for different kind of basis functions
  int index_;
  // major radius
  const double a_;
  // basic form of the basis function
  //T R component along (r, \theta, \phi) direction.
  std::vector<RTMultiply> RT_[2];
  // Copied from sphere3D basis functions, in this case the function along 
  // phi are all constant numbers with coefficients.
  BasicFunc phiFunc_[2];

  // curl data
  BasicFunc curlPhi_[4];
  std::vector<RTMultiply> curlRT_[4];
  // A constant scale to the basis so it lines up with the coordinates.
  const double scale_;
  const double scale3_;
};

#endif  // TORUS_BASIS_2D_ALL_H