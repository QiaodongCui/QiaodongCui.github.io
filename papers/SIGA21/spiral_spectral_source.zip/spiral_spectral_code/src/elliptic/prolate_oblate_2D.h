#ifndef PROLATE_BASIS_2D_H
#define PROLATE_BASIS_2D_H

#include <Eigen/Eigen>
#include <fstream>
#include <glog/logging.h>
#include <memory>
#include <unordered_set>
#include <unordered_map>

#include "common/query_table.h"
#include "common/basic_function.h"
#include "polar_2D/sphere_basis_2D_all.h"

#include <vector>

class ProlateOblate2D : public SphereBasis2DAll {

public:
  ProlateOblate2D(const int k12, const int k22, const int idx, const double& b):
    SphereBasis2DAll(k12, k22, idx),b_(b), a_(sqrt(1.0-b*b)),c_(b/sqrt(1.0-b*b)), is_prolate_(true) {
    // 1/b
    eFact_[0] = EllipticFactor(0, 0, 0, 1/b_);
    // 1/(ah)
    eFact_[1] = EllipticFactor(-1, 0, 0, 1/a_);
    curlSph();
  }
  
  ProlateOblate2D(const int k12, const int k22, const int idx, const IntTable1DData& tabData):
    SphereBasis2DAll(k12, k22, idx), b_(tabData.b), a_(tabData.a),c_(tabData.c), is_prolate_(true) {
    // 1/b
    eFact_[0] = EllipticFactor(0, 0, 0, 1/b_);
    // 1/(ah)
    eFact_[1] = EllipticFactor(-1, 0, 0, 1/a_);

    Normalize(tabData);
    curlSph();
  }

  ProlateOblate2D(const int k12, const int k22, const int idx, const double& b, const bool is_prolate):
    SphereBasis2DAll(k12, k22, idx),b_(b), a_(sqrt(1.0-b*b)),c_(b/sqrt(1.0-b*b)), is_prolate_(is_prolate) {
    if (is_prolate_) {
      // 1/b
      eFact_[0] = EllipticFactor(0, 0, 0, 1/b_);
      // 1/(ah)
      eFact_[1] = EllipticFactor(-1, 0, 0, 1/a_);
    } else {  // oblate
      // 1/b
      eFact_[0] = EllipticFactor(0, 0, 0, 1/(a_*sqrt(1.0 + c_*c_)));
      // 1/(ah)
      eFact_[1] = EllipticFactor(-1, 0, 0, 1/a_);
    }
    curlSph();
  }

  ProlateOblate2D(const int k12, const int k22, const int idx, const IntTable1DData& tabData, const bool is_prolate):
    SphereBasis2DAll(k12, k22, idx), b_(tabData.b), a_(tabData.a),c_(tabData.c), is_prolate_(is_prolate) {
    if (is_prolate_) { // 1/b
      eFact_[0] = EllipticFactor(0, 0, 0, 1/b_);
      // 1/(ah)
      eFact_[1] = EllipticFactor(-1, 0, 0, 1/a_);
    } else {
      // 1/b
      eFact_[0] = EllipticFactor(0, 0, 0, 1/(a_*sqrt(1.0 + c_*c_)));
      // 1/(ah)
      eFact_[1] = EllipticFactor(-1, 0, 0, 1/a_);
    }

    Normalize(tabData);
    curlSph();
  }

  void DiscretizeAdd(const double coef, VFIELD2D* vfield) const;
  void AddUniformU(const double coef, const int nT, const int nP, double* ut, double* up) const;
  double ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const;

  double dotProd(const ProlateOblate2D& other, const IntTable1DData& tabData) const;
  void dotProdPattern(const ProlateOblate2D& other, std::unordered_set<uint64_t>& set) const;

  // int_{\theta = 0}^{Pi} fun1*sin(\theta) d\theta 
  double computeThetaInt(const BasicFunc& fun1, const EllipticFactor& ef, const bool withJacobian,
                                const IntTable1DData& tabData) const;

  static void computeThetaPattern(const BasicFunc& fun1, const EllipticFactor& ef,
                                  const bool withJacobian, std::unordered_set<uint64_t>& set);

  double computeVThetaInt(const std::vector<BasicFunc>& t1, const EllipticFactor& ef,
                                const bool withJacobian,  const IntTable1DData& tabData) const;
  
  static void computeVThetaPattern(const std::vector<BasicFunc>& t1, const EllipticFactor& ef,
                                   const bool withJacobian, std::unordered_set<uint64_t>& set);

  const EllipticFactor& getEFactor(const int idx) const {
    return eFact_[idx];
  };

  double computeTensorEntry(const ProlateOblate2D& phiG,
       const ProlateOblate2D& phiH, const IntTable1DData& tabData);
  
  static void computeTensorPattern(const ProlateOblate2D& phiI, const ProlateOblate2D& phiG,
       const ProlateOblate2D& phiH, std::unordered_set<uint64_t>& set);
  
  static ProlateOblate2D* fromFile(std::ifstream& in, const IntTable1DData& tabData, const bool is_prolate);
  
protected:
  
  void Normalize(const IntTable1DData& tabData) {
    norm2_ = dotProd(*this, tabData);
    invNorm_ = 1.0/sqrt(norm2_);
  }
  // (\int_p <curP>*<crossP>)(\int_t curRT*crossRT)
  double integrateCurlCross(const BasicFunc& curP, const std::vector<BasicFunc>& crossP,
                            const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT,
                            const EllipticFactor& curlEF, const EllipticFactor& crossEF, const IntTable1DData& tabData) const;

  static void patternCurlCross(const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT,
                                 const EllipticFactor& curlEF, const EllipticFactor& crossEF, std::unordered_set<uint64_t>& set);

  const BasicFunc& getCurPhi(int i) const {
    return curlPhi_[i];
  }
  
  const EllipticFactor& getcrossEF() const {
    return crossEF_;
  }
  
  const EllipticFactor& getcurlEF(int i) const {
    return curlEF_[i];
  }

  const std::vector<RTMultiply>& getCurRT(int i) const {
    return curlRT_[i];
  }

  const double b_;
  // focus
  const double a_;
  // sinh(w) = b/a
  const double c_;

  // here we only have the factor per each velocity component
  EllipticFactor eFact_[2];

  // true, prolate, false: oblate
  const bool is_prolate_;
  
  void curlSph();
  // curl data, see eq 23 if Elliptic3D.pdf
  BasicFunc curlPhi_[5];
  EllipticFactor curlEF_[5];
  std::vector<RTMultiply> curlRT_[5];
  // The cross prduct produces one shared elliptic factor: 1/(a*b*h)
  //f_gxf_h = /b*1/a/h (g_t*h_p  - g_p*h_t)
  EllipticFactor crossEF_;
};

typedef std::shared_ptr<ProlateOblate2D> prolate2DPtr;

#endif // PROLATE_BASIS_2D_H