#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "common/basis_set.h"
#include "polar_2D/polar_basis_all.h"
#include "polar_2D/scomp_basis_set_2D.h"

#include "util/util.h"
#include "util/timer.h"

namespace {
  
  void testTensor() {

    SCompBasisSet2D basis(512, 5, 10, false);
    std::vector<Adv_Tensor_Type> Adv_tensor_;
    //basis.FillVariationalTensor(&Adv_tensor_);
    basis.outputTestTensorEntries(100, "./polar_tensorTest1.txt", &Adv_tensor_);
    //BasisSet::VerifyAntisymmetric(Adv_tensor_);
  }

  void testEntry() {
    PolarBasisAll basis_i(4, 14, 0);
    PolarBasisAll basis_g(8, 16, 0);
    PolarBasisAll basis_h(3, 2, 3);
    LOG(INFO) << PolarBasisAll::computeTensorEntry(basis_i, basis_g, basis_h);
  }

}

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);
  testTensor();
  //testEntry();
}