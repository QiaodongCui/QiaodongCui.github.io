#include <cmath>
#include <Eigen/Eigen>
#include <fftw3.h>
#include <glog/logging.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <fstream>

#include "polar_2D/polar_basis_set_2D.h"
#include "setting.h"
#include "util/util.h"
#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "3D/trig_integral_3d.h"

// TODO: Modify the memory layout of VFIELD2D to do every thing inplace.
// Also Modify the memory structure to reduce the cost of shift the data
// in sine direction.


void PolarBasisSet2D::allocateNumerical() {
  LOG(FATAL) << "depredated";
}

void PolarBasisSet2D::setUpFFTWPlan() {

  fftw_r2r_kind invS_ = FFTW_RODFT01;
  fftw_r2r_kind invC_ = FFTW_REDFT01;
  fftw_r2r_kind fwdS_ = FFTW_RODFT10;
  fftw_r2r_kind fwdC_ = FFTW_REDFT10;

  int howmanyR = nTheta_;
  int rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;

  int nr_[1] = {rsize};
  int *inembedr_ = nr_;
  int *onembedr_ = nr_;

  int howmanyT = rsize;
  int nt_[1] = {nTheta_};
  int* inembedt_ = nt_;
  int* onembedt_ = nt_;

  IsinR_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &invS_, FFTW_MEASURE);
  IcosR_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &invC_, FFTW_MEASURE);
  IsinTheta_ = fftw_plan_many_r2r(1, nt_, howmanyT, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &invS_, FFTW_MEASURE);
  IcosTheta_ = fftw_plan_many_r2r(1, nt_, howmanyT, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &invC_, FFTW_MEASURE);
  FsinR_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &fwdS_, FFTW_MEASURE);;
  FcosR_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &fwdC_, FFTW_MEASURE);;
  FsinTheta_ = fftw_plan_many_r2r(1, nt_, howmanyT, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &fwdS_, FFTW_MEASURE);
  FcosTheta_ = fftw_plan_many_r2r(1, nt_, howmanyT, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &fwdC_, FFTW_MEASURE);
  int rsizeEn = nR_;
  if (boundaryCnd_)
    rsizeEn = nR_*2;
  nr_[0] = rsizeEn;
  IsinREn_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &invS_, FFTW_MEASURE);
  IcosREn_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &invC_, FFTW_MEASURE);
  IsinThetaEn_ = fftw_plan_many_r2r(1, nt_, rsizeEn, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &invS_, FFTW_MEASURE);
  IcosThetaEn_ = fftw_plan_many_r2r(1, nt_, rsizeEn, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &invC_, FFTW_MEASURE);
  FsinREn_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &fwdS_, FFTW_MEASURE);
  FcosREn_ = fftw_plan_many_r2r(1, nr_, howmanyR, urTemp_, inembedr_, nTheta_, 1, oddTemp_, onembedr_, nTheta_, 1, &fwdC_, FFTW_MEASURE);
  FsinThetaEn_ = fftw_plan_many_r2r(1, nt_, rsizeEn, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &fwdS_, FFTW_MEASURE);
  FcosThetaEn_ = fftw_plan_many_r2r(1, nt_, rsizeEn, urTemp_, inembedt_, 1, nTheta_, oddTemp_, onembedt_, 1, nTheta_, &fwdC_, FFTW_MEASURE);
  
  rsize = nR_;
  if (! boundaryCnd_)
    rsize = nR_*2;
  rtemp0_ = (double*) malloc(sizeof(double)*rsize);
  std::memset(rtemp0_, 0x00, sizeof(double)*rsize);
  rtemp1_ = (double*) malloc(sizeof(double)*rsize);
  std::memset(rtemp1_, 0x00, sizeof(double)*rsize);
  IsinR1D_ = fftw_plan_r2r_1d(rsize, rtemp0_, rtemp1_, invS_, FFTW_MEASURE);
  FsinR1D_ = fftw_plan_r2r_1d(rsize, rtemp0_, rtemp1_, fwdS_, FFTW_MEASURE);
}

#define interPol(arg_)\
(wt0 * (wr0 * arg_[i000] + wr1 * arg_[i010]) +\
 wt1 * (wr0 * arg_[i100] + wr1 * arg_[i110]))\
// interpolate the urTemp and utTemp to Cartesian field.
void PolarBasisSet2D::interpolateToCartesian(VFIELD2D* vfield) {
  CHECK(vfield->getxRes() == N_);
  CHECK(vfield->getyRes() == N_);
  vfield->clear();
  const double dx = 2.0 / N_;
  const double dy = 2.0 / N_;

  #pragma omp parallel for
  for (int j = 0; j < N_; j++) {
    for (int i = 0; i < N_; i++) {
      const int cidx = i + j*N_;
      
      double x = ((double)(i) + 0.5)*dx - 1.0;
      double y = ((double)(j) + 0.5)*dy - 1.0;
      double r = sqrt(x*x + y*y);
      double t = atan2(y, x);
      if (y < 0)
        t += 2.0*M_PI;
      // outside of the ellipse
      if (r > 1.0)
        continue;
      
      int r0 = (int)(r/dr_);
      int r1 = r0 + 1;
      int t0 = (int)(t/dTheta_);
      int t1 = t0 + 1;
      
      // clamp
      r0 = (r0 < 0) ? 0 : r0;
      r1 = (r1 > nR_ - 1) ? nR_ - 1 : r1;
      // periodic bc
      t0 = (t0 < 0) ? nTheta_ + t0 : t0;
      t1 = (t1 > nTheta_ - 1) ? t1 - nTheta_ : t1;

      // get interpolation weights
      const double wt1 = t/dTheta_ - t0;
      const double wt0 = 1.0 - wt1;
      const double wr1 = r/dr_ - r0;
      const double wr0 = 1.0 - wr1;

      const int i000 = t0 + r0 * nTheta_;
      const int i010 = t0 + r1 * nTheta_;
      const int i100 = t1 + r0 * nTheta_;
      const int i110 = t1 + r1 * nTheta_;
      Eigen::Vector2d uP(0,0);
      uP << interPol(urTemp_), interPol(utTemp_);
      
      (*vfield)[cidx][0] = uP[0]*cos(t) - uP[1]*sin(t);
      (*vfield)[cidx][1] = uP[0]*sin(t) + uP[1]*cos(t);
    }
  }
}

// interpolate the urTemp and utTemp to Cartesian field.
void PolarBasisSet2D::interpolateToCartesian(VFIELD2D* vfield, const double* ur, const double* ut) {
  CHECK(vfield->getxRes() == N_);
  CHECK(vfield->getyRes() == N_);
  vfield->clear();
  const double dx = 2.0 / N_;
  const double dy = 2.0 / N_;

  #pragma omp parallel for
  for (int j = 0; j < N_; j++) {
    for (int i = 0; i < N_; i++) {
      const int cidx = i + j*N_;
      
      double x = ((double)(i) + 0.5)*dx - 1.0;
      double y = ((double)(j) + 0.5)*dy - 1.0;
      double r = sqrt(x*x + y*y);
      double t = atan2(y, x);
      if (y < 0)
        t += 2.0*M_PI;
      // outside of the ellipse
      if (r > 1.0)
        continue;
      
      int r0 = (int)(r/dr_);
      int r1 = r0 + 1;
      int t0 = (int)(t/dTheta_);
      int t1 = t0 + 1;
      
      // clamp
      r0 = (r0 < 0) ? 0 : r0;
      r1 = (r1 > nR_ - 1) ? nR_ - 1 : r1;
      // periodic bc
      t0 = (t0 < 0) ? nTheta_ + t0 : t0;
      t1 = (t1 > nTheta_ - 1) ? t1 - nTheta_ : t1;

      // get interpolation weights
      const double wt1 = t/dTheta_ - t0;
      const double wt0 = 1.0 - wt1;
      const double wr1 = r/dr_ - r0;
      const double wr0 = 1.0 - wr1;

      const int i000 = t0 + r0 * nTheta_;
      const int i010 = t0 + r1 * nTheta_;
      const int i100 = t1 + r0 * nTheta_;
      const int i110 = t1 + r1 * nTheta_;
      Eigen::Vector2d uP(0,0);
      uP << interPol(ur), interPol(ut);
      
      (*vfield)[cidx][0] = uP[0]*cos(t) - uP[1]*sin(t);
      (*vfield)[cidx][1] = uP[0]*sin(t) + uP[1]*cos(t);
    }
  }
}

#undef interPol

void PolarBasisSet2D::interpolateToPolar(const VFIELD2D& field) {
  ClearuR();
  ClearuT();

  CHECK(field.getxRes() == N_ && field.getyRes() == N_);
  
  #pragma omp parallel for
  for (int j = 0; j < nR_; j++) {
    const double r = ((double)(j) + 0.5)*dr_; // [0-1]
    for (int i = 0; i < nTheta_; i++) {
      const double t = ((double)(i) + 0.5)*dTheta_; // [0, 2*pi]
      // need to get the nearest catersian grid
      const double x = (r*cos(t) + 1.0)*0.5;
      const double y = (r*sin(t) + 1.0)*0.5;
      VEC2 vCat = field.GetVelocity(x*N_, y*N_);
      
      urTemp_[i + j*nTheta_] = vCat[0]*cos(t) + vCat[1]*sin(t);
      utTemp_[i + j*nTheta_] = -vCat[0]*sin(t) + vCat[1]*cos(t);
    }
  }
}

// Interpolate velocity from the polar grid.
// [x,y] \in [0,1]^2
VEC2 PolarBasisSet2D::fromPolar(const double x, const double y) {
  // [-1. 1]
  double xx = x*2.0 - 1.0;
  double yy = y*2.0 - 1.0;

  double r = sqrt(xx*xx + yy*yy);
  double t = atan2(yy, xx);
  if (yy < 0)
    t += 2*M_PI;

  if (r > 1.0)
    return VEC2(0,0);
  
  VEC2 veloPolar;

  int tl = floor(t/dTheta_);
  int tu = tl + 1;
  double wt = t/dTheta_ - tl;
  
  if (r > dr_) {
    int rl = floor(r/dr_);
    int ru = rl + 1;

    double wu = r/dr_ - rl;
    // interpolate along r
    VEC2 vtl = polarV_(tl, ru)*wu + polarV_(tl, rl)*(1.0 - wu);
    VEC2 vtu = polarV_(tu, ru)*wu + polarV_(tu, rl)*(1.0 - wu);
    
    veloPolar = vtu*(wt) + vtl*(1.0 - wt);
  } else {  // r < dr, rl = 0
    // compute the velocity at pole.
    VEC2 vp(0,0);
    for (int i = 0; i < nTheta_; i++) {
      vp += polarV_(i, 0);
    }
    vp *= dTheta_;

    double wu = r/dr_;
    VEC2 vtl = polarV_(tl, 1)*wu + vp*(1.0 - wu);
    VEC2 vtu = polarV_(tu, 1)*wu + vp*(1.0 - wu);
    
    veloPolar = vtu*wt + vtl*(1.0 - wt);
  }
  VEC2 result(0,0);
  double cosT = xx/r;
  double sinT = yy/r;
  if (r > 1e-10) {
    result[0] = veloPolar[0]*cosT - veloPolar[1]*sinT;
    result[1] = veloPolar[0]*sinT + veloPolar[1]*cosT;
  }
  return result;
}

void PolarBasisSet2D::addForcePolar() {
  for (int j = 1; j < nR_; j++) {
    for (int i = nTheta_/4 - 20; i < nTheta_/4 + 20; i++) {
      polarF_(i,j)[0] = -100.0;
    }
  }
}

void PolarBasisSet2D::clearPairCoef() {
  for (auto& v : phiCoef_)
    for (auto& p : v) {
      p.coef = 0;
    }
}

void PolarBasisSet2D::weightR(double* buf) {
  const double dr = 1.0 / nR_;
  for (int j = 0; j < nR_; j++) {
    for (int i = 0; i < nTheta_; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      buf[i + j*nTheta_] *= r;
    }
  }
}

double PolarBasisSet2D::computeEnergyPolar(const int nR, const int nTheta, const double* ur, const double* ut) {
  
  double dr = 1.0 / nR;
  double dTheta = 2.0*M_PI/nTheta;
  double result = 0;

  for (int j = 0; j < nR; j++) {
    for (int i = 0; i < nTheta; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
      
      // v *= coef*invNorm_;
      int idx = i + j*nTheta;
      // jacobian
      result += (ur[idx]*ur[idx] + ut[idx]*ut[idx])*r;
    }
  }
  result *= dr*dTheta;
  return result;
}

void PolarBasisSet2D::computeJDivPolar(const int nR, const int nTheta, const double* ur, const double* ut, double* div) {
  double dr = 1.0 / nR;
  double dTheta = 2.0*M_PI/nTheta;
  double maxDiv = -1.0;
  for (int j = 1; j < nR-1; j++) {
    for (int i = 1; i < nTheta-1; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
      // v *= coef*invNorm_;
      int idx = i + j*nTheta;
      div[idx] = 1/r*ur[idx] + (ur[idx+nTheta] - ur[idx-nTheta])/dr*0.5 + 1.0/r*(ut[idx+1] - ut[idx-1])/dTheta*0.5;
      if (abs(div[idx]) > maxDiv)
        maxDiv = abs(div[idx]);
    }
  }

  //for (int j=1; j < nR-1; j++) {
  //  int i = 0;
  //  double r = ((double)(j) + 0.5)*dr;   // [0-1]
  //  double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
  //  int idx = i + j*nTheta;
  //  div[idx] = ur[idx] + r*(ur[idx+nTheta] - ur[idx-nTheta])/dr*0.5 + (ut[idx+1] - ut[idx+nTheta-1])/dTheta*0.5;
  //  i = nTheta-1;
  //  t = ((double)(i) + 0.5)*dTheta;
  //  idx = i + j*nTheta;
  //  div[idx] = ur[idx] + r*(ur[idx+nTheta] - ur[idx-nTheta])/dr*0.5 + (ut[idx-nTheta+1] - ut[idx+nTheta-2])/dTheta*0.5;
  //  if (abs(div[idx]) > maxDiv)
  //    maxDiv = abs(div[idx]);
  //}

  LOG(INFO) << maxDiv;
}