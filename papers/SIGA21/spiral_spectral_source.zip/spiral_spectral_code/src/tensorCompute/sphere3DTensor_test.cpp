#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "tensorCompute/sphere3DTensor.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "sphere_3D/sphere_basis_set_3D.h"
#include "util/timer.h"

namespace {

void test() {
	const int rK_ = 5;
	const int thetaK_ = 8;
	const int phiK_ = 8;
	const double a_ = 3.0;
  const bool boundaryCnd_ = true;

	std::vector<basisPtr3D> all_basis_;

int offsetOdd = !boundaryCnd_ ? 1 : 0;
  // half integer for dirichlet bc
  int offset = boundaryCnd_ ? 1 : 0;

  // allocate Phi^0, Psi^2, Psi^5
  for (int i3 = 1; i3 < phiK_; i3++) {
    if (i3 == 1) {
      // Psi^5
      for (int i1 = 0; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 + offset, 2, 2, 5)));
      }
      // Psi^2
      for (int i2 = 0; i2 < thetaK_; i2++)
        for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 - offsetOdd, i2*2, 2, 2)));
        }
    }

    // Phi^0
    for (int i2 = 1; i2 < thetaK_; i2++) {
      for (int i1 = 1; i1 < rK_; i1++) {
        all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 - offsetOdd, i2*2, i3*2, 0)));
      }
    }
  }

  // allocate Phi^1, Psi^3, Psi^6
  for (int i3 = 1; i3 < phiK_; i3++) {
    if (i3 == 1) {
      // Psi^6
      for (int i1 = 0; i1 < rK_; i1++) {
        all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 + offset, 2, 2, 6)));
      }

      // Psi^3
      for (int i2 = 0; i2 < thetaK_; i2++)
        for (int i1 = 1; i1 < rK_; i1++) {
            all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 - offsetOdd, i2*2, 2, 3)));
        }
    }

    // Phi^1
    for (int i2 = 1; i2 < thetaK_; i2++)
      for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 - offsetOdd, i2*2, i3*2, 1)));
      }
  }

  // allocate Psi^4
  {
    for (int i1 = 0; i1 < rK_; i1++) {
      all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2 + offset, 0, 0, 4)));
    }
  }

  // Phi^7
  {
    for (int i2 = 1; i2 < thetaK_; i2++)
      for (int i1 = 1; i1 < rK_; i1++) {
          all_basis_.push_back(basisPtr3D(new     SphereBasis3D(i1*2, i2*2, 0, 7)));
      }
  }

  const int numBasisAll_ = all_basis_.size();

Timer timer;
timer.Reset();
  LOG(INFO) << numBasisAll_;

  sphere3DTensor tensorEval;

  #pragma omp parallel for
  for (int i = 0; i < numBasisAll_; i++) {
  	//LOG(INFO) << i;
    for (int g = 0; g < numBasisAll_; g++) {
      for (int h = 0; h < numBasisAll_; h++) {
        //
        const SphereBasis3D& basis_i = *all_basis_[i];
        const SphereBasis3D& basis_g = *all_basis_[g];
        const SphereBasis3D& basis_h = *all_basis_[h];
        const double invWnProd = basis_i.getInvWaveN()*basis_g.getInvWaveN()*basis_h.getInvWaveN();
        //double Cigh = SphereBasis3D::computeTensorEntry(basis_i, basis_g, basis_h);
				const int idx = basis_i.index()*64 + basis_g.index()*8 + basis_h.index();
        double Cnew = tensorEval.pointers_[idx](basis_i, basis_g, basis_h)*invWnProd;
        //CHECK(fabs(Cigh -  Cnew) < 1e-6) << Cigh << " " << Cnew << " " << i << " " << g << " " << h;
      }
    }
  }
  LOG(INFO) << timer.ElapsedTimeInSeconds();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
	
	test();

  return 0;
}