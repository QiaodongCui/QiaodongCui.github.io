#include <omp.h>
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>

#include "integrator_2d.h"
#include "solver/bi_cg_s_solver.h"
#include "util/timer.h"


void BiCGSSolver::IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) {
  Timer timer;
  const int num_basis = coefficients_old.size();
  // Allocate the contracted tensor. Generally, it should be dense.
  Eigen::MatrixXd w_C(num_basis, num_basis);
  w_C.setIdentity();
  Eigen::VectorXd w(num_basis);
  w.setZero();
  w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);
  timer.Reset();
#pragma omp parallel for
  for (int i = 0; i < num_basis; i++) {
    w_C.row(i) -= w.transpose() * Adv_tensor[i] * dt; 
  }
  // LOG(INFO) << "contraction time: " << timer.ElapsedTimeInSeconds();
  *contraction_time = timer.ElapsedTimeInSeconds();
  
  timer.Reset();
  Eigen::BiCGSTAB<Eigen::MatrixXd> solver;
  solver.setTolerance(1e-10);
  solver.compute(w_C);
  (*coefficients_new) = solver.solve(w);
  // LOG(INFO) << "solver time: " << timer.ElapsedTimeInSeconds();
  *solver_time = timer.ElapsedTimeInSeconds();
  
  // LOG(INFO) << "#iterations: " << solver.iterations();
  // LOG(INFO) << "estimated error: " << solver.error();
  // Estimate the condition number.
  /*Eigen::JacobiSVD<Eigen::MatrixXd> svd(w_C);
  const double max_eigen = svd.singularValues()(0);
  const double min_eigen = svd.singularValues()(svd.singularValues().size() - 1);
  (*condition_number_) = max_eigen / min_eigen;
  LOG(INFO) << "Maximum eigen value: " << max_eigen;
  LOG(INFO) << "Minimum eigen value: " << min_eigen;*/
}
