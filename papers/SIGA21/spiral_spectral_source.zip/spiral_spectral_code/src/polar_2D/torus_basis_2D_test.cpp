#include "polar_2D/torus_basis_2D.h"
#include "sphere_3D/sphere_basis_3D.h"

std::vector<std::vector<int>> testWnTwo = {{2, 2}, {2, 4}, {2, 6}, {2, 8}, {2, 10}, {4, 2}, {4, 4}, {4, 6}, {4, 
  8}, {4, 10}, {6, 2}, {6, 4}, {6, 6}, {6, 8}, {6, 10}, {8, 2}, {8, 
  4}, {8, 6}, {8, 8}, {8, 10}, {10, 2}, {10, 4}, {10, 6}, {10, 
  8}, {10, 10}};

namespace {

void testInner() {
  const double a = 3.0;

  std::vector<double> val1 = {122.136, 52.7407, 39.8897, 35.3918, 33.3099, 355.306, 111.033, \
65.7974, 49.9649, 42.6367, 743.921, 208.187, 108.977, 74.2534, \
58.1813, 1287.98, 344.202, 169.428, 108.257, 79.9438, 1987.49, \
519.08, 247.151, 151.976, 107.924};

std::vector<double> val2 = {59.2176, 59.2176, 59.2176, 59.2176, 59.2176, 59.2176, 59.2176, \
59.2176, 59.2176, 59.2176, 59.2176, 59.2176, 59.2176, 59.2176, \
59.2176, 59.2176, 59.2176, 59.2176, 59.2176, 59.2176, 59.2176, \
59.2176, 59.2176, 59.2176, 59.2176};

std::vector<double> val3 = {17.58023283944042,8.096159860268614,6.339850049310872,5.725141615475662,5.4406194261005085,0.,0.,0.,0.,0.,
   0.3084251375340302,0.07710628438350756,0.03426945972600336,0.01927657109587689,0.012337005501361208,
   -1.1161179193627622e-14,-2.7902947984069054e-15,-1.2401310215141802e-15,-6.975736996017264e-16,
   -4.464471677451049e-16,-2.2322358387255243e-14,-5.580589596813811e-15,-2.4802620430283603e-15,
   -1.3951473992034527e-15,-8.928943354902098e-16};
std::vector<double> val4 = {9.8696, 9.8696, 9.8696, 9.8696, 9.8696, 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};

  for (int i = 0; i < testWnTwo.size(); i++) {
    TorusBasis2D basis0(testWnTwo[i][0]/2, testWnTwo[i][1], 0, a);
    TorusBasis2D basis1(testWnTwo[i][0]/2, testWnTwo[i][1], 1, a);
    TorusBasis2D basis2(testWnTwo[i][0]/2, testWnTwo[i][1], 2, a);
    TorusBasis2D basis3(testWnTwo[i][0]/2, testWnTwo[i][1], 3, a);
    TorusBasis2D basis4(testWnTwo[i][0]/2, 0, 4, a);
    TorusBasis2D basis5(testWnTwo[i][0]/2, 0, 5, a);

    CHECK(fabs((basis0.dotProd(basis0) - val1[i])/val1[i]) < 1e-5) << basis0.dotProd(basis0) << " " << val1[i];
    CHECK(fabs((basis1.dotProd(basis1) - val1[i])/val1[i]) < 1e-5);
    CHECK(fabs((basis3.dotProd(basis3) - val1[i])/val1[i]) < 1e-5);
    CHECK(fabs((basis2.dotProd(basis2) - val1[i])/val1[i]) < 1e-5) << basis2.dotProd(basis2) << " " << val1[i];
    CHECK(fabs((basis4.dotProd(basis4) - val2[i])/val2[i]) < 1e-5) << basis4.dotProd(basis4) << " " << val2[i];
    CHECK(fabs((basis5.dotProd(basis5) - val2[i])/val2[i]) < 1e-5);

    CHECK(fabs(basis0.dotProd(basis1)) < 1e-12);
    CHECK(fabs(basis0.dotProd(basis2)) < 1e-12);
    CHECK(fabs((basis0.dotProd(basis3) - val3[i])) < 1e-5);
    CHECK(fabs(basis0.dotProd(basis4)) < 1e-12);
    CHECK(fabs(basis0.dotProd(basis5)) < 1e-12);
    
    CHECK(fabs(basis1.dotProd(basis2) - val3[i]) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis3)) < 1e-12);
    CHECK(fabs(basis1.dotProd(basis4)) < 1e-12);
    CHECK(fabs(basis1.dotProd(basis5)) < 1e-12);

    CHECK(fabs(basis2.dotProd(basis3)) < 1e-12);
    CHECK(fabs(basis2.dotProd(basis4)) < 1e-12);
    CHECK(fabs(basis2.dotProd(basis5)) < 1e-12);

    CHECK(fabs(basis3.dotProd(basis4)) < 1e-12);
    CHECK(fabs(basis3.dotProd(basis5)) < 1e-12);

    CHECK(fabs(basis4.dotProd(basis5) -val4[i]) < 1e-5);
  }
}



};  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  testInner();
  return 0;
}