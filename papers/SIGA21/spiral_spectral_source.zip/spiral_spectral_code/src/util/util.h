#ifndef UTIL_H
#define UTIL_H

#include <cfloat>
#include <Eigen/Eigen>
#include <fstream>
#include <math.h>
#include <glog/logging.h>
#include <random>
#include <string.h>
#include <string>
#include <vector>

#include "Alg/VEC3.h"
#include "Alg/VEC2.h"
#include "setting.h"

// #define PI_CUBE M_PI*M_PI*M_PI
// #define PI_SQUARE M_PI*M_PI
const double PI_CUBE = 31.00627668029982;
const double PI_SQUARE = 9.86960440108936;
#define PI M_PI
#define PI2 9.86960440108936
#define PI3 31.00627668029982
#define PI4 97.4090910340024
#define PI5 306.0196847852814
#define PI6 961.389193575304
#define PI7 3020.293227776791
#define PI8 9488.53101607057

#define CLAMP(x, Vmin, Vmax)\
x = x < Vmin ? Vmin : x;\
x = x > Vmax ? Vmax : x;

float clamp(const float& in, float _min, float _max);

template <typename T> T inline getsgn(T in) {
  if (in < 0) return -1;
    else return 1; 
}

// Generate a randomized normalized std::vector (norm is 1).
void GetNormalizedRandomVector(const int size, Eigen::VectorXd* vect);

// sample on the surface of a unit sphere.
Eigen::Vector3d sampleOnSphere(std::default_random_engine &gen);
Eigen::Vector3f sampleOnSpheref(std::default_random_engine &gen);

template <typename T, typename VT>
void sampleSpherePatch(const int nSample, const T tmin, const T tmax, const T pmin, const T pmax, 
                       std::default_random_engine &gen, std::vector<VT>& samples);

void sampleRectangular(const int nSample, const double xMin, const double xMax, const double yMin, const double yMax,
                       std::default_random_engine &gen, std::vector<VEC2>& samples);

inline int LookUpBasisFast(const int i, const int basis_num_root_, const int mode) {
  // Look up X.
 if (mode == 0) {
   return i % basis_num_root_ + 1;
 }
 // Look up Y.
 else if (mode == 1) {
   return i / basis_num_root_ + 1;
 }
};

void axisAngFromAxixs(const Eigen::Vector3f& from, const Eigen::Vector3f& to, Eigen::Vector3f& axis, float& angle);

inline double ComputeBasisAtFast(const int x_pos, const int y_pos,
                                 const int band, const int mode, const int root_num_basis_, const double  delta_) {
    int i1 = LookUpBasisFast(band, root_num_basis_, 0);
    int i2 = LookUpBasisFast(band, root_num_basis_, 1);
#ifndef USE_ROOT_LAMBDA
  const double inv_lambda = -1.0 / (i1*i1 + i2*i2);
#else
  const double inv_lambda = -1.0 / sqrt(i1*i1 + i2*i2);
#endif
  // X component.
  if (mode == 0){
    return i2 * inv_lambda * sin((x_pos + 0.5)*i1*delta_) * cos((y_pos + 0.5)*i2*delta_);
  } else {
    return -i1 * inv_lambda * cos((x_pos + 0.5)*i1*delta_) * sin((y_pos + 0.5)*i2*delta_);
  }
};

inline double AccessMatrix(const Adv_Tensor_Type& C, const int i , const int j) {
  double result = 0.;
#ifndef Adv_Tensor_Sparse
  result = C(i,j);
#else
  result = C.coeff(i,j);
#endif
  return result;
}

inline void SetMatrixEntry(Adv_Tensor_Type* C, const int i, const int j,const double& val) {
#ifndef Adv_Tensor_Sparse
  (*C)(i,j) = val;
#else
  (*C).coeffRef(i,j) = val;
#endif
}

inline void IncrementMatrixEntry(Adv_Tensor_Type* C, const int i, const int j,const double& val) {
#ifndef Adv_Tensor_Sparse
  (*C)(i,j) += val;
#else
  (*C).coeffRef(i,j) += val;
#endif
}

inline bool WithinRangeINT(const int a, const int min, const int max) {
  if ( a>= min && a <=max ) {
    return true;
  } else {
    return false;
  }
}

template<class Matrix>
void writeEigenDense_binary(std::ofstream& out, const Matrix& matrix){
    // std::ofstream out(filename,ios::out | ios::binary | ios::trunc);
    typename Matrix::Index rows=matrix.rows(), cols=matrix.cols();
    out.write((char*) (&rows), sizeof(typename Matrix::Index));
    out.write((char*) (&cols), sizeof(typename Matrix::Index));
    out.write((char*) matrix.data(), rows*cols*sizeof(typename Matrix::Scalar) );
    // out.close();
}

template<class Matrix>
void readEigenDense_binary(std::ifstream& in, Matrix& matrix){
    // std::ifstream in(filename,ios::in | std::ios::binary);
    typename Matrix::Index rows=0, cols=0;
    in.read((char*) (&rows),sizeof(typename Matrix::Index));
    in.read((char*) (&cols),sizeof(typename Matrix::Index));
    matrix.resize(rows, cols);
    in.read( (char *) matrix.data() , rows*cols*sizeof(typename Matrix::Scalar) );
   // in.close();
}

template<class MAT>
void printMinMaxSparseMAT(const MAT& in){
  double minV = FLT_MAX;
  double maxV = -FLT_MAX;

  for (int k = 0; k < in.outerSize(); k++)
    for (typename MAT::InnerIterator it(in, k); it; ++it) {
      if (it.value() > maxV)
        maxV = it.value();
      if (it.value() < minV)
        minV = it.value();
    }

  LOG(INFO) << "maxV " << maxV << " minV " << minV; 
}

inline float GenerateUnifomRnd() {
  return std::rand() / static_cast<float>(RAND_MAX);
}

void CompareTensor(const std::vector<Adv_Tensor_Type>& tensor1, 
                   const std::vector<Adv_Tensor_Type>& tensor2);
bool PointInBox(const VEC3F& point, const VEC3F& box_center, const VEC3F& length_);
bool BoxIntersect(const VEC3F& center1_, const VEC3F& length1_, const VEC3& center2_, const VEC3F& length2_);

std::vector<std::string> splitStringDelim(std::string str, const char delim);
std::string getStrFromFile(const std::string& fname);

long getFileSize(const std::string& fname);

void dumpOddHarmonicSeries(const std::string& name, int K);
void readOddHarmonicSeries(const std::string& name, std::vector<double>& series);

double computeSpherePatchArea(const double& tmin, const double& tmax, const double& pmin, const double& pmax);

// rgb:[0-1]^3, hsv: [0, 1]^3
Eigen::Vector3f hsv2rgb(const Eigen::Vector3f& hsv);

void denseMatrixToSparse(const Eigen::MatrixXd& in, Adv_Tensor_Type& out);
void copySparseMatrix(const Eigen::SparseMatrix<double, Eigen::RowMajor>& in, Eigen::SparseMatrix<double, Eigen::RowMajor>& out);
void copySparseMatrix(const Eigen::SparseMatrix<double, Eigen::ColMajor>& in, Eigen::SparseMatrix<double, Eigen::ColMajor>& out);

template<class MAT>
void outputSparseMATCOO(const MAT& in, std::ofstream& out){

  int nnz = in.nonZeros();
  out.write(reinterpret_cast<const char*>(&nnz), sizeof(int));
  int rows = in.rows();
  out.write(reinterpret_cast<const char*>(&rows), sizeof(int));
  int cols = in.cols();
  out.write(reinterpret_cast<const char*>(&cols), sizeof(int));
  
  // dump row indices
  for (int k = 0; k < in.outerSize(); k++)
    for (typename MAT::InnerIterator it(in, k); it; ++it) {
      int row = it.row();
      out.write(reinterpret_cast<const char*>(&row), sizeof(int));
    }

  // dump col indices
  for (int k = 0; k < in.outerSize(); k++)
    for (typename MAT::InnerIterator it(in, k); it; ++it) {
      int col = it.col();
      out.write(reinterpret_cast<const char*>(&col), sizeof(int));
    }

  // dump value
  for (int k = 0; k < in.outerSize(); k++)
    for (typename MAT::InnerIterator it(in, k); it; ++it) {
      double v = it.value();
      out.write(reinterpret_cast<const char*>(&v), sizeof(double));
    } 
}


#endif  // UTIL_H
