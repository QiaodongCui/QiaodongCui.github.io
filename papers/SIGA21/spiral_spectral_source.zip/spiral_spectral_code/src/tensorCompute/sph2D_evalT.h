#ifndef SPH2D_EVAL_T_H
#define SPH2D_EVAL_T_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define SinTPi TrigInt::IntegrateSinPi_D2
#define CosTPi TrigInt::IntegrateCosPi_D2
#define Pi M_PI


class sph2DtEval{
public:
sph2DtEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~sph2DtEval(){};
/* Sin[2*t]Sin[2*t]Sin[g1*t]Sin[h1*t]Sin[i1*t]Cos[2*t]*/
static double evalT_0(const int i1x2, const int g1x2, const int h1x2){
return SinTPi(2-g1x2-h1x2-i1x2)/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.-SinTPi(2+g1x2-h1x2-i1x2)/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.-SinTPi(2-g1x2+h1x2-i1x2)/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.+SinTPi(2+g1x2+h1x2-i1x2)/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.-SinTPi(2-g1x2-h1x2+i1x2)/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.+SinTPi(2+g1x2-h1x2+i1x2)/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.+SinTPi(2-g1x2+h1x2+i1x2)/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.-SinTPi(2+g1x2+h1x2+i1x2)/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[2*t]*/
static double evalT_1(const int i1x2, const int g1x2, const int h1x2){
return (3*SinTPi(2-g1x2-h1x2-i1x2))/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.-(3*SinTPi(2+g1x2-h1x2-i1x2))/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.-(3*SinTPi(2-g1x2+h1x2-i1x2))/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.+(3*SinTPi(2+g1x2+h1x2-i1x2))/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.-(3*SinTPi(2-g1x2-h1x2+i1x2))/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.+(3*SinTPi(2+g1x2-h1x2+i1x2))/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.+(3*SinTPi(2-g1x2+h1x2+i1x2))/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.-(3*SinTPi(2+g1x2+h1x2+i1x2))/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[g1*t]Sin[h1*t]Cos[2*t]Cos[2*t]Cos[i1*t]*/
static double evalT_2(const int i1x2, const int g1x2, const int h1x2){
return -SinTPi(2-g1x2-h1x2-i1x2)/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.+SinTPi(2+g1x2-h1x2-i1x2)/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.+SinTPi(2-g1x2+h1x2-i1x2)/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.-SinTPi(2+g1x2+h1x2-i1x2)/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.-SinTPi(2-g1x2-h1x2+i1x2)/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.+SinTPi(2+g1x2-h1x2+i1x2)/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.+SinTPi(2-g1x2+h1x2+i1x2)/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.-SinTPi(2+g1x2+h1x2+i1x2)/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[h1*t]Cos[2*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_3(const int i1x2, const int g1x2, const int h1x2){
return -SinTPi(2-g1x2-h1x2-i1x2)/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.-SinTPi(2+g1x2-h1x2-i1x2)/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.+SinTPi(2-g1x2+h1x2-i1x2)/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.+SinTPi(2+g1x2+h1x2-i1x2)/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.-SinTPi(2-g1x2-h1x2+i1x2)/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.-SinTPi(2+g1x2-h1x2+i1x2)/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.+SinTPi(2-g1x2+h1x2+i1x2)/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.+SinTPi(2+g1x2+h1x2+i1x2)/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[h1*t]Sin[i1*t]Cos[g1*t]*/
static double evalT_4(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(2-g1x2-h1x2-i1x2)-SinTPi(2+g1x2-h1x2-i1x2)+SinTPi(2-g1x2+h1x2-i1x2)+SinTPi(2+g1x2+h1x2-i1x2)+SinTPi(2-g1x2-h1x2+i1x2)+SinTPi(2+g1x2-h1x2+i1x2)-SinTPi(2-g1x2+h1x2+i1x2)-SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[g1*t]*/
static double evalT_5(const int i1x2, const int g1x2, const int h1x2){
return -SinTPi(2-g1x2-h1x2-i1x2)/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.-SinTPi(2+g1x2-h1x2-i1x2)/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.+SinTPi(2-g1x2+h1x2-i1x2)/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.+SinTPi(2+g1x2+h1x2-i1x2)/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.+SinTPi(2-g1x2-h1x2+i1x2)/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.+SinTPi(2+g1x2-h1x2+i1x2)/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.-SinTPi(2-g1x2+h1x2+i1x2)/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.-SinTPi(2+g1x2+h1x2+i1x2)/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h1*t]Sin[i1*t]Cos[g1*t]*/
static double evalT_6(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinTPi(2-g1x2-h1x2-i1x2))/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.-(3*SinTPi(2+g1x2-h1x2-i1x2))/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.+(3*SinTPi(2-g1x2+h1x2-i1x2))/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.+(3*SinTPi(2+g1x2+h1x2-i1x2))/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.+(3*SinTPi(2-g1x2-h1x2+i1x2))/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.+(3*SinTPi(2+g1x2-h1x2+i1x2))/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.-(3*SinTPi(2-g1x2+h1x2+i1x2))/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.-(3*SinTPi(2+g1x2+h1x2+i1x2))/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Sin[h1*t]Sin[i1*t]Cos[2*t]*/
static double evalT_7(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(2-g1x2-h1x2-i1x2)-SinTPi(2+g1x2-h1x2-i1x2)-SinTPi(2-g1x2+h1x2-i1x2)+SinTPi(2+g1x2+h1x2-i1x2)-SinTPi(2-g1x2-h1x2+i1x2)+SinTPi(2+g1x2-h1x2+i1x2)+SinTPi(2-g1x2+h1x2+i1x2)-SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Cos[2*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_8(const int i1x2, const int g1x2, const int h1x2){
return -SinTPi(2-g1x2-h1x2-i1x2)/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.+SinTPi(2+g1x2-h1x2-i1x2)/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.-SinTPi(2-g1x2+h1x2-i1x2)/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.+SinTPi(2+g1x2+h1x2-i1x2)/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.-SinTPi(2-g1x2-h1x2+i1x2)/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.+SinTPi(2+g1x2-h1x2+i1x2)/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.-SinTPi(2-g1x2+h1x2+i1x2)/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.+SinTPi(2+g1x2+h1x2+i1x2)/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[g1*t]Sin[i1*t]Cos[h1*t]*/
static double evalT_9(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(2-g1x2-h1x2-i1x2)+SinTPi(2+g1x2-h1x2-i1x2)-SinTPi(2-g1x2+h1x2-i1x2)+SinTPi(2+g1x2+h1x2-i1x2)+SinTPi(2-g1x2-h1x2+i1x2)-SinTPi(2+g1x2-h1x2+i1x2)+SinTPi(2-g1x2+h1x2+i1x2)-SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[g1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[h1*t]*/
static double evalT_10(const int i1x2, const int g1x2, const int h1x2){
return -SinTPi(2-g1x2-h1x2-i1x2)/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.+SinTPi(2+g1x2-h1x2-i1x2)/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.-SinTPi(2-g1x2+h1x2-i1x2)/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.+SinTPi(2+g1x2+h1x2-i1x2)/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.+SinTPi(2-g1x2-h1x2+i1x2)/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.-SinTPi(2+g1x2-h1x2+i1x2)/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.+SinTPi(2-g1x2+h1x2+i1x2)/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.-SinTPi(2+g1x2+h1x2+i1x2)/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g1*t]Sin[i1*t]Cos[h1*t]*/
static double evalT_11(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinTPi(2-g1x2-h1x2-i1x2))/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.+(3*SinTPi(2+g1x2-h1x2-i1x2))/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.-(3*SinTPi(2-g1x2+h1x2-i1x2))/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.+(3*SinTPi(2+g1x2+h1x2-i1x2))/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.+(3*SinTPi(2-g1x2-h1x2+i1x2))/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.-(3*SinTPi(2+g1x2-h1x2+i1x2))/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.+(3*SinTPi(2-g1x2+h1x2+i1x2))/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.-(3*SinTPi(2+g1x2+h1x2+i1x2))/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Sin[h1*t]Sin[i1*t]*/
static double evalT_12(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)-2*SinTPi(g1x2-h1x2-i1x2)+SinTPi(4+g1x2-h1x2-i1x2)+SinTPi(4-g1x2+h1x2-i1x2)+2*SinTPi(g1x2+h1x2-i1x2)-SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)+2*SinTPi(g1x2-h1x2+i1x2)-SinTPi(4+g1x2-h1x2+i1x2)-SinTPi(4-g1x2+h1x2+i1x2)-2*SinTPi(g1x2+h1x2+i1x2)+SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[g1*t]Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[2*t]*/
static double evalT_13(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(4-g1x2-h1x2-i1x2)-2*SinTPi(g1x2-h1x2-i1x2)-SinTPi(4+g1x2-h1x2-i1x2)-SinTPi(4-g1x2+h1x2-i1x2)+2*SinTPi(g1x2+h1x2-i1x2)+SinTPi(4+g1x2+h1x2-i1x2)-SinTPi(4-g1x2-h1x2+i1x2)+2*SinTPi(g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)-2*SinTPi(g1x2+h1x2+i1x2)-SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[g1*t]Sin[h1*t]Cos[2*t]Cos[i1*t]*/
static double evalT_14(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)+SinTPi(4+g1x2-h1x2-i1x2)+SinTPi(4-g1x2+h1x2-i1x2)-SinTPi(4+g1x2+h1x2-i1x2)-SinTPi(4-g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)-SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[g1*t]Sin[h1*t]Sin[i1*t]*/
static double evalT_15(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(g1x2-h1x2-i1x2)+SinTPi(g1x2+h1x2-i1x2)+SinTPi(g1x2-h1x2+i1x2)-SinTPi(g1x2+h1x2+i1x2))/4.;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Sin[h1*t]Cos[2*t]Cos[i1*t]*/
static double evalT_16(const int i1x2, const int g1x2, const int h1x2){
return -CosTPi(2-g1x2-h1x2-i1x2)/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.+CosTPi(2+g1x2-h1x2-i1x2)/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.+CosTPi(2-g1x2+h1x2-i1x2)/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.-CosTPi(2+g1x2+h1x2-i1x2)/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.-CosTPi(2-g1x2-h1x2+i1x2)/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.+CosTPi(2+g1x2-h1x2+i1x2)/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.+CosTPi(2-g1x2+h1x2+i1x2)/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.-CosTPi(2+g1x2+h1x2+i1x2)/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[g1*t]Cos[2*t]Cos[2*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_17(const int i1x2, const int g1x2, const int h1x2){
return CosTPi(2-g1x2-h1x2-i1x2)/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.-CosTPi(2+g1x2-h1x2-i1x2)/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.+CosTPi(2-g1x2+h1x2-i1x2)/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.-CosTPi(2+g1x2+h1x2-i1x2)/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.+CosTPi(2-g1x2-h1x2+i1x2)/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.-CosTPi(2+g1x2-h1x2+i1x2)/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.+CosTPi(2-g1x2+h1x2+i1x2)/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.-CosTPi(2+g1x2+h1x2+i1x2)/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g1*t]Sin[h1*t]Sin[i1*t]*/
static double evalT_18(const int i1x2, const int g1x2, const int h1x2){
return (-3*CosTPi(2-g1x2-h1x2-i1x2))/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.+(3*CosTPi(2+g1x2-h1x2-i1x2))/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.+(3*CosTPi(2-g1x2+h1x2-i1x2))/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.-(3*CosTPi(2+g1x2+h1x2-i1x2))/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.+(3*CosTPi(2-g1x2-h1x2+i1x2))/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.-(3*CosTPi(2+g1x2-h1x2+i1x2))/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.-(3*CosTPi(2-g1x2+h1x2+i1x2))/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.+(3*CosTPi(2+g1x2+h1x2+i1x2))/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Sin[i1*t]Cos[2*t]Cos[h1*t]*/
static double evalT_19(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(2-g1x2-h1x2-i1x2)+CosTPi(2+g1x2-h1x2-i1x2)-CosTPi(2-g1x2+h1x2-i1x2)+CosTPi(2+g1x2+h1x2-i1x2)+CosTPi(2-g1x2-h1x2+i1x2)-CosTPi(2+g1x2-h1x2+i1x2)+CosTPi(2-g1x2+h1x2+i1x2)-CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Sin[i1*t]Cos[2*t]Cos[h1*t]*/
static double evalT_20(const int i1x2, const int g1x2, const int h1x2){
return -CosTPi(2-g1x2-h1x2-i1x2)/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.+CosTPi(2+g1x2-h1x2-i1x2)/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.-CosTPi(2-g1x2+h1x2-i1x2)/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.+CosTPi(2+g1x2+h1x2-i1x2)/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.+CosTPi(2-g1x2-h1x2+i1x2)/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.-CosTPi(2+g1x2-h1x2+i1x2)/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.+CosTPi(2-g1x2+h1x2+i1x2)/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.-CosTPi(2+g1x2+h1x2+i1x2)/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[g1*t]Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[2*t]*/
static double evalT_21(const int i1x2, const int g1x2, const int h1x2){
return -CosTPi(2-g1x2-h1x2-i1x2)/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.+CosTPi(2+g1x2-h1x2-i1x2)/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.+CosTPi(2-g1x2+h1x2-i1x2)/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.-CosTPi(2+g1x2+h1x2-i1x2)/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.+CosTPi(2-g1x2-h1x2+i1x2)/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.-CosTPi(2+g1x2-h1x2+i1x2)/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.-CosTPi(2-g1x2+h1x2+i1x2)/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.+CosTPi(2+g1x2+h1x2+i1x2)/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h1*t]*/
static double evalT_22(const int i1x2, const int g1x2, const int h1x2){
return (-3*CosTPi(2-g1x2-h1x2-i1x2))/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.+(3*CosTPi(2+g1x2-h1x2-i1x2))/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.-(3*CosTPi(2-g1x2+h1x2-i1x2))/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.+(3*CosTPi(2+g1x2+h1x2-i1x2))/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.+(3*CosTPi(2-g1x2-h1x2+i1x2))/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.-(3*CosTPi(2+g1x2-h1x2+i1x2))/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.+(3*CosTPi(2-g1x2+h1x2+i1x2))/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.-(3*CosTPi(2+g1x2+h1x2+i1x2))/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[g1*t]Sin[h1*t]Sin[i1*t]*/
static double evalT_23(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(2-g1x2-h1x2-i1x2)+CosTPi(2+g1x2-h1x2-i1x2)+CosTPi(2-g1x2+h1x2-i1x2)-CosTPi(2+g1x2+h1x2-i1x2)+CosTPi(2-g1x2-h1x2+i1x2)-CosTPi(2+g1x2-h1x2+i1x2)-CosTPi(2-g1x2+h1x2+i1x2)+CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_24(const int i1x2, const int g1x2, const int h1x2){
return CosTPi(2-g1x2-h1x2-i1x2)/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.+CosTPi(2+g1x2-h1x2-i1x2)/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.+CosTPi(2-g1x2+h1x2-i1x2)/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.+CosTPi(2+g1x2+h1x2-i1x2)/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.+CosTPi(2-g1x2-h1x2+i1x2)/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.+CosTPi(2+g1x2-h1x2+i1x2)/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.+CosTPi(2-g1x2+h1x2+i1x2)/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.+CosTPi(2+g1x2+h1x2+i1x2)/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_25(const int i1x2, const int g1x2, const int h1x2){
return CosTPi(2-g1x2-h1x2-i1x2)/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.+CosTPi(2+g1x2-h1x2-i1x2)/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.+CosTPi(2-g1x2+h1x2-i1x2)/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.+CosTPi(2+g1x2+h1x2-i1x2)/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.-CosTPi(2-g1x2-h1x2+i1x2)/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.-CosTPi(2+g1x2-h1x2+i1x2)/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.-CosTPi(2-g1x2+h1x2+i1x2)/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.-CosTPi(2+g1x2+h1x2+i1x2)/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[i1*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_26(const int i1x2, const int g1x2, const int h1x2){
return (3*CosTPi(2-g1x2-h1x2-i1x2))/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.+(3*CosTPi(2+g1x2-h1x2-i1x2))/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.+(3*CosTPi(2-g1x2+h1x2-i1x2))/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.+(3*CosTPi(2+g1x2+h1x2-i1x2))/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.-(3*CosTPi(2-g1x2-h1x2+i1x2))/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.-(3*CosTPi(2+g1x2-h1x2+i1x2))/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.-(3*CosTPi(2-g1x2+h1x2+i1x2))/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.-(3*CosTPi(2+g1x2+h1x2+i1x2))/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[i1*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_27(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(2-g1x2-h1x2-i1x2)+CosTPi(2+g1x2-h1x2-i1x2)+CosTPi(2-g1x2+h1x2-i1x2)+CosTPi(2+g1x2+h1x2-i1x2)-CosTPi(2-g1x2-h1x2+i1x2)-CosTPi(2+g1x2-h1x2+i1x2)-CosTPi(2-g1x2+h1x2+i1x2)-CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* 1*/
static double evalT_28(const int i1x2, const int g1x2, const int h1x2){
return Pi;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Sin[i1*t]Cos[h1*t]*/
static double evalT_29(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(4-g1x2-h1x2-i1x2)+2*CosTPi(g1x2-h1x2-i1x2)-CosTPi(4+g1x2-h1x2-i1x2)+CosTPi(4-g1x2+h1x2-i1x2)+2*CosTPi(g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)-CosTPi(4-g1x2-h1x2+i1x2)-2*CosTPi(g1x2-h1x2+i1x2)+CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)-2*CosTPi(g1x2+h1x2+i1x2)+CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[g1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[h1*t]*/
static double evalT_30(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(4-g1x2-h1x2-i1x2)+2*CosTPi(g1x2-h1x2-i1x2)+CosTPi(4+g1x2-h1x2-i1x2)-CosTPi(4-g1x2+h1x2-i1x2)+2*CosTPi(g1x2+h1x2-i1x2)+CosTPi(4+g1x2+h1x2-i1x2)+CosTPi(4-g1x2-h1x2+i1x2)-2*CosTPi(g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)+CosTPi(4-g1x2+h1x2+i1x2)-2*CosTPi(g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[g1*t]Cos[2*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_31(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(4-g1x2-h1x2-i1x2)-CosTPi(4+g1x2-h1x2-i1x2)+CosTPi(4-g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)+CosTPi(4-g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)+CosTPi(4-g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[g1*t]Sin[i1*t]Cos[h1*t]*/
static double evalT_32(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(g1x2-h1x2-i1x2)+CosTPi(g1x2+h1x2-i1x2)-CosTPi(g1x2-h1x2+i1x2)-CosTPi(g1x2+h1x2+i1x2))/4.;
};

/* Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g1*t]*/
static double evalT_33(const int i1x2, const int g1x2, const int h1x2){
return (-3*CosTPi(2-g1x2-h1x2-i1x2))/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.-(3*CosTPi(2+g1x2-h1x2-i1x2))/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.+(3*CosTPi(2-g1x2+h1x2-i1x2))/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.+(3*CosTPi(2+g1x2+h1x2-i1x2))/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.+(3*CosTPi(2-g1x2-h1x2+i1x2))/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.+(3*CosTPi(2+g1x2-h1x2+i1x2))/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.-(3*CosTPi(2-g1x2+h1x2+i1x2))/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.-(3*CosTPi(2+g1x2+h1x2+i1x2))/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[g1*t]*/
static double evalT_34(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(2-g1x2-h1x2-i1x2)-CosTPi(2+g1x2-h1x2-i1x2)+CosTPi(2-g1x2+h1x2-i1x2)+CosTPi(2+g1x2+h1x2-i1x2)+CosTPi(2-g1x2-h1x2+i1x2)+CosTPi(2+g1x2-h1x2+i1x2)-CosTPi(2-g1x2+h1x2+i1x2)-CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[g1*t]*/
static double evalT_35(const int i1x2, const int g1x2, const int h1x2){
return -CosTPi(2-g1x2-h1x2-i1x2)/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.-CosTPi(2+g1x2-h1x2-i1x2)/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.+CosTPi(2-g1x2+h1x2-i1x2)/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.+CosTPi(2+g1x2+h1x2-i1x2)/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.+CosTPi(2-g1x2-h1x2+i1x2)/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.+CosTPi(2+g1x2-h1x2+i1x2)/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.-CosTPi(2-g1x2+h1x2+i1x2)/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.-CosTPi(2+g1x2+h1x2+i1x2)/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[h1*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_36(const int i1x2, const int g1x2, const int h1x2){
return CosTPi(2-g1x2-h1x2-i1x2)/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.+CosTPi(2+g1x2-h1x2-i1x2)/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.-CosTPi(2-g1x2+h1x2-i1x2)/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.-CosTPi(2+g1x2+h1x2-i1x2)/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.+CosTPi(2-g1x2-h1x2+i1x2)/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.+CosTPi(2+g1x2-h1x2+i1x2)/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.-CosTPi(2-g1x2+h1x2+i1x2)/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.-CosTPi(2+g1x2+h1x2+i1x2)/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[2*t]Cos[g1*t]*/
static double evalT_37(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(4-g1x2-h1x2-i1x2)-2*CosTPi(g1x2-h1x2-i1x2)-CosTPi(4+g1x2-h1x2-i1x2)+CosTPi(4-g1x2+h1x2-i1x2)+2*CosTPi(g1x2+h1x2-i1x2)+CosTPi(4+g1x2+h1x2-i1x2)+CosTPi(4-g1x2-h1x2+i1x2)+2*CosTPi(g1x2-h1x2+i1x2)+CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)-2*CosTPi(g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[h1*t]Cos[2*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_38(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(4-g1x2-h1x2-i1x2)+CosTPi(4+g1x2-h1x2-i1x2)-CosTPi(4-g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)+CosTPi(4-g1x2-h1x2+i1x2)+CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h1*t]Sin[i1*t]Cos[g1*t]*/
static double evalT_39(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(4-g1x2-h1x2-i1x2)-2*CosTPi(g1x2-h1x2-i1x2)+CosTPi(4+g1x2-h1x2-i1x2)-CosTPi(4-g1x2+h1x2-i1x2)+2*CosTPi(g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)-CosTPi(4-g1x2-h1x2+i1x2)+2*CosTPi(g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)+CosTPi(4-g1x2+h1x2+i1x2)-2*CosTPi(g1x2+h1x2+i1x2)+CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[h1*t]Sin[i1*t]Cos[g1*t]*/
static double evalT_40(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(g1x2-h1x2-i1x2)+CosTPi(g1x2+h1x2-i1x2)+CosTPi(g1x2-h1x2+i1x2)-CosTPi(g1x2+h1x2+i1x2))/4.;
};

/* Sin[i1*t]Cos[2*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_41(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(2-g1x2-h1x2-i1x2)-SinTPi(2+g1x2-h1x2-i1x2)-SinTPi(2-g1x2+h1x2-i1x2)-SinTPi(2+g1x2+h1x2-i1x2)+SinTPi(2-g1x2-h1x2+i1x2)+SinTPi(2+g1x2-h1x2+i1x2)+SinTPi(2-g1x2+h1x2+i1x2)+SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_42(const int i1x2, const int g1x2, const int h1x2){
return SinTPi(2-g1x2-h1x2-i1x2)/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.+SinTPi(2+g1x2-h1x2-i1x2)/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.+SinTPi(2-g1x2+h1x2-i1x2)/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.+SinTPi(2+g1x2+h1x2-i1x2)/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.+SinTPi(2-g1x2-h1x2+i1x2)/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.+SinTPi(2+g1x2-h1x2+i1x2)/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.+SinTPi(2-g1x2+h1x2+i1x2)/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.+SinTPi(2+g1x2+h1x2+i1x2)/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[i1*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_43(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinTPi(2-g1x2-h1x2-i1x2))/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.-(3*SinTPi(2+g1x2-h1x2-i1x2))/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.-(3*SinTPi(2-g1x2+h1x2-i1x2))/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.-(3*SinTPi(2+g1x2+h1x2-i1x2))/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.+(3*SinTPi(2-g1x2-h1x2+i1x2))/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.+(3*SinTPi(2+g1x2-h1x2+i1x2))/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.+(3*SinTPi(2-g1x2+h1x2+i1x2))/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.+(3*SinTPi(2+g1x2+h1x2+i1x2))/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[i1*t]Cos[2*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_44(const int i1x2, const int g1x2, const int h1x2){
return -SinTPi(2-g1x2-h1x2-i1x2)/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.-SinTPi(2+g1x2-h1x2-i1x2)/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.-SinTPi(2-g1x2+h1x2-i1x2)/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.-SinTPi(2+g1x2+h1x2-i1x2)/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.+SinTPi(2-g1x2-h1x2+i1x2)/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.+SinTPi(2+g1x2-h1x2+i1x2)/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.+SinTPi(2-g1x2+h1x2+i1x2)/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.+SinTPi(2+g1x2+h1x2+i1x2)/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[h1*t]Sin[i1*t]Cos[2*t]Cos[g1*t]*/
static double evalT_45(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)-SinTPi(4+g1x2-h1x2-i1x2)+SinTPi(4-g1x2+h1x2-i1x2)+SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)-SinTPi(4-g1x2+h1x2+i1x2)-SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[h1*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_46(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(4-g1x2-h1x2-i1x2)-2*SinTPi(g1x2-h1x2-i1x2)+SinTPi(4+g1x2-h1x2-i1x2)-SinTPi(4-g1x2+h1x2-i1x2)+2*SinTPi(g1x2+h1x2-i1x2)-SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)-2*SinTPi(g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)-SinTPi(4-g1x2+h1x2+i1x2)+2*SinTPi(g1x2+h1x2+i1x2)-SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[g1*t]Sin[i1*t]Cos[2*t]Cos[h1*t]*/
static double evalT_47(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)+SinTPi(4+g1x2-h1x2-i1x2)-SinTPi(4-g1x2+h1x2-i1x2)+SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)-SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)-SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_48(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(4-g1x2-h1x2-i1x2)+2*SinTPi(g1x2-h1x2-i1x2)-SinTPi(4+g1x2-h1x2-i1x2)+SinTPi(4-g1x2+h1x2-i1x2)+2*SinTPi(g1x2+h1x2-i1x2)-SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)+2*SinTPi(g1x2-h1x2+i1x2)-SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)+2*SinTPi(g1x2+h1x2+i1x2)-SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[g1*t]Sin[h1*t]Cos[i1*t]*/
static double evalT_49(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(2-g1x2-h1x2-i1x2)+SinTPi(2+g1x2-h1x2-i1x2)+SinTPi(2-g1x2+h1x2-i1x2)-SinTPi(2+g1x2+h1x2-i1x2)-SinTPi(2-g1x2-h1x2+i1x2)+SinTPi(2+g1x2-h1x2+i1x2)+SinTPi(2-g1x2+h1x2+i1x2)-SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[g1*t]Sin[h1*t]Sin[i1*t]Cos[2*t]*/
static double evalT_50(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(4-g1x2-h1x2-i1x2)+CosTPi(4+g1x2-h1x2-i1x2)+CosTPi(4-g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)+CosTPi(4-g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)+CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[2*t]Sin[g1*t]Sin[h1*t]Cos[i1*t]*/
static double evalT_51(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(4-g1x2-h1x2-i1x2)+2*CosTPi(g1x2-h1x2-i1x2)-CosTPi(4+g1x2-h1x2-i1x2)-CosTPi(4-g1x2+h1x2-i1x2)-2*CosTPi(g1x2+h1x2-i1x2)+CosTPi(4+g1x2+h1x2-i1x2)+CosTPi(4-g1x2-h1x2+i1x2)+2*CosTPi(g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)-2*CosTPi(g1x2+h1x2+i1x2)+CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[i1*t]Cos[2*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_52(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(4-g1x2-h1x2-i1x2)+CosTPi(4+g1x2-h1x2-i1x2)+CosTPi(4-g1x2+h1x2-i1x2)+CosTPi(4+g1x2+h1x2-i1x2)-CosTPi(4-g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_53(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(4-g1x2-h1x2-i1x2)+2*CosTPi(g1x2-h1x2-i1x2)-CosTPi(4+g1x2-h1x2-i1x2)-CosTPi(4-g1x2+h1x2-i1x2)+2*CosTPi(g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)-CosTPi(4-g1x2-h1x2+i1x2)+2*CosTPi(g1x2-h1x2+i1x2)-CosTPi(4+g1x2-h1x2+i1x2)-CosTPi(4-g1x2+h1x2+i1x2)+2*CosTPi(g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Sin[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_54(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(2-g1x2-h1x2-i1x2)-CosTPi(2+g1x2-h1x2-i1x2)+CosTPi(2-g1x2+h1x2-i1x2)-CosTPi(2+g1x2+h1x2-i1x2)+CosTPi(2-g1x2-h1x2+i1x2)-CosTPi(2+g1x2-h1x2+i1x2)+CosTPi(2-g1x2+h1x2+i1x2)-CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[h1*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_55(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(2-g1x2-h1x2-i1x2)+CosTPi(2+g1x2-h1x2-i1x2)-CosTPi(2-g1x2+h1x2-i1x2)-CosTPi(2+g1x2+h1x2-i1x2)+CosTPi(2-g1x2-h1x2+i1x2)+CosTPi(2+g1x2-h1x2+i1x2)-CosTPi(2-g1x2+h1x2+i1x2)-CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[i1*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]*/
static double evalT_56(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)-2*SinTPi(g1x2-h1x2-i1x2)-SinTPi(4+g1x2-h1x2-i1x2)-SinTPi(4-g1x2+h1x2-i1x2)-2*SinTPi(g1x2+h1x2-i1x2)-SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)+2*SinTPi(g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)+2*SinTPi(g1x2+h1x2+i1x2)+SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_57(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(4-g1x2-h1x2-i1x2)+SinTPi(4+g1x2-h1x2-i1x2)+SinTPi(4-g1x2+h1x2-i1x2)+SinTPi(4+g1x2+h1x2-i1x2)+SinTPi(4-g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)+SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[g1*t]Sin[h1*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[i1*t]*/
static double evalT_58(const int i1x2, const int g1x2, const int h1x2){
return (-3*CosTPi(2-g1x2-h1x2-i1x2))/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.+(3*CosTPi(2+g1x2-h1x2-i1x2))/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.+(3*CosTPi(2-g1x2+h1x2-i1x2))/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.-(3*CosTPi(2+g1x2+h1x2-i1x2))/32.-CosTPi(6+g1x2+h1x2-i1x2)/32.-(3*CosTPi(2-g1x2-h1x2+i1x2))/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.+(3*CosTPi(2+g1x2-h1x2+i1x2))/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.+(3*CosTPi(2-g1x2+h1x2+i1x2))/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.-(3*CosTPi(2+g1x2+h1x2+i1x2))/32.-CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[h1*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_59(const int i1x2, const int g1x2, const int h1x2){
return (3*CosTPi(2-g1x2-h1x2-i1x2))/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.+(3*CosTPi(2+g1x2-h1x2-i1x2))/32.-CosTPi(6+g1x2-h1x2-i1x2)/32.-(3*CosTPi(2-g1x2+h1x2-i1x2))/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.-(3*CosTPi(2+g1x2+h1x2-i1x2))/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.+(3*CosTPi(2-g1x2-h1x2+i1x2))/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.+(3*CosTPi(2+g1x2-h1x2+i1x2))/32.-CosTPi(6+g1x2-h1x2+i1x2)/32.-(3*CosTPi(2-g1x2+h1x2+i1x2))/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.-(3*CosTPi(2+g1x2+h1x2+i1x2))/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Sin[h1*t]Cos[2*t]Cos[i1*t]*/
static double evalT_60(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(2-g1x2-h1x2-i1x2)+CosTPi(2+g1x2-h1x2-i1x2)+CosTPi(2-g1x2+h1x2-i1x2)-CosTPi(2+g1x2+h1x2-i1x2)-CosTPi(2-g1x2-h1x2+i1x2)+CosTPi(2+g1x2-h1x2+i1x2)+CosTPi(2-g1x2+h1x2+i1x2)-CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_61(const int i1x2, const int g1x2, const int h1x2){
return (3*CosTPi(2-g1x2-h1x2-i1x2))/32.-CosTPi(6-g1x2-h1x2-i1x2)/32.-(3*CosTPi(2+g1x2-h1x2-i1x2))/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.+(3*CosTPi(2-g1x2+h1x2-i1x2))/32.-CosTPi(6-g1x2+h1x2-i1x2)/32.-(3*CosTPi(2+g1x2+h1x2-i1x2))/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.+(3*CosTPi(2-g1x2-h1x2+i1x2))/32.-CosTPi(6-g1x2-h1x2+i1x2)/32.-(3*CosTPi(2+g1x2-h1x2+i1x2))/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.+(3*CosTPi(2-g1x2+h1x2+i1x2))/32.-CosTPi(6-g1x2+h1x2+i1x2)/32.-(3*CosTPi(2+g1x2+h1x2+i1x2))/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Sin[h1*t]Cos[i1*t]*/
static double evalT_62(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(g1x2-h1x2-i1x2)-CosTPi(g1x2+h1x2-i1x2)+CosTPi(g1x2-h1x2+i1x2)-CosTPi(g1x2+h1x2+i1x2))/4.;
};

/* Sin[g1*t]Sin[h1*t]Cos[2*t]Cos[2*t]Cos[i1*t]*/
static double evalT_63(const int i1x2, const int g1x2, const int h1x2){
return (-CosTPi(4-g1x2-h1x2-i1x2)+2*CosTPi(g1x2-h1x2-i1x2)+CosTPi(4+g1x2-h1x2-i1x2)+CosTPi(4-g1x2+h1x2-i1x2)-2*CosTPi(g1x2+h1x2-i1x2)-CosTPi(4+g1x2+h1x2-i1x2)-CosTPi(4-g1x2-h1x2+i1x2)+2*CosTPi(g1x2-h1x2+i1x2)+CosTPi(4+g1x2-h1x2+i1x2)+CosTPi(4-g1x2+h1x2+i1x2)-2*CosTPi(g1x2+h1x2+i1x2)-CosTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[g1*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_64(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinTPi(2-g1x2-h1x2-i1x2))/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.+(3*SinTPi(2+g1x2-h1x2-i1x2))/32.+SinTPi(6+g1x2-h1x2-i1x2)/32.-(3*SinTPi(2-g1x2+h1x2-i1x2))/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.+(3*SinTPi(2+g1x2+h1x2-i1x2))/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.-(3*SinTPi(2-g1x2-h1x2+i1x2))/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.+(3*SinTPi(2+g1x2-h1x2+i1x2))/32.+SinTPi(6+g1x2-h1x2+i1x2)/32.-(3*SinTPi(2-g1x2+h1x2+i1x2))/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.+(3*SinTPi(2+g1x2+h1x2+i1x2))/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Cos[2*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_65(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(2-g1x2-h1x2-i1x2)+SinTPi(2+g1x2-h1x2-i1x2)-SinTPi(2-g1x2+h1x2-i1x2)+SinTPi(2+g1x2+h1x2-i1x2)-SinTPi(2-g1x2-h1x2+i1x2)+SinTPi(2+g1x2-h1x2+i1x2)-SinTPi(2-g1x2+h1x2+i1x2)+SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Sin[g1*t]Sin[h1*t]Cos[i1*t]*/
static double evalT_66(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinTPi(2-g1x2-h1x2-i1x2))/32.+SinTPi(6-g1x2-h1x2-i1x2)/32.+(3*SinTPi(2+g1x2-h1x2-i1x2))/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.+(3*SinTPi(2-g1x2+h1x2-i1x2))/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.-(3*SinTPi(2+g1x2+h1x2-i1x2))/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.-(3*SinTPi(2-g1x2-h1x2+i1x2))/32.+SinTPi(6-g1x2-h1x2+i1x2)/32.+(3*SinTPi(2+g1x2-h1x2+i1x2))/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.+(3*SinTPi(2-g1x2+h1x2+i1x2))/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.-(3*SinTPi(2+g1x2+h1x2+i1x2))/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_67(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(2-g1x2-h1x2-i1x2)+SinTPi(2+g1x2-h1x2-i1x2)+SinTPi(2-g1x2+h1x2-i1x2)+SinTPi(2+g1x2+h1x2-i1x2)+SinTPi(2-g1x2-h1x2+i1x2)+SinTPi(2+g1x2-h1x2+i1x2)+SinTPi(2-g1x2+h1x2+i1x2)+SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[2*t]Sin[2*t]Sin[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_68(const int i1x2, const int g1x2, const int h1x2){
return (3*SinTPi(2-g1x2-h1x2-i1x2))/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.+(3*SinTPi(2+g1x2-h1x2-i1x2))/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.+(3*SinTPi(2-g1x2+h1x2-i1x2))/32.-SinTPi(6-g1x2+h1x2-i1x2)/32.+(3*SinTPi(2+g1x2+h1x2-i1x2))/32.-SinTPi(6+g1x2+h1x2-i1x2)/32.+(3*SinTPi(2-g1x2-h1x2+i1x2))/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.+(3*SinTPi(2+g1x2-h1x2+i1x2))/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.+(3*SinTPi(2-g1x2+h1x2+i1x2))/32.-SinTPi(6-g1x2+h1x2+i1x2)/32.+(3*SinTPi(2+g1x2+h1x2+i1x2))/32.-SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_69(const int i1x2, const int g1x2, const int h1x2){
return (SinTPi(g1x2-h1x2-i1x2)+SinTPi(g1x2+h1x2-i1x2)+SinTPi(g1x2-h1x2+i1x2)+SinTPi(g1x2+h1x2+i1x2))/4.;
};

/* Sin[g1*t]Cos[2*t]Cos[2*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_70(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)+2*SinTPi(g1x2-h1x2-i1x2)+SinTPi(4+g1x2-h1x2-i1x2)-SinTPi(4-g1x2+h1x2-i1x2)+2*SinTPi(g1x2+h1x2-i1x2)+SinTPi(4+g1x2+h1x2-i1x2)-SinTPi(4-g1x2-h1x2+i1x2)+2*SinTPi(g1x2-h1x2+i1x2)+SinTPi(4+g1x2-h1x2+i1x2)-SinTPi(4-g1x2+h1x2+i1x2)+2*SinTPi(g1x2+h1x2+i1x2)+SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Sin[h1*t]Cos[2*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_71(const int i1x2, const int g1x2, const int h1x2){
return (-3*SinTPi(2-g1x2-h1x2-i1x2))/32.-SinTPi(6-g1x2-h1x2-i1x2)/32.-(3*SinTPi(2+g1x2-h1x2-i1x2))/32.-SinTPi(6+g1x2-h1x2-i1x2)/32.+(3*SinTPi(2-g1x2+h1x2-i1x2))/32.+SinTPi(6-g1x2+h1x2-i1x2)/32.+(3*SinTPi(2+g1x2+h1x2-i1x2))/32.+SinTPi(6+g1x2+h1x2-i1x2)/32.-(3*SinTPi(2-g1x2-h1x2+i1x2))/32.-SinTPi(6-g1x2-h1x2+i1x2)/32.-(3*SinTPi(2+g1x2-h1x2+i1x2))/32.-SinTPi(6+g1x2-h1x2+i1x2)/32.+(3*SinTPi(2-g1x2+h1x2+i1x2))/32.+SinTPi(6-g1x2+h1x2+i1x2)/32.+(3*SinTPi(2+g1x2+h1x2+i1x2))/32.+SinTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Sin[h1*t]Cos[2*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_72(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(2-g1x2-h1x2-i1x2)-SinTPi(2+g1x2-h1x2-i1x2)+SinTPi(2-g1x2+h1x2-i1x2)+SinTPi(2+g1x2+h1x2-i1x2)-SinTPi(2-g1x2-h1x2+i1x2)-SinTPi(2+g1x2-h1x2+i1x2)+SinTPi(2-g1x2+h1x2+i1x2)+SinTPi(2+g1x2+h1x2+i1x2))/8.;
};

/* Sin[h1*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_73(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(g1x2-h1x2-i1x2)+SinTPi(g1x2+h1x2-i1x2)-SinTPi(g1x2-h1x2+i1x2)+SinTPi(g1x2+h1x2+i1x2))/4.;
};

/* Sin[h1*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[i1*t]*/
static double evalT_74(const int i1x2, const int g1x2, const int h1x2){
return (-SinTPi(4-g1x2-h1x2-i1x2)-2*SinTPi(g1x2-h1x2-i1x2)-SinTPi(4+g1x2-h1x2-i1x2)+SinTPi(4-g1x2+h1x2-i1x2)+2*SinTPi(g1x2+h1x2-i1x2)+SinTPi(4+g1x2+h1x2-i1x2)-SinTPi(4-g1x2-h1x2+i1x2)-2*SinTPi(g1x2-h1x2+i1x2)-SinTPi(4+g1x2-h1x2+i1x2)+SinTPi(4-g1x2+h1x2+i1x2)+2*SinTPi(g1x2+h1x2+i1x2)+SinTPi(4+g1x2+h1x2+i1x2))/16.;
};

/* Cos[2*t]Cos[2*t]Cos[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_75(const int i1x2, const int g1x2, const int h1x2){
return (3*CosTPi(2-g1x2-h1x2-i1x2))/32.+CosTPi(6-g1x2-h1x2-i1x2)/32.+(3*CosTPi(2+g1x2-h1x2-i1x2))/32.+CosTPi(6+g1x2-h1x2-i1x2)/32.+(3*CosTPi(2-g1x2+h1x2-i1x2))/32.+CosTPi(6-g1x2+h1x2-i1x2)/32.+(3*CosTPi(2+g1x2+h1x2-i1x2))/32.+CosTPi(6+g1x2+h1x2-i1x2)/32.+(3*CosTPi(2-g1x2-h1x2+i1x2))/32.+CosTPi(6-g1x2-h1x2+i1x2)/32.+(3*CosTPi(2+g1x2-h1x2+i1x2))/32.+CosTPi(6+g1x2-h1x2+i1x2)/32.+(3*CosTPi(2-g1x2+h1x2+i1x2))/32.+CosTPi(6-g1x2+h1x2+i1x2)/32.+(3*CosTPi(2+g1x2+h1x2+i1x2))/32.+CosTPi(6+g1x2+h1x2+i1x2)/32.;
};

/* Cos[2*t]Cos[g1*t]Cos[h1*t]Cos[i1*t]*/
static double evalT_76(const int i1x2, const int g1x2, const int h1x2){
return (CosTPi(2-g1x2-h1x2-i1x2)+CosTPi(2+g1x2-h1x2-i1x2)+CosTPi(2-g1x2+h1x2-i1x2)+CosTPi(2+g1x2+h1x2-i1x2)+CosTPi(2-g1x2-h1x2+i1x2)+CosTPi(2+g1x2-h1x2+i1x2)+CosTPi(2-g1x2+h1x2+i1x2)+CosTPi(2+g1x2+h1x2+i1x2))/8.;
};

};

#endif // SPH2D_EVAL_T_H