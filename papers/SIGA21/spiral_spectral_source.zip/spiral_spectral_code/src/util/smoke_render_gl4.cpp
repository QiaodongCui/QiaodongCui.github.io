/* Rewrite from  https://graphics.ethz.ch/teaching/former/imagesynthesis_06/miniprojects/p3/index.html
 *Author: Johannes Schmid and Ingemar Rask, 2006, johnny@grob.org */
#include <glog/logging.h>
#include "util/smoke_render_gl4.h"

using namespace std;


Renderer3DGL4::Renderer3DGL4(const int xRes, const int yRes, const int zRes, const int ScaleRes):xRes_(xRes), yRes_(yRes),zRes_(zRes)
{
	_textureData = NULL;
	_isDrawSliceOutline = false;
	_isRendering = true;

	_SIZE = xRes_*yRes_*zRes_;
    Slabsize_ = xRes_*yRes_;
    MaxRes_ = ScaleRes;
    // Maximum edge length is 1.
    x_ = xRes_ / static_cast<float>(MaxRes_);
    y_ = yRes_ / static_cast<float>(MaxRes_);
    z_ = zRes_ / static_cast<float>(MaxRes_);
    xN_ = x_;
    yN_ = y_;
    zN_ = z_;
    invxN_ = 1.0 / xN_;
    invyN_ = 1.0 / yN_;
    invzN_ = 1.0 / zN_;
    
	// cube vertices
	GLfloat cv[][3] = {
		{x_, y_, z_}, {-x_, y_, z_}, {-x_, -y_, z_}, {x_, -y_, z_},
		{x_, y_, -z_}, {-x_, y_, -z_}, {-x_, -y_, -z_}, {x_, -y_, -z_}
	};

	// cube edges have the form edges[n][0][xyz] + t*edges[n][1][xyz]
	GLfloat ce[12][2][3] = {
		{{x_, y_, -z_}, {0.0f, 0.0f, z_}},
		{{-x_, y_, -z_}, {0.0f, 0.0f, z_}},
		{{-x_, -y_, -z_}, {0.0f, 0.0f, z_}},
		{{x_, -y_, -z_}, {0.0f, 0.0f, z_}},

		{{x_, -y_, z_}, {0.0f, y_, 0.0f}},
		{{-x_, -y_, z_}, {0.0f, y_, 0.0f}},
		{{-x_, -y_, -z_}, {0.0f, y_, 0.0f}},
		{{x_, -y_, -z_}, {0.0f, y_, 0.0f}},

		{{-x_, y_, z_}, {x_, 0.0f, 0.0f}},
		{{-x_, -y_, z_}, {x_, 0.0f, 0.0f}},
		{{-x_, -y_, -z_}, {x_, 0.0f, 0.0f}},
		{{-x_, y_, -z_}, {x_, 0.0f, 0.0f}}};

	memcpy(_cubeVertices, cv, sizeof(_cubeVertices) );
	memcpy(_cubeEdges, ce, sizeof(_cubeEdges) );

	InitGL();
}

Renderer3DGL4::~Renderer3DGL4()
{
	if (_textureData)
		free(_textureData);
}

void Renderer3DGL4::SetLightPostion(const Eigen::Vector3f &pos)
{
	_lightPos = pos;
	_lightDir = -_lightPos;

	GenerateRayTemplate();
}

void Renderer3DGL4::InitGL()
{
	glEnable(GL_TEXTURE_3D);
	glDisable(GL_DEPTH_TEST);
	glCullFace(GL_FRONT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glGenTextures(1, &_hTexture);
	glBindTexture(GL_TEXTURE_3D, _hTexture);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S,GL_CLAMP);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T,GL_CLAMP);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R,GL_CLAMP);
    
    if (_textureData == NULL) {
		_textureData = new unsigned char[_SIZE*4];
	}
	memset(_textureData, 0, _SIZE*4);

	glTexImage3D(GL_TEXTURE_3D, 0, GL_RGBA, xRes_, yRes_, zRes_, 0, GL_RGBA, GL_UNSIGNED_BYTE, _textureData);

	// 4 trigs each slice, each vert has a text coord.
	// [pos, text cord]
  bufSize = (int)(SLICE_NUM)*4*9*2;
  buf = (float*) malloc(sizeof(float)*bufSize);
  memset(buf, 0x00, sizeof(float)*bufSize);

  glGenVertexArrays(1, &VAO);
  glGenBuffers(1, &VBO);
  // bind the Vertex Array Object first, then bind and set vertex buffer(s), and then configure vertex attributes(s).
  glBindVertexArray(VAO);

  glBindBuffer(GL_ARRAY_BUFFER, VBO);
  glBufferData(GL_ARRAY_BUFFER, sizeof(float)*bufSize, buf, GL_STATIC_DRAW);

  // position attribute
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)0);
  glEnableVertexAttribArray(0);

  // 3d texture coord.
  glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)(3*sizeof(float)));
  glEnableVertexAttribArray(1);

}

void Renderer3DGL4::Render(const glm::mat4& modelView)
{
	//GLdouble mvMatrix[16];
	//glGetDoublev(GL_MODELVIEW_MATRIX, mvMatrix);
	glDisable(GL_DEPTH_TEST);	//Important in this rendering

	// DrawLight();
    glPushMatrix();
    glScalef(0.5,0.5,0.5);
    DrawSlices(modelView);
    glPopMatrix();
	glEnable(GL_DEPTH_TEST);
}

void Renderer3DGL4::DrawLight()
{
	
	glPushAttrib(GL_POINT_BIT | GL_CURRENT_BIT);	//save current state
	//draw light
	glPointSize(13.0f);
	glBegin(GL_POINTS);
	glColor4f(0.0f, 1.0f, 1.0f, 1.0f);
	glVertex3f(_lightPos[0], _lightPos[1], _lightPos[2]);
	glEnd();
	glPopAttrib();		//restore painting state
}

void Renderer3DGL4::SetRendering(bool isRendering)
{
	_isRendering = isRendering;
}

void Renderer3DGL4::SetSliceOutline(bool isDrawSliceOutline)
{
	_isDrawSliceOutline = isDrawSliceOutline;
}

class Convexcomp
{
	private:
		const Eigen::Vector3f &p0, &up;
	public:
		Convexcomp(const Eigen::Vector3f& p0, const Eigen::Vector3f& up) : p0(p0), up(up) {}

		bool operator()(const Eigen::Vector3f& a, const Eigen::Vector3f& b) const
		{
			Eigen::Vector3f va = a-p0, vb = b-p0;
			//return dot(up, cross(va, vb)) >= 0;
			return up.dot(va.cross(vb)) >= 0;
		}
};

void Renderer3DGL4::DrawSlices(const glm::mat4& modelView)
{
	int i;
	Eigen::Vector3f viewdir(-modelView[0][2], -modelView[1][2], -modelView[2][2]);	//FIXME
	//viewdir = -Eigen::Vector3f(1,1,1);
	viewdir.normalize();
	// find cube vertex that is closest to the viewer
	GLfloat (*cv)[3] = _cubeVertices;
	for (i=0; i<8; i++) {
		float x = cv[i][0] + viewdir[0];
		float y = cv[i][1] + viewdir[1];
		float z = cv[i][2] + viewdir[2];
		if ((x>=-x_) && (x<=x_) && (y>=-y_)&&(y<=y_) && (z>=-z_) && (z<=z_))
		{
			break;
		}
	}
	assert(i != 8);

	// our slices are defined by the plane equation A*x + B*y +C*z + D = 0
	// (a,b,c), the plane normal, are given by viewdir
	// d is the parameter along the view direction. the first d is given by
	// inserting previously found vertex into the plane equation
	float d0 = -(viewdir[0]*cv[i][0] + viewdir[1]*cv[i][1] + viewdir[2]*cv[i][2]);
	float dStep = 2*d0/SLICE_NUM;

	vector<vector<Eigen::Vector3f>> sliceVerts;
	vector<vector<Eigen::Vector3f>> textureCords;
	unsigned int maxPtSize = 0;

	for (float d = -d0; d < d0; d += dStep) {
		vector<Eigen::Vector3f> pt = IntersectEdges(viewdir[0], viewdir[1], viewdir[2], d);
		if (pt.size() > maxPtSize)
			maxPtSize = pt.size();
		
		if (pt.size() > 2) {
			// sort points to get a convex polygon
			std::sort(pt.begin()+1, pt.end(), Convexcomp(pt[0], viewdir));
			sliceVerts.push_back(pt);
			vector<Eigen::Vector3f> cords;
			for (int i=0; i<pt.size(); i++) {
				Eigen::Vector3f cord((pt[i][0]*invxN_+1.0)*0.5, (pt[i][1]*invyN_+1.0)*0.5, (pt[i][2]*invzN_+1.0)*0.5);//FIXME
				cords.push_back(cord);
			}
			textureCords.push_back(cords);
		}
	}
	Eigen::Map<Eigen::VectorXf> bufV(buf, bufSize);
	int trigIdx = 0;
	for (int i = 0; i < sliceVerts.size(); i++) {
		const vector<Eigen::Vector3f>& pt = sliceVerts[i];
		const vector<Eigen::Vector3f>& cords = textureCords[i];
		// first trig
		unsigned int totalIdx = trigIdx*18;
		bufV.segment(totalIdx + 0, 3) = pt[0];
		bufV.segment(totalIdx + 3, 3) = cords[0];
		bufV.segment(totalIdx + 6, 3) = pt[1];
		bufV.segment(totalIdx + 9, 3) = cords[1];
		bufV.segment(totalIdx + 12, 3) = pt[2];
		bufV.segment(totalIdx + 15, 3) = cords[2];
		trigIdx++;
		for (int idx = 3; idx < pt.size(); idx++) {
			unsigned int totalIdx = trigIdx*18;
			bufV.segment(totalIdx + 0, 3) = pt[0];
			bufV.segment(totalIdx + 3, 3) = cords[0];
			bufV.segment(totalIdx + 6, 3) = pt[idx-1];
			bufV.segment(totalIdx + 9, 3) = cords[idx-1];
			bufV.segment(totalIdx + 12, 3) = pt[idx];
			bufV.segment(totalIdx + 15, 3) = cords[idx];
			trigIdx++;
		}
	}

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
  glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float)*bufSize, buf);
	glEnable(GL_TEXTURE_3D);
  glBindVertexArray(VAO);
	glDrawArrays(GL_TRIANGLES, 0, trigIdx*3);
	glDisable(GL_TEXTURE_3D);
	
	/*for (int j = 0; j < sliceVerts.size(); j++) {
		const vector<Eigen::Vector3f>& pt = sliceVerts[j];
		// sort points to get a convex polygon
		//std::sort(pt.begin()+1, pt.end(), Convexcomp(pt[0], viewdir));
		//nvt += pt.size();
		
		glBegin(GL_POLYGON);
		for (int i=0; i<pt.size(); i++){
			glColor3f(0.0, 0.0, 0.0);
              glTexCoord3d((pt[i][0]*invxN_+1)/2.0, (pt[i][1]*invyN_+1)/2.0, (pt[i][2]*invzN_+1)/2.0);//FIXME
              // glTexCoord3d((pt[i][2]+zN_)/2.0, (pt[i][1]+yN_)/2.0, (pt[i][0]+xN_)/2.0);
			glVertex3f(pt[i][0], pt[i][1], pt[i][2]);
		}
		glEnd();

		if (_isDrawSliceOutline)
		{
			glDisable(GL_TEXTURE_3D);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glBegin(GL_POLYGON);
			for (int i=0; i<pt.size(); i++) {
				glColor3f(0.0, 0.0, 1.0);
				glVertex3f(pt[i][0], pt[i][1], pt[i][2]);
			}
			glEnd();
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		}
	}*/

}

std::vector<Eigen::Vector3f> Renderer3DGL4::IntersectEdges(float A, float B, float C, float D)
{
	float t;
	Eigen::Vector3f p;
	std::vector<Eigen::Vector3f> res;
	GLfloat (*edges)[2][3] = _cubeEdges;
	

	for (int i=0; i<12; i++) {
		t = -(A*edges[i][0][0] + B*edges[i][0][1] + C*edges[i][0][2] + D)
			/ (A*edges[i][1][0] + B*edges[i][1][1] + C*edges[i][1][2]);
		if ((t>0)&&(t<2)) {
			p[0] = edges[i][0][0] + edges[i][1][0]*t;
			p[1] = edges[i][0][1] + edges[i][1][1]*t;
			p[2] = edges[i][0][2] + edges[i][1][2]*t;
			res.push_back(p);
		}
	}

	return res;
}


void Renderer3DGL4::FillTexture(const FIELD_3D& density_field, const float multiplier, const int low_cut)
{

	//unsigned char* intensity = new unsigned char[_SIZE];
	//memset(intensity, 0, _SIZE);
	//CastLight(density_field, intensity);

	//FIXME: It is important to beware that texture coordinate
	//is in reverse order  of the simulation coordinate
	for (int k = 0 ; k < zRes_ ; k++) {
		for (int j = 0 ; j < yRes_ ; j++) {
			for (int i = 0 ; i < xRes_ ; i++) {
				//unsigned char c = 200;
				int texIndex = k*Slabsize_ + j*xRes_ + i;	/*reverse order*/
				int densIndex = k*Slabsize_ + j*xRes_ + i;
				int denV = density_field[densIndex]*255.0*multiplier;
				denV = denV > 255 ? 255 : denV;
				_textureData[texIndex*4] = 255 - denV;
				_textureData[texIndex*4+1] = 255 - denV;
				_textureData[texIndex*4+2] = 255- denV;
				int alplaV = density_field[densIndex]*88.0*multiplier;
				alplaV = alplaV > 88 ? 88 : alplaV;
				alplaV = alplaV < low_cut ? 0 : alplaV;
        _textureData[texIndex*4+3] = alplaV;
			}
		}
	}

	//delete []intensity;

	// glActiveTextureARB(GL_TEXTURE0_ARB);
	//glTexImage3D(GL_TEXTURE_3D, 0, GL_RGBA, xRes_, yRes_, zRes_, 0, GL_RGBA, GL_UNSIGNED_BYTE, _textureData);
    glBindTexture(GL_TEXTURE_3D, _hTexture);
    glTexSubImage3D(GL_TEXTURE_3D, 0,0,0,0, xRes_, yRes_, zRes_, GL_RGBA,GL_UNSIGNED_BYTE, _textureData);
}

void Renderer3DGL4::GenerateRayTemplate()
{
	_rayTemplate[0][0] = _rayTemplate[0][2] = _rayTemplate[0][2] = 0;
	float fx = 0.0f, fy = 0.0f, fz = 0.0f;
	int x = 0, y = 0, z = 0;
	float lx = _lightDir[0] + 0.000001f, ly = _lightDir[1] + 0.000001f, lz = _lightDir[2] + 0.000001f;
	int xinc = (lx > 0) ? 1 : -1;
	int yinc = (ly > 0) ? 1 : -1;
	int zinc = (lz > 0) ? 1 : -1;
	float tx, ty, tz;
	int i = 1;
	int len = 0;
    int edgeLen = std::max(std::max(yRes_, zRes_), xRes_);
	int maxlen = 3*edgeLen*edgeLen;
	while (len <= maxlen)
	{
		// fx + t*lx = (x+1)   ->   t = (x+1-fx)/lx
		tx = (x+xinc-fx)/lx;
		ty = (y+yinc-fy)/ly;
		tz = (z+zinc-fz)/lz;

		if ((tx<=ty)&&(tx<=tz)) {
			_rayTemplate[i][0] = _rayTemplate[i-1][0] + xinc;
			x =+ xinc;
			fx = x;

			if (ALMOST_EQUAL(ty,tx)) {
				_rayTemplate[i][1] = _rayTemplate[i-1][1] + yinc;
				y += yinc;
				fy = y;
			} else {
				_rayTemplate[i][1] = _rayTemplate[i-1][1];
				fy += tx*ly;
			}

			if (ALMOST_EQUAL(tz,tx)) {
				_rayTemplate[i][2] = _rayTemplate[i-1][2] + zinc;
				z += zinc;
				fz = z;
			} else {
				_rayTemplate[i][2] = _rayTemplate[i-1][2];
				fz += tx*lz;
			}
		} else if ((ty<tx)&&(ty<=tz)) {
			_rayTemplate[i][0] = _rayTemplate[i-1][0];
			fx += ty*lx;

			_rayTemplate[i][1] = _rayTemplate[i-1][1] + yinc;
			y += yinc;
			fy = y;

			if (ALMOST_EQUAL(tz,ty)) {
				_rayTemplate[i][2] = _rayTemplate[i-1][2] + zinc;
				z += zinc;
				fz = z;
			} else {
				_rayTemplate[i][2] = _rayTemplate[i-1][2];
				fz += ty*lz;
			}
		} else {
			assert((tz<tx)&&(tz<ty));
			_rayTemplate[i][0] = _rayTemplate[i-1][0];
			fx += tz*lx;
			_rayTemplate[i][1] = _rayTemplate[i-1][1];
			fy += tz*ly;
			_rayTemplate[i][2] = _rayTemplate[i-1][2] + zinc;
			z += zinc;
			fz = z;
		}

		len = _rayTemplate[i][0]*_rayTemplate[i][0]
			+ _rayTemplate[i][1]*_rayTemplate[i][1]
			+ _rayTemplate[i][2]*_rayTemplate[i][2];
		i++;
	}
}

#define DECAY 0.06f
void Renderer3DGL4::CastLight(const FIELD_3D& density, unsigned char* intensity)
{

	int i,j;
	int sx = (_lightDir[0]>0) ? 0 : xRes_-1;
	int sy = (_lightDir[1]>0) ? 0 : yRes_-1;
	int sz = (_lightDir[2]>0) ? 0 : zRes_-1;

	float decay = 1.0f/(MaxRes_*DECAY);

	/*for (i=0; i<n; i++)
		for (j=0; j<n; j++) {
			if (!ALMOST_EQUAL(_lightDir[0], 0) )
          LightRay(sx, i, j, decay, density, intensity);
			if (!ALMOST_EQUAL(_lightDir[1], 0) )
				LightRay(i, sy, j, decay, density, intensity);
			if (!ALMOST_EQUAL(_lightDir[2], 0) )
				LightRay(i, j, sz, decay, density, intensity);
		}
		*/
    for (int i = 0; i < yRes_; i++) {
      for (int j = 0; j < zRes_; j++) {
        if (!ALMOST_EQUAL(_lightDir[0], 0) )
          LightRay(sx, i, j, decay, density, intensity);
      }
    }
    for (int i = 0; i < xRes_; i++) {
      for (int j = 0; j < zRes_; j++) {
        if (!ALMOST_EQUAL(_lightDir[1], 0) )
          LightRay(i, sy, j, decay, density, intensity);
      }
    }
    for (int i = 0; i < xRes_; i++) {
      for (int j = 0; j < yRes_; j++) {
        if (!ALMOST_EQUAL(_lightDir[2], 0) )
          LightRay(i, j, sz, decay, density, intensity);
      }
    }
}


#define AMBIENT 100
inline void Renderer3DGL4::LightRay(int x, int y, int z, float decay, const FIELD_3D& density, unsigned char* intensity)
{
	int xx = x, yy = y, zz = z, i = 0;
	int offset;

	int l = 200;
	float d;

	do {
		offset = ((xx*xRes_) + yy)*yRes_ + zz;//FIXME
		if (intensity[offset] > 0)
			intensity[offset] = (unsigned char) ((intensity[offset] + l)*0.5f);
		else
			intensity[offset] = (unsigned char) l;
		d = density[offset]*255.0f;
		if (l > AMBIENT) {
			l -= d*decay;
			if (l < AMBIENT)
				l = AMBIENT;
		}

		i++;
		xx = x + _rayTemplate[i][0];
		yy = y + _rayTemplate[i][1];
		zz = z + _rayTemplate[i][2];
	} while ((xx>=0)&&(xx<xRes_)&&(yy>=0)&&(yy<yRes_)&&(zz>=0)&&(zz<zRes_));
}


