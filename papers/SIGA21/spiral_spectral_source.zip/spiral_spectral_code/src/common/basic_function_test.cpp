#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "common/basic_function.h"

#include "util/util.h"
#include "util/timer.h"


using namespace std;
namespace {
  
void testBasicFuncHash() {
  std::vector<BasicFunc> funs = {BasicFunc(SIN, R, 2, 0.0), BasicFunc(COS, R, 2, 0.0), BasicFunc(ONE, R, 2, 0.0), BasicFunc(ZERO, R, 0, 0),
                            BasicFunc(ONE, R, 0, 0.0), BasicFunc(SIN, R, 2, 0.0, 2), BasicFunc(ONE, R, 2, 0.0, 2), BasicFunc(ZERO, R, 0,0,2),
                            BasicFunc(COS, R, 4, 0.0, 4), BasicFunc(SIN, R, -5, 0, 2), BasicFunc(COS, R, -4, 0, 1), BasicFunc(SIN, R, -1, 0, 2),
                            BasicFunc(COS, T, 16, 0), BasicFunc(SIN, T, 12, 0), BasicFunc(ONE, T, 0, 0), BasicFunc(ZERO, T, 0,0), 
                            BasicFunc(COS, T, -12, 0), BasicFunc(SIN, T, -5, 0), BasicFunc(COS, P, 16, 0), BasicFunc(SIN, P, 12, 0), BasicFunc(ONE, P, 0, 0), BasicFunc(ZERO, P, 0,0), 
                            BasicFunc(COS, P, -12, 0), BasicFunc(SIN, P, -5, 0),BasicFunc(SIN, R, 2, 0.0, -2), BasicFunc(SIN, R, 2, 0.0, -1),
                            BasicFunc(SIN, R, 2, 0.0, -2), BasicFunc(COS, R, 4, 0.0, -3)};
  for (const auto& f : funs) {
    uint hash = f.toHash();
    BasicFunc recov = BasicFunc::fromHash(hash);
    CHECK(BasicFunc::equalFun(recov, f)) << recov.rPower << " " << f.rPower;
  }
  
  std::vector<BasicFunc> fun1 = {BasicFunc(SIN, R, 2, 1.0), BasicFunc(SIN, R, 2, 1.0), BasicFunc(COS, R, 2, -1.0), BasicFunc(COS, R, 2, 1), BasicFunc(ZERO, R,0,0),
                            BasicFunc(ONE, R, 0, 5.0, 2), BasicFunc(ONE, R, 0, 2.0, 2), BasicFunc(ONE, R, 0, 1.0, 1), 
                            BasicFunc(SIN, R, 4, 1.0), BasicFunc(SIN, R, 4, -1.0), BasicFunc(COS, R, 11, 2.0), BasicFunc(COS, R, 11, -1.0)};

  std::vector<BasicFunc> Negresult = {BasicFunc(SIN, R, 2, -2.0), BasicFunc(ONE, R, 0, -7.0, 2), BasicFunc(ONE, R, 0, -1.0, 1), 
                              BasicFunc(COS, R, 11, -1.0)};

  BasicFunc::hashSimplify(fun1);
  for (const auto& f : fun1) {
    f.print();
    printf("\n");
  }

  fun1.insert(fun1.end(), Negresult.begin(), Negresult.end());
  BasicFunc::hashSimplify(fun1);
  CHECK(fun1.size() == 0);
}

void testVecVecProd() {
  std::vector<BasicFunc> A = {BasicFunc(COS, R, 2, 1.0, 2)};
  // + 4.934802r^2  + 4.934802r^2Cos[4/2*r] + 3.141593r^1Sin[4/2*r] + 3.141593r^1Sin[4/2*r] + 2.000000  + -2.000000Cos[4/2*r] 
  std::vector<BasicFunc> B = {BasicFunc(ONE, R, 0, 1.0, 2)};

  RTMultiply R1;
  R1.rComp = A;

  RTMultiply R2;
  R2.rComp = B;

  RTMultiply R3;
  R3.rComp = BasicFunc::vecVecMult(A, B);

  R1.print(); printf("\n");
  R2.print(); printf("\n");
  R3.print();

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  testBasicFuncHash();
  testVecVecProd();

  return 0;
}