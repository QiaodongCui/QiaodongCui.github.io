#ifndef BASIS_SET_H
#define BASIS_SET_H

#include <cstring>
#include <Eigen/Eigen>
#include <vector>
#include "setting.h"

#include "2D/VFIELD2D.h"
#include "polar_2D/polar_basis_2D.h"

class BasisSet {

public:
  BasisSet(){
  };
  ~BasisSet(){};
  virtual void allocateBasis();
  virtual void allocateNumerical();

  // Verify the tensor is antisymmetric C_{ij}^k = - C_{ik}^j
  static void VerifyAntisymmetric(const std::vector<Adv_Tensor_Type>& C);
  static void EigenCompress(std::vector<Adv_Tensor_Type> *Adv_tensor);
  virtual void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor);
  virtual void InverseTransformToVelocity(
      const Eigen::VectorXd& coefficients, VFIELD2D* field);
  // Input a std::vector field, transform and output the basis coefficients.
  virtual void ForwardTransformtoFrequency(
      const VFIELD2D& field, Eigen::VectorXd* coefficients);
  
  virtual void init() {
    LOG(FATAL) << "base called";
  };

  const Eigen::MatrixXd& transferMat() const  {
    return A_;
  }

  int numBasisAll() const {
    return numBasisAll_;
  }

  int GetnumBasisOrtho() const  {
    return numBasisOrtho_;
  }
  // IO...
  virtual void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const;
  virtual void readFromFile(std::ifstream& in);
  void computeInnerProduct();
  
  // compute the ur, ut on a uniform r, t grid, test only.
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut);

  // project the force field fr, ft on a uniform r, t grid, test only.  
  void projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef);

  const Eigen::VectorXd& waveNum2() const {
    return waveNum2_;
  }
protected:
	
	int numBasisAll_;
  // number of orthogonal basis.
  int numBasisOrtho_;

	// inner product of all basis.
  Eigen::MatrixXd H_;
  // transfer matrix
  Eigen::MatrixXd A_;

  //std::vector<basisPtr> all_basis_;
  std::vector<VFIELD2D> cached_basis_;

  // square of wavenumbers.
  Eigen::VectorXd waveNum2_;

};


#endif  // BASIS_SET_H