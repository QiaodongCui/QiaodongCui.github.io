#include <vector>
#include "tensorCompute/evalP.h"
pEval::pEval() {
pointers_.resize(25);
pointers_[0] = &evalP_0;
pointers_[1] = &evalP_1;
pointers_[2] = &evalP_2;
pointers_[3] = &evalP_3;
pointers_[4] = &evalP_4;
pointers_[5] = &evalP_5;
pointers_[6] = &evalP_6;
pointers_[7] = &evalP_7;
pointers_[8] = &evalP_8;
pointers_[9] = &evalP_9;
pointers_[10] = &evalP_10;
pointers_[11] = &evalP_11;
pointers_[12] = &evalP_12;
pointers_[13] = &evalP_13;
pointers_[14] = &evalP_14;
pointers_[15] = &evalP_15;
pointers_[16] = &evalP_16;
pointers_[17] = &evalP_17;
pointers_[18] = &evalP_18;
pointers_[19] = &evalP_19;
pointers_[20] = &evalP_20;
pointers_[21] = &evalP_21;
pointers_[22] = &evalP_22;
pointers_[23] = &evalP_23;
pointers_[24] = &evalP_24;
}


