#include "polar_2D/polar_basis_all.h"
#include "sphere_3D/sphere_basis_3D.h"

void PolarBasisAll::initBasicCoef() {
  double invk2 = 1.0;
  if (k2x2 != 0)
    invk2 = 1.0/k2;

  // seee from basisAnalysis_3D.pdf in the doc
  switch (index_) {
    // two regular basis
    case 0:
            phiFunc_[0] = BasicFunc(ONE, P, 0, 1.0);
            phiFunc_[1] = BasicFunc(ONE, P, 0, invk2);
            CHECK(k1x2 > 0 && k2x2 > 0);
    break;
  
    case 1:
            phiFunc_[0] = BasicFunc(ONE, P, 0, 1.0);
            phiFunc_[1] = BasicFunc(ONE, P, 0, -invk2);
            CHECK(k1x2 > 0 && k2x2 > 0);
    break;
    // enrich at pole
    case 2:
            phiFunc_[0] = BasicFunc(ONE, P, 0, 1.0);
            phiFunc_[1] = BasicFunc(ONE, P, 0, invk2);
            CHECK(k1x2 >= 0 && k2x2 > 0);
    break;
    
    case 3:
            phiFunc_[0] = BasicFunc(ONE, P, 0, 1.0);
            phiFunc_[1] = BasicFunc(ONE, P, 0, invk2);
            CHECK(k1x2 >= 0 && k2x2 > 0);
    break;

    // circ mode
    case 4:
            phiFunc_[0] = BasicFunc(ZERO, P, 0, 0.0);
            phiFunc_[1] = BasicFunc(ONE, P, 0, 1.0);
            CHECK(k1x2 > 0 && k2x2 == 0);
    break;

    default:
    LOG(FATAL) << "idx " << index_ << "not supported";
  }

  if (index_ == 0) {  // shares expression
    RTMultiply r0;
    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 1.0)};
    t0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
  
    RT_[0] = {r0}; RT_[1] = {t0};
  } else if (index_ == 1) { // shares expression
    RTMultiply r0;
    r0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
    
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, k1*M_PI, 1), BasicFunc(SIN, R, k1x2, 1.0)};
    t0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RT_[0] = {r0}; RT_[1] = {t0};
  } else if (index_ == 2) {   // enrich psi0
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};
  
    RTMultiply t0;
    // [cos(i1*pi*r) - i1*pi*r*sin(i1*pi*r)]cos(i2*v)
    t0.rComp = {BasicFunc(COS, R, k1x2, 1.0), BasicFunc(SIN, R, k1x2, -k1*M_PI, 1)};
    t0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};

    RT_[0] = {r0}; RT_[1] = {t0};
  } else if (index_ == 3) {   // enrich psi1
    RTMultiply r0;
    r0.rComp = {BasicFunc(COS, R, k1x2, 1.0)};
    r0.tComp = {BasicFunc(COS, T, k2x2, 1.0)};
    // [-cos(i1*pi*r) + i1*pi*r*sin(i1*pi*r)]*sin(i2*v)
    RTMultiply t0;
    t0.rComp = {BasicFunc(COS, R, k1x2, -1.0), BasicFunc(SIN, R, k1x2, k1*M_PI, 1)};
    t0.tComp = {BasicFunc(SIN, T, k2x2, 1.0)};

    RT_[0] = {r0}; RT_[1] = {t0};
  } else if (index_ == 4) {   // enrich psi2
    RTMultiply p0;
    p0.rComp = {BasicFunc(SIN, R, k1x2, 1.0)};
    p0.tComp = {BasicFunc(ONE, T, 0, 1.0)};
    RT_[0] = {}; RT_[1] = {p0};
  } else {
    LOG(FATAL) << "idx " << index_ << "not supported";
  }
}

void PolarBasisAll::toCartesianMat(const double& t, Eigen::Matrix2d& mat) {
  double sinT = sin(t);
  double cosT = cos(t);
  mat << cosT, -sinT,
         sinT, cosT; 
}

#define PHI0 sin(k1*r)*sin(k2*t),\
             invk2*(sin(k1*r) + k1*r*cos(k1*r))*cos(k2*t)

#define PHI1 sin(k1*r)*cos(k2*t),\
             -invk2*(sin(k1*r) + k1*r*cos(k1*r))*sin(k2*t)

#define PHI2 cos(k1*r)*sin(t),\
             (cos(k1*r) - k1*r*sin(k1*r))*cos(t)

#define PHI3 cos(k1*r)*cos(t),\
             (-cos(k1*r) + k1*r*sin(k1*r))*sin(t)

#define PHI4 0,\
             sin(k1*r)

#define computeBasis switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }

void PolarBasisAll::DiscretizeAdd(const double coef, const FIELD2D& radius, const FIELD2D& theta,
                                  VFIELD2D* vfield) const {
  double dx = 2.0 / vfield->getxRes();
  double dy = 2.0 / vfield->getyRes();
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  Eigen::Matrix2d trans;
  for (int j = 0; j < vfield->getyRes(); j++) {
    for (int i = 0; i < vfield->getxRes(); i++) {
      double r = radius(i,j);
      double t = theta(i,j);

      if (r > 1.0)
        continue;
      r *= M_PI;
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      toCartesianMat(t, trans);
      Eigen::Vector2d uCartesian = invNorm_*coef*trans*v;
      (*vfield)(i,j)[0] = uCartesian[0];
      (*vfield)(i,j)[1] = uCartesian[1];
    }
  }
}

void PolarBasisAll::AddUniformU(const double coef, const int nR, const int nTheta, double* ur, double* ut) const {
  double dr = 1.0 / nR;
  double dTheta = 2.0*M_PI/nTheta;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;

  for (int j = 0; j < nR; j++) {
    for (int i = 0; i < nTheta; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
      r *= M_PI;
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      v *= coef*invNorm_;
      int idx = i + j*nTheta;
      ur[idx] += v[0];
      ut[idx] += v[1];
    }
  }
}

double PolarBasisAll::ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const {
  double dr = 1.0 / nR;
  double dTheta = 2.0*M_PI/nTheta;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double result = 0;

  for (int j = 0; j < nR; j++) {
    for (int i = 0; i < nTheta; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
      r *= M_PI;
      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      // v *= coef*invNorm_;
      int idx = i + j*nTheta;
      result += v[0]*fr[idx] + v[1]*ft[idx];
    }
  }
  result *= invNorm_;
  result *= dr*dTheta;

  return result;
}
  
// int_{\theta = 0}^{2*Pi} fun1*fun2 d\theta 
double PolarBasisAll::computeThetaInt(const BasicFunc& fun1, const BasicFunc& fun2) {
    std::vector<BasicFunc> mult = BasicFunc::multiply(fun1, fun2);
  double result = 0;
  for (auto& f : mult) {
    result += f.integrateP2Pi();
  }
  return result;
}

// int_{r = 0}^{1} fun1*fun2*r dr 
double PolarBasisAll::computeRInt(const BasicFunc& fun1, const BasicFunc& fun2) {
  CHECK(fun1.dir == R && fun2.dir == R);

  std::vector<BasicFunc> mult = BasicFunc::multiply(fun1, fun2);
  double result = 0;
  for (auto& f : mult) {
    f.rPower += 1;
    result += f.integrate();
  }
  return result;
}

// (std::vector of sum)*(std::vector of sum)
double PolarBasisAll::computeVThetaInt(const std::vector<BasicFunc>& t1, const std::vector<BasicFunc>& t2) {
  double result = 0;
  for (const auto& fun1 : t1)
    for (const auto& fun2 : t2)
      result += computeThetaInt(fun1, fun2);

  return result;
}

// (std::vector of sum)*(std::vector of sum)
double PolarBasisAll::computeVRInt(const std::vector<BasicFunc>& r1, const std::vector<BasicFunc>& r2) {
  double result = 0;
  for (const auto& fun1 : r1)
    for (const auto& fun2: r2)
      result += computeRInt(fun1, fun2);

  return result;
}

/*  // this is (sum rComp)*(sum tComp)
  std::vector<BasicFunc> rComp;
  std::vector<BasicFunc> tComp;*/
/* \int_{r,t} rt1.rcomp*rt1.tcomp*rt2.rcomp*rt2.tcomp dr dt =
  \int_{r} rt1.rcomp*rt2.rcomp*dr \int_{t} rt1.tcomp*rt2.tcomp dt
*/
double PolarBasisAll::computeRTMultInt(const RTMultiply& rt1, const RTMultiply& rt2) {
  double thetaInt = computeVThetaInt(rt1.tComp, rt2.tComp);
  if (thetaInt == 0)
    return 0;
 
  double rInt = computeVRInt(rt1.rComp, rt2.rComp);
  //LOG(INFO) << thetaInt << " " << rInt;

  return thetaInt*rInt;
}

double PolarBasisAll::dotProd(const PolarBasisAll& other) const {
  Eigen::Vector2d result(0,0);

  for (int i = 0; i < 2; i++) {
    // <phi_i, phi_i>    
    double pINT = phiFunc_[i].coef*other.getPhiFunc(i).coef;
    //LOG(INFO) << k3x2/2;

    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and phi.
      double rtINT = 0;
      for (const auto& rt1 : RT_[i])
        for (const auto& rt2 : other.getRT(i))
          rtINT += computeRTMultInt(rt1, rt2);

      result[i] = pINT*rtINT;
    }
  }

  return result.sum();
}

// r*\nabla x f = r*D[f_t, r] + f_t - D[f_r, t]
void PolarBasisAll::curlSph() {
  // sign is grouped into phi func
  curlPhi_[0] = phiFunc_[1];
  curlPhi_[1] = phiFunc_[1];
  curlPhi_[2] = -phiFunc_[0];

  curlRT_[0] = RT_[1];
  RTMultiply::derivRVec(curlRT_[0]);
  RTMultiply::multRVec(1, curlRT_[0]);

  curlRT_[1] = RT_[1];

  curlRT_[2] = RT_[0];
  RTMultiply::derivTVec(curlRT_[2]);
}

// a1 b2 - a2 b1
void PolarBasisAll::crossProdPhi(const PolarBasisAll& phiG, const PolarBasisAll& phiH,
                                 std::vector<BasicFunc> (&crossPhi)[2]) {
  crossPhi[0] = BasicFunc::multiply(phiG.getPhiFunc(0), phiH.getPhiFunc(1));
  crossPhi[1] = BasicFunc::multiply(phiG.getPhiFunc(1), -phiH.getPhiFunc(0));
}

// This also doesnt include norm
// These doesnt include the sin(t) weight included in integral, the term is baked into curl.
// sign is in phi component.
// (crossPhi[0][0])*(crossRT[0][0]);
// 
void PolarBasisAll::crossProdRT(const PolarBasisAll& phiG, const PolarBasisAll& phiH,
                                std::vector<RTMultiply> (&crossRT)[2]) {
  crossRT[0] = RTMultiply::multV(phiG.getRT(0), phiH.getRT(1));
  crossRT[1] = RTMultiply::multV(phiG.getRT(1), phiH.getRT(0));
}

double PolarBasisAll::integrateCurlCross(const BasicFunc& curlP, const std::vector<BasicFunc>& crossP,
                                         const std::vector<RTMultiply>& curlRT, const std::vector<RTMultiply>& crossRT) {
  // in this case phi only carries constants.
  double phiInt = 0;
  for (const auto& cp : crossP)
    phiInt += curlP.coef*cp.coef;
  if (fabs(phiInt) < 1e-14)
    return 0.0;
  // integrate along theta, without sin(t) term, because its already in curl.
  double rtInt = 0;
  std::vector<RTMultiply> RTProd = RTMultiply::multV(curlRT, crossRT);
  for (const auto& rt : RTProd) {
    double tInt = rt.integrateT2Pi();
    if (fabs(tInt) < 1e-14)  // prod is zero.
      continue;
    double rInt = rt.integrateR();
    rtInt += tInt*rInt;
  }

  return phiInt*rtInt;
}

double PolarBasisAll::computeTensorEntry(const PolarBasisAll& phiI, const PolarBasisAll& phiG, const PolarBasisAll& phiH) {
  // compute cross product.
  std::vector<BasicFunc> crossPhi[2];
  std::vector<RTMultiply> crossRT[2];
  PolarBasisAll::crossProdPhi(phiG, phiH, crossPhi);
  PolarBasisAll::crossProdRT(phiG, phiH, crossRT);

  // int_{\omega} {r^2 sin(t)(\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  // r component
  double rVal = 0;
  // compute integral.
  for (int ind = 0; ind < 3; ind++) {
    rVal += PolarBasisAll::integrateCurlCross(phiI.getCurPhi(ind), crossPhi[0], phiI.getCurRT(ind), crossRT[0]);
    rVal += PolarBasisAll::integrateCurlCross(phiI.getCurPhi(ind), crossPhi[1], phiI.getCurRT(ind), crossRT[1]);
  }

  return (rVal)*phiI.GetInvNorm()*phiG.GetInvNorm()*phiH.GetInvNorm();
}

  
void PolarBasisAll::writeToFile(std::ofstream& out) const {
  out.write(reinterpret_cast<const char *>(&k1x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k2x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&index_), sizeof(int));
}


PolarBasisAll* PolarBasisAll::fromFile(std::ifstream& in) {
  int k1x2, k2x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));

  return new PolarBasisAll(k1x2, k2x2, index_);
}