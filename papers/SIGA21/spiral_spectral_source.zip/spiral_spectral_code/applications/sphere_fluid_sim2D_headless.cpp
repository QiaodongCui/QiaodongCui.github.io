// Viewer for 3D laplacian fluid simulation.

#include "setting.h"
#include <Eigen/Eigen>
#include <fftw3.h>
#include <iostream>
#include <sstream>

#include <glog/logging.h>
#include <gflags/gflags.h>
#include <sys/time.h>
#include <string>
#include <sstream>
#include <vector>

#include "polar_2D/sphere_fluid_2D1.h"

const double spectra_draw_factor = 0.1;
DEFINE_int32(window_x, 1920, "The x resolution of the window");
DEFINE_int32(window_y, 1080, "The y resolution of the window");

DEFINE_bool(add_density, true, "Whether to add density into the fluid.");
DEFINE_double(added_smoke_density, 2.0, "The density of added smoke.");
DEFINE_int32(xRes, 512, "The xReslution of the fluid.");
DEFINE_int32(yRes, 512, "The yReslution of the fluid.");
DEFINE_int32(basis_dim, 20, "The number of wanted basis.");
DEFINE_double(dt, 0.1, "The time step of the simulation.");
DEFINE_double(buoyancy, 0.0001, "The buoyancy of the fluid.");
DEFINE_double(viscosity, 0.005, "The viscosity of the fluid.");
DEFINE_double(b, 0.9, "The shorter axis.");

DEFINE_string(basis_type, "all_dirichlet", "The basis type. Can be all_dirichlet,"
              "three_dirichlet_one_neumann, two_neumann_x");
DEFINE_string(integrator_type, "RK4", "The integrator_type. Can be RK4, semi_implicit"
              "BiCGSTAB");
DEFINE_int32(total_frame, 2000, "The total frame want to simulate.");
DEFINE_int32(total_num_particles, 1000, "The total number of particles");
DEFINE_double(particle_length_factor, 0.1, "How long is the particles.");
DEFINE_double(tensor_weight, 1.0, "Weight of the tensor.");
DEFINE_double(force_scale, 0.5, "The force scale to apply the force by mouse");
DEFINE_string(Tensor_file, "", "The file which stores all the tensor.");
DEFINE_bool(add_density_once, false, "Only add the density to the first of the frame");

DEFINE_bool(capture_video, false, "Whether to capture the video.");
DEFINE_string(preview_fpath, "", "The folder to put the preview video.");
DEFINE_double(densityPtlWeight, 1.f, "weight of density particles.");
DEFINE_int32(maxDensityParticles, 2, "maximum number of density particles.");
DEFINE_int32(scenario, 2, "which scenario is it");
DEFINE_double(blendW, 0.9, "Blend wegiht.");
DEFINE_double(omega, 0, "coriolis wegiht.");

// IO
DEFINE_bool(output_texture, false, "whether to output the texture.");
DEFINE_string(texture_folder, "", "The folder to dump the texture.");
DEFINE_bool(writeRGB, false, "Write RGB image");
DEFINE_bool(writeVelocity, false, "Write velocity image.");

SphereFluid2D1* fluid = NULL;

double b = 1.0;
bool is_prolate = false;
bool is_oblate = false;

static void idle_func ( void ) {
  fluid->Step();
}

int main(int argc, char ** argv) {

  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  b = FLAGS_b;
  if (FLAGS_basis_type == "sphere_2d") {
    b = 1.0;
  } else if (FLAGS_basis_type == "oblate_2d") {
    is_oblate = true;
  } else if (FLAGS_basis_type == "prolate_2d") {
    is_prolate = true;
  }

  // For problems of smaller size, use less threads are better.
  fftw_init_threads();
  fftw_plan_with_nthreads(12);
  CHECK(FLAGS_xRes == FLAGS_yRes);

  fluid = new SphereFluid2D1(FLAGS_xRes, FLAGS_yRes, FLAGS_basis_dim,
      FLAGS_dt, FLAGS_basis_type, FLAGS_integrator_type, FLAGS_buoyancy, FLAGS_viscosity,
      FLAGS_total_num_particles, FLAGS_total_frame, FLAGS_added_smoke_density, FLAGS_Tensor_file,
      FLAGS_tensor_weight, b, FLAGS_densityPtlWeight, FLAGS_maxDensityParticles, FLAGS_scenario,
      FLAGS_output_texture, FLAGS_texture_folder, true, FLAGS_writeRGB, FLAGS_writeVelocity,
      FLAGS_blendW, FLAGS_omega);

  // render loop
  // -----------
  while (!fluid->isFinished()) {
    idle_func();
  }
  LOG(INFO) << "complected, quitting";    
  return 0;
}
