#include <fstream>
#include <glog/logging.h>
#include <sstream>
#include <stdlib.h> 

#include "util/write_density_pbrt.h"

void WriteDensityPBRT(const std::string& fname, const FIELD_3D& field, const float atten_fact) {
  std::ofstream out(fname);
  if (!out.is_open()) {
    LOG(FATAL) << "Cannot write to file: " << fname;
  }
  const int xRes = field.xRes();
  const int yRes = field.yRes();
  const int zRes = field.zRes();
  const int maxRes = std::max(std::max(xRes, yRes), zRes);
  const uint total = xRes*yRes*zRes;
  
  // Header.
  //out << "Volume \"volumegrid\" \n"; // PBRT v2.
  out << "MakeNamedMedium \"smoke\" \n "; //PBRT v3
  out << "\"integer nx\" [ " << xRes << " ]\n";
  out << "\"integer ny\" [ " << yRes << " ]\n";
  out << "\"integer nz\" [ " << zRes << " ]\n";
  // Write the extent, the maximum extent is 1.
  out << "\"point p0\" [ 0.0 0.0 0.0 ] ";
  out << "\"point p1\" [ " << static_cast<float>(xRes) / maxRes << " " << static_cast<float>(yRes) / maxRes 
      << " " << static_cast<float>(zRes) / maxRes << " ] \n";
  out << "\"float density\" [\n";
  // Dump all the density values.
  for (int i = 0; i < total; i++) {
    if (std::abs(field[i]*atten_fact) < 1e-10) {
      out << "0 ";
    } else {
      out << field[i]*atten_fact << " ";
    }
    if (i % 50 == 0) {
      out << "\n";
    }
  }
  out << " ]\n";
  out << "\"string type\" [ \"heterogeneous\" ] ";  //PBRT v3
  
  out.close();
  
  std::stringstream zip_cmd;
  zip_cmd << "gzip " << fname << " &";
  // zip the frame.
  system(zip_cmd.str().c_str());
}; 
