use strict;
use warnings;
use Time::HiRes;
my $BIN_PATH = "bin/precompute_3D_tensor";

my $xRes = 64;
my $yRes = 64;
my $zRes = 64;

my $basis_dim_des = 3000;
#all_dirichlet, one_neumann, two_neumann_x, four_neumann_xz, six_neumann
my $basis_type = "all_dirichlet";
#principle_x, principle_y. principle_z, random, uniform
my $constant_init_strategy = "principle_x";
my $folder_name = "./Tensor/Const_amp/";
my $allocate_high_freq="true";
my $low_freq_basis_ratio=0.7;

# convert to flags.
$basis_dim_des = "--basis_dim_des=".$basis_dim_des;
$basis_type = "--basis_type=".$basis_type;
$folder_name = "--folder_name=".$folder_name;
$constant_init_strategy = "--constant_init_strategy=".$constant_init_strategy;
$allocate_high_freq="--allocate_high_freq=".$allocate_high_freq;
$low_freq_basis_ratio="--low_freq_basis_ratio=".$low_freq_basis_ratio;

$xRes = "--xRes=".$xRes;
$yRes = "--yRes=".$yRes;
$zRes = "--zRes=".$zRes;

system($BIN_PATH." ".$basis_dim_des." ".$basis_type." ".$folder_name." ".
	   $allocate_high_freq." ".$low_freq_basis_ratio." ".
	   $constant_init_strategy." ".$xRes." ".$yRes." ".$zRes." --logtostderr");