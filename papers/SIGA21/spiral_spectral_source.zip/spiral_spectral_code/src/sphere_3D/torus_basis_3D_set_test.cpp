#include <Eigen/Eigen>
#include <math.h>
#include <glog/logging.h>

#include "sphere_3D/torus_basis_set_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "common/basis_set.h"

#include "util/util.h"
#include "util/timer.h"

using namespace std;

namespace {
  
void testTransform() {
  unique_ptr<TorusBasisSet3D> cBasis_;
  const int xRes_ = 128;
  cBasis_.reset(new TorusBasisSet3D(xRes_/2, xRes_, xRes_*2,  4,4,4, 3.0));
  VECTOR3_FIELD_3D velocity_(xRes_, xRes_, xRes_);
  Eigen::VectorXd vecCoef = Eigen::VectorXd::Zero(cBasis_->numBasisAll());
  //vecCoef[0] = 1.0;
  //cBasis_->InverseTransformToVelocity(vecCoef, &velocity_);
  //cBasis_->InverseTransformToVelocity(vecCoef, &velocity_);
  cBasis_->ForwardTransformtoFrequency(velocity_, &vecCoef);
  //cBasis_->ForwardTransformtoFrequency(velocity_, &vecCoef);
}

void testTensor() {
  const int xRes_ = 128;
  TorusBasisSet3D basis(xRes_/2, xRes_, xRes_*2,  4,4,4, 3.0);
  vector<Adv_Tensor_Type> Adv_tensor_;
  basis.outputTestTensorEntries(100, "./torus3D_tensorTest.txt", &Adv_tensor_);
  BasisSet::VerifyAntisymmetric(Adv_tensor_);
}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  fftw_init_threads();
  fftw_plan_with_nthreads(6);
  testTransform();
  //testTensor();
}