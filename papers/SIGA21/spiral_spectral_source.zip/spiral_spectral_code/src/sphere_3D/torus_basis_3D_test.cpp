#include <Eigen/Eigen>
#include <glog/logging.h>
#include <math.h>
#include <vector>

#include "3D/trig_integral_3d.h"
#include "3D/GRID_3D.h"
#include "3D/VECTOR3_GRID_3D.h"
#include "common/basic_function.h"
#include "polar_2D/torus_basis_2D.h"
#include "sphere_3D/torus_basis_3D.h"
#include "util/util.h"

using namespace std;

vector<vector<int>> testTrip = {{2, 1, 2}, {2, 1, 4}, {2, 1, 6}, {2, 1, 8}, {2, 1, 10}, {2, 2, 
  2}, {2, 2, 4}, {2, 2, 6}, {2, 2, 8}, {2, 2, 10}, {2, 3, 2}, {2, 3, 
  4}, {2, 3, 6}, {2, 3, 8}, {2, 3, 10}, {2, 4, 2}, {2, 4, 4}, {2, 4, 
  6}, {2, 4, 8}, {2, 4, 10}, {2, 5, 2}, {2, 5, 4}, {2, 5, 6}, {2, 5, 
  8}, {2, 5, 10}, {4, 1, 2}, {4, 1, 4}, {4, 1, 6}, {4, 1, 8}, {4, 1, 
  10}, {4, 2, 2}, {4, 2, 4}, {4, 2, 6}, {4, 2, 8}, {4, 2, 10}, {4, 3, 
  2}, {4, 3, 4}, {4, 3, 6}, {4, 3, 8}, {4, 3, 10}, {4, 4, 2}, {4, 4, 
  4}, {4, 4, 6}, {4, 4, 8}, {4, 4, 10}, {4, 5, 2}, {4, 5, 4}, {4, 5, 
  6}, {4, 5, 8}, {4, 5, 10}, {6, 1, 2}, {6, 1, 4}, {6, 1, 6}, {6, 1, 
  8}, {6, 1, 10}, {6, 2, 2}, {6, 2, 4}, {6, 2, 6}, {6, 2, 8}, {6, 2, 
  10}, {6, 3, 2}, {6, 3, 4}, {6, 3, 6}, {6, 3, 8}, {6, 3, 10}, {6, 4, 
  2}, {6, 4, 4}, {6, 4, 6}, {6, 4, 8}, {6, 4, 10}, {6, 5, 2}, {6, 5, 
  4}, {6, 5, 6}, {6, 5, 8}, {6, 5, 10}, {8, 1, 2}, {8, 1, 4}, {8, 1, 
  6}, {8, 1, 8}, {8, 1, 10}, {8, 2, 2}, {8, 2, 4}, {8, 2, 6}, {8, 2, 
  8}, {8, 2, 10}, {8, 3, 2}, {8, 3, 4}, {8, 3, 6}, {8, 3, 8}, {8, 3, 
  10}, {8, 4, 2}, {8, 4, 4}, {8, 4, 6}, {8, 4, 8}, {8, 4, 10}, {8, 5, 
  2}, {8, 5, 4}, {8, 5, 6}, {8, 5, 8}, {8, 5, 10}, {10, 1, 2}, {10, 1,
   4}, {10, 1, 6}, {10, 1, 8}, {10, 1, 10}, {10, 2, 2}, {10, 2, 
  4}, {10, 2, 6}, {10, 2, 8}, {10, 2, 10}, {10, 3, 2}, {10, 3, 
  4}, {10, 3, 6}, {10, 3, 8}, {10, 3, 10}, {10, 4, 2}, {10, 4, 
  4}, {10, 4, 6}, {10, 4, 8}, {10, 4, 10}, {10, 5, 2}, {10, 5, 
  4}, {10, 5, 6}, {10, 5, 8}, {10, 5, 10}};

vector<vector<int>> testWnTwo = {{2, 1}, {2, 2}, {2, 3}, {2, 4}, {2, 5}, {4, 1}, {4, 2}, {4, 3}, {4, 
  4}, {4, 5}, {6, 1}, {6, 2}, {6, 3}, {6, 4}, {6, 5}, {8, 1}, {8, 
  2}, {8, 3}, {8, 4}, {8, 5}, {10, 1}, {10, 2}, {10, 3}, {10, 4}, {10,
   5}};

namespace {
void testDotProd() {
  const double a = 3.0;
  TorusBasis3D basis(2, 2, 2, 0, a);
  LOG(INFO) << basis.dotProd(basis, a);
 vector<double> val1 = {63.1201, 189.36, 399.761, 694.321, 1073.04, 59.5396, 202.435, \
440.593, 774.015, 1202.7, 85.3267, 255.98, 540.402, 938.594, 1450.55, \
104.757, 314.272, 663.464, 1152.33, 1780.88, 129.74, 389.22, 821.686, \
1427.14, 2205.58, 227.498, 682.494, 1440.82, 2502.48, 3867.46, \
196.521, 668.172, 1454.26, 2554.78, 3969.73, 249.705, 749.114, \
1581.46, 2746.75, 4244.98, 269.135, 807.406, 1704.52, 2960.49, \
4575.3, 294.118, 882.353, 1862.75, 3235.3, 5000., 501.461, 1504.38, \
3175.92, 5516.07, 8524.84, 424.824, 1444.4, 3143.7, 5522.71, 8581.44, \
523.668, 1571., 3316.56, 5760.34, 8902.35, 543.098, 1629.3, 3439.62, \
5974.08, 9232.67, 568.081, 1704.24, 3597.85, 6248.89, 9657.37, \
885.009, 2655.03, 5605.06, 9735.1, 15045.2, 744.447, 2531.12, \
5508.91, 9677.82, 15037.8, 907.216, 2721.65, 5745.7, 9979.38, \
15422.7, 926.647, 2779.94, 5868.76, 10193.1, 15753., 951.629, \
2854.89, 6026.98, 10467.9, 16177.7, 1378.14, 4134.43, 8728.24, \
15159.6, 23428.4, 1155.39, 3928.33, 8549.9, 15020.1, 23338.9, \
1400.35, 4201.05, 8868.88, 15403.8, 23805.9, 1419.78, 4259.34, \
8991.94, 15617.6, 24136.3, 1444.76, 4334.29, 9150.16, 15892.4, 24561.};

 vector<double> val2 = {63.1201, 189.36, 399.761, 694.321, 1073.04, 83.3555, 226.251, \
464.409, 797.831, 1226.52, 85.3267, 255.98, 540.402, 938.594, \
1450.55, 104.757, 314.272, 663.464, 1152.33, 1780.88, 129.74, 389.22, \
821.686, 1427.14, 2205.58, 227.498, 682.494, 1440.82, 2502.48, \
3867.46, 275.13, 746.78, 1532.87, 2633.38, 4048.34, 249.705, 749.114, \
1581.46, 2746.75, 4244.98, 269.135, 807.406, 1704.52, 2960.49, \
4575.3, 294.118, 882.353, 1862.75, 3235.3, 5000., 501.461, 1504.38, \
3175.92, 5516.07, 8524.84, 594.753, 1614.33, 3313.63, 5692.64, \
8751.37, 523.668, 1571., 3316.56, 5760.34, 8902.35, 543.098, 1629.3, \
3439.62, 5974.08, 9232.67, 568.081, 1704.24, 3597.85, 6248.89, \
9657.37, 885.009, 2655.03, 5605.06, 9735.1, 15045.2, 1042.23, 2828.9, \
5806.69, 9975.59, 15335.6, 907.216, 2721.65, 5745.7, 9979.37, \
15422.7, 926.647, 2779.94, 5868.76, 10193.1, 15753., 951.629, \
2854.89, 6026.98, 10467.9, 16177.7, 1378.14, 4134.43, 8728.24, \
15159.6, 23428.4, 1617.55, 4390.49, 9012.06, 15482.3, 23801.1, \
1400.35, 4201.05, 8868.88, 15403.8, 23805.9, 1419.78, 4259.34, \
8991.94, 15617.6, 24136.3, 1444.76, 4334.29, 9150.16, 15892.4, 24561.};

  for (int i = 0; i < testTrip.size(); i++) {
    TorusBasis3D basis0(testTrip[i][0], testTrip[i][1], testTrip[i][2], 0, a);
    TorusBasis3D basis1(testTrip[i][0], testTrip[i][1], testTrip[i][2], 1, a);
    TorusBasis3D basis2(testTrip[i][0], testTrip[i][1], testTrip[i][2], 2, a);
    TorusBasis3D basis3(testTrip[i][0], testTrip[i][1], testTrip[i][2], 3, a);

    CHECK(fabs((basis0.dotProd(basis0, a) - val1[i])/val1[i]) < 1e-5);
    CHECK(fabs((basis1.dotProd(basis1, a) - val1[i])/val1[i]) < 1e-5);
    CHECK(fabs((basis2.dotProd(basis2, a) - val2[i])/val2[i]) < 1e-5) << basis2.dotProd(basis2, a) << " " << val2[i];
    CHECK(fabs((basis3.dotProd(basis3, a) - val2[i])/val2[i]) < 1e-5);
    CHECK(fabs((basis0.dotProd(basis1, a)) < 1e-12));
  }

vector<double> val3 = {120.689, 362.066, 764.361, 1327.57, 2051.71, 449.444, 1348.33, \
2846.48, 4943.89, 7640.55, 997.37, 2992.11, 6316.68, 10971.1, \
16955.3, 1764.47, 5293.4, 11175., 19409.1, 29995.9, 2750.73, 8252.2, \
17421.3, 30258.1, 46762.5};

  for (int i = 0; i < testWnTwo.size(); i++) {
    TorusBasis3D basis2(testWnTwo[i][0], 0, testWnTwo[i][1]*2, 2, a);
    TorusBasis3D basis3(testWnTwo[i][0], 0, testWnTwo[i][1]*2, 3, a);
    CHECK(fabs((basis2.dotProd(basis2, a) - val3[i])/val3[i]) < 1e-5) << basis2.dotProd(basis2, a) << " " << val3[i];
    CHECK(fabs((basis3.dotProd(basis3, a) - val3[i])/val3[i]) < 1e-5);
  }

vector<double> val4 = {59.2176, 148.044, 296.088, 503.35, 769.829, 103.712, 268.813, \
543.983, 929.22, 1424.53, 295.486, 789.343, 1612.44, 2764.77, \
4246.35, 615.109, 1656.89, 3393.2, 5824.03, 8949.38, 1062.58, \
2871.46, 5886.26, 10107., 15533.6};

vector<double> val5 = {29.6088, 118.435, 266.479, 473.741, 740.22, 61.3902, 226.492, \
501.662, 886.899, 1382.2, 198.372, 692.229, 1515.32, 2667.66, \
4149.23, 426.674, 1468.46, 3204.76, 5635.59, 8760.94, 746.298, \
2555.18, 5569.98, 9790.7, 15217.3};

vector<double> val6 = {29.6088, 29.6088, 29.6088, 29.6088, 29.6088, 14.8044, 14.8044, \
14.8044, 14.8044, 14.8044, 14.8044, 14.8044, 14.8044, 14.8044, \
14.8044, 14.8044, 14.8044, 14.8044, 14.8044, 14.8044, 14.8044, \
14.8044, 14.8044, 14.8044, 14.8044};

  for (int i = 0; i < testWnTwo.size(); i++) {
    TorusBasis3D basis4(testWnTwo[i][0] - 2, 2, testWnTwo[i][1]*2, 4, a);
    TorusBasis3D basis5(testWnTwo[i][0] - 2, 2, testWnTwo[i][1]*2, 5, a);
    TorusBasis3D basis6(testWnTwo[i][0] - 2, 2, testWnTwo[i][1]*2, 6, a);
    TorusBasis3D basis7(testWnTwo[i][0] - 2, 2, testWnTwo[i][1]*2, 7, a);
    TorusBasis3D basis8(testWnTwo[i][0] - 2, testWnTwo[i][1], 0, 8, a);
    TorusBasis3D basis9(testWnTwo[i][0] - 2, testWnTwo[i][1], 0, 9, a);

    CHECK(fabs((basis4.dotProd(basis4, a) - val4[i])/val4[i]) < 1e-5);
    CHECK(fabs((basis5.dotProd(basis5, a) - val4[i])/val4[i]) < 1e-5);
    CHECK(fabs((basis6.dotProd(basis6, a) - val5[i])/val5[i]) < 1e-5) << basis6.dotProd(basis6, a) << " " << val5[i];
    CHECK(fabs((basis7.dotProd(basis7, a) - val5[i])/val5[i]) < 1e-5);
    CHECK(fabs((basis8.dotProd(basis8, a) - val6[i])/val6[i]) < 1e-5);
    CHECK(fabs((basis9.dotProd(basis9, a) - val6[i])/val6[i]) < 1e-5);
  }

  // between modes.
  for (int i = 0; i < testTrip.size(); i++) {
    TorusBasis3D basis0(testTrip[i][0], testTrip[i][1], testTrip[i][2], 0, a);
    TorusBasis3D basis1(testTrip[i][0], testTrip[i][1], testTrip[i][2], 1, a);
    TorusBasis3D basis2(testTrip[i][0], testTrip[i][1], testTrip[i][2], 2, a);
    TorusBasis3D basis3(testTrip[i][0], testTrip[i][1], testTrip[i][2], 3, a);
    TorusBasis3D basis4(testTrip[i][0], 2, testTrip[i][2], 4, a);
    TorusBasis3D basis5(testTrip[i][0], 2, testTrip[i][2], 5, a);
    TorusBasis3D basis6(testTrip[i][0], 2, testTrip[i][2], 6, a);
    TorusBasis3D basis7(testTrip[i][0], 2, testTrip[i][2], 7, a);
    TorusBasis3D basis8(testTrip[i][0] - 2, testTrip[i][1], 0, 8, a);
    TorusBasis3D basis9(testTrip[i][0] - 2, testTrip[i][1], 0, 9, a);

    CHECK(fabs((basis0.dotProd(basis1, a)) < 1e-12));
    CHECK(fabs((basis0.dotProd(basis3, a)) < 1e-12));
    CHECK(fabs((basis0.dotProd(basis5, a)) < 1e-12));
    CHECK(fabs((basis0.dotProd(basis7, a)) < 1e-12));
    CHECK(fabs((basis0.dotProd(basis8, a)) < 1e-12));
    CHECK(fabs((basis0.dotProd(basis9, a)) < 1e-12));

    CHECK(fabs((basis1.dotProd(basis2, a)) < 1e-12));
    CHECK(fabs((basis1.dotProd(basis4, a)) < 1e-12));
    CHECK(fabs((basis1.dotProd(basis6, a)) < 1e-12));
    CHECK(fabs((basis1.dotProd(basis8, a)) < 1e-12));
    CHECK(fabs((basis1.dotProd(basis9, a)) < 1e-12));

    CHECK(fabs((basis2.dotProd(basis3, a)) < 1e-12));
    CHECK(fabs((basis2.dotProd(basis5, a)) < 1e-12));
    CHECK(fabs((basis2.dotProd(basis7, a)) < 1e-12));
    CHECK(fabs((basis2.dotProd(basis8, a)) < 1e-12));
    CHECK(fabs((basis2.dotProd(basis9, a)) < 1e-12));

    CHECK(fabs((basis3.dotProd(basis4, a)) < 1e-12));
    CHECK(fabs((basis3.dotProd(basis6, a)) < 1e-12));
    CHECK(fabs((basis3.dotProd(basis8, a)) < 1e-12));
    CHECK(fabs((basis3.dotProd(basis9, a)) < 1e-12));

    CHECK(fabs((basis4.dotProd(basis5, a)) < 1e-12));
    CHECK(fabs((basis4.dotProd(basis7, a)) < 1e-12));
    CHECK(fabs((basis4.dotProd(basis8, a)) < 1e-12));
    CHECK(fabs((basis4.dotProd(basis9, a)) < 1e-12));

    CHECK(fabs((basis5.dotProd(basis6, a)) < 1e-12));
    CHECK(fabs((basis5.dotProd(basis8, a)) < 1e-12));
    CHECK(fabs((basis5.dotProd(basis9, a)) < 1e-12));
  }

  vector<vector<int>> wnn = {{2, 1, 2}, {2, 1, 4}, {2, 1, 6}, {2, 1, 8}, {2, 1, 10}, {2, 3, 2}, {2, 3, 4}, {2, 3, 6}, {2, 3, 8}, {2, 3, 10}};
  vector<double> vall = {-6.74194, -22.9226, -49.8904, -87.6453, -136.187, -1.52276, -1.52276, -1.52276, -1.52276, -1.52276};
  vector<double> val7 = {14.3479, 39.4567, 81.3047, 139.892, 215.218, -27.5267, -72.7226, \
-148.049, -253.506, -389.094};
vector<double> val8 = {5.18719, 19.1786, 42.4975, 75.144, 117.118, 3.75921, 12.6102, \
27.3618, 48.0141, 74.567};
vector<double> val12 ={1.43935, 4.18719, 8.76692, 15.1786, 23.4221, 3.24745, 9.13568, \
18.9494, 32.6886, 50.3533};
vector<double> val13 ={-20.6305, -75.3482, -166.544, -294.219, -458.372, 13.3793, 39.0099, \
81.7275, 141.532, 218.424};

  for (int i = 0; i < wnn.size(); i++) {
    TorusBasis3D basis0(wnn[i][0], wnn[i][1], wnn[i][2], 0, a);
    TorusBasis3D basis2(wnn[i][0], wnn[i][1], wnn[i][2], 2, a);
    TorusBasis3D basis4(wnn[i][0], 2, wnn[i][2], 4, a);
    TorusBasis3D basis6(wnn[i][0], 2, wnn[i][2], 6, a);
    CHECK(fabs((basis0.dotProd(basis2, a) - vall[i])/vall[i]) < 1e-5);
    CHECK(fabs((basis0.dotProd(basis4, a) - val7[i])/val7[i]) < 1e-5);
    CHECK(fabs((basis0.dotProd(basis6, a) - val8[i])/val8[i]) < 1e-5);

    CHECK(fabs((basis2.dotProd(basis4, a) - val12[i])/val12[i]) < 1e-5);
    CHECK(fabs((basis2.dotProd(basis6, a) - val13[i])/val13[i]) < 1e-5);

    CHECK(fabs(basis4.dotProd(basis6, a) < 1e-12));
  }

  vector<double> val9 = {-6.74194, -22.9226, -49.8904, -87.6453, -136.187, -1.52276, \
-1.52276, -1.52276, -1.52276, -1.52276};
  vector<double> val10 = {14.3479, 39.4567, 81.3047, 139.892, 215.218, -27.5267, -72.7226, \
-148.049, -253.506, -389.094};
  vector<double> val11 ={5.18719, 19.1786, 42.4975, 75.144, 117.118, 3.75921, 12.6102, \
27.3618, 48.0141, 74.567};

vector<double> val14 = {1.43935, 4.18719, 8.76692, 15.1786, 23.4221, 3.24745, 9.13568, \
18.9494, 32.6886, 50.3533};
vector<double> val15 = {-20.6305, -75.3482, -166.544, -294.219, -458.372, 13.3793, 39.0099, \
81.7275, 141.532, 218.424};

  for (int i = 0; i < wnn.size(); i++) {
    TorusBasis3D basis1(wnn[i][0], wnn[i][1], wnn[i][2], 1, a);
    TorusBasis3D basis3(wnn[i][0], wnn[i][1], wnn[i][2], 3, a);
    TorusBasis3D basis5(wnn[i][0], 2, wnn[i][2], 5, a);
    TorusBasis3D basis7(wnn[i][0], 2, wnn[i][2], 7, a);
    //TorusBasis3D basis6(wnn[i][0], 2, wnn[i][2], 6, a);
    CHECK(fabs((basis1.dotProd(basis3, a) - val9[i])/val9[i]) < 1e-5);
    CHECK(fabs((basis1.dotProd(basis5, a) - val10[i])/val10[i]) < 1e-5);
    CHECK(fabs((basis1.dotProd(basis7, a) - val11[i])/val11[i]) < 1e-5);

    CHECK(fabs((basis3.dotProd(basis5, a) - val14[i])/val14[i]) < 1e-5);
    CHECK(fabs((basis3.dotProd(basis7, a) - val15[i])/val15[i]) < 1e-5);

    CHECK(fabs(basis5.dotProd(basis7, a) < 1e-12));
  }

vector<double> val16 = {3.28987, 3.28987, 3.28987, 3.28987, 3.28987, 0, \
0, 0, 0, 0};
  for (int i = 0; i < wnn.size(); i++) {
    TorusBasis3D basis8(wnn[i][0] - 2, wnn[i][1], 0, 8, a);
    TorusBasis3D basis9(wnn[i][0] - 2, wnn[i][1], 0, 9, a);
    //TorusBasis3D basis6(wnn[i][0], 2, wnn[i][2], 6, a);
    CHECK(fabs((basis8.dotProd(basis9, a) - val16[i])) < 1e-5) << basis8.dotProd(basis9, a) << " " << basis8.dotProd(basis9, a);  
  }

  for (int i = 0; i < wnn.size(); i++) {
    TorusBasis3D basis0(wnn[i][0], wnn[i][1], wnn[i][2], 0, a);
    TorusBasis3D basis2(wnn[i][0], wnn[i][1], wnn[i][2] + 2, 2, a);
    TorusBasis3D basis4(wnn[i][0], 2, wnn[i][2] + 2, 4, a);
    TorusBasis3D basis6(wnn[i][0], 2, wnn[i][2] + 2, 6, a);

    CHECK(fabs(basis0.dotProd(basis2, a) < 1e-12));
    CHECK(fabs(basis0.dotProd(basis4, a) < 1e-12));
    CHECK(fabs(basis0.dotProd(basis6, a) < 1e-12));
  }

}

}  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  
  testDotProd();
  
  return 0;
}