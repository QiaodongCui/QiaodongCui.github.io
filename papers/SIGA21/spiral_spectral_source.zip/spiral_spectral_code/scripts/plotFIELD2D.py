import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt
import struct
import matplotlib.cm as cm 
import sys

def main(argv):
	fin = open(argv[0], "rb")
	xres = struct.unpack('i', fin.read(4))[0]
	yres = struct.unpack('i', fin.read(4))[0]
	field = np.fromfile(fin, dtype=np.float64, count=xres*yres).reshape([xres, yres])
	x = np.linspace(-1., 1., xres) 
	y = np.linspace(-1., 1., yres) 
	X, Y = np.meshgrid(y, x)
	#plt.axes().set_aspect('equal', 'datalim')
	normalize = matplotlib.colors.Normalize(vmin=field.min(), vmax=field.max())
	plt.pcolormesh(X, Y, field, norm=normalize, cmap = cm.gray_r) 
	plt.show()
	#plt.savefig("./div.png", bbox_inches='tight')


if __name__ == "__main__":
  main(sys.argv[1:])