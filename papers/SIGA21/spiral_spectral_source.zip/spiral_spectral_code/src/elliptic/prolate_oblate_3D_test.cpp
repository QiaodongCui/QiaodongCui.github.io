#include <Eigen/Eigen>
#include <cfloat>
#include <fstream>
#include <sstream>
#include <glog/logging.h>
#include <memory>
#include <unordered_set>
#include <unordered_map>

#include "common/query_table.h"
#include "common/basic_function.h"
#include "elliptic/elliptic_basis_2D.h"
#include "elliptic/prolate_oblate_3D.h"
#include "polar_2D/sphere_basis_2D_all.h"
#include "sphere_3D/sphere_basis_3D.h"
#include "util/timer.h"

std::vector<std::vector<int>> testWnTripe = {{1, 2, 2}, {1, 2, 4}, {1, 2, 6}, {1, 2, 8}, {1, 2, 10}, {1, 4, 
  2}, {1, 4, 4}, {1, 4, 6}, {1, 4, 8}, {1, 4, 10}, {1, 6, 2}, {1, 6, 
  4}, {1, 6, 6}, {1, 6, 8}, {1, 6, 10}, {1, 8, 2}, {1, 8, 4}, {1, 8, 
  6}, {1, 8, 8}, {1, 8, 10}, {1, 10, 2}, {1, 10, 4}, {1, 10, 6}, {1, 
  10, 8}, {1, 10, 10}, {2, 2, 2}, {2, 2, 4}, {2, 2, 6}, {2, 2, 8}, {2,
   2, 10}, {2, 4, 2}, {2, 4, 4}, {2, 4, 6}, {2, 4, 8}, {2, 4, 10}, {2,
   6, 2}, {2, 6, 4}, {2, 6, 6}, {2, 6, 8}, {2, 6, 10}, {2, 8, 2}, {2, 
  8, 4}, {2, 8, 6}, {2, 8, 8}, {2, 8, 10}, {2, 10, 2}, {2, 10, 4}, {2,
   10, 6}, {2, 10, 8}, {2, 10, 10}, {3, 2, 2}, {3, 2, 4}, {3, 2, 
  6}, {3, 2, 8}, {3, 2, 10}, {3, 4, 2}, {3, 4, 4}, {3, 4, 6}, {3, 4, 
  8}, {3, 4, 10}, {3, 6, 2}, {3, 6, 4}, {3, 6, 6}, {3, 6, 8}, {3, 6, 
  10}, {3, 8, 2}, {3, 8, 4}, {3, 8, 6}, {3, 8, 8}, {3, 8, 10}, {3, 10,
   2}, {3, 10, 4}, {3, 10, 6}, {3, 10, 8}, {3, 10, 10}, {4, 2, 2}, {4,
   2, 4}, {4, 2, 6}, {4, 2, 8}, {4, 2, 10}, {4, 4, 2}, {4, 4, 4}, {4, 
  4, 6}, {4, 4, 8}, {4, 4, 10}, {4, 6, 2}, {4, 6, 4}, {4, 6, 6}, {4, 
  6, 8}, {4, 6, 10}, {4, 8, 2}, {4, 8, 4}, {4, 8, 6}, {4, 8, 8}, {4, 
  8, 10}, {4, 10, 2}, {4, 10, 4}, {4, 10, 6}, {4, 10, 8}, {4, 10, 
  10}, {5, 2, 2}, {5, 2, 4}, {5, 2, 6}, {5, 2, 8}, {5, 2, 10}, {5, 4, 
  2}, {5, 4, 4}, {5, 4, 6}, {5, 4, 8}, {5, 4, 10}, {5, 6, 2}, {5, 6, 
  4}, {5, 6, 6}, {5, 6, 8}, {5, 6, 10}, {5, 8, 2}, {5, 8, 4}, {5, 8, 
  6}, {5, 8, 8}, {5, 8, 10}, {5, 10, 2}, {5, 10, 4}, {5, 10, 6}, {5, 
  10, 8}, {5, 10, 10}};

std::vector<std::vector<int>> testWnTwo = {{1, 2}, {1, 4}, {1, 6}, {1, 8}, {1, 10}, {2, 2}, {2, 4}, {2, 6}, {2, 
8}, {2, 10}, {3, 2}, {3, 4}, {3, 6}, {3, 8}, {3, 10}, {4, 2}, {4, 
4}, {4, 6}, {4, 8}, {4, 10}, {5, 2}, {5, 4}, {5, 6}, {5, 8}, {5, 
10}};

std::vector<double> val1 = {8.20472, 6.28275, 5.92683, 5.80226, 5.7446, 1.93436, 1.27076, \
1.14787, 1.10486, 1.08496, 0.851889, 0.678428, 0.646305, 0.635062, \
0.629858, 0.593817, 0.488604, 0.46912, 0.462301, 0.459144, 0.467095, \
0.39845, 0.385738, 0.381289, 0.37923, 3.34891, 2.57178, 2.42786, \
2.37749, 2.35418, 0.76074, 0.492114, 0.442369, 0.424958, 0.416899, \
0.321802, 0.251444, 0.238415, 0.233854, 0.231744, 0.216194, 0.173577, \
0.165685, 0.162923, 0.161645, 0.16436, 0.13657, 0.131423, 0.129622, \
0.128789, 13.616, 10.375, 9.77483, 9.56477, 9.46754, 2.98256, \
1.86562, 1.65878, 1.58639, 1.55288, 1.18579, 0.894442, 0.840488, \
0.821604, 0.812863, 0.757157, 0.579996, 0.547189, 0.535706, 0.530392, \
0.545701, 0.430118, 0.408714, 0.401222, 0.397755, 12.3073, 9.38343, \
8.84197, 8.65246, 8.56475, 2.66161, 1.65366, 1.46701, 1.40168, \
1.37144, 1.04029, 0.777225, 0.728509, 0.711459, 0.703567, 0.652535, \
0.492635, 0.463024, 0.45266, 0.447863, 0.461254, 0.356949, 0.337634, \
0.330873, 0.327744, 25.1947, 19.1719, 18.0565, 17.6662, 17.4855, \
5.3645, 3.28971, 2.90549, 2.77101, 2.70876, 2.04139, 1.5004, 1.40022, \
1.36515, 1.34892, 1.24776, 0.918618, 0.857667, 0.836334, 0.82646, \
0.855711, 0.640988, 0.601224, 0.587307, 0.580865};
std::vector<double> val2 = {5.83232, 1.84022, 1.07355, 0.769791, 0.623292, 2.33853, 0.713165, \
0.399085, 0.274832, 0.214929, 9.25847, 2.69144, 1.42914, 0.927067, \
0.684805, 8.31648, 2.38573, 1.24387, 0.789859, 0.570804, 16.8547, \
4.73933, 2.40868, 1.4807, 1.03286};

std::vector<int> testWnOne = {1, 2, 3, 4, 5};
std::vector<double> val3 = {0.784318, 4.46826, 4.73727, 9.69407, 11.8539};
std::vector<double> val4 = {1.12962, 4.93068, 6.86784, 12.4249, 17.1183};
std::vector<double> val5 = {1.20662, 0.905987, 0.891282, 0.883385, 0.879544, 0.404797, 0.295474, \
0.293363, 0.291227, 0.290136, 0.811368, 0.610749, 0.600349, 0.594945, \
0.592327, 0.601303, 0.447089, 0.441226, 0.437558, 0.435746, 0.728549, \
0.546153, 0.537566, 0.532851, 0.530552};
std::vector<std::vector<int>> sixWn = {{5, 40, 14, 5, 48, 6}, {12, 10, 56, 27, 2, 32}, {20, 60, 20, 30, 50, 
20}, {14, 42, 36, 21, 26, 54}, {30, 36, 2, 30, 10, 22}, {7, 38, 40, 
1, 12, 8}, {17, 54, 6, 28, 34, 12}, {7, 16, 22, 22, 20, 58}, {9, 18,
 36, 10, 4, 28}, {17, 2, 20, 12, 60, 14}, {4, 52, 6, 19, 4, 18}, {3,
 26, 20, 27, 18, 8}, {23, 56, 52, 11, 22, 40}, {24, 22, 4, 15, 46, 
60}, {26, 10, 50, 27, 42, 48}, {14, 32, 30, 8, 20, 14}, {25, 14, 18,
 28, 2, 56}, {8, 30, 4, 8, 44, 38}, {27, 2, 52, 21, 8, 22}, {25, 42,
 60, 20, 26, 54}, {13, 20, 60, 22, 56, 26}, {4, 36, 18, 8, 30, 
32}, {1, 16, 26, 11, 42, 38}, {24, 42, 38, 23, 52, 4}, {4, 18, 8, 
11, 16, 46}, {29, 60, 26, 27, 38, 50}, {21, 12, 24, 14, 42, 34}};
std::vector<double> val6 = {0., 0., 0., 0., 0.0165222, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
std::vector<double> val7 = {0., 0., 0., 0., 0.000615346, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
std::vector<double> val8 = {0, -0.567678, 0, -0.0163375, 0, -0.00195124, -0.00607323, 0, \
0.270145, 39.4571, 0, -0.00137355, 0, -0.0663998, 14.5653, 0, \
-3.37546, -0.00165392, 174.481, -0.0383559, 0, 0, 0, -0.107529, \
-0.0447391, 0, 0};
std::vector<double> val9 = {8.14731, 5.66271, 5.2026, 5.04156, 4.96702, 1.963, 1.16695, 1.01953, \
0.967937, 0.944055, 0.793729, 0.598886, 0.562804, 0.550175, 0.54433, \
0.565785, 0.434538, 0.410233, 0.401726, 0.397789, 0.43592, 0.351975, \
0.33643, 0.330989, 0.32847, 3.3204, 2.29557, 2.10579, 2.03936, \
2.00862, 0.7733, 0.446596, 0.386095, 0.36492, 0.355119, 0.296751, \
0.216917, 0.202133, 0.196959, 0.194564, 0.204458, 0.150354, 0.140335, \
0.136828, 0.135205, 0.151207, 0.116716, 0.110329, 0.108093, 0.107059, \
13.5388, 9.41388, 8.65001, 8.38265, 8.2589, 3.06, 1.73486, 1.48946, \
1.40357, 1.36382, 1.12434, 0.799424, 0.739253, 0.718194, 0.708446, \
0.742813, 0.524767, 0.484388, 0.470255, 0.463714, 0.526399, 0.386761, \
0.360902, 0.351851, 0.347662, 12.2349, 8.49536, 7.80285, 7.56048, \
7.44829, 2.73411, 1.53415, 1.31193, 1.23416, 1.19816, 0.984846, \
0.690772, 0.636314, 0.617254, 0.608432, 0.640577, 0.442933, 0.406333, \
0.393522, 0.387593, 0.444698, 0.318214, 0.294791, 0.286593, 0.282798, \
25.0621, 17.4199, 16.0047, 15.5094, 15.2801, 5.52617, 3.06984, \
2.61497, 2.45576, 2.38207, 1.94695, 1.34449, 1.23293, 1.19388, \
1.1758, 1.23947, 0.835436, 0.760616, 0.734428, 0.722307, 0.838317, \
0.579511, 0.531584, 0.51481, 0.507046};
std::vector<double> val10 ={5.31467, 1.62405, 0.969252, 0.686125, 0.552123, 2.11001, 0.618454, \
0.353846, 0.238843, 0.184548, 8.50504, 2.39938, 1.31107, 0.840798, \
0.61787, 7.6229, 2.11802, 1.13676, 0.712152, 0.510983, 15.5112, \
4.23323, 2.22018, 1.35003, 0.937403};
std::vector<double> val11 = {1.25331, 6.04317, 7.86526, 15.2553, 20.2971};
std::vector<double> val12 = {1.50742, 6.05118, 9.11536, 16.3323, 23.062};
std::vector<double> val13 = {1.17273, 1.00839, 0.95148, 0.936057, 0.929343, 0.388846, 0.3481, \
0.324649, 0.318702, 0.316156, 0.789925, 0.678548, 0.640443, 0.630095, \
0.625589, 0.582253, 0.507803, 0.477167, 0.469076, 0.465577, 0.707939, \
0.611072, 0.575938, 0.566485, 0.562378};
std::vector<double> val14 = {0., 0., 0., 0., 0.0139087, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
std::vector<double> val15 = {0., 0., 0., 0., 0.000524469, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., \
0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.};
std::vector<double> val16 = {0, -0.6825, 0, -0.0176265, 0, -0.00218442, -0.00658055, 0, 0.308501, \
42.4232, 0, -0.00156791, 0, -0.0703638, 19.9244, 0, -3.52208, \
-0.00142487, 195.139, -0.041389, 0, 0, 0, -0.123822, -0.047951, 0, 0};

namespace {

// prolate
void collectInnerPattern() {
	const double b = 0.9;
	const bool is_prolate = false;

	const int phiK_ = 5, thetaK_ = 5, rK_ = 5;
	bool boundaryCnd_ = true;

	int offsetOdd = !boundaryCnd_ ? 1 : 0;
	// half integer for dirichlet bc
	int offset = boundaryCnd_ ? 1 : 0;
	std::vector<prolate3DPtr> tempBuffer;

	// allocate Phi^0, Psi^2, Psi^5
	for (int i3 = 1; i3 < phiK_; i3++) {
		if (i3 == 1) {
			// Psi^5
			for (int i1 = 0; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 5, b, is_prolate)));
			}
			// Psi^2
			for (int i2 = 0; i2 < thetaK_; i2++)
				for (int i1 = 1; i1 < rK_; i1++) {
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, 2, 2, b, is_prolate)));
				}
		}

		// Phi^0
		for (int i2 = 1; i2 < thetaK_; i2++) {
			for (int i1 = 1; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, i3*2, 0, b, is_prolate)));
			}
		}
	}

	// allocate Phi^1, Psi^3, Psi^6
	for (int i3 = 1; i3 < phiK_; i3++) {
		if (i3 == 1) {
			// Psi^6
			for (int i1 = 0; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 6, b, is_prolate)));
			}
			// Psi^3
			for (int i2 = 0; i2 < thetaK_; i2++)
				for (int i1 = 1; i1 < rK_; i1++) {
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, 2, 3, b, is_prolate)));
				}
		}
		// Phi^1
		for (int i2 = 1; i2 < thetaK_; i2++)
			for (int i1 = 1; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, i3*2, 1, b, is_prolate)));
			}
		}

	// allocate Psi^4
	{
		for (int i1 = 0; i1 < rK_; i1++) {
			tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 0, 0, 4, b, is_prolate)));
		}
	}

	// Phi^7
  {
		for (int i2 = 1; i2 < thetaK_; i2++)
			for (int i1 = 1; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2, i2*2, 0, 7, b, is_prolate)));
			}
	}
	
	std::unordered_set<uint64_t> set;

	for (int i = 0; i < tempBuffer.size(); i++)
		for (int j = i; j < tempBuffer.size(); j++) {
			tempBuffer[i]->dotProdPattern(*tempBuffer[j], false, set);
		}

	EllipticBasis2D::exportNumericalPatternTensor(set, "./oblate3D_dot_2D.txt");

	set.clear();
	for (int i = 0; i < tempBuffer.size(); i++)
		for (int j = i; j < tempBuffer.size(); j++) {
			tempBuffer[i]->dotProdPattern(*tempBuffer[j], true, set);
		}
	EllipticBasis2D::exportNumericalPattern1D(set, "./oblate3D_dot_1D.txt");
}

void checkFile() {
	std::ifstream in("Dot2D09_l1.bin");
	int totalsize = 1200000/sizeof(double);
	double data[totalsize];
	in.read((char*)(data), sizeof(double)*totalsize);
	double min = FLT_MAX;
	double max = -FLT_MAX;

	for (int i = 0; i < totalsize; i++) {
		if (data[i] > max)
			max = data[i];
		if (data[i] < min)
			min = data[i];
	}
	LOG(INFO) << max << " " << min;
}
const std::string folder = "./Tensor/tables/prolate3D/";

void testDotProdMode0() {
	const double b = 0.9;
  IntTable1DData tabData(b);
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  std::shared_ptr<TensorTable2D> TensorQueryTable_;
  tab1D.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                        folder + "prolate3D_dot_1D_val.bin",
                                        folder + "prolate3D_dot_1D.txt"));
  tabData.setIntTable(tab1D);
  
  TensorQueryTable_.reset(new TensorTable2D(folder + "TensorListWn.csv", b, folder + "blistTableName.txt", 
                                              folder + "prolate3D_dot_2D.txt", false));
	tabData.set2DTable(TensorQueryTable_);

	//ProlateOblate3D basis2(2, 20, 2, 2, b, true);
 	//ProlateOblate3D basis5(2, 2, 2, 5, b, true);
 	//LOG(INFO) << basis2.dotProd(basis5, tabData);
	/*EllipticFactor ef(0, 1, 1, 1.0);
	BasicFunc rfun(COS, R, 4, 1.0);
	BasicFunc tfun(SIN, T, 2, 1.0);
	LOG(INFO) << ProlateOblate3D::integrateRT(ef,rfun,tfun, tabData);*/

	//Timer timer_;
	//timer_= Timer();
	//timer_.Reset();
	for (int i = 0; i < testWnTripe.size(); i++) {
		ProlateOblate3D basis(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 0, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val1[i]) < 1e-4) << val1[i] << " " << basis.dotProd(basis, tabData) 
			<< " " << testWnTripe[i][0] << " " << testWnTripe[i][1] << " " << testWnTripe[i][2];
	}
	for (int i = 0; i < testWnTripe.size(); i++) {
		ProlateOblate3D basis(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 1, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val1[i]) < 1e-4) << val1[i] << " " << basis.dotProd(basis, tabData)
			<< " " << testWnTripe[i][0] << " " << testWnTripe[i][1] << " " << testWnTripe[i][2];
	}
	for (int i = 0; i < testWnTwo.size(); i++) {
		ProlateOblate3D basis(testWnTwo[i][0], testWnTwo[i][1], 2, 2, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val2[i]) < 1e-4) << val2[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnTwo.size(); i++) {
		ProlateOblate3D basis(testWnTwo[i][0], testWnTwo[i][1], 2, 3, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val2[i]) < 1e-4) << val2[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnOne.size(); i++) {
		ProlateOblate3D basis(testWnOne[i], 0, 0, 4, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val3[i]) < 1e-4) << val3[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnOne.size(); i++) {
		ProlateOblate3D basis(testWnOne[i], 2, 2, 5, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val4[i]) < 1e-4) << val4[i] << " " << basis.dotProd(basis, tabData) << " " << testWnOne[i];
	}
	for (int i = 0; i < testWnOne.size(); i++) {
		ProlateOblate3D basis(testWnOne[i], 2, 2, 6, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val4[i]) < 1e-4) << val4[i] << " " << basis.dotProd(basis, tabData) << " " << testWnOne[i];
	}
	for (int i = 0; i < testWnTwo.size(); i++) {
		ProlateOblate3D basis(testWnTwo[i][0], testWnTwo[i][1], 0, 7, b, true);
		CHECK(fabs(basis.dotProd(basis, tabData) - val5[i]) < 1e-4) << val5[i] << " " << basis.dotProd(basis, tabData);
	}

	// dot with other modes	    
  for (int i = 0; i < testWnTripe.size(); i++) {
    ProlateOblate3D basis1(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 0, b, true);
    ProlateOblate3D basis2(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 1, b, true);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }

  for (int i = 0; i < sixWn.size(); i++) {
    ProlateOblate3D basis1(sixWn[i][0], sixWn[i][1], sixWn[i][2], 0, b, true);
    ProlateOblate3D basis2(sixWn[i][3], sixWn[i][4], 2, 2, b, true);
    ProlateOblate3D basis3(sixWn[i][3], sixWn[i][4], 2, 3, b, true);
    ProlateOblate3D basis4(sixWn[i][3], 0, 0, 4, b, true);
    ProlateOblate3D basis5(sixWn[i][3], 2, 2, 5, b, true);
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, true);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, true);

    CHECK(fabs(basis1.dotProd(basis2, tabData) - val6[i]) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis5, tabData) - val7[i]) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis3, tabData) - 0) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis4, tabData) - 0) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis6, tabData) - 0) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis7, tabData) - 0) < 1e-5);
  }

  for (int i = 0; i < sixWn.size(); i++) {
  	ProlateOblate3D basis2(sixWn[i][0], sixWn[i][1], 2, 2, b, true);
    ProlateOblate3D basis3(sixWn[i][3], sixWn[i][4], 2, 3, b, true);
    ProlateOblate3D basis4(sixWn[i][3], 0, 0, 4, b, true);
    ProlateOblate3D basis5(sixWn[i][3], 2, 2, 5, b, true);
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, true);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, true);

    CHECK(fabs(basis2.dotProd(basis3, tabData) - 0) < 1e-5);
    CHECK(fabs(basis2.dotProd(basis4, tabData) - 0) < 1e-5);
    //LOG(INFO) << basis2.dotProd(basis5, tabData);
    CHECK(fabs(basis2.dotProd(basis5, tabData) - val8[i]) < 1e-3) << val8[i];
    CHECK(fabs(basis2.dotProd(basis6, tabData) - 0) < 1e-5);
    CHECK(fabs(basis2.dotProd(basis7, tabData) - 0) < 1e-5);
  }

  for (int i = 0; i < sixWn.size(); i++) {
    ProlateOblate3D basis4(sixWn[i][0], 0, 0, 4, b, true);
    ProlateOblate3D basis5(sixWn[i][3], 2, 2, 5, b, true);
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, true);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, true);

    CHECK(fabs(basis4.dotProd(basis5, tabData) - 0) < 1e-5) << val8[i];
    CHECK(fabs(basis4.dotProd(basis6, tabData) - 0) < 1e-5);
    CHECK(fabs(basis4.dotProd(basis7, tabData) - 0) < 1e-5);
  }

  for (int i = 0; i < sixWn.size(); i++) {
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, true);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, true);
    CHECK(fabs(basis6.dotProd(basis7, tabData) - 0) < 1e-5);
  }

	//LOG(INFO) << timer_.ElapsedTimeInSeconds();
}

void testDotProdMode1() {
	const double b = 0.9;
  IntTable1DData tabData(b);
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  std::shared_ptr<TensorTable2D> TensorQueryTable_;
  tab1D.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                        folder + "oblate3D_dot_1D_val.bin",
                                        folder + "oblate3D_dot_1D.txt"));
  tabData.setIntTable(tab1D);
  
  TensorQueryTable_.reset(new TensorTable2D(folder + "TensorListWn.csv", b, folder + "blistTableOb.txt", 
                                              folder + "oblate3D_dot_2D.txt", false));
	tabData.set2DTable(TensorQueryTable_);

	ProlateOblate3D basis2(2, 2, 2, 5, b, false);
 	ProlateOblate3D basis5(2, 2, 2, 5, b, false);
 	LOG(INFO) << basis2.dotProd(basis5, tabData);
 	for (int i = 0; i < testWnTripe.size(); i++) {
		ProlateOblate3D basis(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 0, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val9[i]) < 1e-4) << val9[i] << " " << basis.dotProd(basis, tabData) 
			<< " " << testWnTripe[i][0] << " " << testWnTripe[i][1] << " " << testWnTripe[i][2];
	}
 	for (int i = 0; i < testWnTripe.size(); i++) {
		ProlateOblate3D basis(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 1, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val9[i]) < 1e-4) << val9[i] << " " << basis.dotProd(basis, tabData) 
			<< " " << testWnTripe[i][0] << " " << testWnTripe[i][1] << " " << testWnTripe[i][2];
	}
	for (int i = 0; i < testWnTwo.size(); i++) {
		ProlateOblate3D basis(testWnTwo[i][0], testWnTwo[i][1], 2, 2, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val10[i]) < 1e-4) << val10[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnTwo.size(); i++) {
		ProlateOblate3D basis(testWnTwo[i][0], testWnTwo[i][1], 2, 3, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val10[i]) < 1e-4) << val10[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnOne.size(); i++) {
		ProlateOblate3D basis(testWnOne[i], 0, 0, 4, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val11[i]) < 1e-4) << val11[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnOne.size(); i++) {
		ProlateOblate3D basis(testWnOne[i], 2, 2, 5, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val12[i]) < 1e-4) << val12[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnOne.size(); i++) {
		ProlateOblate3D basis(testWnOne[i], 2, 2, 6, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val12[i]) < 1e-4) << val12[i] << " " << basis.dotProd(basis, tabData);
	}
	for (int i = 0; i < testWnTwo.size(); i++) {
		ProlateOblate3D basis(testWnTwo[i][0], testWnTwo[i][1], 0, 7, b, false);
		CHECK(fabs(basis.dotProd(basis, tabData) - val13[i]) < 1e-4) << val13[i] << " " << basis.dotProd(basis, tabData);
	}

	// dot with other modes	    
  for (int i = 0; i < testWnTripe.size(); i++) {
    ProlateOblate3D basis1(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 0, b, false);
    ProlateOblate3D basis2(testWnTripe[i][0], testWnTripe[i][1], testWnTripe[i][2], 1, b, false);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }

  for (int i = 0; i < sixWn.size(); i++) {
    ProlateOblate3D basis1(sixWn[i][0], sixWn[i][1], sixWn[i][2], 0, b, false);
    ProlateOblate3D basis2(sixWn[i][3], sixWn[i][4], 2, 2, b, false);
    ProlateOblate3D basis3(sixWn[i][3], sixWn[i][4], 2, 3, b, false);
    ProlateOblate3D basis4(sixWn[i][3], 0, 0, 4, b, false);
    ProlateOblate3D basis5(sixWn[i][3], 2, 2, 5, b, false);
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, false);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, false);

    CHECK(fabs(basis1.dotProd(basis2, tabData) - val14[i]) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis5, tabData) - val15[i]) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis3, tabData) - 0) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis4, tabData) - 0) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis6, tabData) - 0) < 1e-5);
    CHECK(fabs(basis1.dotProd(basis7, tabData) - 0) < 1e-5);
  }

    for (int i = 0; i < sixWn.size(); i++) {
  	ProlateOblate3D basis2(sixWn[i][0], sixWn[i][1], 2, 2, b, false);
    ProlateOblate3D basis3(sixWn[i][3], sixWn[i][4], 2, 3, b, false);
    ProlateOblate3D basis4(sixWn[i][3], 0, 0, 4, b, false);
    ProlateOblate3D basis5(sixWn[i][3], 2, 2, 5, b, false);
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, false);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, false);

    CHECK(fabs(basis2.dotProd(basis3, tabData) - 0) < 1e-5);
    CHECK(fabs(basis2.dotProd(basis4, tabData) - 0) < 1e-5);
    //LOG(INFO) << basis2.dotProd(basis5, tabData);
    CHECK(fabs(basis2.dotProd(basis5, tabData) - val16[i]) < 1e-4) << val16[i];
    CHECK(fabs(basis2.dotProd(basis6, tabData) - 0) < 1e-5);
    CHECK(fabs(basis2.dotProd(basis7, tabData) - 0) < 1e-5);
  }

  for (int i = 0; i < sixWn.size(); i++) {
    ProlateOblate3D basis4(sixWn[i][0], 0, 0, 4, b, false);
    ProlateOblate3D basis5(sixWn[i][3], 2, 2, 5, b, false);
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, false);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, false);

    CHECK(fabs(basis4.dotProd(basis5, tabData) - 0) < 1e-5);
    CHECK(fabs(basis4.dotProd(basis6, tabData) - 0) < 1e-5);
    CHECK(fabs(basis4.dotProd(basis7, tabData) - 0) < 1e-5);
  }

  for (int i = 0; i < sixWn.size(); i++) {
    ProlateOblate3D basis6(sixWn[i][3], 2, 2, 6, b, false);
    ProlateOblate3D basis7(sixWn[i][3], sixWn[i][4], 0, 7, b, false);
    CHECK(fabs(basis6.dotProd(basis7, tabData) - 0) < 1e-5);
  }
}


// prolate
void collectTensorPattern() {
	const double b = 0.9;
	const bool is_prolate = false;

	const int phiK_ = 4, thetaK_ = 4, rK_ = 4;
	bool boundaryCnd_ = true;

	int offsetOdd = !boundaryCnd_ ? 1 : 0;
	// half integer for dirichlet bc
	int offset = boundaryCnd_ ? 1 : 0;
	std::vector<prolate3DPtr> tempBuffer;

	// allocate Phi^0, Psi^2, Psi^5
	for (int i3 = 1; i3 < phiK_; i3++) {
		if (i3 == 1) {
			// Psi^5
			for (int i1 = 0; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 5, b, is_prolate)));
			}
			// Psi^2
			for (int i2 = 0; i2 < thetaK_; i2++)
				for (int i1 = 1; i1 < rK_; i1++) {
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, 2, 2, b, is_prolate)));
				}
		}

		// Phi^0
		for (int i2 = 1; i2 < thetaK_; i2++) {
			for (int i1 = 1; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, i3*2, 0, b, is_prolate)));
			}
		}
	}

	// allocate Phi^1, Psi^3, Psi^6
	for (int i3 = 1; i3 < phiK_; i3++) {
		if (i3 == 1) {
			// Psi^6
			for (int i1 = 0; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 2, 2, 6, b, is_prolate)));
			}
			// Psi^3
			for (int i2 = 0; i2 < thetaK_; i2++)
				for (int i1 = 1; i1 < rK_; i1++) {
					tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, 2, 3, b, is_prolate)));
				}
		}
		// Phi^1
		for (int i2 = 1; i2 < thetaK_; i2++)
			for (int i1 = 1; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 - offsetOdd, i2*2, i3*2, 1, b, is_prolate)));
			}
		}

	// allocate Psi^4
	{
		for (int i1 = 0; i1 < rK_; i1++) {
			tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2 + offset, 0, 0, 4, b, is_prolate)));
		}
	}

	// Phi^7
  {
		for (int i2 = 1; i2 < thetaK_; i2++)
			for (int i1 = 1; i1 < rK_; i1++) {
				tempBuffer.push_back(prolate3DPtr(new ProlateOblate3D(i1*2, i2*2, 0, 7, b, is_prolate)));
			}
	}
	
	LOG(INFO) << tempBuffer.size();

	std::unordered_set<uint64_t> set;
	for (int i = 0; i < tempBuffer.size(); i++) {
		LOG(INFO) << i;
		for (int g = 0; g < tempBuffer.size(); g++) {
			for (int h = 0; h < tempBuffer.size(); h++) {
				tempBuffer[i]->computeTensorPattern(*tempBuffer[g], *tempBuffer[h], set);
			}
		}
	}

	LOG(INFO) << set.size();
	EllipticBasis2D::exportNumericalPatternTensor(set, "./oblate_tensor.txt");

}

void splitTensorTable() {
	std::ifstream in("./oblate_tensor.txt");	
	int hpow, sqrtPow, rpow;
  int rType, tType;
  std::ofstream out1("./oblate3D_tensor_1D.txt");
  std::unordered_set<int> hpowset;

  // std::ofstream out2("./oblate_tensor_2D.txt");
  std::vector<std::string> splitStr;
	while (in >> hpow && in >> sqrtPow && in >> rpow && in >> rType && in >> tType) {
    if (hpow == 0)
    	out1 << hpow << " " << sqrtPow << " " << rpow << " " << rType << " " << tType << "\n";
    else {
    	std::stringstream ss;
    	ss << hpow << " " << sqrtPow << " " << rpow << " " << rType << " " << tType << "\n";
    	splitStr.push_back(ss.str());
    }
    hpowset.insert(hpow);
  }
  out1.close();
  // out2.close();
  int fidx = 1;
  std::string outName = "./oblate_tensor_2D_";
  std::stringstream ss;
  ss << outName << fidx << ".txt";
  std::ofstream out2(ss.str());
  int counter = 1;
  for (int i = 0; i < splitStr.size(); i++) {
  	out2 << splitStr[i];
  	counter ++;
  	if (counter > 50) {
  		fidx ++;
  		ss.str("");
  		ss << outName << fidx << ".txt";
  		out2.close();
  		out2.open(ss.str());
  		counter = 1;
  	}
  }

  out2.close();

  for (const auto& a : hpowset)
  	LOG(INFO) << a;
}

void collectPower2() {
	std::ifstream in("./oblate_tensor.txt");	
	int hpow, sqrtPow, rpow;
  int rType, tType;
  std::ofstream out1("./oblate_tensor_pow2.txt");

  // std::ofstream out2("./oblate_tensor_2D.txt");
  std::vector<std::string> splitStr;
	while (in >> hpow && in >> sqrtPow && in >> rpow && in >> rType && in >> tType) {
    if (hpow == -2)
    	out1 << hpow << " " << sqrtPow << " " << rpow << " " << rType << " " << tType << "\n";
  }
}

void testTensor() {
	const double b_ = 0.9;

  std::shared_ptr<IntegrationTable1DPtn> dotTable1D_;
  std::shared_ptr<TensorTable2D> dotTable2D_;
  std::shared_ptr<IntTable1DData> dotData_;

  std::shared_ptr<IntegrationTable1DPtn> tensorTable1D_;
  std::shared_ptr<TensorTable2D> tensorTable2D_;
  std::shared_ptr<IntTable1DData> tensorData_;

	dotTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                        folder + "prolate3D_dot_1D_val.bin",
                                        folder + "prolate3D_dot_1D.txt"));
  dotTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "blistTableName.txt", 
                                              folder + "prolate3D_dot_2D.txt", false));
	dotData_.reset(new IntTable1DData(b_));
	dotData_->setIntTable(dotTable1D_);
	dotData_->set2DTable(dotTable2D_);

	tensorTable1D_.reset(new IntegrationTable1DPtn(folder + "bList.csv", folder + "k1x2Range.csv",
                                        folder + "prolate3D_tensor_1D_val.bin",
                                        folder + "prolate3D_tensor_1D.txt"));
	tensorTable2D_.reset(new TensorTable2D(folder + "TensorListWn.csv", b_, folder + "pro3DTensorName.txt", 
                                              folder + "prolate_tensor_2D.txt", false));
	tensorData_.reset(new IntTable1DData(b_));
	tensorData_->setIntTable(tensorTable1D_);
	tensorData_->set2DTable(tensorTable2D_);

	ProlateOblate3D basis_i(1, 2, 2, 5, *dotData_, true);
 	ProlateOblate3D basis_g(1, 2, 2, 5, *dotData_, true);
	ProlateOblate3D basis_h(2, 4, 4, 1, *dotData_, true);

	LOG(INFO) << basis_i.computeTensorEntry(basis_g, basis_h, *tensorData_);
}


};  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  //checkFile();
  //testDotProdMode0();
  //testDotProdMode1();
  //testTensor();
  //openTensorTable();
  //collectInnerPattern();
  //collectTensorPattern();
  //splitTensorTable();
	//mergeTensorTable();
	//mergeTensor1();
  //collectPower2();

  return 0;
}