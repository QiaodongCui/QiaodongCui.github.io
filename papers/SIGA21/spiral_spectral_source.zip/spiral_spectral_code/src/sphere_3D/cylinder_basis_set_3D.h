#ifndef CYLINDER_BASIS_SET_3D_H
#define CYLINDER_BASIS_SET_3D_H

#include <Eigen/Eigen>
#include <fftw3.h>
#include <fstream>
#include <glog/logging.h>
#include <unordered_map>
#include <memory>

#include "common/basic_function.h"
#include "common/pairedCoef.h"
#include "common/particle_sph_3d.h"
#include "3D/FIELD_3D.h"
#include "3D/VECTOR3_FIELD_3D.h"
#include "sphere_3D/basis_set_3D.h"
#include "sphere_3D/cylinder_basis_3D.h"

#define FAST_TENSOR

#ifdef FAST_TENSOR
#include "tensorCompute/cylSinTensor.h"
#include "tensorCompute/cylCosTensor.h"
#endif

typedef std::shared_ptr<CylinderBasis3D> basisPtr3DCyl;

class CylinderBasisSet3D : public BasisSet3D {

public:
  // init, 2*wavenumber
  CylinderBasisSet3D(const int nR, const int nTheta, const int nZ, const int rK, const int thetaK, const int zK,
                     const double b, const bool isDirichletR, const int zBndCndIdx):
    nR_(nR), nTheta_(nTheta),nZ_(nZ), rK_(rK), thetaK_(thetaK), zK_(zK),
    nZTheta_(nZ*nTheta),
    b_(b),isDirichletR_(isDirichletR), zBndCndIdx_(zBndCndIdx) {
   
    // nPhi_ must be even to ensure dst works.
    CHECK(nTheta_ % 2 == 0);
    CHECK(nZ_ % 2 == 0);
    // 0, 1, 2, 3
    CHECK(zBndCndIdx_ >= 0 && zBndCndIdx_ < 4);
    
    // largeest dimension is b
    if (b > 2.0)
      scale_ = 2.0/b;
    else // largest dimension is R
      scale_ = 1.0;

    scale3_ = scale_*scale_*scale_;

    allocateMGS();
    allocateTemp();
    setUpFFTWPlan();
  };

  CylinderBasisSet3D(const int nR, const int nTheta, const int nZ, std::ifstream& in):nR_(nR), nTheta_(nTheta),nZ_(nZ),
                rK_(0), thetaK_(0), zK_(0),
                nZTheta_(nZ*nTheta) {
    // nPhi_ must be even to ensure dst works.
    CHECK(nTheta_ % 2 == 0);
    CHECK(nZ_ % 2 == 0);

    readFromFile(in);
    allocateTemp();
    setUpFFTWPlan();
  }

  ~CylinderBasisSet3D(){};
  void ReSeedParticles(std::vector<ParticleSph3D>& particles, std::vector<Eigen::Vector3d>& initPos) override;
  void projBackParticles(const std::vector<Eigen::Vector3d>& initPos, std::vector<ParticleSph3D>& particles) override;
  void FillFields(FIELD_3D& rad, FIELD_3D& theta, FIELD_3D& z) const {
    all_basis_[0]->FillFields(rad, theta, z);
  }
  
  void DiscretizeAdd(const double coef, FIELD_3D& r, FIELD_3D& theta, FIELD_3D& phi,
            VECTOR3_FIELD_3D* vfield) const {
    all_basis_[0]->DiscretizeAdd(coef, r, theta, phi, vfield);
  }

  void InverseTransformToVelocity(Eigen::VectorXd& coefficients) override;
  void ForwardTransformtoFrequency(
      const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) override;
  void ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) override;

  void outputTestTensorEntries(const int numWant, const std::string& fname,
        std::vector<Adv_Tensor_Type> *Adv_tensor);
  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const override;
  void readFromFile(std::ifstream& in) override;
  VEC3 getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) override;
  
  template<typename DT, typename VT, typename MT>
  void getVelocityPosT(const VT& pos, VT& uCat);

  Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) override;
  Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) override;
  void projPosBack(ParaParticle3Dd& p) override;
  void projPosBack(ParaParticle3Df& p) override;
  void interpolateToCartesian(VECTOR3_FIELD_3D* field) override;

  int nR() { return nR_;}
  int nTheta() {return nTheta_;}
  int nZ() {return nZ_;}
  
  template<typename DT, typename VT>
  void addParticleForce(const double& ptlWeight, const VT& pos, const VT& f, VECTOR3_FIELD_3D& buf);
  
  int inverseLookup(const int k12, const int k22, const int k32, const int idx) {
    uint64_t hash = Basis3D::toHash(k12, k22, k32, idx);
    std::unordered_map<uint64_t, int>::const_iterator it = basisLookup_.find(hash);
    if (it != basisLookup_.end())
      return it->second;
    else
      return -1;
  }
  void setScenario(const int scenario) {scenario_ = scenario;}
  double* getVrTemp() {return vrTemp_;}
  double* getVtTemp() {return vtTemp_;}
  double* getVpTemp() {return vpTemp_;}
  double getB(){return b_;}
  double getScale(){return scale_;}

  void computeLaplacianMatrix(Eigen::MatrixXd& laplacian);
  void printBasis(const int idx) {
    if (idx < numBasisAll_)
      all_basis_[idx]->debugPrint();
  }
  Eigen::MatrixXd& getLaplacianD() {return LaplacianD_;}

protected:
  
  void allocateMGS();
  void initPhiCoef();

  void allocateTemp();
  void setUpFFTWPlan();
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta,
       const int nPhi, double* ur, double* ut, double* up);
  void projectUniformRTNumerical(const int nR, const int nTheta, const int nZ, double* fr,
                                           double* ft, double* fz, Eigen::VectorXd& fullCoef);


  void interpolateToSphere(const VECTOR3_FIELD_3D& field);
  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);

  // Good luck read through the implementation of transformations.
  void InverseTransformVR();
  void InverseTransformVT();
  void InverseTransformVZ();
  void ForwardTransformVR();
  void ForwardTransformVT();
  void ForwardTransformVZ();

  void weightSinCosR(const int zStride, const double* rf, double* field);

  // weight by r along the radial, only used by phi4D and phi4A
  void weightR(const int zStride, double* field);
  void weightRB(const int zStride, double* buf);
  void weightJacobian(const int zStride, double* ur, double* ut, double* up);

  // clear chunk of mem following ptr, it's up to user
  void clearPointer(double* ptr) {
    std::unordered_map<double*, int>::const_iterator it = pointerSize_.find(ptr);
    CHECK(it != pointerSize_.end());
    memset(ptr, 0x00, sizeof(double)*it->second);
  }
  
  void TranscosR(const bool inverse, double* in, double* out);
  void TransR(fftw_plan rPlan, double* in, double* out);

  void TranscosT(const bool inverse, double* in, double* out);
  void TranssinT(const bool inverse, double* in, double* out);
  void TransT(fftw_plan tPlan, double* in, double* out);

  // copy a R-Z 2d slice to full 3D grid
  void add2DSliceToFull(const int offset, const double* slice2D, double* out);
  // extract a R-Z 2d slice to from 3D grid
  void extract2DSliceToFull(const int offset, const double* in, double* slice2D);
  
  void moveInToTgrid(const double* in, double* out);
  void moveTtoPGrid(const double* in, double* out);
  void sumTtoPGrid(const double* in, double* out);
  void moveTToIngrid(const double* in, double* out);
  void movePtoTGrid(const double* in, double* out);
  void clearPairCoef();
  void assignPairCoef(Eigen::VectorXd& fieldCoef);
  void runMGS(const double thresh, const std::vector<basisPtr3DCyl>& in, std::vector<basisPtr3DCyl>& out,
            Eigen::MatrixXd& Coef, int& m);
  
  double dotProdCast(const basisPtr3DCyl a, const basisPtr3DCyl b) const {
    return a->dotProdScale(*b)*a->GetInvNorm()*b->GetInvNorm();
  }
  
  double tensorEntryCast(const basisPtr3DCyl basis_i, const basisPtr3DCyl basis_g, const basisPtr3DCyl basis_h);

  const int nR_;
  const int nTheta_;
  const int nZ_;

  // zStride for DCT/DST.
  int zStride_ = nZ_;
  // need to write this out.....
  int rK_;
  // number of basis along theta
  int thetaK_;
  // number of basis along phi
  int zK_;

  // trimmed dimensions.
  int nRE_;
  int nThetaE_;
  int nZE_;

  // grid scale of cartesian grid
  // const double dx_;
  const int nZTheta_;
  
  double dR_;
  double dTheta_;
  double dZ_;

  std::vector<basisPtr3DCyl> all_basis_;
  
  // height of the cylinder.
  double b_;

  // velocity boundary conditions.
  bool isDirichletR_;
  // 0 : both Dirichlet -> F(z) = sin(i3 pi z), i3 \in z^+
  // 1 : Dirichlet at 0, Neumann at 1 -> F(z) = sin(i3 pi z), i3 \in z^+ - 0.5
  // 2 : both Neumann -> F(z) = cos(i3 pi z), i3 \in z
  // 3 : Neumann at 0, Dirichlet at 1 -> F(z) = cos(i3 pi z),  i3 \in z^+ - 0.5
  int zBndCndIdx_;

  std::default_random_engine m_gen_;

  int totalSize_;
  double invTotalSize_;

  // multipler account for boundary conditions of r and z.
  int multipier_;

  // pointers of size nR_*nThetaE_*nZE_
  double* inTemp_ = NULL;
  double* inTemp1_ = NULL;

  double* vpTemp_ = NULL;
  double* vtTemp_ = NULL;
  double* vrTemp_ = NULL;
  double* temp0_ = NULL;

  double* tTemp_ = NULL;  // grid of size nR_*nTheta*nZE_

  // 2D pointers used for enrichment functions.
  double* rZTemp_ = NULL;
  double* rZTemp1_ = NULL;
  double* rZTemp4A_ = NULL;
  double* rZTemp4A1_ = NULL;

  // only used for Phi5
  double* rZTemp5_ = NULL;

  std::unordered_map<double*, int> pointerSize_;
  std::unordered_map<uint64_t, int> basisLookup_;

  // pointers of size nR
  double* sinHalfPiR_ = NULL;
  double* cosHalfPiR_ = NULL;
  double* weightF_ = NULL;
  double* weightDerivF_ = NULL;
  //const bool useTrimmedPlan = true;
  // inverse full plans
  fftw_plan IcosP_;
  fftw_plan IsinP_;
  
  // inverse trimmed plans, this plans are 2D for the same reason IsinT_ and IcosT_ are 2D.
  // due to jump in idsit.
  fftw_plan IsinRE_;
  fftw_plan IcosRE_;

  // use for enrichmode 2,3, they have different number along r than plans for 0, 1
  fftw_plan IsinR2D_;
  fftw_plan IcosR2D_;
  // used for phi4A
  fftw_plan IsinR4A_;
  fftw_plan IcosR4A_;
  fftw_plan IsinTE_;
  fftw_plan IcosTE_;
  // used for Phi5
  fftw_plan IsinRsinZ_;
  fftw_plan IsinRcosZ_;

  // forward full plans
  fftw_plan FcosP_;
  fftw_plan FsinP_;

  // forward trimmed plans
  fftw_plan FsinRE_; 
  fftw_plan FcosRE_;
  // 1d plans use for enrichmode 2,3, they have different number along r than plans for 0, 1
  fftw_plan FsinR2D_;
  fftw_plan FcosR2D_;
  fftw_plan FsinR4A_;
  fftw_plan FcosR4A_;
  fftw_plan FsinTE_;
  fftw_plan FcosTE_;
  // used for Phi5
  fftw_plan FsinRsinZ_;
  fftw_plan FsinRcosZ_;

  std::vector<std::vector<pairedCoef>> phiCoef_;
  cylSinTensor sinEval_;
  cylCosTensor cosEval_;

  int scenario_ = 0;

  // reduced Laplacian.
  Eigen::MatrixXd LaplacianD_;
};

#endif // CYLINDER_BASIS_SET_3D_H