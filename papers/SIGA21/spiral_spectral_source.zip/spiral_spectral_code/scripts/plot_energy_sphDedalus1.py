import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt

def read_from_file(fname):
    e = []
    f = open(fname)
    for line in f:
        temp = line.split()
        e.append((float)(temp[0]))
    f.close()
    e = np.asarray(e)
    #ed = np.asarray(ed)
    result = {}
    result['e'] = e
    #result['ed'] = ed
    return result

data4 = read_from_file("./Energy_dedalus_zero")['e']
data4 = data4[3:-1]
data4 = data4 / data4[0] * 100.0

data6 = read_from_file("./Energy_dedalus_zero1")['e']
data6 = data6[3:-1]
data6 = data6 / data6[0] * 100.0

#index = np.arange(0, len(data1))

font_size = 30
linge_width = 2

fig, ax = plt.subplots()
ax.set_ylabel('%  Energy ', fontsize = font_size)
ax.set_xlabel('Timestep', fontsize = font_size)
#ax.set_title('Error comparison, visc = 0.002', fontsize = font_size )
idxDedalus = np.arange(0, 350, 1.0/3.0)
line4, = ax.plot(idxDedalus, data4[0:len(idxDedalus)].transpose(), color = 'green' , lw = linge_width, label="dt = 1e-4")

idxDedalus = np.arange(0, 350, 1.0/32.0)
line4, = ax.plot(idxDedalus, data6[0:len(idxDedalus)].transpose(), color = 'lime' , lw = linge_width, label="dt = 1e-5")


plt.ylim(0, 1010)
ax.legend(loc='upper right', bbox_to_anchor=(1., 1.0), fontsize = font_size)

#plt.xticks(np.arange(0, x_ceil, 200))
for tick in ax.xaxis.get_major_ticks():
                tick.label.set_fontsize(font_size)
for tick in ax.yaxis.get_major_ticks():
               tick.label.set_fontsize(font_size)   
plt.show()