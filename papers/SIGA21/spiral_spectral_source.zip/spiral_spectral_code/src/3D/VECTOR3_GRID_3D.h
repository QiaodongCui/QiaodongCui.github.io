/*
 This file is part of SSFR (Zephyr).
 
 Zephyr is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Zephyr is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Zephyr.  If not, see <http://www.gnu.org/licenses/>.
 
 Copyright 2013 Theodore Kim
 */
#ifndef VECTOR3_GRID_3D_H
#define VECTOR3_GRID_3D_H

#include <Eigen/Eigen>

#include <cmath>
#include <string>
#include <map>
#include <iostream>
#include "Alg/VECTOR.h"

#include "Alg/VEC3.h"
#include "FIELD_3D.h"



template <class T>
class VECTOR3_GRID_3D {
public:
  VECTOR3_GRID_3D();
  VECTOR3_GRID_3D(const int& xRes, const int& yRes, const int& zRes, const T& center = T(0,0,0), const T& lengths = T(1,1,1));
  ~VECTOR3_GRID_3D();

  // accessors
  inline T& operator()(int x, int y, int z) { return _data[z * _slabSize + y * _xRes + x]; };
  const T operator()(int x, int y, int z) const { return _data[z * _slabSize + y * _xRes + x]; };
  const T operator()(const T& position) const;
  inline T& operator[](int x) { 
    assert(x >= 0);
    assert(x < _totalCells);
    return _data[x]; 
  };
  const T operator[](int x) const { 
    assert(x >= 0);
    assert(x < _totalCells);
    return _data[x]; 
  };
  T* data() { return _data; };
  T*& dataRef() { return _data; };
  inline const int xRes() const { return _xRes; };
  inline const int yRes() const { return _yRes; };
  inline const int zRes() const { return _zRes; };
  
  T dims() { return T(_xRes, _yRes, _zRes); };
  const Real dx() const { return _dx; };
  const Real dy() const { return _dy; };
  const Real dz() const { return _dz; };
  T dxs() const { return T(_dx, _dy, _dz); };
  const int slabSize() const { return _slabSize; };
  const T center() const { return _center; };
  const T lengths() const { return _lengths; };
  const int totalCells() const { return _totalCells; };
  const bool initialized() const { return _initialized; };
  const T constEntry(int index) const { return _data[index]; };
  void clear();
 
  void setCenter(const T& center) { _center = center; };

  // what's the maximum resolution in any direction?
  int maxRes();

  // retrieve the components
  FIELD_3D magnitudeField() const;

  // absolute max single entry
  Real maxAbsScalar();

  // 2 norm of the whole field
  Real twoNorm();
  Real twoNormSqared();
  // overloaded operators
  VECTOR3_GRID_3D& operator-=(const VECTOR3_GRID_3D& input);
  VECTOR3_GRID_3D& operator+=(const VECTOR3_GRID_3D& input);
  VECTOR3_GRID_3D& operator+=(const Real& value);
  VECTOR3_GRID_3D& operator*=(const Real& value);
  VECTOR3_GRID_3D& operator*=(const T& value);
  VECTOR3_GRID_3D& operator*=(const FIELD_3D& input);
  VECTOR3_GRID_3D& operator=(const Real& value);
  VECTOR3_GRID_3D& operator=(const VECTOR3_GRID_3D& input);

  // file stream IO
  void write(FILE* file) const;
  // advect using first order semi-Lagrangian

  template<typename U>
  static void advect(const Real dt, const VECTOR3_GRID_3D<T>& velocityGrid, const U& oldField, U& newField);

  template<typename U>
  static void advectMacCormack(const Real dt, const VECTOR3_GRID_3D<T>& velocityGrid, U& oldField, 
                               U& newField, U& temp1, U& temp2); 

  template<typename U>
  static void clampOutsideRays(const Real dt, const VECTOR3_GRID_3D<T>& velocityField, const U&  
                                        oldField, const U& oldAdvection, U& newField);

  static void clampExtrema(const Real dt, const VECTOR3_GRID_3D& velocityField, const VECTOR3_GRID_3D& oldField,
                           VECTOR3_GRID_3D& newField);
  static void clampExtrema(const Real dt, const VECTOR3_GRID_3D& velocityField, const FIELD_3D& 
                                      oldField, FIELD_3D& newField);

  // Get the velocity at a specific position.
  // posx: [0-xRes], pos_y : [0: yRes], pos_z : [0, zRes]
  T GetVelocity(const float pos_x, const float pos_y, const float pos_z) const;
  // normalize all the std::vectors in the field
  void normalizeToLargest();

  // set various components
  void setZeroX();
  void setZeroY();
  void setZeroZ();
  void setZeroBorder();

  void setNeumannX();  
  void setNeumannY();  
  void setNeumannZ();

  void copyBorderX();
  void copyBorderY();
  void copyBorderZ();
  void copyBorderAll();
  
  // BLAS-like interface, output += alpha * input
  void axpy(const Real& alpha, const VECTOR3_GRID_3D& field);

  // swap the contents with another object
  void swapPointers(VECTOR3_GRID_3D& field);

  // unproject the reduced coordinate into the peeled cells in this field
  void peeledUnproject(const Eigen::MatrixXd& U, const Eigen::VectorXd& q);

  // take the dot product of the current field with another std::vector field
  // and return the scalar field
  FIELD_3D dot(const VECTOR3_GRID_3D& rhs);
  
private:
  int _xRes;
  int _yRes;
  int _zRes;

  int _slabSize;
  int _totalCells;

  T* _data;

  // center position of the grid
  T _center;

  // lengths of the x,y,z dimensions of the grid
  T _lengths;

  // physical lengths
  Real _dx;
  Real _dy;
  Real _dz;
  
  // has this field been allocated?
  bool _initialized;
};

// take the field dot product
template <class T> FIELD_3D operator*(const VECTOR3_GRID_3D<T>&u, const VECTOR3_GRID_3D<T>& v);
template <class T> VECTOR3_GRID_3D<T> operator*(const Real& a, const VECTOR3_GRID_3D<T>& v);

template <class T> VECTOR3_GRID_3D<T> operator*(const VECTOR3_GRID_3D<T>& v, const Real& a);
template <class T> VECTOR3_GRID_3D<T> operator*(const FIELD_3D& u, const VECTOR3_GRID_3D<T>& v);

template <class T> VECTOR3_GRID_3D<T> operator+(const VECTOR3_GRID_3D<T>& u, const VECTOR3_GRID_3D<T>& v);
// diff two std::vector fields
template <class T> VECTOR3_GRID_3D<T> operator-(const VECTOR3_GRID_3D<T>& u, const VECTOR3_GRID_3D<T>& v);

#endif

