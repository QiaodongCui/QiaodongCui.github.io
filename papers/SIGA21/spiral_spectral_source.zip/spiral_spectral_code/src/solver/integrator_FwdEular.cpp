
#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <vector>

#include "integrator_FwdEular.h"
#include "setting.h"

// Solve the equation dw_k/dt = wT C_k w
void IntegratorFwdEular::IntegrateForward(
    const std::vector<Adv_Tensor_Type>& Adv_tensor,
    const Eigen::VectorXd& coefficients_old,
    const double dt,
    Eigen::VectorXd* coefficients_new,
    double* condition_number_ ,
    float* contraction_time,
    float* solver_time) {
  LOG(INFO) << "fwd Eular";
    /* RK4: higher order explicit integrator */
  const int num_coefficient = coefficients_old.size();
  
  const int num_basis = coefficients_old.size();
  // Allocate the contracted tensor. Generally, it should be dense.
  
  Eigen::MatrixXd P(num_basis, num_basis);
  P.setZero();
  Eigen::VectorXd w(num_basis);
  w.setZero();
  w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);
  
  #pragma omp parallel for
  for (int i = 0; i < num_basis; i++) {
    P.row(i).noalias() = w.transpose() * Adv_tensor[i]; 
  }
  // P = TransferMatrix.transpose() * P;
  // *contraction_time = timer.ElapsedTimeInSeconds();

  *coefficients_new  = w + P*(1.0*dt*w);
}
