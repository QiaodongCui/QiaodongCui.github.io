#include "util/glutDraw.h"

void DrawCube(const float boxXLength, const float boxYLength, const float boxZLength)
{
  glPushMatrix(); 
  glTranslatef(boxXLength,boxYLength,boxZLength);
  glBegin(GL_LINE_STRIP);
  glColor3f(1.f,1.f,1.f);
  glVertex3f(-boxXLength,-boxYLength,-boxZLength);
  glVertex3f(boxXLength,-boxYLength,-boxZLength);
  glVertex3f(boxXLength,boxYLength,-boxZLength);
  glVertex3f(-boxXLength, boxYLength,-boxZLength);
  glVertex3f(-boxXLength,-boxYLength,-boxZLength);
  
  glVertex3f(-boxXLength,-boxYLength,boxZLength);
  glVertex3f(boxXLength,-boxYLength,boxZLength);
  glVertex3f(boxXLength,boxYLength,boxZLength);
  glVertex3f(-boxXLength,boxYLength,boxZLength);
  glVertex3f(-boxXLength,-boxYLength,boxZLength);
  glVertex3f(-boxXLength,boxYLength,boxZLength);
  glVertex3f(-boxXLength,boxYLength,-boxZLength);
  glVertex3f(boxXLength,boxYLength,-boxZLength);
  glVertex3f(boxXLength,boxYLength,boxZLength);
  glVertex3f(boxXLength,-boxYLength,boxZLength);
  glVertex3f(boxXLength,-boxYLength,-boxZLength);
  glEnd();
  glTranslatef(-0.1f, -0.1f, -0.1f);
  glLineWidth(3.0f);
  glBegin(GL_LINES);
    // x axis is red
    glColor4f(10.0f, 0.0f, 0.0f, 1.0f);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glColor4f(10.0f, 0.0f, 0.0f, 0.0f);
    glVertex3f(1.0f, 0.0f, 0.0f);

    // y axis is green 
    glColor4f(0.0f, 10.0f, 0.0f, 1.0f);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glColor4f(0.0f, 10.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);
    
    // z axis is blue
    glColor4f(0.0f, 0.0f, 10.0f, 1.0f);
    glVertex3f(0.0f, 0.0f, 0.0f);
    glColor4f(0.0f, 0.0f, 10.0f, 0.0f);
    glVertex3f(0.0f, 0.0f, 1.0f);
  glEnd();
  glLineWidth(1.0f);
  glPopMatrix();
}