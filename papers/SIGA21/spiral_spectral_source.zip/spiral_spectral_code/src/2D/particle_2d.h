#ifndef PARTICLE_2D_H
#define PARTICLE_2D_H

#include "Alg/VEC2.h"

class Particle2D {
public:
  Particle2D(const double px, const double py){
    position[0] = px;
    position[1] = py;
  }
  Particle2D(){};
  
  ~Particle2D(){}
  VEC2 position;
  VEC2 velocity;
};

class Particle2DIdx : public Particle2D {
public:
	Particle2DIdx(const double px, const double py):Particle2D(px, py) {
	}
	Particle2DIdx(){};

	int gridIdx;
};

struct DensParticle2D {
  
  DensParticle2D(const double px, const double py) {
    position_[0] = px;
    position_[1] = py;
  }

  VEC2 position_;
};

#endif  // PARTICLE_2D_H
