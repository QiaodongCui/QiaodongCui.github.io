#ifndef SETTING_H
#define SETTING_H

#include <Eigen/Eigen>
#include <Eigen/Sparse>

//#ifndef Real
//#define Real double
//#endif
using Real = double;
//#if Real==float 
// #define SINGLE_PRECISION true
//#else 
// #define SINGLE_PRECISION false
//#endif

#ifndef Adv_Tensor_Sparse
#define Adv_Tensor_Sparse
#endif

typedef Eigen::SparseMatrix<double> Adv_Tensor_Type;
// typedef Eigen::MatrixXd Adv_Tensor_Type;

#ifndef USE_ROOT_LAMBDA
#define USE_ROOT_LAMBDA
#endif

//#define APPLE

//#ifndef max
//#define max(a,b) (((a) > (b)) ? (a) : (b))
//#endif

//#ifndef min
//#define min(a,b) (((a) < (b)) ? (a) : (b))
//#endif

#endif
