#include "util/solve_quadratic.h"

// Solve Ax^2 + bx + c = 0
void SolveQuadratic(const double A, const double b, const double c,
                    double* root_plus, double*root_minus) {
  const double Delta = b*b - 4*A*c;
  if (Delta < 0) {
    LOG(INFO) << "Imaginary roots.";
    *root_plus = 0;
    *root_minus = 0;
    return;
  } else {
    *root_plus = 0.5*(-b + sqrt(Delta)) / A;
    *root_minus = 0.5*(-b - sqrt(Delta)) / A;
  }
}
