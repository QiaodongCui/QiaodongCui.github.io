#ifndef SCOMP_BASIS_SET_2D_H
#define SCOMP_BASIS_SET_2D_H

 #include <cstring>
#include <Eigen/Eigen>
#include <fstream>
#include <vector>
#include <fftw3.h>

#include "2D/VFIELD2D.h"
#include "polar_2D/polar_basis_2D.h"
#include "polar_2D/polar_basis_set_2D.h"
#include "polar_2D/polar_basis_all.h"

typedef std::shared_ptr<PolarBasisAll> basisPtrAll;

class SCompBasisSet2D : public PolarBasisSet2D  {

public:
  SCompBasisSet2D(int N, int radiusK, int angK, bool bndCnd): PolarBasisSet2D(N, radiusK, angK, bndCnd) {
    nTheta_ = ((int)((double)(N)*M_PI));
    nR_ = (N/2);
    // nTheta_ must be even to ensure dst works.
    if (nTheta_ % 2 != 0)
      nTheta_ ++;

    // allocate twice memory anyway
      allocateTemp(true);
      init();
  };
  
  SCompBasisSet2D(int N, std::ifstream& in):PolarBasisSet2D(N, 0,0, true) {
    nTheta_ = ((int)((double)(N)*M_PI));
    nR_ = (N/2);
    // nTheta_ must be even to ensure dst works.
    if (nTheta_ % 2 != 0)
      nTheta_ ++;
    
    // allocate twice memory anyway
    allocateTemp(true);
    readFromFile(in);
    setUpFFTWPlan();
  };

  // depercated, use MGS to allocate instead.
  void allocateBasis() override;
  void allocateBasisMGS();

  // void allocateNumerical();
  ~SCompBasisSet2D(){};

  void InverseTransformToVelocity(
      const Eigen::VectorXd& coefficients, VFIELD2D* field) override;  
  void InversetTransformEnrich(const Eigen::VectorXd& fieldCoef, Eigen::Map<Eigen::VectorXd>& vr, Eigen::Map<Eigen::VectorXd>& vt);

  // Input a std::vector field, transform and output the basis coefficients.
  void ForwardTransformtoFrequency(
      const VFIELD2D& field, Eigen::VectorXd* coefficients) override;
  void ForwardTransformEnrichUR(Eigen::VectorXd& fieldCoef);
  void ForwardTransformEnrichUT1(Eigen::VectorXd& fieldCoef);
  void ForwardTransformEnrichUT2(Eigen::VectorXd& fieldCoef);

  
  void debugInfo(const PolarBasis2D& basis_i, const PolarBasis2D& basis_j,
                          const PolarBasis2D& basis_k);

  void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) override;
  
  void outputTestTensorEntries(const int numWant, const std::string& fname, std::vector<Adv_Tensor_Type> *Adv_tensor);

  void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& Adv_tensor_) const override;
  void readFromFile(std::ifstream& in) override;

protected:
  void init() override {
    //allocateBasis();
    allocateBasisMGS();
    setUpFFTWPlan();
  }
  void runMGS(const double thresh, const std::vector<basisPtrAll>& in, std::vector<basisPtrAll>& out,
            Eigen::MatrixXd& Coef, int& m);
  void assignPairCoef(Eigen::VectorXd& fieldCoef);
  void collectPairedCoef(const Eigen::VectorXd& fieldCoef);
  void computeUniformRTNumerical(const Eigen::VectorXd& fullCoef, const int nR, const int nTheta, double* ur, double* ut);

  void projectUniformRTNumerical(const int nR, const int nTheta, double* fr, double* ft, Eigen::VectorXd& fullCoef);


protected:
  std::vector<basisPtrAll> all_basis_;
  
};

#endif  // SCOMP_BASIS_SET_2D_H