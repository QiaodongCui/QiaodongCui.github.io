#ifndef QUERY_TABLE_H
#define QUERY_TABLE_H

#include <unordered_map>
#include <utility>
#include "common/basic_function.h"

class IntegrationTable1DPtn {

public:
  IntegrationTable1DPtn(const std::string& bName, const std::string& kName, const std::string& datName, const std::string& ptnName);
  
  ~IntegrationTable1DPtn(){
    free(bList_);
    free(data_);
  };
  
  // do a binary search to see if b is in the list
  int findBidx(const double bq) const;

  inline double queryTable(const EllipticFactor& ef, const BasicFunc& fun, const int bIdx) const;

protected: 
  // list of b values the table contains.
  double* bList_ = NULL;
  // number of b values in the table.
  int nBValues_ = 0;

  int k1x2Min_ = 0;
  int k1x2Max_ = 0;

  // number of k values in the table.
  int nKValues_;
  int setSize_;

  int k1Delta_;
  
  double* data_;
  std::unordered_map<uint64_t, int> hashToIdx;

};

class TensorTable2D {
public:
  TensorTable2D(const std::string& kName, const double& bwant, const std::string& blistTableName, const std::string& ptnName, const bool theta_2Pi);
  ~TensorTable2D(){
    free(data_);
  };
  double queryTable(const EllipticFactor& ef, const BasicFunc& rf, const BasicFunc& tf) const;
  void verifyTable();
protected:
  double* data_;
  std::unordered_map<uint64_t, int> hashToIdx;
  
  std::vector<std::pair<double, std::string>> listOfDat_;

  int k1x2Min_ = 0;
  int k1x2Max_ = 200;
  int k2x2Min_ = 0; // k2 even only->k2x2 multiple of 4.
  int k2x2Max_ = 400;

  int nk1_ = k1x2Max_ - k1x2Min_ + 1;
  int nk2_ = (k2x2Max_ - k2x2Min_)/4 + 1;
  int k1Delta_ = 1;
  int k2Delta_ = 1;

  int setSize_ = 0;
  // is the integration from [0, 2*pi] or [0, pi].
  const bool theta_2Pi_;
};

class IntTable1DData {

public:
  IntTable1DData(const double bIn):a(sqrt(1.0 - bIn*bIn)), b(bIn),c(bIn/sqrt(1.0 - bIn*bIn)) {
    tab = NULL;
  };

  ~IntTable1DData(){};
  double a;
  double b;
  double c;
  int bidx;
  double queryTable(const EllipticFactor& ef, const BasicFunc& fun) const;
  void setIntTable(std::shared_ptr<IntegrationTable1DPtn> tabIn) {
    tab = tabIn;
    bidx = tabIn->findBidx(b);
  }

  double query2D(const EllipticFactor& ef, const BasicFunc& rf, const BasicFunc& tf) const {
    return tab2D->queryTable(ef, rf, tf);
  }
  
  void set2DTable(std::shared_ptr<TensorTable2D> tabIn) {
    tab2D = tabIn;
  }

protected:
  std::shared_ptr<IntegrationTable1DPtn> tab;
  std::shared_ptr<TensorTable2D> tab2D;
};


#endif // QUERY_TABLE_H