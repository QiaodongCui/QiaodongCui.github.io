#ifndef SPHERE_BASIS_2D_ALL_H
#define SPHERE_BASIS_2D_ALL_H

#include <Eigen/Eigen>
#include <fstream>

#include "2D/VFIELD2D.h"
#include "2D/FIELD2D.h"
#include "common/basic_function.h"
#include "2D/basis_2D.h"
#include "util/util.h"

class SphereBasis2DAll : public Basis2D {

public:
	SphereBasis2DAll(const int k12, const int k22, const int idx):
    Basis2D(k12, k22), index_(idx) {
  	
  	invNorm_ = 0; // Default zero.
    // Initialize DCT norm.
    int num_zeros = 0;
    if (k1x2 == 0) num_zeros ++;
    if (k2x2 == 0) num_zeros ++;

    // need dct both directions
    if (num_zeros == 0) {
      DCTNorm_ = 0.25;
    } else if (num_zeros == 1) { // only dct one direction
      DCTNorm_ = 0.5;
    } else {  // dc component
      DCTNorm_ = 1.;
    }

    initBasicCoef();
    Normalize();
    curlSph();
	};

	~SphereBasis2DAll(){};

  double GetDCTNorm() const {
    return DCTNorm_;
  }
  
  void debugPrint() const {
    LOG(INFO) << "k1 " << k1 << " k2 " << k2 << " index " << index_ << " norm " << invNorm_;
  }
  
  int index() const {
    return  index_;
  }
	void DiscretizeAdd(const double coef, VFIELD2D* vfield) const;
	void AddUniformU(const double coef, const int nT, const int nP, double* ut, double* up) const;
	double ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const;
  
  double dotProd(const SphereBasis2DAll& other) const;
	void Normalize();

	const BasicFunc& getPhiFunc(int idx) const {
    return phiFunc_[idx];
  }
  
  const std::vector<RTMultiply>& getRT(int idx) const {
    return RT_[idx];
  }

  const BasicFunc& getCurPhi(int i) const {
    return curlPhi_[i];
  }
  
  const std::vector<RTMultiply>& getCurRT(int i) const {
    return curlRT_[i];
  }
  static void crossProdPhi(const SphereBasis2DAll& phiG, const SphereBasis2DAll& phiH,
                                 std::vector<BasicFunc> (&crossPhi)[2]);

  static void crossProdRT(const SphereBasis2DAll& phiG, const SphereBasis2DAll& phiH,
                                std::vector<RTMultiply> (&crossRT)[2]);
  
  static double integrateCurlCross(const BasicFunc& curP, const std::vector<BasicFunc>& crossP,
                                   const std::vector<RTMultiply>& curRT, const std::vector<RTMultiply>& crossRT);
	static double computeTensorEntry(const SphereBasis2DAll& phiI, const SphereBasis2DAll& phiG, const SphereBasis2DAll& phiH);
	
	void writeToFile(std::ofstream& out) const;
  static SphereBasis2DAll* fromFile(std::ifstream& in);

  const double getInvWaveN() const {
    if (index_ == 0 || index_ == 1) {
      return 1.0/k2;
    }
    return 1.0;
  }
protected:
	void initBasicCoef();
  // sin(t)*\nabla x f = sin(t)*D[f_p, t] + cos(t)f_p - D[f_t, p]
  void curlSph();

  double DCTNorm_;
  double norm2_;
  // index for different kind of basis functions
  int index_;
  
  // basic form of the basis function
  //T R component along (r, \theta, \phi) direction.
  std::vector<RTMultiply> RT_[2];
  // Copied from sphere3D basis functions, in this case the function along 
  // phi are all constant numbers with coefficients.
  BasicFunc phiFunc_[2];

  // curl data
  BasicFunc curlPhi_[3];
  std::vector<RTMultiply> curlRT_[3];
};

#endif  // SPHERE_BASIS_2D_ALL_H