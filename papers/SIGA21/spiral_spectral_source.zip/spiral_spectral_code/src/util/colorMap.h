#ifndef COLOR_MAP_H
#define COLOR_MAP_H

#include <Eigen/Eigen>
#include <string>
#include <vector>

class ColorMap {
public:
	ColorMap(const std::string fname);
	~ColorMap(){};

	Eigen::Vector3f getColor(const float t) const;

protected:
	std::vector<Eigen::Vector3f> colorMap_;
};

#endif  // COLOR_MAP_H