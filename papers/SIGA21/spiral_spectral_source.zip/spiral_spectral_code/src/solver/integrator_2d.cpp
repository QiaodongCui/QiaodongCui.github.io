#include "solver/integrator_2d.h"
#include "util/timer.h"
#include "setting.h"

#include <Eigen/Eigen>
#include <Eigen/Sparse>

void Integrator2D::conjugate_gradient(const Eigen::MatrixXd& mat, const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                      const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond, int& iters,
                      Eigen::VectorXd::RealScalar& tol_error) {
  using std::sqrt;
  using std::abs;
  typedef typename Eigen::VectorXd::RealScalar RealScalar;
  typedef typename Eigen::VectorXd::Scalar Scalar;
  typedef Eigen::Matrix<Scalar,Eigen::Dynamic,1> VectorType;
  
  RealScalar tol = tol_error;
  int maxIters = iters;
  
  int n = mat.cols();

  VectorType residual = rhs - mat * x; //initial residual

  RealScalar rhsNorm2 = rhs.squaredNorm();
  if(rhsNorm2 == 0) 
  {
    x.setZero();
    iters = 0;
    tol_error = 0;
    return;
  }
  const RealScalar considerAsZero = (std::numeric_limits<RealScalar>::min)();
  RealScalar threshold = Eigen::numext::maxi(tol*tol*rhsNorm2,considerAsZero);
  RealScalar residualNorm2 = residual.squaredNorm();
  if (residualNorm2 < threshold)
  {
    iters = 0;
    tol_error = sqrt(residualNorm2 / rhsNorm2);
    return;
  }

  VectorType p(n);
  p = precond.solve(residual);      // initial search direction

  VectorType z(n), tmp(n);
  RealScalar absNew = Eigen::numext::real(residual.dot(p));  // the square of the absolute value of r scaled by invM
  int i = 0;
  while(i < maxIters)
  {
    tmp.noalias() = mat * p;                    // the bottleneck of the algorithm

    Scalar alpha = absNew / p.dot(tmp);         // the amount we travel on dir
    x += alpha * p;                             // update solution
    residual -= alpha * tmp;                    // update residual
    
    residualNorm2 = residual.squaredNorm();
    if(residualNorm2 < threshold)
      break;
    
    z = precond.solve(residual);                // approximately solve for "A z = residual"

    RealScalar absOld = absNew;
    absNew = Eigen::numext::real(residual.dot(z));     // update the absolute value of r
    RealScalar beta = absNew / absOld;          // calculate the Gram-Schmidt value used to create the new search direction
    p = z + beta * p;                           // update search direction
    i++;
  }
  tol_error = sqrt(residualNorm2 / rhsNorm2);
  iters = i;
}

// Diffusion, system matrix: mat = (I_rxr - v*dt*A*D*A^T). A: transfer matrix, D: reduced Laplacian., v*dt, diffusion.
template<typename MAT>  
void Integrator2D::conjugate_gradient_A(const MAT& D, const MAT& A, const double vdt,
                      const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                      const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond, int& iters,
                      Eigen::VectorXd::RealScalar& tol_error) {
  using std::sqrt;
  using std::abs;
  typedef typename Eigen::VectorXd::RealScalar RealScalar;
  typedef typename Eigen::VectorXd::Scalar Scalar;
  typedef Eigen::Matrix<Scalar,Eigen::Dynamic,1> VectorType;
  
  RealScalar tol = tol_error;
  int maxIters = iters;
  
  int n = D.cols();
  // mat*x = (I_rxr - v*dt*A*D*A^T)*x = x - v*dt*A*D*A^T*x
  VectorType ATX, DATX;
  ATX.setZero();
  DATX.setZero();
  ATX = A.transpose()*x;
  DATX = D*ATX;

  VectorType residual = rhs - (x - vdt*A*DATX); //initial residual

  RealScalar rhsNorm2 = rhs.squaredNorm();
  if(rhsNorm2 == 0) 
  {
    x.setZero();
    iters = 0;
    tol_error = 0;
    return;
  }
  const RealScalar considerAsZero = (std::numeric_limits<RealScalar>::min)();
  RealScalar threshold = Eigen::numext::maxi(tol*tol*rhsNorm2,considerAsZero);
  RealScalar residualNorm2 = residual.squaredNorm();
  if (residualNorm2 < threshold)
  {
    iters = 0;
    tol_error = sqrt(residualNorm2 / rhsNorm2);
    return;
  }
  VectorType p(n);
  p = precond.solve(residual);      // initial search direction

  VectorType z(n), tmp(n);
  RealScalar absNew = Eigen::numext::real(residual.dot(p));  // the square of the absolute value of r scaled by invM
  int i = 0;
  while(i < maxIters)
  {
    // mat * p = (I_rxr - v*dt*A*D*A^T)*p = p - v*dt*A*D*A^T*p
    ATX = A.transpose()*p;
    DATX = D*ATX;
    tmp.noalias() = p - vdt*A*DATX;                    // the bottleneck of the algorithm

    Scalar alpha = absNew / p.dot(tmp);         // the amount we travel on dir
    x += alpha * p;                             // update solution
    residual -= alpha * tmp;                    // update residual
    
    residualNorm2 = residual.squaredNorm();
    if(residualNorm2 < threshold)
      break;
    
    z = precond.solve(residual);                // approximately solve for "A z = residual"

    RealScalar absOld = absNew;
    absNew = Eigen::numext::real(residual.dot(z));     // update the absolute value of r
    RealScalar beta = absNew / absOld;          // calculate the Gram-Schmidt value used to create the new search direction
    p = z + beta * p;                           // update search direction
    i++;
  }
  tol_error = sqrt(residualNorm2 / rhsNorm2);
  iters = i;
}

template void Integrator2D::conjugate_gradient_A<Eigen::MatrixXd>(const Eigen::MatrixXd& D, const Eigen::MatrixXd& A, const double vdt,
                      const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                      const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond, int& iters,
                      Eigen::VectorXd::RealScalar& tol_error);

template void Integrator2D::conjugate_gradient_A<Adv_Tensor_Type>(const Adv_Tensor_Type& D, const Adv_Tensor_Type& A, const double vdt,
                      const Eigen::VectorXd& rhs, Eigen::VectorXd& x,
                      const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond, int& iters,
                      Eigen::VectorXd::RealScalar& tol_error);

template<typename MAT>
void Integrator2D::solveDiffusion(const MAT& D,
                           const MAT& A,     // transfer matrix for non-orthogonal bases.
                           const Eigen::VectorXd& coefficients_old,
                           const double vdt,
                           Eigen::VectorXd& coefficients_new) {

  CHECK(D.rows() == A.rows());
  CHECK(D.cols() == A.cols());
  // TODO, set a approproate preconditioner
  Eigen::DiagonalPreconditioner<Eigen::MatrixXd::RealScalar> precond(Eigen::MatrixXd::Identity(D.rows(), D.cols()));
  int maxIters = 200;
  double tol_error = 1e-10;
  conjugate_gradient_A(D, A, vdt, coefficients_old, coefficients_new, precond, maxIters, tol_error);
  
  LOG(INFO) << "Diffusion " << " maxIter: " << maxIters << " tolErr: " << tol_error;
}

template void Integrator2D::solveDiffusion<Eigen::MatrixXd>(const Eigen::MatrixXd& D,
                           const Eigen::MatrixXd& A,     // transfer matrix for non-orthogonal bases.
                           const Eigen::VectorXd& coefficients_old,
                           const double vdt,
                           Eigen::VectorXd& coefficients_new);

template void Integrator2D::solveDiffusion<Adv_Tensor_Type>(const Adv_Tensor_Type& D,
                           const Adv_Tensor_Type& A,     // transfer matrix for non-orthogonal bases.
                           const Eigen::VectorXd& coefficients_old,
                           const double vdt,
                           Eigen::VectorXd& coefficients_new);

template void Integrator2D::solveDiffusion<Eigen::SparseMatrix<double, Eigen::RowMajor>>(const Eigen::SparseMatrix<double, Eigen::RowMajor>& D,
                           const Eigen::SparseMatrix<double, Eigen::RowMajor>& A,     // transfer matrix for non-orthogonal bases.
                           const Eigen::VectorXd& coefficients_old,
                           const double vdt,
                           Eigen::VectorXd& coefficients_new);

void Integrator2D::conjugate_gradient_NE(const Eigen::MatrixXd& mat, const Eigen::VectorXd& rhs,
                                         Eigen::VectorXd& x,
                        const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond,
                        int& iters,
                        Eigen::VectorXd::RealScalar& tol_error)
{
  using std::sqrt;
  using std::abs;
  typedef typename Eigen::VectorXd::RealScalar RealScalar;
  typedef typename Eigen::VectorXd::Scalar Scalar;
  typedef Eigen::Matrix<Scalar,Eigen::Dynamic,1> VectorType;
  
  RealScalar tol = tol_error;
  int maxIters = iters;
  
  int n = mat.cols();

  VectorType residual = rhs - mat.transpose()*(mat * x); //initial residual

  RealScalar rhsNorm2 = rhs.squaredNorm();
  if(rhsNorm2 == 0) 
  {
    x.setZero();
    iters = 0;
    tol_error = 0;
    return;
  }
  RealScalar threshold = tol*tol*rhsNorm2;
  RealScalar residualNorm2 = residual.squaredNorm();
  if (residualNorm2 < threshold)
  {
    iters = 0;
    tol_error = sqrt(residualNorm2 / rhsNorm2);
    return;
  }
  
  VectorType p(n);
  p = precond.solve(residual);      //initial search direction

  VectorType z(n), tmp(n), tmp1(n);
  RealScalar absNew = Eigen::numext::real(residual.dot(p));  // the square of the absolute value of r scaled by invM
  int i = 0;
  while(i < maxIters)
  {
    tmp1.noalias() = mat * p;
    tmp.noalias() = mat.transpose() * tmp1;              // the bottleneck of the algorithm

    Scalar alpha = absNew / p.dot(tmp);   // the amount we travel on dir
    x += alpha * p;                       // update solution
    residual -= alpha * tmp;              // update residue
    
    residualNorm2 = residual.squaredNorm();
    if(residualNorm2 < threshold)
      break;
    
    z = precond.solve(residual);          // approximately solve for "A z = residual"

    RealScalar absOld = absNew;
    absNew = Eigen::numext::real(residual.dot(z));     // update the absolute value of r
    RealScalar beta = absNew / absOld;            // calculate the Gram-Schmidt value used to create the new search direction
    p = z + beta * p;                             // update search direction
    i++;
  }
  tol_error = sqrt(residualNorm2 / rhsNorm2);
  iters = i;
}

// w_C = I - C*(0.5*dt);
// w_C^T w_C = I + 0.25*t^2*C^T C due to C is skew-symmetric
// w_C^T w_C x = x +  0.25*t^2*C^T C x
void Integrator2D::conjugate_gradient_NEA(const Eigen::MatrixXd& C, const double dt,  const Eigen::VectorXd& rhs,
                                         Eigen::VectorXd& x,
                        const Eigen::DiagonalPreconditioner<Eigen::VectorXd::RealScalar>& precond,
                        int& iters,
                        Eigen::VectorXd::RealScalar& tol_error)
{
  using std::sqrt;
  using std::abs;
  typedef typename Eigen::VectorXd::RealScalar RealScalar;
  typedef typename Eigen::VectorXd::Scalar Scalar;
  typedef Eigen::Matrix<Scalar,Eigen::Dynamic,1> VectorType;
  
  RealScalar tol = tol_error;
  int maxIters = iters;
  
  int n = C.cols();

  // VectorType residual = rhs - C.transpose()*(C * x); //initial residual
  VectorType residual = rhs - x - 0.25*dt*dt*C.transpose()*(C*x); //initial residual

  RealScalar rhsNorm2 = rhs.squaredNorm();
  if(rhsNorm2 == 0) 
  {
    x.setZero();
    iters = 0;
    tol_error = 0;
    return;
  }
  RealScalar threshold = tol*tol*rhsNorm2;
  RealScalar residualNorm2 = residual.squaredNorm();
  if (residualNorm2 < threshold)
  {
    iters = 0;
    tol_error = sqrt(residualNorm2 / rhsNorm2);
    return;
  }
  
  VectorType p(n);
  p = precond.solve(residual);      //initial search direction

  VectorType z(n), tmp(n), tmp1(n);
  RealScalar absNew = Eigen::numext::real(residual.dot(p));  // the square of the absolute value of r scaled by invM
  int i = 0;
  while(i < maxIters)
  {
    // tmp1.noalias() = C * p;
    // tmp.noalias() = C.transpose() * tmp1;              // the bottleneck of the algorithm
    tmp.noalias() = p + 0.25*dt*dt*C.transpose()*(C*p);

    Scalar alpha = absNew / p.dot(tmp);   // the amount we travel on dir
    x += alpha * p;                       // update solution
    residual -= alpha * tmp;              // update residue
    
    residualNorm2 = residual.squaredNorm();
    if(residualNorm2 < threshold)
      break;
    
    z = precond.solve(residual);          // approximately solve for "A z = residual"

    RealScalar absOld = absNew;
    absNew = Eigen::numext::real(residual.dot(z));     // update the absolute value of r
    RealScalar beta = absNew / absOld;            // calculate the Gram-Schmidt value used to create the new search direction
    p = z + beta * p;                             // update search direction
    i++;
  }
  tol_error = sqrt(residualNorm2 / rhsNorm2);
  iters = i;
}

Eigen::VectorXd Integrator2D::skewSymMult(const Eigen::MatrixXd& C, const Eigen::MatrixXd& A, const Eigen::VectorXd& rhs) {
  Eigen::VectorXd prod = A*(C*(A.transpose()*rhs));
  Eigen::VectorXd symProd = 0.5*(A*(C*(A.transpose())*rhs) + A*(C.transpose()*(A.transpose()*rhs)));
  return prod - symProd;
}

// C = AC0A^T
template<typename MAT, typename MAT1>
void Integrator2D::conjugate_gradient_NEA(const MAT1& C, const MAT& A, const double dt,  const Eigen::VectorXd& rhs,
                                         Eigen::VectorXd& x, int& iters, Eigen::VectorXd::RealScalar& tol_error)
{
  using std::sqrt;
  using std::abs;
  typedef typename Eigen::VectorXd::RealScalar RealScalar;
  typedef typename Eigen::VectorXd::Scalar Scalar;
  typedef Eigen::Matrix<Scalar,Eigen::Dynamic,1> VectorType;
  
  RealScalar tol = tol_error;
  int maxIters = iters;
  
  int n = A.rows();
  VectorType ACAX(n), CTCX(n);
  ACAX.setZero();
  CTCX.setZero();
  ACAX = A*(C*(A.transpose()*x));
  CTCX = A*(C.transpose()*(A.transpose()*ACAX));
  // VectorType residual = rhs - C.transpose()*(C * x); //initial residual
  VectorType residual = rhs - x - 0.25*dt*dt*CTCX; //initial residual

  RealScalar rhsNorm2 = rhs.squaredNorm();
  if(rhsNorm2 == 0) 
  {
    x.setZero();
    iters = 0;
    tol_error = 0;
    return;
  }
  RealScalar threshold = tol*tol*rhsNorm2;
  RealScalar residualNorm2 = residual.squaredNorm();
  if (residualNorm2 < threshold)
  {
    iters = 0;
    tol_error = sqrt(residualNorm2 / rhsNorm2);
    return;
  }
  
  VectorType p(n);
  p = residual;      //initial search direction

  VectorType z(n), tmp(n);
  RealScalar absNew = Eigen::numext::real(residual.dot(p));  // the square of the absolute value of r scaled by invM
  int i = 0;
  while(i < maxIters)
  {
    // tmp1.noalias() = C * p;
    // tmp.noalias() = C.transpose() * tmp1; 
                 // the bottleneck of the algorithm
    ACAX.setZero();
    ACAX = A*(C*(A.transpose()*p));
    CTCX.setZero();
    CTCX = A*(C.transpose()*(A.transpose()*ACAX));

    tmp.noalias() = p + 0.25*dt*dt*CTCX;

    Scalar alpha = absNew / p.dot(tmp);   // the amount we travel on dir
    x += alpha * p;                       // update solution
    residual -= alpha * tmp;              // update residue
    
    residualNorm2 = residual.squaredNorm();
    if(residualNorm2 < threshold)
      break;
    
    z = residual;          // approximately solve for "A z = residual"

    RealScalar absOld = absNew;
    absNew = Eigen::numext::real(residual.dot(z));     // update the absolute value of r
    RealScalar beta = absNew / absOld;            // calculate the Gram-Schmidt value used to create the new search direction
    p = z + beta * p;                             // update search direction
    i++;
  }
  tol_error = sqrt(residualNorm2 / rhsNorm2);
  iters = i;
}

template void Integrator2D::conjugate_gradient_NEA<Eigen::MatrixXd, Eigen::MatrixXd>(const Eigen::MatrixXd& C, const Eigen::MatrixXd& A, const double dt,
                                   const Eigen::VectorXd& rhs, Eigen::VectorXd& x, int& iters, Eigen::VectorXd::RealScalar& tol_error);

template void Integrator2D::conjugate_gradient_NEA<Adv_Tensor_Type, Eigen::MatrixXd>(const Eigen::MatrixXd& C, const Adv_Tensor_Type& A, const double dt,
                                   const Eigen::VectorXd& rhs, Eigen::VectorXd& x, int& iters, Eigen::VectorXd::RealScalar& tol_error);

template void Integrator2D::conjugate_gradient_NEA<Eigen::SparseMatrix<double, Eigen::RowMajor>, Eigen::MatrixXd>(const Eigen::MatrixXd& C,
                                   const Eigen::SparseMatrix<double, Eigen::RowMajor>& A, const double dt,
                                   const Eigen::VectorXd& rhs, Eigen::VectorXd& x, int& iters, Eigen::VectorXd::RealScalar& tol_error);

template void Integrator2D::conjugate_gradient_NEA<Eigen::SparseMatrix<double, Eigen::RowMajor>, Adv_Tensor_Type>(const Adv_Tensor_Type& C,
                                   const Eigen::SparseMatrix<double, Eigen::RowMajor>& A, const double dt,
                                   const Eigen::VectorXd& rhs, Eigen::VectorXd& x, int& iters, Eigen::VectorXd::RealScalar& tol_error);