#ifndef BASIS_SET_3D_H
#define BASIS_SET_3D_H

#include <cstring>
#include <Eigen/Eigen>
#include <vector>
#include "setting.h"

#include "common/particle_sph_3d.h"
#include "3D/VECTOR3_FIELD_3D.h"

class BasisSet3D {

public:
  BasisSet3D() {
  };

  ~BasisSet3D(){};

  virtual void FillVariationalTensor(std::vector<Adv_Tensor_Type> *Adv_tensor) = 0;
  virtual void InverseTransformToVelocity(
    Eigen::VectorXd& coefficients) = 0;
  virtual void interpolateToCartesian(VECTOR3_FIELD_3D* field) = 0;
  // Input a std::vector field, transform and output the basis coefficients.
  virtual void ForwardTransformtoFrequency(
      const VECTOR3_FIELD_3D& field, Eigen::VectorXd* coefficients) = 0;
  virtual void ForwardTransformDirect(const VECTOR3_FIELD_3D& df, Eigen::VectorXd* coefficients) = 0;
  const Eigen::MatrixXd& transferMat() const  {
    return A_;
  }

  int numBasisAll() const {
    return numBasisAll_;
  }

  int GetnumBasisOrtho() const  {
    return numBasisOrtho_;
  }
  // IO...
  virtual void writeToFile(std::ofstream& out, const std::vector<Adv_Tensor_Type>& C) const = 0;
  virtual void readFromFile(std::ifstream& in) = 0;
  virtual void ReSeedParticles(std::vector<ParticleSph3D>& particles, std::vector<Eigen::Vector3d>& initPos) = 0;
  virtual void projBackParticles(const std::vector<Eigen::Vector3d>& initPos, std::vector<ParticleSph3D>& particles) = 0;

  const Eigen::VectorXd& waveNum2() const {
    return waveNum2_;
  }

  // particles are always zero centered
  virtual VEC3 getVelocityCartesian(const VEC3& p, const VECTOR3_FIELD_3D& velocity) = 0;
  virtual Eigen::Vector3d getVelocityPos(const Eigen::Vector3d& pos) = 0;
  virtual Eigen::Vector3f getVelocityPos(const Eigen::Vector3f& pos) = 0;
  
  virtual void projPosBack(ParaParticle3Dd& p) = 0;
  virtual void projPosBack(ParaParticle3Df& p) = 0;

  void splatParticle(const double& ptlWeight, const double& dx, Eigen::Vector3d& p, FIELD_3D& density);
  void splatParticle(const double& ptlWeight, const double& dx, Eigen::Vector3f& p, FIELD_3D& density);

  template<typename DT, typename VT>
  static void splatParticleT(const double& ptlWeight, const double& dx, VT& p, FIELD_3D& density);
  const double& scale() {return scale_;}

  void advectRK4(ParticleSph3D& p, const double& dt_);
  void advectRK4(ParaParticle3Df& p, const double& dt_);
protected:
	
	int numBasisAll_;
  // number of orthogonal basis.
  int numBasisOrtho_;

	// inner product of all basis.
  Eigen::MatrixXd H_;
  // transfer matrix
  Eigen::MatrixXd A_;

  // square of wavenumbers.
  Eigen::VectorXd waveNum2_;

  // A constant scale to the basis so it lines up with the coordinates.
  double scale_ = 1.0;
  double scale3_ = 1.0;
};

#endif  // BASIS_SET_3D_H