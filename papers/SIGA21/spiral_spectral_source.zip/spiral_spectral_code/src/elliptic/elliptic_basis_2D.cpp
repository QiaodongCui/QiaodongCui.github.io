#include "elliptic/elliptic_basis_2D.h"

#include <unordered_map>


#define PHI0 c_*r*sin(k1*M_PI*r)*sin(k2*t),\
             sqrtCR*invk2*(sin(k1*M_PI*r) + k1*M_PI*r*cos(k1*M_PI*r))*cos(k2*t)

#define PHI1 c_*r*sin(k1*M_PI*r)*cos(k2*t),\
             -sqrtCR*invk2*(sin(k1*M_PI*r) + k1*M_PI*r*cos(k1*M_PI*r))*sin(k2*t)

#define PHI2 sqrtCR*cos(k1*M_PI*r)*sin(k2*t),\
             1.0*invk2*(c_*r*cos(k1*M_PI*r) - k1*M_PI/c_*(1.0 + c_*c_*r*r)*sin(k1*M_PI*r))*cos(k2*t)

#define PHI3 c_*r*cos(k1*M_PI*r)*cos(k2*t),\
             invk2*sqrtCR*(-cos(k1*M_PI*r) + k1*M_PI*r*sin(k1*M_PI*r))*sin(k2*t)

#define PHI4 0,\
             c_*r*sin(k1*M_PI*r)

// compuet without h
#define computeBasis switch (index_) {\
          case 0:\
            v << PHI0;\
          break;\
\
          case 1:\
            v << PHI1;\
          break;\
\
          case 2:\
            v << PHI2;\
          break;\
\
          case 3:\
            v << PHI3;\
          break;\
\
          case 4:\
            v << PHI4;\
          break;\
\
          default:\
          LOG(FATAL) << "idx " << index_ << "not supported";\
        }

void EllipticBasis2D::DiscretizeAdd(const double coef, const FIELD2D& radius, const FIELD2D& theta,
                                    VFIELD2D* vfield) const {
  double dx = 2.0 / vfield->getxRes();
  double dy = 2.0 / vfield->getyRes();
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  Eigen::Matrix2d trans;
  for (int j = 0; j < vfield->getyRes(); j++) {
    for (int i = 0; i < vfield->getxRes(); i++) {
      double r = radius(i,j);
      double t = theta(i,j);
      double h = sqrt(sin(t)*sin(t) + c_*c_*r*r);
      double sqrtCR = sqrt(1.0 + c_*c_*r*r);
      Eigen::Vector2d er(c_*r*cos(t)/h, sqrtCR*sin(t)/h);
      Eigen::Vector2d ev(-sqrtCR*sin(t)/h, c_*r*cos(t)/h);
      if (r > 1.0)
        continue;

      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      v/=h;
      v*= invNorm_*coef;
      // now it corresponds velocity in elliptic cord.
      // fr*er_x + ft*et_x
      (*vfield)(i,j)[0] = v[0]*er[0] + v[1]*ev[0];
      // fr*er_y + ft*et_y
      (*vfield)(i,j)[1] = v[0]*er[1] + v[1]*ev[1];
    }
  }
}

void EllipticBasis2D::AddUniformU(const double coef, const int nR, const int nTheta, double* ur, double* ut) const {
  double dr = 1.0 / nR;
  double dTheta = 2.0*M_PI/nTheta;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;

  for (int j = 0; j < nR; j++) {
    for (int i = 0; i < nTheta; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
      double h = sqrt(sin(t)*sin(t) + c_*c_*r*r);
      double sqrtCR = sqrt(1.0 + c_*c_*r*r);

      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      v/=h;
      // v now has the v_r, v_t corresponds to the polar velocity.
      // now it corresponds velocity in elliptic cord.
      v *= coef*invNorm_;
      int idx = i + j*nTheta;
      ur[idx] += v[0];
      ut[idx] += v[1];
    }
  }
}

// assume the field is already weight by jacobian/h
double EllipticBasis2D::ProjectUniformU(const int nR, const int nTheta, double* fr, double* ft) const {
  double dr = 1.0 / nR;
  double dTheta = 2.0*M_PI/nTheta;
  double invk2 = (k2x2 == 0) ? 1.0 : 1.0/k2;
  double result = 0;

  for (int j = 0; j < nR; j++) {
    for (int i = 0; i < nTheta; i++) {
      double r = ((double)(j) + 0.5)*dr;   // [0-1]
      double t = ((double)(i) + 0.5)*dTheta;// - M_PI;  // [0, 2*pi]
      double h = sqrt(sin(t)*sin(t) + c_*c_*r*r);
      double sqrtCR = sqrt(1.0 + c_*c_*r*r);

      Eigen::Vector2d v;
      v.setZero();
      computeBasis;
      //v/=h;
      // v now has the v_r, v_t corresponds to the polar velocity.
      // now it corresponds velocity in elliptic cord.
      int idx = i + j*nTheta;
      result += v[0]*fr[idx] + v[1]*ft[idx];
    }
  }
  result *= invNorm_;
  result *= dr*dTheta;

  return result;
}

void EllipticBasis2D::CatersianToElliptic(const double a, const double c, const double x, const double y, double& r, double& v) {
  const double B = x*x + y*y - a*a;
  const double sqrtac = sqrt(B*B + 4.0*a*a*y*y);
  const double q = (B + sqrtac)*0.5/a/a;
  const double p = (-B + sqrtac)*0.5/a/a;
  r = sqrt(q)/c;
  // p > 0, v \in [0, pi/2]
  v = asin(sqrt(p));
  // correct angle
  if (x < 0 && y >= 0)
    v = M_PI - v;
  else if (x <= 0 && y < 0)
    v = M_PI + v;
  else if (x > 0 && y < 0)
    v = 2.0*M_PI - v;
}

void EllipticBasis2D::FillFields(const int xRes, const int yRes, const double a, const double c,
                                 FIELD2D& radius, FIELD2D& theta, FIELD2D& h, FIELD2D& sqrtCR,
                                 VFIELD2D& er, VFIELD2D& ev) {
  const double dx = 2.0 / xRes;
  const double dy = 2.0 / yRes;
  radius = FIELD2D(xRes, yRes);
  theta = FIELD2D(xRes, yRes);
  h = FIELD2D(xRes, yRes);
  sqrtCR = FIELD2D(xRes, yRes);
  er = VFIELD2D(xRes, yRes);
  ev = VFIELD2D(xRes, yRes);

  // [-1, 1]x[-1, 1]
  for (int j = 0; j < yRes; j++) {
    for (int i = 0; i < xRes; i++) {
      const double x = -1.0 + ((double)(i) + 0.5)*dx;
      const double y = -1.0 + ((double)(j) + 0.5)*dx;
      double r = 0;
      double v = 0;
      CatersianToElliptic(a, c, x, y, r, v);
      radius(i,j) = r;
      theta(i,j) = v;
      h(i,j) = sqrt(c*c*r*r + sin(v)*sin(v));
      sqrtCR(i,j) = sqrt(1.0 + c*c*r*r);
      er(i,j)[0] = c*r/h(i,j)*cos(v);
      er(i,j)[1] = sqrtCR(i,j)/h(i,j)*sin(v);
      ev(i,j)[0] = -er(i,j)[1];
      ev(i,j)[1] = er(i,j)[0];
    }
  }
}

/*  // this is (sum ef1[i]*rComp[i])*(sum ef2[j]*rComp[i])*(sum tComp)*(sum tComp)
This function assumes r, t are seperable, hpow = 0
*/
double EllipticBasis2D::computeRTMultInt(const std::vector<EllipticFactor>& ef1, const std::vector<EllipticFactor>& ef2,
                                         const RTMultiply& rt1, const RTMultiply& rt2,
                                         const IntTable1DData& tabData) const {
  //std::vector<BasicFunc> rf = BasicFunc::vecVecMult(rt1.rComp, rt2.rComp);
  std::vector<BasicFunc> tfv = BasicFunc::vecVecMult(rt1.tComp, rt2.tComp);

  double result = 0;
  // CAN BE OPTIMZIED
  for (const auto& tf : tfv) {
    double thetaInt = tf.integrateP2Pi();
    if (thetaInt == 0)
      continue;

    for (int i = 0; i < rt1.rComp.size(); i++)
      for (int j = 0; j < rt2.rComp.size(); j++) {
        // ef1[i]*ef2[j]
        EllipticFactor ef = ef1[i];
        ef *= ef2[j];
        // multiply with Jacobian: abh^2/sqrt{1+c^2r^2}
        ef.hPow_ += 2;
        ef.sqrtCRPow_ -= 1;
        ef.coef_ *= tabData.a*tabData.b;

        std::vector<BasicFunc> rfv = BasicFunc::multiply(rt1.rComp[i], rt2.rComp[j]);

        for (const auto& rf : rfv)
          result += thetaInt*computeRInt(ef, rf, tabData);
      }
  }

  return result;
}

// <ef1*ef2>*<rfv>*<tfv>
double EllipticBasis2D::computeTripleMultInt(const TripleCoef& t1, const TripleCoef& t2, const IntTable1DData& tabData, 
                                             const bool withJacobian) {
  double result = 0;
  std::vector<BasicFunc> tfv = BasicFunc::multiply(t1.tf_, t2.tf_);
  EllipticFactor ef = t1.ef_;
  ef *= t2.ef_;
  // Jacobian already in nabla part
  if (withJacobian) {
    ef.hPow_ += 2;
    ef.sqrtCRPow_ -= 1;
    ef.coef_ *= tabData.a*tabData.b;
  }

  std::vector<BasicFunc> rfv = BasicFunc::multiply(t1.rf_, t2.rf_);
  
  // seperable
  if (ef.hPow_ == 0) {
    for (const auto& tf : tfv) {
      double thetaInt = tf.integrateP2Pi();
      if (thetaInt == 0)
        continue;
      for (const auto& rf : rfv)
        result += thetaInt*computeRInt(ef, rf, tabData);
    }
  } else {  // non seperable.
    for (const auto& tf : tfv) {
      if (tf.type == SIN || tf.type == ZERO || tf.wnx2 % 4 != 0)  // integrates to zero.
        continue;
      for (const auto& rf : rfv)
        result += tabData.query2D(ef, rf, tf);
    }
  }

  return result;
}

void EllipticBasis2D::TripleToPatternSet(const TripleCoef& t1, const TripleCoef& t2, const bool withJacobian, 
                                        std::unordered_map<uint64_t, double>& set) {
  std::vector<BasicFunc> tfv = BasicFunc::multiply(t1.tf_, t2.tf_);
  EllipticFactor ef = t1.ef_;
  ef *= t2.ef_;
  if (withJacobian) {
    ef.hPow_ += 2;
    ef.sqrtCRPow_ -= 1;
  }

  std::vector<BasicFunc> rfv = BasicFunc::multiply(t1.rf_, t2.rf_);
  for (auto& tf : tfv) {
    if (tf.type == SIN || tf.type == ZERO)  // integrates to zero.
      continue;
    for (auto& rf : rfv) {
      if (rf.type == ONE) {
        rf.type = COS;
        rf.wnx2 = 0;
      }
      if (tf.type == ONE) {
        tf.type = COS;
        tf.wnx2 = 0;
      }

      TripleCoef coefNew(rf, tf, ef);
      uint64_t hash = tripleCoefToHash(coefNew);
      // get rid of wavenumber info
       hash &= ~0x000000ffffffff00;
      //set.insert(hash);
      if (set.find(hash) == set.end())
        set[hash] = 0;
      //else
      //  set[hash] += coefNew.totalCoef();
      //if (rType == COS && tType == COS && ef.hPow_ == -2 && ef.sqrtCRPow_ == 2 && (ef.rPow_ + rf.rPower) == 0)
      //  exit(0);

    }
  }
}

// std::vector version of above. \int <vt1><vt2> = distribution law
double EllipticBasis2D::computeVTripleMultInt(const std::vector<TripleCoef>& vt1, const std::vector<TripleCoef>& vt2,
                                              const IntTable1DData& tabData, const bool withJacobian) {
  double result = 0;
  for (const auto& t1 : vt1) {
    for (const auto& t2 : vt2) {
      result += computeTripleMultInt(t1, t2, tabData, withJacobian);
    }
  }

  return result;
}

void EllipticBasis2D::VTripleMultIntToPatternSet(const std::vector<TripleCoef>& vt1, const std::vector<TripleCoef>& vt2, const bool withJacobian,
                                                 std::unordered_map<uint64_t, double>& set) {
  for (const auto& t1 : vt1) {
    for (const auto& t2 : vt2) {
      TripleToPatternSet(t1, t2, withJacobian, set);
    }
  }
}

// both works.
double EllipticBasis2D::dotProd1(const EllipticBasis2D& other, const IntTable1DData& tabData) const {
  double result = 0;
  const std::vector<TripleCoef>& UR = other.getU(0);
  const std::vector<TripleCoef>& UT = other.getU(1);
  double phir = phiFunc_[0].coef*other.getPhiFunc(0).coef;
  double phit = phiFunc_[1].coef*other.getPhiFunc(1).coef;
  // UR, UR
  result += phir*computeVTripleMultInt(UR, U_[0], tabData, true);

  // UT, UT
  result += phit*computeVTripleMultInt(UT, U_[1], tabData, true);

  return result;
}

void EllipticBasis2D::countTMultInt(const std::vector<EllipticFactor>& ef1, const std::vector<EllipticFactor>& ef2,
                        const RTMultiply& rt1, const RTMultiply& rt2,
                        std::unordered_set<uint64_t>& set) {

  std::vector<BasicFunc> tfv = BasicFunc::vecVecMult(rt1.tComp, rt2.tComp);
  double result = 0;
  for (const auto& tf : tfv) {
    for (int i = 0; i < rt1.rComp.size(); i++)
      for (int j = 0; j < rt2.rComp.size(); j++) {
        // ef1[i]*ef2[j]
        EllipticFactor ef = ef1[i];
        ef *= ef2[j];
        // multiply with Jacobian: abh^2/sqrt{1+c^2r^2}
        ef.hPow_ += 2;
        ef.sqrtCRPow_ -= 1;

        std::vector<BasicFunc> rfv = BasicFunc::multiply(rt1.rComp[i], rt2.rComp[j]);
        for (const auto& rf : rfv)
          countRTPattern(ef, rf, tf, set);
      }
  }
}

double EllipticBasis2D::intCRPow(const EllipticFactor& ef, const BasicFunc& rfun, const double& c) {
  int crPow = ef.sqrtCRPow_/2;
  
  switch(crPow) {
    case 0:  // r^rpow*fun
      return ef.coef_*rfun.integrateRPow(ef.rPow_);
    break;

    case 1:  //(r^rpow*fun+ r^rpow c^2 r^2*fun)
      return ef.coef_*(rfun.integrateRPow(ef.rPow_) + c*c*rfun.integrateRPow(ef.rPow_ + 2));
    break;
    
    case 2:  //r^rpow*(1 + 2 c^2 r^2 + c^4 r^4)*fun
      return ef.coef_*(rfun.integrateRPow(ef.rPow_) + 2.0*c*c*rfun.integrateRPow(ef.rPow_ + 2) + 
                       pow(c,4)*rfun.integrateRPow(ef.rPow_ + 4));
    break;

    case 3:  // r^rpow*(1+c^2 r^2)^3*fun
      return ef.coef_*(rfun.integrateRPow(ef.rPow_) + 3.0*c*c*rfun.integrateRPow(ef.rPow_ + 2) + 
                       3.0*pow(c,4)*rfun.integrateRPow(ef.rPow_ + 4) + pow(c, 6)*rfun.integrateRPow(ef.rPow_ + 6));
    break;

    default:
      LOG(FATAL) << "power not supported " << crPow;
  }

  return 0;
}

// Assume j is already in ef.
// int_{r=0}^{1} ef*fun(r) dr 
double EllipticBasis2D::computeRInt(const EllipticFactor& ef, const BasicFunc& rfun,
                                    const IntTable1DData& tabData) {
  // seperable
  if (ef.hPow_ == 0) {
    //double thetaInt = tfun.integrateP2Pi();
    //if (thetaInt == 0)
     // return 0;
    if (ef.sqrtCRPow_ % 2 != 0) { // has to be computed numerically.
      return tabData.queryTable(ef, rfun);
    } else {    // analytical solution exists.
      //int crPow = ef.sqrtCRPow_ /2;
      // r^rpow*(1+c^2 r^2)^crPow*fun
      return intCRPow(ef, rfun, tabData.c);
    }
  } else {
    // non seperable.
    LOG(FATAL) << "non seperable not supported yet";
  }

  return 0;
}

// count the patterns in RT integral. if hpow == 0, then seperable, otherwise not.
void EllipticBasis2D::countRTPattern(const EllipticFactor& ef, const BasicFunc& rfun, const BasicFunc& tfun,
                                     std::unordered_set<uint64_t>& set) {
  if (tfun.type == ZERO || rfun.type == ZERO) {
    return;
  }
  FUNTYPE rType = rfun.type;
  FUNTYPE tType = tfun.type;
  if (rType == ONE)
    rType = COS;
  if (tType == ONE)
    tType = COS;
  uint64_t hash = tripleInfoToHash(ef.hPow_, ef.sqrtCRPow_, ef.rPow_ + rfun.rPower, rType, tType);
  set.insert(hash);
}

// convert tcoef to hash, without the double coefficients.
// The information contains-> hpow, rpow, sqrtpow, rtype, ttype, k1x2, k2x2
// ellipfactor*rf*tf
// hpow, rpow, sqrtpow->8 bits each = 24 bits total
// k1x2, k2x2 -> 16 bits each = 32 bits total
// rtype, ttype -> 4 bits each = 8 bits total.
// total of 64 bits
uint64_t EllipticBasis2D::tripleCoefToHash(const TripleCoef& tcoef) {
  uint64_t result = 0;
  int hpow = tcoef.ef_.hPow_;
  int rpow = tcoef.ef_.rPow_ + tcoef.rf_.rPower;
  int sqrtpow = tcoef.ef_.sqrtCRPow_;
  result |= (0xff00000000000000 & static_cast<uint64_t>(hpow) << 56);
  result |= (0x00ff000000000000 & static_cast<uint64_t>(rpow) << 48);
  result |= (0x0000ff0000000000 & static_cast<uint64_t>(sqrtpow) << 40);
  result |= (0x000000ffff000000 & static_cast<uint64_t>(tcoef.rf_.wnx2) << 24);
  result |= (0x0000000000ffff00 & static_cast<uint64_t>(tcoef.tf_.wnx2) << 8);
  result |= (0x00000000000000f0 & static_cast<uint64_t>(tcoef.rf_.type) << 4);
  result |= (0x000000000000000f & static_cast<uint64_t>(tcoef.tf_.type));

  return result;
}

// doesnot include wavenumber
uint64_t EllipticBasis2D::tripleInfoToHash(const int hpow, const int sqrtpow, const int rpow,
                                           const FUNTYPE rType, const FUNTYPE tType) {
  uint64_t result = 0;
  result |= (0xff00000000000000 & static_cast<uint64_t>(hpow) << 56);
  result |= (0x00ff000000000000 & static_cast<uint64_t>(rpow) << 48);
  result |= (0x0000ff0000000000 & static_cast<uint64_t>(sqrtpow) << 40);
  result |= (0x00000000000000f0 & static_cast<uint64_t>(rType) << 4);
  result |= (0x000000000000000f & static_cast<uint64_t>(tType));

  return result;
}

TripleCoef EllipticBasis2D::hashToTriple(const uint64_t& hash) {
  int hpow = static_cast<signed char>(0x00000000000000ff & (hash >> 56));
  int rpow = static_cast<signed char>(0x00000000000000ff & (hash >> 48));
  int sqrtpow = static_cast<signed char>(0x00000000000000ff & (hash >> 40));
  int rwn = static_cast<short>(0x000000000000ffff & (hash >> 24));
  int twn = static_cast<short>(0x000000000000ffff & (hash >> 8));
  FUNTYPE rType = static_cast<FUNTYPE>(0x000000000000000f & (hash >> 4));
  FUNTYPE tType = static_cast<FUNTYPE>(0x000000000000000f & hash);

  TripleCoef result(BasicFunc(rType, R, rwn, 1.0), BasicFunc(tType, T, twn, 1.0), EllipticFactor(hpow, sqrtpow, rpow, 1.0));
  return result;
}

void EllipticBasis2D::hashToTripleInfo(const uint64_t& hash, int& hpow, int& sqrtpow, int& rpow, FUNTYPE& rType, FUNTYPE& tType) {
  hpow = static_cast<signed char>(0x00000000000000ff & (hash >> 56));
  rpow = static_cast<signed char>(0x00000000000000ff & (hash >> 48));
  sqrtpow = static_cast<signed char>(0x00000000000000ff & (hash >> 40));
  //int rwn = static_cast<short>(0x000000000000ffff & (hash >> 24));
  //int twn = static_cast<short>(0x000000000000ffff & (hash >> 8));
  rType = static_cast<FUNTYPE>(0x000000000000000f & (hash >> 4));
  tType = static_cast<FUNTYPE>(0x000000000000000f & hash);
}

void EllipticBasis2D::enumeratePattern(std::unordered_set<uint64_t>& set) {
  // total of 5 types.
  // some randomwn, doesnt matter.
  int i1 = 2, j1 = 8;
  for (int idxI = 0; idxI < 5; idxI++)
    for (int idxJ = idxI; idxJ < 5; idxJ++) {
      int i2 = (idxI == 4) ? 0 : 6;
      int j2 = (idxJ == 4) ? 0 : 12;
      EllipticBasis2D basisI(i1, i2, idxI, 0.9);
      EllipticBasis2D basisJ(j1, j2, idxJ, 0.9);

      for (int i = 0; i < 2; i++) {
        // then integrate along theta and phi.
        const std::vector<RTMultiply>& IRT = basisI.getRT(i);
        const std::vector<RTMultiply>& JRT = basisJ.getRT(i);
        const std::vector<std::vector<EllipticFactor>>& IEF = basisI.geteRFact(i);
        const std::vector<std::vector<EllipticFactor>>& JEF = basisJ.geteRFact(i);

        for (int rt1 = 0; rt1 < IRT.size(); rt1++) {
          for (int rt2 = 0; rt2 < JRT.size(); rt2++) {
            countTMultInt(IEF[rt1], JEF[rt2], IRT[rt1], JRT[rt2], set);
          }
        }
      }
    }
}

void EllipticBasis2D::printPattern(std::unordered_set<uint64_t>& set) {
  for (const auto& hash : set) {
    // hashToPattern(hash, hpow, rpow, sqrtPow, rtype, tType);
    TripleCoef coef = hashToTriple(hash);
    coef.print();
    printf("\n");
  }
}

void EllipticBasis2D::exportNumericalPattern1D(const std::unordered_set<uint64_t>& set, const std::string& fname) {
  std::unordered_set<uint64_t> pattern1D;
  int hpow, rpow, sqrtPow;
  FUNTYPE rType, tType;
  for (const auto& hash : set) {
    hashToTripleInfo(hash, hpow, sqrtPow, rpow, rType, tType);
    // these has to be computed numerically.
    if (hpow == 0 && (sqrtPow%2 != 0 || sqrtPow < 0)) {
      //pattern1D.insert(patternToHash(hpow, rpow, sqrtPow, rType, ONE));
      pattern1D.insert(tripleInfoToHash(hpow, sqrtPow, rpow, rType, ONE));
    }
  }
  // output to file.
  exportNumericalPatternTensor(pattern1D, fname);
}

void EllipticBasis2D::exportNumericalPatternTensor(const std::unordered_map<uint64_t, double>& set) {
  // output to file.
  std::ofstream out("./Tensor/patternTensor.txt");
  for (const auto& hash : set) {
    TripleCoef result = EllipticBasis2D::hashToTriple(hash.first);
    int hpow = result.ef_.hPow_;
    int rpow = result.ef_.rPow_ + result.rf_.rPower;
    int sqrtPow = result.ef_.sqrtCRPow_;
    out << hpow << " " << sqrtPow << " " << rpow << " " << result.rf_.type << " " << result.tf_.type << "\n";
  }
  out.close();
}

void EllipticBasis2D::exportNumericalPatternTensor(const std::unordered_set<uint64_t>& set, const std::string& fname) {
  // output to file.
  std::ofstream out(fname);
  for (const auto& hash : set) {
    TripleCoef result = EllipticBasis2D::hashToTriple(hash);
    int hpow = result.ef_.hPow_;
    int rpow = result.ef_.rPow_ + result.rf_.rPower;
    int sqrtPow = result.ef_.sqrtCRPow_;
    out << hpow << " " << sqrtPow << " " << rpow << " " << result.rf_.type << " " << result.tf_.type << "\n";
  }
  out.close();
}

double EllipticBasis2D::dotProd(const EllipticBasis2D& other, const IntTable1DData& tabData) const {
  Eigen::Vector2d result(0,0);

  for (int i = 0; i < 2; i++) {
    // <phi_i, phi_i>    
    double pINT = phiFunc_[i].coef*other.getPhiFunc(i).coef;

    if (pINT == 0)
      result[i] = 0.0;
    else {
      // then integrate along theta and phi.
      double rtINT = 0;
      for (int rt1 = 0; rt1 < RT_[i].size(); rt1++) {
        const std::vector<RTMultiply>& otherRT = other.getRT(i);
        const std::vector<std::vector<EllipticFactor>>& otherEF = other.geteRFact(i); 
        for (int rt2 = 0; rt2 < otherRT.size(); rt2++) {
          rtINT += computeRTMultInt(eRFact_[i][rt1], otherEF[rt2],
                                    RT_[i][rt1], otherRT[rt2], tabData);
        }
      }

      result[i] = pINT*rtINT;
    }
  }

  return result.sum();
  //return dotProd1(other, tabData);
}

// D[ef*f, t] = D[ef, t]*f + ef*D[f, t]
void EllipticBasis2D::derivT(const EllipticFactor& ef, const BasicFunc& f,
                             std::vector<EllipticFactor>& efReturn, std::vector<BasicFunc>& bfReturn) {
  EllipticFactor dEf;
  BasicFunc dFun1;
  ef.derivT(dFun1, dEf);
  // D[ef, t] != 0
  if (dFun1.type != ZERO) {  // dEf*(f*dfun)
    std::vector<BasicFunc> mult = BasicFunc::multiply(dFun1, f);
    for (const auto& m : mult) {
      efReturn.push_back(dEf);
      bfReturn.push_back(m);
    }
  }

  // ef*D[f, t]
  BasicFunc df = f.derivT();
  if (df.type != ZERO) {
    efReturn.push_back(ef);
    bfReturn.push_back(df);
  }
}

// D[er*f, r] = D[ef, r]*f + ef*D[f, r]
void EllipticBasis2D::derivR(const EllipticFactor& ef, const BasicFunc& f, const double c,
                             std::vector<EllipticFactor>& efReturn, std::vector<BasicFunc>& bfReturn) {
  // coef*h^{hpow}*sqrt{1 + c^2 r^2}^{sqrtCRpow}*r^{rpowA}*fun
  EllipticFactor efAdd = ef;
  BasicFunc fwoR = f;
  // transfer the power of f to power of r.
  efAdd.rPow_ += fwoR.rPower;
  fwoR.rPower = 0;
  // ef*D[f, r]
  BasicFunc df = fwoR.derivR();
  if (df.type != ZERO) {
    efReturn.push_back(efAdd);
    bfReturn.push_back(df);
  }

  // D[ef, r]*f = (ef[0] + ef[1] + ef[2])*f
  // derivR(const double& c, EllipticFactor& d1, EllipticFactor& d2, EllipticFactor& d3)
  EllipticFactor def[3];
  efAdd.derivR(c, def[0], def[1], def[2]);
  for (int i = 0; i < 3; i++) {
    if (def[i].coef_ != 0) {
      efReturn.push_back(def[i]);
      bfReturn.push_back(fwoR);
    }
  }
}

// length of rf should match to length of rcomp in rt
void EllipticBasis2D::RTMtoTriple(const RTMultiply& rt, const std::vector<EllipticFactor>& efv,
                                  std::vector<TripleCoef>& coefReturn) {
  CHECK(efv.size() == rt.rComp.size());
  for (int i = 0; i < efv.size(); i++){
    for (int j = 0; j < rt.tComp.size(); j++) {
      BasicFunc rf = rt.rComp[i];
      BasicFunc tf = rt.tComp[j];
      EllipticFactor ef = efv[i];
      ef.rPow_ += rf.rPower;
      rf.rPower = 0;
      coefReturn.push_back(TripleCoef(rf, tf, ef));
    }
  }
}

// see elliptic3D for descriptions.
// (std::vector<BasicFunc> rComp*std::vector<EllipticFactor>)*(std::vector<BasicFunc> tComp)
// EllipticFactor(const int hp, const int sqrtP, const int rP, const double coef)
// sign is carred into the curlCoef terms.
void EllipticBasis2D::curlSph() {
  //std::vector<TripleCoef> fv;
  for (int i = 0; i < RT_[1].size(); i++) {
    RTMtoTriple(RT_[1][i], eRFact_[1][i], U_[1]);  // unrolled fv
  }

  //std::vector<TripleCoef> fr;
  for (int i = 0; i < RT_[0].size(); i++) {
    RTMtoTriple(RT_[0][i], eRFact_[0][i], U_[0]);  // unrolled fr
  }

  BasicFunc COSR(COS, R, k1x2, 1.0);
  BasicFunc SINR(SIN, R, k1x2, 1.0);
  BasicFunc COST(COS, T, k2x2, 1.0);
  BasicFunc SINT(SIN, T, k2x2, 1.0);
  BasicFunc COSZERO(COS, T, 0, 1.0);
  // See from EllipticTensor.nb
  if (index_ == 0) { // phi0
    EllipticFactor ef0(0, -1, 0, 2.0*M_PI*a_*k1/k2);
    EllipticFactor ef1(0, -1, 2, 3.0*a_*c_*c_*k1*M_PI/k2);
    double efConst = a_*c_*c_/k2 -a_*c_*c_*k2 -a_*k1*k1*M_PI*M_PI/k2;
    EllipticFactor ef24(0, -1, 1, efConst); // 2,3,4
    EllipticFactor ef5(0, -1, 3, -a_*c_*c_*k1*k1*M_PI*M_PI/k2);
    curlRT_ = {TripleCoef(COSR, COST, ef0), TripleCoef(COSR, COST, ef1), TripleCoef(SINR, COST, ef24), TripleCoef(SINR, COST, ef5)};
  } else if (index_ == 1) {
    EllipticFactor ef0(0, -1, 0, -2.0*a_*k1*M_PI/k2);
    EllipticFactor ef1(0, -1, 2, -3.0*a_*c_*c_*k1*M_PI/k2);
    double efConst = - a_*c_*c_/k2 + a_*c_*c_*k2 + a_*k1*k1*M_PI*M_PI/k2;
    EllipticFactor ef24(0, -1, 1, efConst);
    EllipticFactor ef5(0, -1, 3, a_*c_*c_*k1*k1*M_PI*M_PI/k2);
    curlRT_ = {TripleCoef(COSR, SINT, ef0), TripleCoef(COSR, SINT, ef1), TripleCoef(SINR, SINT, ef24), TripleCoef(SINR, SINT, ef5)};
  } else if (index_ == 2) {
    double efConst = a_*c_/k2 - a_*c_*k2 - a_*k1*k1*M_PI*M_PI/k2/c_;
    EllipticFactor ef02(0, 0, 0, efConst);
    EllipticFactor ef3(0, 0, 2, -a_*c_*k1*k1*M_PI*M_PI/k2);
    EllipticFactor ef4(0, 0, 1, -3.0*a_*c_*k1*M_PI/k2);
    curlRT_ = {TripleCoef(COSR, COST, ef02), TripleCoef(COSR, COST, ef3), TripleCoef(SINR, COST, ef4)};
  } else if (index_ == 3) {
    double efConst = -a_*c_*c_/k2 + a_*c_*c_*k2 + a_*k1*k1*M_PI*M_PI/k2;
    EllipticFactor ef02(0, -1, 1, efConst);
    EllipticFactor ef3(0, -1, 3, a_*c_*c_*k1*k1*M_PI*M_PI/k2);
    EllipticFactor ef4(0, -1, 0, 2.0*M_PI*a_*k1/k2);
    EllipticFactor ef5(0, -1, 2, 3.0*a_*c_*c_*k1*M_PI/k2);
    curlRT_ = {TripleCoef(COSR, SINT, ef02), TripleCoef(COSR, SINT, ef3), TripleCoef(SINR, SINT, ef4), TripleCoef(SINR, SINT, ef5)};
  } else if (index_ == 4) {
    EllipticFactor ef0(0, 0, 1, a_*c_*k1*M_PI);
    EllipticFactor ef1(0, 0, 0, a_*c_);
    curlRT_ = {TripleCoef(COSR, COSZERO, ef0), TripleCoef(SINR, COSZERO, ef1)};
  }
}

// phiG_r phiH_t - phiG_t PhiH_r
// result[0] = phiG_r phiH_t
// sign is in phi component.
void EllipticBasis2D::crossProdRT(const EllipticBasis2D& phiG, const EllipticBasis2D& phiH,
                                  std::vector<TripleCoef> (&result)[2]) {
  // phiG_r phiH_t
  // std::vector<TripleCoef>*std::vector<TripleCoef>
  const std::vector<TripleCoef>& Grv = phiG.getU(0);
  const std::vector<TripleCoef>& Htv = phiH.getU(1);
  for (const auto& Gr : Grv) {
    for (const auto& Ht : Htv) {
      TripleCoef::multiply(Gr, Ht, result[0]);
    }
  }
  // phiG_t PhiH_r
  const std::vector<TripleCoef>& Gtv = phiG.getU(1);
  const std::vector<TripleCoef>& Hrv = phiH.getU(0);
  for (const auto& Gt : Gtv) {
    for (const auto& Hr : Hrv) {
      TripleCoef::multiply(Gt, Hr, result[1]);
    }
  }
}

double EllipticBasis2D::computeTensorEntry(const EllipticBasis2D& phiG, const EllipticBasis2D& phiH, const IntTable1DData& tabData) const {
  std::vector<BasicFunc> crossPhi[2];
  std::vector<TripleCoef> crossRT[2];
  PolarBasisAll::crossProdPhi(phiG, phiH, crossPhi);
  crossProdRT(phiG, phiH, crossRT);
  // int_{\omega} {J (\nabla \times phi_i)}_r * {phi_g \times phi_h}_r d omega
  double result = 0;
    // (curlCoef_[i]*crossRT[0])*(curlPhi_[i]*crossPhi[0]) +
    // (curlCoef_[i]*crossRT[1])*(curlPhi_[i]*crossPhi[1]);
  double phiDot0 = 0; 
  for (const auto& phi0 : crossPhi[0])
    phiDot0 += phi0.coef;  // only carry constants
  if (phiDot0 != 0) {
    result += phiDot0*computeVTripleMultInt(curlRT_, crossRT[0], tabData, false);
  }

  double phiDot1 = 0;
  for (const auto& phi1 : crossPhi[1])
    phiDot1 += phi1.coef;  // only carry constants
  if (phiDot1 != 0) {
    result += phiDot1*computeVTripleMultInt(curlRT_, crossRT[1], tabData, false);
  }
  
  return result*invNorm_*phiG.GetInvNorm()*phiH.GetInvNorm();
}

void EllipticBasis2D::enumerateTensorEntry(const EllipticBasis2D& phiG, const EllipticBasis2D& phiH, std::unordered_map<uint64_t, double>& set) {
  std::vector<TripleCoef> crossRT[2];
  crossProdRT(phiG, phiH, crossRT);

  VTripleMultIntToPatternSet(curlRT_, crossRT[0], false, set);
  VTripleMultIntToPatternSet(curlRT_, crossRT[1], false, set);

}

void EllipticBasis2D::writeToFile(std::ofstream& out) {
  out.write(reinterpret_cast<const char *>(&k1x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&k2x2), sizeof(int));
  out.write(reinterpret_cast<const char *>(&index_), sizeof(int));
}

EllipticBasis2D* EllipticBasis2D::fromFile(std::ifstream& in, const IntTable1DData& tabData) {
  int k1x2, k2x2;
  int index_;
  in.read(reinterpret_cast<char *>(&k1x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&k2x2), sizeof(int));
  in.read(reinterpret_cast<char *>(&index_), sizeof(int));

  return new EllipticBasis2D(k1x2, k2x2, index_, tabData);
}