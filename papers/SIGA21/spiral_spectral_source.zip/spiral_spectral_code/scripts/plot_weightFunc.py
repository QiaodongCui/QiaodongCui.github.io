import numpy as np
import matplotlib.pyplot as plt
from matplotlib import pyplot as pl
import matplotlib.pyplot as plt

dx = 0.001
r = np.arange(0,1, dx)

font_size = 15
linge_width = 2

fig, ax = plt.subplots()
ax.set_ylabel('f(r) ', fontsize = font_size)
ax.set_xlabel('r', fontsize = font_size)
#ax.set_title('Forward scattering amplified 5.0', fontsize = font_size )

sinW = np.sin(np.pi/2*r)
pieceW = -100.0*r**2 + 20.0*r
pieceW[int(0.1/dx) : ] = 1
line1, = ax.plot(r.transpose(), sinW.transpose(), color = 'blue' , lw = linge_width, label="f(r) = sin(Pi/2*r)")
line1, = ax.plot(r.transpose(), pieceW.transpose(), color = 'red' , lw = linge_width, label="f(r) = -100r^2 + 20r, r < 0.1")

plt.ylim(0, 1.1)
plt.xlim(0, 1.1)
ax.legend(loc='lower right', fontsize = font_size)

#plt.xticks(np.arange(0, x_ceil, 200))
#for tick in ax.xaxis.get_major_ticks():
#                tick.label.set_fontsize(font_size)
#for tick in ax.yaxis.get_major_ticks():
#               tick.label.set_fontsize(font_size)   
#plt.axes().set_aspect('equal', 'datalim')
plt.tight_layout()
plt.savefig("./weightFunCylinder.pdf",  bbox_inches='tight')