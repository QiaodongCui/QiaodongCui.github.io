#ifndef TOR2D_EVAL_P_H
#define TOR2D_EVAL_P_H

#include <cmath>
#include <vector>
#include "tensorCompute/trig_integral.h"

#define Sin2Pi TrigInt::IntegrateSin2Pi_D2
#define Cos2Pi TrigInt::IntegrateCos2Pi_D2
#define Pi M_PI


class tor2DpEval{
public:
tor2DpEval();
std::vector<double (*)(const int, const int, const int)> pointers_;
~tor2DpEval(){};
/* Sin[g2*p]Sin[i2*p]Cos[h2*p]*/
static double evalP_0(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2-i2x2)+Cos2Pi(g2x2+h2x2-i2x2)-Cos2Pi(g2x2-h2x2+i2x2)-Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[h2*p]Sin[i2*p]Cos[g2*p]*/
static double evalP_1(const int i2x2, const int g2x2, const int h2x2){
return (-Cos2Pi(g2x2-h2x2-i2x2)+Cos2Pi(g2x2+h2x2-i2x2)+Cos2Pi(g2x2-h2x2+i2x2)-Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[g2*p]Sin[h2*p]Sin[i2*p]*/
static double evalP_2(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2-i2x2)+Sin2Pi(g2x2+h2x2-i2x2)+Sin2Pi(g2x2-h2x2+i2x2)-Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[i2*p]Cos[g2*p]Cos[h2*p]*/
static double evalP_3(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2-i2x2)-Sin2Pi(g2x2+h2x2-i2x2)+Sin2Pi(g2x2-h2x2+i2x2)+Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[i2*p]Cos[g2*p]*/
static double evalP_4(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-i2x2)+Sin2Pi(g2x2+i2x2))/2.;
};

/* Sin[g2*p]Sin[i2*p]*/
static double evalP_5(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-i2x2)-Cos2Pi(g2x2+i2x2))/2.;
};

/* Sin[i2*p]Cos[h2*p]*/
static double evalP_6(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(h2x2-i2x2)+Sin2Pi(h2x2+i2x2))/2.;
};

/* Sin[h2*p]Sin[i2*p]*/
static double evalP_7(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(h2x2-i2x2)-Cos2Pi(h2x2+i2x2))/2.;
};

/* 1*/
static double evalP_8(const int i2x2, const int g2x2, const int h2x2){
return 2*Pi;
};

/* Sin[g2*p]Cos[h2*p]Cos[i2*p]*/
static double evalP_9(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(g2x2-h2x2-i2x2)+Sin2Pi(g2x2+h2x2-i2x2)+Sin2Pi(g2x2-h2x2+i2x2)+Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[h2*p]Cos[g2*p]Cos[i2*p]*/
static double evalP_10(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2-i2x2)+Sin2Pi(g2x2+h2x2-i2x2)-Sin2Pi(g2x2-h2x2+i2x2)+Sin2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Sin[g2*p]Sin[h2*p]Cos[i2*p]*/
static double evalP_11(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2-i2x2)-Cos2Pi(g2x2+h2x2-i2x2)+Cos2Pi(g2x2-h2x2+i2x2)-Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Cos[g2*p]Cos[h2*p]Cos[i2*p]*/
static double evalP_12(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2-i2x2)+Cos2Pi(g2x2+h2x2-i2x2)+Cos2Pi(g2x2-h2x2+i2x2)+Cos2Pi(g2x2+h2x2+i2x2))/4.;
};

/* Cos[g2*p]Cos[i2*p]*/
static double evalP_13(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-i2x2)+Cos2Pi(g2x2+i2x2))/2.;
};

/* Sin[g2*p]Cos[i2*p]*/
static double evalP_14(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(g2x2-i2x2)+Sin2Pi(g2x2+i2x2))/2.;
};

/* Cos[h2*p]Cos[i2*p]*/
static double evalP_15(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(h2x2-i2x2)+Cos2Pi(h2x2+i2x2))/2.;
};

/* Sin[h2*p]Cos[i2*p]*/
static double evalP_16(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(h2x2-i2x2)+Sin2Pi(h2x2+i2x2))/2.;
};

/* Sin[g2*p]Cos[h2*p]*/
static double evalP_17(const int i2x2, const int g2x2, const int h2x2){
return (Sin2Pi(g2x2-h2x2)+Sin2Pi(g2x2+h2x2))/2.;
};

/* Sin[h2*p]Cos[g2*p]*/
static double evalP_18(const int i2x2, const int g2x2, const int h2x2){
return (-Sin2Pi(g2x2-h2x2)+Sin2Pi(g2x2+h2x2))/2.;
};

/* Sin[g2*p]Sin[h2*p]*/
static double evalP_19(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2)-Cos2Pi(g2x2+h2x2))/2.;
};

/* Cos[g2*p]Cos[h2*p]*/
static double evalP_20(const int i2x2, const int g2x2, const int h2x2){
return (Cos2Pi(g2x2-h2x2)+Cos2Pi(g2x2+h2x2))/2.;
};

/* Cos[g2*p]*/
static double evalP_21(const int i2x2, const int g2x2, const int h2x2){
return Cos2Pi(g2x2);
};

/* Sin[g2*p]*/
static double evalP_22(const int i2x2, const int g2x2, const int h2x2){
return Sin2Pi(g2x2);
};

/* Cos[h2*p]*/
static double evalP_23(const int i2x2, const int g2x2, const int h2x2){
return Cos2Pi(h2x2);
};

/* Sin[h2*p]*/
static double evalP_24(const int i2x2, const int g2x2, const int h2x2){
return Sin2Pi(h2x2);
};

};

#endif // TOR2D_EVAL_P_H