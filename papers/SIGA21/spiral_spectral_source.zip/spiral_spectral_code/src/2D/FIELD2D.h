#ifndef FIELD2D_H
#define FIELD2D_H

#include <cassert>
#include <fstream>
#include <memory>
#include <stdlib.h>
#include <stdio.h>
#include "setting.h"

class FIELD2D
{
public:
	FIELD2D(){};

	//x minor index, y multiplied by xres
	inline Real& operator()(int x, int y) { 
		assert(  y >= 0 && y < yRes && x >= 0 && x < xRes);
		return data[ y * xRes + x]; 
	};
 		//x minor index, y multiplied by xres
	inline const Real& operator()(int x, int y) const { 
		assert(  y >= 0 && y < yRes && x >= 0 && x < xRes);
		return data[ y * xRes + x]; 
	};

	inline Real& operator[](int x) { return data[x]; };
	const Real operator[](int x) const { return data[x]; };
	FIELD2D(int _xRes, int _yRes):xRes(_xRes),yRes(_yRes)
	{
		data = (Real*) malloc(sizeof(Real) * xRes* yRes);
		//memset(data, 0x00, sizeof(Real) * xRes * yRes);
		for(int i=0;i<xRes*yRes;i++)
			data[i] = 0.;
		totalsize = xRes*yRes;
	}
	void CheckNegative();
	FIELD2D& operator *=(const Real alpha);
	FIELD2D& operator +=(const Real alpha);
// 	FIELD2D& operator=(const Real& alpha);
// 	FIELD2D& operator=(const FIELD2D& A);
	FIELD2D& operator +=(const FIELD2D& input);
	FIELD2D& operator *=(const FIELD2D& input);
	void clear();
	void setZeroBorder();
    void setZeroBorder2Layers();
	Real* getdata(){return data;}
	void swapPointer(FIELD2D& field);
	int getxRes() const {return xRes;}
	int getyRes() const {return yRes;}

	void copyBorderAll();
	Real dot(const FIELD2D& in);
	void axpy(const Real& alpha, const FIELD2D& input);
	Real& get_dens(int i) {return data[i];}
	void Field2D_Save(FILE* out);
	// Debug only
	void checkValue();
	Real max();

	// Get the value at a specific position.
  Real GetValue(const float pos_x, const float pos_y) const;
  void writeToFile(std::ofstream& out) const;

protected:
	int totalsize;
	int xRes;
	int yRes;
	Real* data;

};



#endif
