#include <Eigen/Eigen>
#include <glog/logging.h>
#include <math.h>
#include <unordered_set>

#include "common/basic_function.h"
#include "elliptic/elliptic_basis_2D.h"


using namespace std;

std::vector<std::vector<int>> normTestWn = {{1, 2}, {1, 4}, {1, 6}, {1, 8}, {1, 10}, {2, 2}, {2, 4}, {2, 6}, {2, 
  8}, {2, 10}, {3, 2}, {3, 4}, {3, 6}, {3, 8}, {3, 10}, {4, 2}, {4, 
  4}, {4, 6}, {4, 8}, {4, 10}, {5, 2}, {5, 4}, {5, 6}, {5, 8}, {5, 
  10}};

std::vector<double> val1 = {3.1267, 1.33585, 1.00421, 0.888137, 0.834411, 4.73654, 1.53387, \
0.940785, 0.733204, 0.637124, 10.3429, 2.96426, 1.59784, 1.11959, \
0.898234, 16.0626, 4.37485, 2.21045, 1.45291, 1.10228, 25.4058, \
6.72102, 3.26088, 2.04983, 1.48928};


std::vector<double> val2 = {2.22148, 1.12147, 0.917769, 0.846473, 0.813472, 7.71715, 2.64336, \
1.70376, 1.37491, 1.22269, 14.3463, 4.27146, 2.40574, 1.75274, \
1.4505, 25.4396, 7.06022, 3.65663, 2.46538, 1.914, 38.0227, 10.1971, \
5.0442, 3.24069, 2.40592};

std::vector<double> val3 = {1.58582, 0.573028, 0.385474, 0.319831, 0.289447, 5.63122, 1.78882, \
1.07726, 0.828216, 0.712944, 9.45026, 2.71478, 1.46747, 1.03091, \
0.82885, 16.9262, 4.60309, 2.32104, 1.52232, 1.15262, 24.5487, \
6.49836, 3.1557, 1.98576, 1.44425};

std::vector<double> val4 = {1.4778, 1.4778, 1.4778, 1.4778, 1.4778, 0.932631, 0.932631, \
0.932631, 0.932631, 0.932631, 1.00941, 1.00941, 1.00941, 1.00941, \
1.00941, 0.957873, 0.957873, 0.957873, 0.957873, 0.957873, 0.985526, \
0.985526, 0.985526, 0.985526, 0.985526};

std::vector<double> val5 = {0.0598199, 0.332724, -0.0032636, -0.00467901, 0.0573027, 0.0249247, \
-0.0158619, -0.127903, -0.14389, -28.9069, -0.0967989, 0.105177, \
-0.0323261, 0.13477, 0.779602, 0.0128451, -0.852261, -0.0235413, \
-45.9452, -0.0802956, -0.190016, -0.0919631, 0.381562, 0.0247328, \
-0.0641024, -0.0408853, -0.973575};

std::vector<double> val6 = {0.0576544, 0.501999, 0.00641929, 0.00912572, 0.0906371, 0.0301558, \
-0.00445806, -0.0691353, -0.0826417, -18.8342, -0.0878555, 0.0949422, \
-0.0167205, 0.204981, 1.14049, 0.0345814, -0.551648, -0.00651847, \
-29.9528, -0.0483437, -0.11612, -0.0807782, 0.288009, 0.0452125, \
-0.0400037, -0.0232022, -0.629904};

std::vector<std::vector<int>> AR = {{5, 40, 14, 5, 48, 6}, {12, 10, 56, 27, 2, 32}, {20, 60, 20, 30, 
    50, 20}, {14, 42, 36, 21, 26, 54}, {30, 36, 2, 30, 10, 22}, {7, 
    38, 40, 1, 12, 8}, {17, 54, 6, 28, 34, 12}, {7, 16, 22, 22, 20, 
    58}, {9, 18, 36, 10, 4, 28}, {17, 2, 20, 12, 60, 14}, {4, 52, 6, 
    19, 4, 18}, {3, 26, 20, 27, 18, 8}, {23, 56, 52, 11, 22, 40}, {24,
     22, 4, 15, 46, 60}, {26, 10, 50, 27, 42, 48}, {14, 32, 30, 8, 20,
     14}, {25, 14, 18, 28, 2, 56}, {8, 30, 4, 8, 44, 38}, {27, 2, 52, 
    21, 8, 22}, {25, 42, 60, 20, 26, 54}, {13, 20, 60, 22, 56, 
    26}, {4, 36, 18, 8, 30, 32}, {1, 16, 26, 11, 42, 38}, {24, 42, 38,
     23, 52, 4}, {4, 18, 8, 11, 16, 46}, {29, 60, 26, 27, 38, 
    50}, {21, 12, 24, 14, 42, 34}};

namespace {

void testEllipticFactor() {
	const double c = 5.0;
	EllipticFactor f1(-1, 1, 0, 0.5);
	EllipticFactor f2(-1, 1, 0, 0.5);
	EllipticFactor f3(-1, 0, 1, 0.5);
	EllipticFactor f4(-1, 0, 1, 0.5);
	f1 *= f2;
	f3 *= f4;
	f1.print();
	f3.print();
	printf("\n");
}

const std::string tableFolder = "./Tensor/tables/elliptic/";

// Test the norm
void testDotProdMode0() {
	const double b = 0.9;
	IntTable1DData tabData(b);
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  tab1D.reset(new IntegrationTable1DPtn(tableFolder + "bList.csv", tableFolder + "k1x2Range.csv", tableFolder + "fun1DVal.bin",
                            tableFolder + "pattern1D.txt"));
  //IntegrationTable1DPtn tab1D("./Tensor/tables/bList.csv", "./Tensor/tables/k1x2Range.csv", "./Tensor/tables/fun1DVal.bin",
  //													"./Tensor/tables/pattern1D.txt");
	tabData.setIntTable(tab1D);

 	//EllipticFactor ef(0, -1, 2, 1.0);
	//BasicFunc rf(SIN, R, 2, 1.0);
	//BasicFunc tf(COS, T, 2, 1.0);
	//LOG(INFO) << EllipticBasis2D::computeRTInt(ef, rf, tf, tabData);

	EllipticBasis2D basis1(2, 2, 0, tabData);
	LOG(INFO) << basis1.dotProd(basis1, tabData);

  for (int i = 0; i < normTestWn.size(); i++) {
    EllipticBasis2D basis1(normTestWn[i][0], normTestWn[i][1], 0, tabData);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val1[i]) < 1e-4) << val1[i] << " " << basis1.dotProd(basis1, tabData);
  }

  for (int i = 0; i < normTestWn.size(); i++) {
    EllipticBasis2D basis1(normTestWn[i][0], normTestWn[i][1], 1, tabData);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val1[i]) < 1e-4) << val1[i] << " " << basis1.dotProd(basis1, tabData);
  }

  for (int i = 0; i < normTestWn.size(); i++) {
    EllipticBasis2D basis1(normTestWn[i][0], normTestWn[i][1], 2, tabData);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val2[i]) < 1e-4) << val2[i] << " " << basis1.dotProd(basis1, tabData);
  }

  for (int i = 0; i < normTestWn.size(); i++) {
    EllipticBasis2D basis1(normTestWn[i][0], normTestWn[i][1], 3, tabData);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val3[i]) < 1e-4) << val3[i] << " " << basis1.dotProd(basis1, tabData);
  }

  for (int i = 0; i < normTestWn.size(); i++) {
    EllipticBasis2D basis1(normTestWn[i][0], 0, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis1, tabData) - val4[i]) < 1e-4) << val4[i] << " " << basis1.dotProd(basis1, tabData);
  }

  // 0x1
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 0, tabData);
    EllipticBasis2D basis2(AR[i][2],AR[i][3], 1, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12) << val4[i] << " " << basis1.dotProd(basis2, tabData);
  }
  // 0x2
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 0, tabData);
    EllipticBasis2D basis2(AR[i][0],AR[i][1], 2, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - val5[i]) < 1e-4) << val5[i] << " " << basis1.dotProd(basis2, tabData);
  }
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 0, tabData);
    EllipticBasis2D basis2(AR[i][2],AR[i][3], 2, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }
  // 0x3
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 0, tabData);
    EllipticBasis2D basis2(AR[i][0],AR[i][1], 3, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }
   // 0x4
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 0, tabData);
    EllipticBasis2D basis2(AR[i][0],0, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }

  // 1x2
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 1, tabData);
    EllipticBasis2D basis2(AR[i][0],AR[i][1], 2, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }

  // 1x3
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 1, tabData);
    EllipticBasis2D basis2(AR[i][0],AR[i][1], 3, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - val6[i]) < 1e-4);
  }

  // 1x4
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 1, tabData);
    EllipticBasis2D basis2(AR[i][0],0, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }

  // 2x3
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 2, tabData);
    EllipticBasis2D basis2(AR[i][0],AR[i][1], 3, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 2, tabData);
    EllipticBasis2D basis2(AR[i][0],0, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }
  // 3x4
  for (int i = 0; i < AR.size(); i++) {
    EllipticBasis2D basis1(AR[i][0],AR[i][1], 3, tabData);
    EllipticBasis2D basis2(AR[i][0],0, 4, tabData);
    CHECK(fabs(basis1.dotProd(basis2, tabData) - 0) < 1e-12);
  }
  
}

void collectInnerPattern() {
  std::unordered_set<uint64_t> set;
  EllipticBasis2D::enumeratePattern(set);
  std::string fname = tableFolder + "pattern1D.txt";
  EllipticBasis2D::exportNumericalPattern1D(set, fname);
}

void testTensor() {
  std::vector<EllipticBasis2D> basis;
  const double b = 0.9;
  IntTable1DData tabData(b);
  std::shared_ptr<IntegrationTable1DPtn> tab1D;
  tab1D.reset(new IntegrationTable1DPtn(tableFolder + "bList.csv", tableFolder + "k1x2Range.csv", tableFolder+"fun1DVal.bin",
                            tableFolder + "pattern1D.txt"));
  tabData.setIntTable(tab1D);
  std::shared_ptr<TensorTable2D> tab2D;
  tab2D.reset(new TensorTable2D(tableFolder + "TensorListWn.csv",  b, tableFolder + "blistTableName.txt", tableFolder + "patternTensor.txt", true));
  tabData.set2DTable(tab2D);

  bool boundaryCnd_ = true;

  int offsetOdd = !boundaryCnd_ ? 1 : 0;\
  int offset = boundaryCnd_ ? 1 : 0;\
  const double thresh = 0.2;\
  int angK_ = 3;
  int radK_ = 3;

  /*Phi^2, Phi^0*/\
  for (int i2 = 1; i2 < angK_; i2++) {\
\
    if (i2 == 1) {\
      /*phi^2*/\
      for (int i1 = 0; i1 < radK_; i1++) {\
        basis.push_back(EllipticBasis2D(i1*2 + offset, 2, 2, tabData));\
      }\
    }\
    /* phi^0*/\
    for (int i1 = 1; i1 < radK_; i1++) {\
      basis.push_back(EllipticBasis2D(i1*2 - offsetOdd, i2*2, 0, tabData));\
    }\
  }\
\
  /*Phi^3, Phi^1*/\
  for (int i2 = 1; i2 < angK_; i2++) {\
    if (i2 == 1) {\
      /* phi^3*/\
      for (int i1 = 0; i1 < radK_; i1++) {\
        basis.push_back(EllipticBasis2D(i1*2 + offset, 2, 3, tabData));\
      }\
    }\
\
    /*phi^1*/\
    for (int i1 = 1; i1 < radK_; i1++) {\
      basis.push_back(EllipticBasis2D(i1*2 - offsetOdd, i2*2, 1, tabData));\
    }\
  }\
\
  /* Phi^4*/\
  for (int i1 = 1; i1 < radK_; i1++) {\
    basis.push_back(EllipticBasis2D(i1*2, 0, 4, tabData));\
  }\
\


  std::unordered_map<uint64_t, double> set;
  for (int i = 0; i < basis.size(); i++) {
    for (int g = 0; g < basis.size(); g++) {
      for (int h = 0; h < basis.size(); h++) {
        double val = basis[i].computeTensorEntry(basis[g], basis[h], tabData);
      }
    }
  }
  
  for (const auto& hash : set) {
    TripleCoef result = EllipticBasis2D::hashToTriple(hash.first);
    result.print(); printf(" %f \n", hash.second);
  }
  EllipticBasis2D::exportNumericalPatternTensor(set);
  
  LOG(INFO) << set.size();
  LOG(INFO) << tabData.c;
}

void openTensorTable() {
  TensorTable2D table(tableFolder + "TensorListWn.csv",  0.9, tableFolder + "blistTableName.txt", tableFolder + "patternTensor.txt", true);
}

};  // namespace

int main(int argc, char ** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  
	testDotProdMode0();
  //testTensor();
	openTensorTable();
  //collectInnerPattern();

	return 0;
}