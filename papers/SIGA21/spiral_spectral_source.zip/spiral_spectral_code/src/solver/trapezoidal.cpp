#include <Eigen/Eigen>
#include <Eigen/Sparse>
#include <glog/logging.h>
#include <omp.h>
#include <vector>
#include <float.h>

#include "solver/integrator_2d.h"
#include "solver/trapezoidal.h"
#include "util/timer.h"

#include <Eigen/Eigenvalues>



namespace {
  void computeContractionRho(const std::vector<Adv_Tensor_Type>& Adv_tensor, const Eigen::VectorXd& coefficients_old,
                            const double dt,
                            Eigen::MatrixXd& C, Eigen::VectorXd& w ) {

    const int num_basis = coefficients_old.size();
    w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);
    #pragma omp parallel for
    for (int idx = 0; idx < num_basis; idx++) {
      for (int i = 0; i < num_basis; i++) {
        C.col(idx) += w[i] * Adv_tensor[i].col(idx); 
      }
    }
    w = w + dt*C*w + 0.25*dt*dt*C*(C*w);
  }
}  // namespace

void Trapezoidal::IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                        const Eigen::VectorXd & coefficients_old,
                        const double dt,
                        Eigen::VectorXd* coefficients_new,
                        double* condition_number_,
                        float* contraction_time,
                        float* solver_time) {

  Timer timer;
  const int num_basis = coefficients_old.size();
  // Allocate the contracted tensor. Generally, it should be dense.;
  Eigen::MatrixXd C = Eigen::MatrixXd::Zero(num_basis, num_basis);
  Eigen::VectorXd w = Eigen::VectorXd::Zero(num_basis);
  timer.Reset();

  computeContractionRho(Adv_tensor, coefficients_old, dt, C, w);
  *contraction_time = timer.ElapsedTimeInSeconds();
  
  // TODO, set a approproate preconditioner
  Eigen::DiagonalPreconditioner<Eigen::MatrixXd::RealScalar> precond(Eigen::MatrixXd::Identity(num_basis, num_basis));
  int maxIters = 200;
  double tol_error = 1e-10;
  timer.Reset();
  conjugate_gradient_NEA(C, dt, w, *coefficients_new, precond, maxIters, tol_error);
  *solver_time = timer.ElapsedTimeInSeconds();
  // LOG(INFO) << "maxIter: " << maxIters << " tolErr: " << tol_error
}

template<typename MAT>
void Trapezoidal::IntegrateForward(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                            const MAT& A,     // transfer matrix for non-orthogonal bases.
                            const Eigen::VectorXd& coefficients_old,
                            const double dt,
                            Eigen::VectorXd& coefficients_new,
                            double& condition_number_, 
                            float& contraction_time,
                            float& solver_time) {
  Timer timer;
  const int num_basis = coefficients_old.size();
  Eigen::VectorXd w = Eigen::VectorXd::Zero(num_basis);
  timer.Reset();
  w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);
  
  Eigen::VectorXd oldW = A.transpose()*coefficients_old;
  // Allocate the contracted tensor. Generally, it should be dense.;
  Eigen::MatrixXd C = Eigen::MatrixXd::Zero(oldW.size(), oldW.size());
  #pragma omp parallel for
  for (int idx = 0; idx < oldW.size(); idx++) {
    for (int i = 0; i < oldW.size(); i++) {
      C.col(idx) += oldW[i] * Adv_tensor[i].col(idx); 
    }
  }

  Eigen::VectorXd CWW = C*oldW;
  Eigen::VectorXd ACAX = A*CWW;

  Eigen::VectorXd CTCX = A*(C*(A.transpose()*ACAX));
  w = w + dt*ACAX + 0.25*dt*dt*CTCX;
  //w = w + dt*C*w + 0.25*dt*dt*C*(C*w);
  contraction_time = timer.ElapsedTimeInSeconds();
  
  // TODO, set a approproate preconditioner
  Eigen::DiagonalPreconditioner<Eigen::MatrixXd::RealScalar> precond(Eigen::MatrixXd::Identity(num_basis, num_basis));
  int maxIters = 200;
  double tol_error = 1e-12;
  timer.Reset();

  conjugate_gradient_NEA(C, A, dt, w, coefficients_new, maxIters, tol_error);

  solver_time = timer.ElapsedTimeInSeconds();
  LOG(INFO) << "maxIter: " << maxIters << " tolErr: " << tol_error;
}

template void Trapezoidal::IntegrateForward<Eigen::MatrixXd>(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                    const Eigen::MatrixXd& A,     // transfer matrix for non-orthogonal bases.
                    const Eigen::VectorXd&, const double dt, Eigen::VectorXd&, double&, float&, float&);

template void Trapezoidal::IntegrateForward<Adv_Tensor_Type>(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                    const Adv_Tensor_Type& A,     // transfer matrix for non-orthogonal bases.
                    const Eigen::VectorXd&, const double dt, Eigen::VectorXd&, double&, float&, float&);

template void Trapezoidal::IntegrateForward<Eigen::SparseMatrix<double, Eigen::RowMajor>>(const std::vector<Adv_Tensor_Type>& Adv_tensor,
                    const Eigen::SparseMatrix<double, Eigen::RowMajor>& A,     // transfer matrix for non-orthogonal bases.
                    const Eigen::VectorXd&, const double dt, Eigen::VectorXd&, double&, float&, float&);

template<typename MAT>
void Trapezoidal::IntegrateForwardSparse(const MAT& A,     // transfer matrix for non-orthogonal bases.
                      const Eigen::VectorXd & coefficients_old,
                      const double dt,
                      Adv_Tensor_Type& C, // should already contracted with the advection tensor
                      Eigen::VectorXd& coefficients_new) {

  //Timer timer;
  const int num_basis = coefficients_old.size();
  Eigen::VectorXd w = Eigen::VectorXd::Zero(num_basis);
  //timer.Reset();
  w = Eigen::VectorXd::Map(coefficients_old.data(), num_basis);  
  Eigen::VectorXd oldW = A.transpose()*coefficients_old;

  Eigen::VectorXd CWW = C*oldW;
  Eigen::VectorXd ACAX = A*CWW;

  Eigen::VectorXd CTCX = A*(C*(A.transpose()*ACAX));
  w = w + dt*ACAX + 0.25*dt*dt*CTCX;
  //w = w + dt*C*w + 0.25*dt*dt*C*(C*w);
  //contraction_time = timer.ElapsedTimeInSeconds();
  
  // TODO, set a approproate preconditioner
  Eigen::DiagonalPreconditioner<Eigen::MatrixXd::RealScalar> precond(Eigen::MatrixXd::Identity(num_basis, num_basis));
  int maxIters = 200;
  double tol_error = 1e-12;
  //timer.Reset();

  conjugate_gradient_NEA(C, A, dt, w, coefficients_new, maxIters, tol_error);

  //solver_time = timer.ElapsedTimeInSeconds();
  LOG(INFO) << "maxIter: " << maxIters << " tolErr: " << tol_error;  
}

template void Trapezoidal::IntegrateForwardSparse<Eigen::SparseMatrix<double, Eigen::RowMajor>>(
                    const Eigen::SparseMatrix<double, Eigen::RowMajor>& A,     // transfer matrix for non-orthogonal bases.
                    const Eigen::VectorXd&, const double dt,  Adv_Tensor_Type&, Eigen::VectorXd&);