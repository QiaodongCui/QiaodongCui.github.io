1) Install basic packages:
    apt-get update
    apt-get -y install software-properties-common build-essential cmake
    add-apt-repository universe
    apt-get update
    apt-get -y install libgoogle-glog-dev libeigen3-dev libblas-dev freeglut3-dev libglfw3-dev libglew-dev libassimp-dev libjpeg-dev
    apt-get -y install libboost-all-dev libgl1-mesa-dev libglu1-mesa-dev
    apt-get -y install libglm-dev

2) Install fftw:
    cd /packages
    tar -xvf fftw-3.3.8.tar.gz
    cd fftw-3.3.8
    ./configure --enable-shared --enable-sse2 -enable-openmp --enable-threads
    make CFLAGS=-fPIC
    make install
    cd ..

3) Build the code:
    mkdir build
    mkdir bin
    cd build
    cmake ..
    make -j8
    cd ..

4) Run the code:
    First, run perl precompute_sphere_3D.pl, this will precompute about 3000 3D cylinder basis functions, including the advection tensor.
    This should take a few minutes. After the precomputation is finished, there should be a precomputed tensor file inside ./Tensor/
    Then, run perl run_sphere3D.perl, this should run a plume example inside a cylinder with 3000 basis functions.

    Five other examples are also included, and here are the scence flag files:

    cylinder3D_precompte.flags, compute a cylinder tensor for cylinderPlume.flags example.
    cylinder3D_precompte1.flags computes a cylinder tensor for cylinderObsMore.flags example.
    tours3D_precompute.flags computes a torus tensor for torus3DPlasma.flags example.
    sphere3D_precompte.flags computes a sphere tensor for sphere3DStir.flags example.

    To run other examples, point the $script_file in precompute_sphere_3D.pl to appropriate flag files, then run the
    script, that should precompute the advection tensor for the corresponding flag file. After that, point $script_file
    in run_sphere3D.pl to a corresponding scene file.

    Two 2D examples are also included. To run the 2D example, first point the $script_file in precompute_2D.pl to an
    appropriate 2D flag files in the following list, and then run perl precompute_2D.pl to compute the advection tensor.
    After that, point $script_file in run_sphere2D.pl to a corresponding scene file, and then run perl run_sphere2D.perl 
    to run that scene.

    sphere2D_precompute.flags computes a sphere tensor for sphere2D_plantary.flags example.
    torus2D_precompute.flags computes a tours 2d tensor for torus2D.flags example.
    
    After the simulation is finished, there should be a preview that is saved in the ./preview folder.

5) Contact information:
    Qiaodong Cui (cqd123123@hotmail.com)
    Theodore Kim (theodore.kim@yale.edu)